@echo off
echo =============================================
echo  SIMFI - Verificador de Ollama
echo =============================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0verificar_ollama.ps1"
echo.
pause
