@echo off
echo =============================================
echo  SIMFI - Actualizacion a la version 1.2.1
echo =============================================
echo Antes de actualizar se creara un respaldo en
echo RESPALDO_VERSIONES. No apague la computadora.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0actualizar_simfi.ps1"
set "CODIGO=%ERRORLEVEL%"
echo.
if "%CODIGO%"=="0" (
    echo Actualizacion finalizada correctamente.
) else (
    echo La actualizacion no se pudo aplicar. Revise el mensaje anterior.
)
echo.
pause
exit /b %CODIGO%
