﻿# Verifica y orienta la sincronizacion de Ollama con SIMFI en esta PC.
$ErrorActionPreference = "Continue"

function Escribir-Seccion { param([string]$Texto) Write-Host ""; Write-Host ("== " + $Texto + " ==") -ForegroundColor Cyan }

Escribir-Seccion "1) Aplicacion Ollama"
$Proceso = Get-Process -Name "*ollama*" -ErrorAction SilentlyContinue
if ($Proceso) {
    Write-Host "Ollama esta en ejecucion (proceso: $($Proceso.Name -join ', '))." -ForegroundColor Green
} else {
    Write-Host "Ollama NO esta en ejecucion. Abra la aplicacion Ollama." -ForegroundColor Yellow
}
$OllamaCli = Get-Command ollama -ErrorAction SilentlyContinue
if ($OllamaCli) {
    Write-Host "Ollama CLI: $($OllamaCli.Source)"
} else {
    Write-Host "No se encontro 'ollama' en el PATH." -ForegroundColor Yellow
}

Escribir-Seccion "2) Servidor local en el puerto 11434"
$Tags = $null
$Modelos = @()
try {
    $Tags = Invoke-RestMethod -Uri "http://localhost:11434/api/tags" -TimeoutSec 5
    Write-Host "El servidor responde en http://localhost:11434" -ForegroundColor Green
    foreach ($Modelo in $Tags.models) {
        $Modelos += [string]$Modelo.name
    }
    Write-Host ("Modelos instalados: " + ($Modelos -join ", "))
} catch {
    Write-Host "El servidor NO responde en http://localhost:11434" -ForegroundColor Yellow
    Write-Host "Instale Ollama desde https://ollama.com/download y abra la aplicacion."
    Write-Host "Luego ejecute:  ollama pull qwen2.5:3b"
}

Escribir-Seccion "3) Configuracion de SIMFI"
$ConfigRuta = Join-Path $env:LOCALAPPDATA "SIMFI\config_ia.json"
if (Test-Path -LiteralPath $ConfigRuta) {
    $Config = Get-Content -LiteralPath $ConfigRuta -Raw -ErrorAction Stop | ConvertFrom-Json
    Write-Host "Servidor configurado: $($Config.servidor)"
    Write-Host "Modelo configurado: $($Config.modelo)"
    if ($null -ne $Tags) {
        if ($Modelos -contains $Config.modelo) {
            Write-Host "El modelo esta instalado. Sincronizacion COMPLETA." -ForegroundColor Green
        } else {
            Write-Host ("El modelo '" + $Config.modelo + "' no esta instalado. Ejecute:  ollama pull " + $Config.modelo) -ForegroundColor Yellow
        }
    }
} else {
    Write-Host "No se encontro config_ia.json en la instalacion SIMFI." -ForegroundColor Yellow
    Write-Host "Aplique primero la actualizacion 1.0.3 con ACTUALIZAR.bat."
}

Escribir-Seccion "4) Verificacion final en SIMFI"
Write-Host "Abra SIMFI, inicie sesion y en el menu SISTEMA abra 'Prueba IA'."
Write-Host "La pagina debe mostrar 'Disponible' y, al pulsar el boton, devolver una interpretacion."
Write-Host ""
