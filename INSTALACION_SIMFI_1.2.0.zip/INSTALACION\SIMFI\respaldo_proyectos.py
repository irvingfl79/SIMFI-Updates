"""Respaldos automáticos de proyectos SIMFI.

Antes de cada guardado se toma un respaldo del estado vigente del
archivo del proyecto en <data>/backups/proyectos/<proyecto>/, con
retención controlada: los últimos respaldos, un ancla por día y un
máximo histórico por proyecto. Desde Archivos > Respaldos se pueden
consultar, descargar y restaurar.
"""

import os
import re
import shutil
import datetime
import hashlib

_INTERVALO_MINIMO = 15
_RETENER_ULTIMOS = 6
_DIAS_ANCLA = 30
_MAXIMO_POR_PROYECTO = 40

PATRON_RESPALDO = re.compile(r"^respaldo_(\d{8}_\d{6})(?:_(\d+))?\.json$")


def carpeta_respaldos(data_dir: str) -> str:
    return os.path.join(data_dir, "backups", "proyectos")


def carpeta_proyecto(data_dir: str, ruta_proyecto: str) -> str:
    """Carpeta de respaldos propia de cada archivo de proyecto."""
    base = os.path.basename(ruta_proyecto or "sin_proyecto.json")
    slug = re.sub(r"[^A-Za-z0-9_.-]+", "_", base).strip("._") or "sin_proyecto"
    return os.path.join(carpeta_respaldos(data_dir), slug)


def _huella(ruta: str) -> str:
    try:
        with open(ruta, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except OSError:
        return ""


def _ultimo_respaldo(carpeta: str):
    archivos = [a for a in os.listdir(carpeta) if PATRON_RESPALDO.match(a)] \
        if os.path.isdir(carpeta) else []
    if not archivos:
        return None
    archivos.sort()
    return archivos[-1]


def respaldar(ruta_proyecto: str, data_dir: str, ahora=None) -> bool:
    """Copia el estado vigente del proyecto si corresponde respaldar.

    Se respalda cuando el contenido cambió respecto al último respaldo y
    pasó el intervalo mínimo (o nunca se había respaldado). Devuelve
    True si se creó un respaldo nuevo.
    """
    if not ruta_proyecto or not os.path.isfile(ruta_proyecto):
        return False
    ahora = ahora or datetime.datetime.now()
    carpeta = carpeta_proyecto(data_dir, ruta_proyecto)
    os.makedirs(carpeta, exist_ok=True)
    ultimo = _ultimo_respaldo(carpeta)
    if ultimo:
        ruta_ultimo = os.path.join(carpeta, ultimo)
        if _huella(ruta_proyecto) == _huella(ruta_ultimo):
            return False
        try:
            diferencia = (ahora - datetime.datetime.fromtimestamp(
                os.path.getmtime(ruta_ultimo))).total_seconds() / 60.0
            if diferencia < _INTERVALO_MINIMO:
                return False
        except OSError:
            pass
    marca = ahora.strftime("%Y%m%d_%H%M%S")
    nombre = f"respaldo_{marca}.json"
    contador = 2
    while os.path.exists(os.path.join(carpeta, nombre)):
        nombre = f"respaldo_{marca}_{contador}.json"
        contador += 1
    try:
        shutil.copy2(ruta_proyecto, os.path.join(carpeta, nombre))
    except OSError:
        return False
    _limpiar(carpeta, ahora)
    return True


def _limpiar(carpeta: str, ahora: datetime.datetime):
    """Retención: últimos respaldos + un ancla por día + techo duro.

    Los `pre_restauracion_*.json` no se tocan (su conservación es de 7
    días, gestionada al restaurar).
    """
    try:
        archivos = sorted(
            (a for a in os.listdir(carpeta) if PATRON_RESPALDO.match(a)),
            reverse=True)
    except OSError:
        return
    total = len(archivos)
    conservados = set(archivos[:_RETENER_ULTIMOS])
    dias_vistos = {PATRON_RESPALDO.match(n).group(1)[:8] for n in conservados}
    for nombre in archivos[_RETENER_ULTIMOS:]:
        dia = PATRON_RESPALDO.match(nombre).group(1)[:8]
        try:
            fecha_archivo = datetime.datetime.strptime(
                PATRON_RESPALDO.match(nombre).group(1), "%Y%m%d_%H%M%S")
        except ValueError:
            fecha_archivo = None
        vigente = True
        if fecha_archivo is not None:
            vigente = (ahora - fecha_archivo).days < _DIAS_ANCLA
        if dia not in dias_vistos and vigente:
            conservados.add(nombre)
            dias_vistos.add(dia)
    # Techo duro: si aún sobran, elimina del más antiguo al más reciente,
    # sin quitar los últimos _RETENER_ULTIMOS respaldos.
    excedente = len(conservados) - _MAXIMO_POR_PROYECTO
    if excedente > 0:
        protegidos = archivos[:_RETENER_ULTIMOS]
        for nombre in reversed(archivos):
            if excedente <= 0:
                break
            if nombre in conservados and nombre not in protegidos:
                conservados.discard(nombre)
                excedente -= 1
    for nombre in archivos:
        if nombre in conservados:
            continue
        try:
            os.remove(os.path.join(carpeta, nombre))
        except OSError:
            pass


def listar_respaldos(ruta_proyecto: str, data_dir: str) -> list:
    """Respaldos del proyecto, del más reciente al más antiguo."""
    carpeta = carpeta_proyecto(data_dir, ruta_proyecto)
    if not ruta_proyecto or not os.path.isdir(carpeta):
        return []
    salida = []
    for nombre in sorted(
            (a for a in os.listdir(carpeta) if PATRON_RESPALDO.match(a)),
            reverse=True):
        ruta = os.path.join(carpeta, nombre)
        try:
            stat = os.stat(ruta)
            fecha = datetime.datetime.fromtimestamp(stat.st_mtime)
        except OSError:
            continue
        salida.append({"archivo": nombre, "fecha": fecha,
                       "bytes": stat.st_size})
    return salida


def ruta_respaldo(ruta_proyecto: str, nombre: str, data_dir: str) -> str:
    """Ruta validada de un respaldo (o "" si no pertenece al proyecto)."""
    if not nombre or not PATRON_RESPALDO.match(nombre):
        return ""
    ruta = os.path.join(carpeta_proyecto(data_dir, ruta_proyecto), nombre)
    if os.path.isfile(ruta):
        return ruta
    return ""


def restaurar(ruta_proyecto: str, nombre: str, data_dir: str) -> bool:
    """Devuelve el proyecto a un respaldo, conservando el estado actual."""
    origen = ruta_respaldo(ruta_proyecto, nombre, data_dir)
    if not origen or not ruta_proyecto:
        return False
    carpeta = carpeta_proyecto(data_dir, ruta_proyecto)
    if os.path.isfile(ruta_proyecto):
        marca = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        contador = 1
        while os.path.exists(os.path.join(
                carpeta, f"pre_restauracion_{marca}_{contador:02d}.json")):
            contador += 1
        destino = os.path.join(carpeta, f"pre_restauracion_{marca}_{contador:02d}.json")
        try:
            shutil.copy2(ruta_proyecto, destino)
        except OSError:
            return False
    try:
        shutil.copy2(origen, ruta_proyecto)
    except OSError:
        return False
    # Conserva las copias previas a restaurar solo 7 días.
    limite = datetime.datetime.now() - datetime.timedelta(days=7)
    try:
        for a in os.listdir(carpeta):
            if not a.startswith("pre_restauracion_"):
                continue
            ruta_vieja = os.path.join(carpeta, a)
            if datetime.datetime.fromtimestamp(os.path.getmtime(ruta_vieja)) < limite:
                os.remove(ruta_vieja)
    except OSError:
        pass
    return True


def descargar_bytes(ruta_proyecto: str, nombre: str, data_dir: str):
    """Contenido del respaldo listo para descargar."""
    ruta = ruta_respaldo(ruta_proyecto, nombre, data_dir)
    if not ruta:
        return None
    with open(ruta, "rb") as f:
        return f.read()
