import math
import unittest
from unittest.mock import patch

from app import app
from guias_densidad import (calcular_diametro_cuadratico, calcular_grado_densidad,
                             calcular_idr, calcular_n_fcc, calcular_n_frontera,
                             cargar_modelos_densidad, construir_analisis_densidad,
                             clasificar_densidad, evaluar_condicion,
                            generar_datos_grafica, modelos_para_especie,
                            obtener_datos_rodal, seleccionar_modelo)
from modelos import ClaseDiametrica, PMFProyecto, Rodal, TablaInventarioRodal


class GuiasDensidadTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.modelos = cargar_modelos_densidad()
        cls.teocote = seleccionar_modelo("Pinus teocote", modelos=cls.modelos)
        cls.montezumae = seleccionar_modelo("Pinus montezumae", modelos=cls.modelos)
        cls.patula = seleccionar_modelo("Pinus patula", modelos=cls.modelos)
        cls.rudis = seleccionar_modelo("Pinus rudis", modelos=cls.modelos)

    def test_seleccion_estricta_por_especie(self):
        self.assertEqual(self.teocote["modelo_id"], "pinus_teocote_hidalgo")
        self.assertEqual(modelos_para_especie("Pinus teocote Schlecht. et Cham.", self.modelos),
                         [self.teocote])
        self.assertIsNone(seleccionar_modelo("Pinus pseudostrobus", modelos=self.modelos))
        self.assertEqual(self.montezumae["modelo_id"], "pinus_montezumae_hidalgo_2009")
        self.assertEqual(self.patula["modelo_id"], "pinus_patula_zacualtipan_hidalgo_2013")
        self.assertEqual(self.rudis["modelo_id"], "pinus_rudis_mixteca_oaxaca_2021")

    def test_linea_a_y_clasificacion_con_b_disponible(self):
        linea = self.teocote["fronteras"][0]["parametros"]
        self.assertAlmostEqual(linea["a"] * 25 ** linea["b"], 755.14, places=2)
        evaluacion = evaluar_condicion(620, 30.5, self.teocote)
        self.assertAlmostEqual(evaluacion["dq"], 25.03, places=2)
        self.assertIsNotNone(evaluacion["grado_densidad"])
        self.assertIsNotNone(evaluacion["clasificacion"])
        n_a = calcular_n_frontera(evaluacion["dq"], self.teocote, "A")
        self.assertAlmostEqual(evaluacion["grado_densidad"], 620 / n_a * 100, places=2)

    def test_linea_a_montezumae_contra_cuadro_publicado(self):
        esperados = {
            10: (4215.4, 33.11), 20: (2085.8, 65.53), 25: (1663.0, 81.63),
            30: (1382.0, 97.69), 40: (1032.0, 129.69),
            50: (822.8, 161.57), 80: (510.6, 256.68),
        }
        for dq, (n_esperada, g_esperada) in esperados.items():
            n = calcular_n_frontera(dq, self.montezumae, "A")
            g = n * math.pi * dq ** 2 / 40000.0
            self.assertAlmostEqual(n, n_esperada, delta=0.2)
            self.assertAlmostEqual(g, g_esperada, delta=0.02)

    def test_linea_b_fcc_contra_cuadro_publicado(self):
        esperados = {
            10: (1593.0, 12.51), 20: (556.9, 17.50), 25: (384.0, 18.85),
            30: (280.6, 19.84), 40: (168.6, 21.19), 80: (46.7, 23.49),
        }
        for dq, (n_esperada, g_esperada) in esperados.items():
            n = calcular_n_fcc(dq, self.montezumae)
            g = n * math.pi * dq ** 2 / 40000.0
            self.assertAlmostEqual(n, n_esperada, delta=0.2)
            self.assertAlmostEqual(g, g_esperada, delta=0.02)

    def test_dq_grado_y_clasificaciones_montezumae(self):
        dq = 25.0
        n_a = calcular_n_frontera(dq, self.montezumae, "A")
        n_b = calcular_n_fcc(dq, self.montezumae)

        def g_para(n):
            return n * math.pi * dq ** 2 / 40000.0

        self.assertEqual(clasificar_densidad(n_a * 1.1, g_para(n_a * 1.1), self.montezumae), "Excesiva")
        n_intermedia = (n_a + n_b) / 2
        self.assertEqual(clasificar_densidad(n_intermedia, g_para(n_intermedia), self.montezumae), "Suficiente")
        self.assertEqual(clasificar_densidad(n_b * 0.9, g_para(n_b * 0.9), self.montezumae), "Deficiente")
        evaluacion = evaluar_condicion(n_a * 0.8, g_para(n_a * 0.8), self.montezumae)
        self.assertAlmostEqual(evaluacion["dq"], dq)
        self.assertAlmostEqual(evaluacion["grado_densidad"], 80.0)

    def test_dominancia_por_area_basal_y_totales_del_rodal(self):
        pmf = PMFProyecto("Prueba")
        pmf.agregar_rodal(Rodal("R1", 10, sitios=1, area_sitio_m2=1000))
        teocote = TablaInventarioRodal("R1", "Pinus teocote", [ClaseDiametrica(30, 15, 10)])
        patula = TablaInventarioRodal("R1", "Pinus patula", [ClaseDiametrica(10, 12, 20)])
        pmf.agregar_tabla_inventario(teocote)
        pmf.agregar_tabla_inventario(patula)
        datos = obtener_datos_rodal(pmf, "R1")
        self.assertEqual(datos["especie_dominante"], "Pinus teocote")
        self.assertAlmostEqual(datos["n"], 300.0)
        self.assertGreater(datos["g"], 0)
        self.assertTrue(datos["es_mixto"])

    def test_permite_elegir_especie_no_dominante(self):
        pmf = PMFProyecto("Prueba")
        pmf.agregar_rodal(Rodal("R1", 10, sitios=1, area_sitio_m2=1000))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Pinus teocote", [ClaseDiametrica(40, 20, 10)]))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Pinus patula", [ClaseDiametrica(20, 15, 20)]))

        analisis = construir_analisis_densidad(
            pmf, "R1", modelos=self.modelos, especie="Pinus patula")

        self.assertEqual(analisis["datos_rodal"]["especie_dominante"], "Pinus teocote")
        self.assertEqual(analisis["datos_rodal"]["especie_seleccionada"], "Pinus patula")
        self.assertEqual(analisis["modelo"]["modelo_id"], self.patula["modelo_id"])
        self.assertAlmostEqual(analisis["condicion"]["n"], 200)
        self.assertLess(analisis["condicion"]["n"], analisis["datos_rodal"]["n_total"])

    def test_evalua_composicion_conjunta_con_guia_seleccionada(self):
        pmf = PMFProyecto("Prueba conjunta")
        pmf.agregar_rodal(Rodal("R1", 10, sitios=1, area_sitio_m2=1000))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Pinus teocote", [ClaseDiametrica(30, 15, 10)]))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Pinus patula", [ClaseDiametrica(10, 12, 20)]))

        analisis = construir_analisis_densidad(
            pmf, "R1", modelo_id=self.teocote["modelo_id"],
            modelos=self.modelos, especie="Pinus patula",
            especies_incluidas=["Pinus teocote", "Pinus patula"])

        self.assertEqual(analisis["modelo"]["modelo_id"], self.teocote["modelo_id"])
        self.assertEqual(analisis["especies_incluidas"], ["Pinus teocote", "Pinus patula"])
        self.assertAlmostEqual(analisis["condicion"]["n"], 300.0)
        self.assertGreater(analisis["condicion"]["g"], 0)

    def test_sin_guia_muestra_condicion_base_de_la_especie(self):
        pmf = PMFProyecto("Prueba")
        pmf.agregar_rodal(Rodal("R1", 10, sitios=1, area_sitio_m2=1000))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Pinus pseudostrobus", [ClaseDiametrica(30, 18, 15)]))

        analisis = construir_analisis_densidad(
            pmf, "R1", modelos=self.modelos, especie="Pinus pseudostrobus")

        self.assertIsNone(analisis["modelo"])
        self.assertIsNone(analisis["error"])
        self.assertIn("No existe una guía", analisis["mensaje"])
        self.assertAlmostEqual(analisis["condicion"]["n"], 150)
        self.assertGreater(analisis["condicion"]["g"], 0)
        self.assertGreater(analisis["condicion"]["dq"], 0)

    def test_pagina_lista_especies_y_muestra_resultado_sin_guia(self):
        pmf = PMFProyecto("Prueba")
        pmf.agregar_rodal(Rodal("R1", 10, sitios=1, area_sitio_m2=1000))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Pinus teocote", [ClaseDiametrica(40, 20, 10)]))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Pinus pseudostrobus", [ClaseDiametrica(30, 18, 15)]))
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=pmf):
            respuesta = cliente.get("/aclareos/guias-densidad", query_string={
                "rid": "R1", "especie": "Pinus pseudostrobus"})
        html = respuesta.get_data(as_text=True)
        self.assertEqual(respuesta.status_code, 200)
        self.assertIn('value="Pinus teocote"', html)
        self.assertIn('value="Pinus pseudostrobus" selected', html)
        self.assertIn("Condición observada sin guía registrada", html)
        self.assertIn("No se emite clasificación ni recomendación", html)

    def test_dashboard_del_rodal_muestra_distribucion_y_especies_incluidas(self):
        pmf = PMFProyecto("Dashboard")
        pmf.agregar_rodal(Rodal("R1", 10, sitios=1, area_sitio_m2=1000))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Pinus teocote", [ClaseDiametrica(30, 15, 10)]))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Pinus patula", [ClaseDiametrica(10, 12, 20)]))
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()
        respuesta = cliente.get("/aclareos/guias-densidad?rid=R1")
        html = respuesta.get_data(as_text=True)
        self.assertEqual(respuesta.status_code, 200)
        self.assertIn("Dashboard del rodal", html)
        self.assertIn("Distribución diamétrica del rodal", html)
        self.assertIn('name="incluida"', html)

    def test_grafica_genera_isolineas_y_fronteras_disponibles(self):
        condicion = evaluar_condicion(620, 30.5, self.teocote)
        grafica = generar_datos_grafica(self.teocote, condicion)
        self.assertEqual([linea["dq"] for linea in grafica["isolineas"]],
                         [10, 15, 20, 25, 30, 35, 40, 45, 50])
        self.assertTrue(grafica["curvas"][0]["puntos"])
        self.assertTrue(grafica["curvas"][1]["puntos"])
        self.assertFalse(grafica["curvas"][2]["puntos"])
        self.assertGreaterEqual(grafica["max_n"], condicion["n"])
        self.assertGreaterEqual(grafica["max_g"], condicion["g"])

    def test_grafica_montezumae_respeta_vistas_y_porcentajes(self):
        condicion = evaluar_condicion(742, 31.84, self.montezumae)
        grafica = generar_datos_grafica(self.montezumae, condicion)
        self.assertEqual(grafica["vista"]["id"], "10-40")
        self.assertEqual([c["nombre"] for c in grafica["curvas"]], ["A", "B"])
        self.assertEqual([c["porcentaje"] for c in grafica["curvas_grado"]],
                         [90, 80, 70, 60, 50, 40, 30, 20])
        completa = generar_datos_grafica(self.montezumae, condicion, vista_id="completa")
        self.assertEqual(completa["vista"]["min_cm"], 10)
        self.assertEqual(completa["vista"]["max_cm"], 80)

    def test_dq_y_frontera_maxima_patula(self):
        self.assertAlmostEqual(calcular_diametro_cuadratico(720, 32.6), 24.01, places=2)
        n_maximo = calcular_n_frontera(20, self.patula, "MAX_100")
        self.assertAlmostEqual(n_maximo, 1662, delta=1.0)

    def test_idr_patula_en_diametro_referencia(self):
        self.assertAlmostEqual(calcular_idr(900, 20, self.patula), 900.0)

    def test_zonas_porcentuales_patula_sin_truncar(self):
        n_maximo = calcular_n_frontera(20, self.patula, "MAX_100")

        def evaluar_porcentaje(porcentaje):
            n = n_maximo * porcentaje / 100.0
            g = n * math.pi * 20 ** 2 / 40000.0
            return evaluar_condicion(n, g, self.patula)

        casos = {
            80: "Auto-aclareo / mortalidad inminente",
            55: "Auto-aclareo / mortalidad inminente",
            50: "Crecimiento constante",
            30: "Crecimiento constante",
            25: "Zona de transición hacia crecimiento libre",
            15: "Crecimiento libre / baja densidad",
            105: "Densidad superior a la frontera estimada",
        }
        for porcentaje, zona in casos.items():
            resultado = evaluar_porcentaje(porcentaje)
            self.assertAlmostEqual(resultado["grado_densidad"], porcentaje)
            self.assertEqual(resultado["clasificacion"], zona)
        self.assertGreater(evaluar_porcentaje(105)["grado_densidad"], 100)

    def test_grafica_patula_usa_fronteras_porcentuales(self):
        n = 720
        g = 32.6
        condicion = evaluar_condicion(n, g, self.patula)
        grafica = generar_datos_grafica(self.patula, condicion)
        self.assertEqual([curva["etiqueta"] for curva in grafica["curvas"]], ["100 %"])
        self.assertEqual([curva["porcentaje"] for curva in grafica["curvas_grado"]],
                         [90, 80, 70, 60, 55, 50, 40, 30, 20])
        self.assertEqual([curva["porcentaje"] for curva in grafica["curvas_grado"] if curva["fundamental"]],
                         [55, 30, 20])

    def test_linea_a_rudis_contra_cuadro_publicado(self):
        esperados = {
            10: (4179, 32.82), 15: (2225, 39.32), 20: (1423, 44.70),
            25: (1006, 49.37), 30: (758, 53.55), 35: (596, 57.35),
            40: (484, 60.87), 45: (403, 64.15), 50: (342, 67.23),
        }
        for dq, (n_esperada, g_esperada) in esperados.items():
            n = calcular_n_frontera(dq, self.rudis, "A")
            g = n * math.pi * dq ** 2 / 40000.0
            self.assertAlmostEqual(n, n_esperada, delta=0.6)
            self.assertAlmostEqual(g, g_esperada, delta=0.02)

    def test_linea_b_rudis_contra_cuadro_publicado(self):
        esperados = {
            10: (1632, 12.82), 15: (1058, 18.69), 20: (740, 23.26),
            25: (547, 26.86), 30: (421, 29.74), 35: (334, 32.10),
            40: (271, 34.05), 45: (224, 35.70), 50: (189, 37.10),
        }
        for dq, (n_esperada, g_esperada) in esperados.items():
            n = calcular_n_fcc(dq, self.rudis)
            g = n * math.pi * dq ** 2 / 40000.0
            self.assertAlmostEqual(n, n_esperada, delta=0.6)
            self.assertAlmostEqual(g, g_esperada, delta=0.02)

    def test_idr_y_clasificacion_rudis(self):
        self.assertAlmostEqual(calcular_idr(800, 25, self.rudis), 800.0)
        n_a = calcular_n_frontera(25, self.rudis, "A")
        n_b = calcular_n_fcc(25, self.rudis)

        def evaluar_n(n):
            g = n * math.pi * 25 ** 2 / 40000.0
            return evaluar_condicion(n, g, self.rudis)

        self.assertEqual(evaluar_n(n_a * 1.05)["clasificacion"], "Excesiva")
        intermedia = evaluar_n((n_a + n_b) / 2)
        self.assertEqual(intermedia["clasificacion"], "Suficiente")
        self.assertEqual(evaluar_n(n_b * 0.9)["clasificacion"], "Deficiente")
        self.assertEqual(evaluar_n(800)["condicion_competencia"], "Competencia establecida")

    def test_ejemplo_y_simulacion_publicados_rudis(self):
        actual = evaluar_condicion(2045, 38.27, self.rudis)
        residual = evaluar_condicion(1500, 30.01, self.rudis)
        self.assertAlmostEqual(actual["dq"], 15.5, delta=0.1)
        self.assertAlmostEqual(actual["grado_densidad"], 96, delta=0.2)
        self.assertEqual(actual["clasificacion"], "Suficiente")
        self.assertAlmostEqual(residual["grado_densidad"], 75, delta=1.0)
        self.assertAlmostEqual(actual["n"] - residual["n"], 545)
        self.assertAlmostEqual(actual["g"] - residual["g"], 8.26)

    def test_grafica_rudis_incluye_30_a_110_por_ciento(self):
        condicion = evaluar_condicion(2045, 38.27, self.rudis)
        grafica = generar_datos_grafica(self.rudis, condicion)
        self.assertEqual([curva["nombre"] for curva in grafica["curvas"]], ["A", "B"])
        self.assertEqual([curva["porcentaje"] for curva in grafica["curvas_grado"]],
                         [110, 90, 80, 70, 60, 50, 40, 30])


if __name__ == "__main__":
    unittest.main()
