import io
import datetime
import os
import re
from collections import defaultdict
from xml.sax.saxutils import escape

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.section import WD_ORIENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                TableStyle, PageBreak)
from reportlab.graphics.shapes import Drawing, String
from reportlab.graphics.charts.barcharts import VerticalBarChart
from PIL import Image, ImageDraw
from cuadros_word import GRIS_ENCABEZADO, GRIS_TOTAL, crear_cuadro
from modelos import _orden_especie_volumen
from reporte_densidad import (_configurar_pie, _margenes_celda, _sombrear, _tabla,
                              VERDE, VERDE_CLARO, VERDE_OSCURO, FIRMA_EXPORTACION)


FIRMA = FIRMA_EXPORTACION
TOLERANCIA_BALANCE_EXISTENCIAS = 0.001


def _aplicar_vmerge(tabla, inicio, fin, columnas):
    """Aplica fusión vertical restart/continue en un rango de filas."""
    if inicio is None or fin <= inicio:
        return
    for columna in columnas:
        superior = tabla.rows[inicio]._tr.tc_lst[columna]
        for indice in range(inicio + 1, fin + 1):
            inferior = tabla.rows[indice]._tr.tc_lst[columna]
            for hijo in list(inferior):
                if hijo.tag != qn("w:tcPr"):
                    inferior.remove(hijo)
            inferior.append(OxmlElement("w:p"))
            for celda, valor in ((superior, "restart"), (inferior, "continue")):
                propiedades = celda.get_or_add_tcPr()
                nodo = propiedades.find(qn("w:vMerge"))
                if nodo is None:
                    nodo = OxmlElement("w:vMerge")
                    propiedades.append(nodo)
                nodo.set(qn("w:val"), valor)
        celda_superior = tabla.rows[inicio].cells[columna]
        celda_superior.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        for parrafo in celda_superior.paragraphs:
            parrafo.alignment = WD_ALIGN_PARAGRAPH.CENTER


def _fusionar_rodal_superficie_word(tabla, data, fila_inicial=2, columnas=(0, 1)):
    """Une Rodal y Superficie en las filas de detalle de cada rodal."""
    fila_tabla = fila_inicial
    inicio = None
    rodal_actual = None

    def cerrar(fin):
        nonlocal inicio, rodal_actual
        _aplicar_vmerge(tabla, inicio, fin, columnas)
        inicio = None
        rodal_actual = None

    for fila in data.get("filas", []):
        if fila.get("_type") == "subtotal":
            cerrar(fila_tabla - 1)
            inicio = None
            rodal_actual = None
            fila_tabla += 1
            continue
        if inicio is None:
            inicio = fila_tabla
            rodal_actual = fila.get("rodal")
        elif fila.get("rodal") != rodal_actual:
            cerrar(fila_tabla - 1)
            inicio = fila_tabla
            rodal_actual = fila.get("rodal")
        fila_tabla += 1
    cerrar(fila_tabla - 1)


def _fusionar_area_corta_word(tabla, datos_intervenciones, fila_inicial=2):
    """Une el área de corta en las filas de detalle de cada anualidad."""
    fila_tabla = fila_inicial
    inicio = None
    for indice, dato in enumerate(datos_intervenciones):
        anualidad = dato["intervencion"].anualidad
        if inicio is None:
            inicio = fila_tabla
        fila_tabla += len(dato["filas"]) or 1
        es_ultimo = indice == len(datos_intervenciones) - 1
        cambia = (not es_ultimo and
                  datos_intervenciones[indice + 1]["intervencion"].anualidad != anualidad)
        if es_ultimo or cambia:
            _aplicar_vmerge(tabla, inicio, fila_tabla - 1, (0,))
            fila_tabla += 1
            inicio = None


def _fusionar_area_resumen_word(tabla, resumen_plan, fila_inicial=2):
    """Une el área de corta en las filas de detalle de cada grupo del resumen."""
    fila_tabla = fila_inicial
    for grupo in resumen_plan:
        detalle = len(grupo["filas"])
        if detalle > 1:
            _aplicar_vmerge(tabla, fila_tabla, fila_tabla + detalle - 1, (0,))
        fila_tabla += detalle + 1


def _sombrear_subtotales_word(tabla, data, fila_inicial=2):
    """Aplica el gris del encabezado a todas las celdas del subtotal."""
    fila_tabla = fila_inicial
    for fila in data.get("filas", []):
        if fila.get("_type") == "subtotal":
            for celda in tabla.rows[fila_tabla].cells:
                _sombrear(celda, GRIS_ENCABEZADO)
        fila_tabla += 1


def _dato_registrado(valor):
    return valor if valor not in (None, "") else "No registrado en el proyecto"


def _tratamientos_por_rodal(pmf, rodales):
    tratamientos = {rodal: [] for rodal in rodales}
    for intervencion in pmf.plan_cortas.intervenciones:
        if intervencion.rodal_id in tratamientos and intervencion.tratamiento:
            tratamientos[intervencion.rodal_id].append(intervencion.tratamiento)
    return {rodal: list(dict.fromkeys(valores)) for rodal, valores in tratamientos.items()}


def construir_datos_reporte_existencias(pmf, usuario="", version="", tolerancia=TOLERANCIA_BALANCE_EXISTENCIAS):
    """Agrupa resultados oficiales y valida su consistencia sin recalcular existencias."""
    data = pmf.cuadro_existencias()
    filas = [dict(fila) for fila in data.get("filas", []) if not fila.get("_type")]
    rodales = {}
    for fila in filas:
        rodal = rodales.setdefault(fila["rodal"], {"id": fila["rodal"], "superficie": float(fila["superficie"] or 0), "filas": []})
        rodal["filas"].append(fila)
    tratamientos = _tratamientos_por_rodal(pmf, rodales)
    validaciones = []

    def validar(etiqueta, esperado, obtenido, fila=None):
        diferencia = abs(esperado - obtenido)
        estado = "verificado" if diferencia == 0 else "redondeo" if diferencia <= tolerancia else "revisar"
        validaciones.append({"elemento": etiqueta, "rodal": (fila or {}).get("rodal", "Total"),
                             "especie": (fila or {}).get("especie", "Total"), "esperado": esperado,
                             "obtenido": obtenido, "diferencia": diferencia, "estado": estado})

    especies = {}
    for fila in filas:
        vol = float(fila.get("vol_umm", 0) or 0)
        pos = float(fila.get("pos_umm", 0) or 0)
        residual = float(fila.get("res_vol", 0) or 0)
        sup = float(fila.get("superficie", 0) or 0)
        validar("Balance volumétrico", vol, pos + residual, fila)
        validar("Existencias por superficie", vol, float(fila.get("vol_ha", 0) or 0) * sup, fila)
        validar("Posibilidad por superficie", pos, float(fila.get("pos_ha", 0) or 0) * sup, fila)
        especie = especies.setdefault(fila["especie"], {"especie": fila["especie"], "existencias": 0.0,
                                  "posibilidad": 0.0, "residual": 0.0, "ab_superficie": 0.0,
                                  "res_ab_superficie": 0.0})
        especie["existencias"] += vol
        especie["posibilidad"] += pos
        especie["residual"] += residual
        especie["ab_superficie"] += float(fila.get("ab", 0) or 0) * sup
        especie["res_ab_superficie"] += float(fila.get("res_ab", 0) or 0) * sup

    superficie = sum(rodal["superficie"] for rodal in rodales.values())
    total_existencias = sum(fila["existencias"] for fila in especies.values())
    total_posibilidad = sum(fila["posibilidad"] for fila in especies.values())
    total_residual = sum(fila["residual"] for fila in especies.values())
    total_ab_superficie = sum(fila["ab_superficie"] for fila in especies.values())
    total_res_ab_superficie = sum(fila["res_ab_superficie"] for fila in especies.values())
    validar("Balance volumétrico", total_existencias, total_posibilidad + total_residual)
    validar("Existencias por superficie", total_existencias,
            (total_existencias / superficie if superficie else 0.0) * superficie)
    validar("Posibilidad por superficie", total_posibilidad,
            (total_posibilidad / superficie if superficie else 0.0) * superficie)
    total_ab = total_ab_superficie / superficie if superficie else 0.0
    total_res_ab = total_res_ab_superficie / superficie if superficie else 0.0
    for especie in especies.values():
        especie["participacion_vol"] = especie["existencias"] * 100 / total_existencias if total_existencias else 0.0
        especie["ab"] = especie.pop("ab_superficie") / superficie if superficie else 0.0
        especie["res_ab"] = especie.pop("res_ab_superficie") / superficie if superficie else 0.0
        especie["participacion_ab"] = especie["ab"] * 100 / total_ab if total_ab else 0.0
        especie["intensidad"] = especie["posibilidad"] * 100 / especie["existencias"] if especie["existencias"] else 0.0
        especie["residual_pct"] = especie["residual"] * 100 / especie["existencias"] if especie["existencias"] else 0.0
        participacion = especie["participacion_vol"]
        especie["condicion"] = ("Dominante" if participacion >= 50 else "Codominante" if participacion >= 20
                                else "Secundaria" if participacion >= 5 else "Ocasional")
        ecuacion = pmf.obtener_ecuacion(especie["especie"])
        especie["ecuacion"] = (f"a0={ecuacion.a0}; a1={ecuacion.a1}; a2={ecuacion.a2}; b0={ecuacion.b0}"
                               if ecuacion else "No registrada en el proyecto")
    especies = sorted(
        especies.values(),
        key=lambda fila: _orden_especie_volumen(
            fila["especie"], fila["existencias"] / superficie if superficie else 0.0))
    for rodal in rodales.values():
        rodal["filas"].sort(key=lambda fila: float(fila.get("vol_umm", 0) or 0), reverse=True)
        rodal["tratamientos"] = tratamientos.get(rodal["id"], [])
        rodal["tratamiento"] = "; ".join(rodal["tratamientos"]) or "No registrado en el proyecto"
        rodal["existencias"] = sum(float(fila.get("vol_umm", 0) or 0) for fila in rodal["filas"])
        rodal["posibilidad"] = sum(float(fila.get("pos_umm", 0) or 0) for fila in rodal["filas"])
        rodal["residual"] = sum(float(fila.get("res_vol", 0) or 0) for fila in rodal["filas"])
        rodal["ab"] = sum(float(fila.get("ab", 0) or 0) for fila in rodal["filas"])
        rodal["res_ab"] = sum(float(fila.get("res_ab", 0) or 0) for fila in rodal["filas"])
        rodal["existencias_ha"] = rodal["existencias"] / rodal["superficie"] if rodal["superficie"] else 0.0
        rodal["posibilidad_ha"] = rodal["posibilidad"] / rodal["superficie"] if rodal["superficie"] else 0.0
        rodal["residual_ha"] = rodal["residual"] / rodal["superficie"] if rodal["superficie"] else 0.0
        rodal["intensidad"] = rodal["posibilidad"] * 100 / rodal["existencias"] if rodal["existencias"] else 0.0
        rodal["dominante"] = rodal["filas"][0]["especie"] if rodal["filas"] else "No registrado en el proyecto"
    estados = {fila["estado"] for fila in validaciones}
    balance = "revisar" if "revisar" in estados else "redondeo" if "redondeo" in estados else "verificado"
    tratamientos_unicos = sorted({tratamiento for valores in tratamientos.values() for tratamiento in valores})
    return {"cuadro": data, "filas": filas, "rodales": list(rodales.values()), "especies": especies,
            "validaciones": validaciones, "tolerancia": tolerancia, "balance": balance,
            "fecha": datetime.datetime.now(), "version": version or "No registrado en el proyecto",
            "usuario": _dato_registrado(usuario), "generales": {
                "predio": _dato_registrado(pmf.predio or pmf.nombre), "propietario": _dato_registrado(pmf.propietario),
                "municipio": _dato_registrado(pmf.municipio), "estado": _dato_registrado(pmf.estado),
                "superficie": superficie, "num_umm": len(rodales), "num_especies": len(especies),
                "tratamiento": "; ".join(tratamientos_unicos) or "No registrado en el proyecto",
                "existencias": total_existencias, "existencias_ha": total_existencias / superficie if superficie else 0.0,
                "ab": total_ab, "posibilidad": total_posibilidad,
                "posibilidad_ha": total_posibilidad / superficie if superficie else 0.0,
                "residual": total_residual, "residual_ha": total_residual / superficie if superficie else 0.0,
                "res_ab": total_res_ab, "intensidad": total_posibilidad * 100 / total_existencias if total_existencias else 0.0,
                "intensidad_residual": total_residual * 100 / total_existencias if total_existencias else 0.0,
                "modificado": _dato_registrado(getattr(pmf, "modificado", "")),
                "historial": list(getattr(pmf, "reportes_generados", [])),
            }}


VERSION_PLANTILLA_EXISTENCIAS = "2.0"


def interpretar_reporte_existencias(reporte):
    """Construye texto técnico determinista y conserva los valores de cada regla."""
    generales = reporte["generales"]
    fecha = reporte["fecha"].isoformat()
    reglas = []

    def agregar(codigo, valores, texto):
        reglas.append({"codigo_regla": codigo, "valores_utilizados": valores,
                       "texto_generado": texto, "fecha": fecha,
                       "version_plantilla": VERSION_PLANTILLA_EXISTENCIAS})

    agregar("EXI-01-INTEGRACION", {"umm": generales["num_umm"], "superficie": generales["superficie"],
                                    "existencias": generales["existencias"], "existencias_ha": generales["existencias_ha"],
                                    "ab": generales["ab"]},
            f"El análisis comprende {generales['num_umm']} UMM con una superficie total de {generales['superficie']:,.3f} ha. "
            f"Las existencias reales estimadas ascienden a {generales['existencias']:,.3f} m3 VTA, equivalentes a "
            f"{generales['existencias_ha']:,.3f} m3 VTA/ha. El área basal inicial promedio corresponde a {generales['ab']:,.3f} m2/ha.")
    dominante_vol = max(reporte["especies"], key=lambda fila: fila["existencias"], default=None)
    dominante_ab = max(reporte["especies"], key=lambda fila: fila["ab"], default=None)
    if dominante_vol:
        if dominante_ab and dominante_ab["especie"] != dominante_vol["especie"]:
            texto = (f"La composición volumétrica está dominada por {dominante_vol['especie']}, con "
                     f"{dominante_vol['participacion_vol']:.2f} % de las existencias. El mayor componente del área basal es "
                     f"{dominante_ab['especie']}, con {dominante_ab['participacion_ab']:.2f} %, por lo que la dominancia volumétrica "
                     "y estructural no recae en la misma especie.")
        else:
            texto = (f"La composición volumétrica se encuentra dominada por {dominante_vol['especie']}, especie que concentra "
                     f"{dominante_vol['participacion_vol']:.2f} % de las existencias totales. De manera complementaria, representa "
                     f"{dominante_vol['participacion_ab']:.2f} % del área basal registrada, por lo que constituye el principal componente estructural del área analizada.")
        agregar("EXI-02-COMPOSICION", {"especie_volumen": dominante_vol["especie"],
                                        "participacion_vol": dominante_vol["participacion_vol"],
                                        "especie_ab": dominante_ab["especie"] if dominante_ab else "",
                                        "participacion_ab": dominante_ab["participacion_ab"] if dominante_ab else 0}, texto)
    agregar("EXI-03-POSIBILIDAD", {"posibilidad": generales["posibilidad"], "intensidad": generales["intensidad"],
                                    "residual": generales["residual"], "residual_pct": generales["intensidad_residual"]},
            f"La posibilidad calculada es de {generales['posibilidad']:,.3f} m3 VTA, equivalente a una intensidad global de aprovechamiento de "
            f"{generales['intensidad']:.2f} %. El volumen residual estimado es de {generales['residual']:,.3f} m3 VTA, "
            f"equivalente a {generales['intensidad_residual']:.2f} % de las existencias iniciales.")
    if len(reporte["especies"]) > 1:
        comparables = sorted(reporte["especies"], key=lambda fila: fila["intensidad"], reverse=True)
        mayor, menor = comparables[0], comparables[-1]
        agregar("EXI-04-COMPARACION-ESPECIES", {"especie_mayor": mayor["especie"], "intensidad_mayor": mayor["intensidad"],
                                                  "residual_mayor": mayor["residual_pct"], "especie_menor": menor["especie"],
                                                  "intensidad_menor": menor["intensidad"], "residual_menor": menor["residual_pct"]},
                f"La intensidad de aprovechamiento no es homogénea entre especies. {mayor['especie']} presenta una intensidad de "
                f"{mayor['intensidad']:.2f} % y conserva {mayor['residual_pct']:.2f} % de sus existencias; mientras que "
                f"{menor['especie']} presenta una intensidad de {menor['intensidad']:.2f} % y conserva {menor['residual_pct']:.2f} %.")
    agregar("EXI-05-RESIDUAL", {"ab_residual": generales["res_ab"]},
            f"Después de aplicar las intensidades registradas, el área basal residual promedio se estima en {generales['res_ab']:,.3f} m2/ha. "
            "Este valor representa la condición estructural residual prevista para la UMM y deberá interpretarse conjuntamente con el tratamiento silvícola, la composición específica y los objetivos establecidos para el rodal.")
    for rodal in reporte["rodales"]:
        if rodal["tratamientos"]:
            texto = (f"Para la UMM {rodal['id']} se registró el tratamiento silvícola: {rodal['tratamiento']}. La intensidad y condición residual "
                     "deben analizarse en ese contexto; este reporte verifica la consistencia numérica, mientras que la congruencia silvícola corresponde a la prescripción específica de la UMM.")
        else:
            texto = (f"No se identificó un tratamiento silvícola registrado para la UMM {rodal['id']}. Por ello, el reporte presenta la condición "
                     "volumétrica y estructural resultante, sin emitir una conclusión automática sobre la congruencia silvícola de la intensidad aplicada.")
        agregar("EXI-06-TRATAMIENTO", {"rodal": rodal["id"], "tratamiento": rodal["tratamiento"]}, texto)
    if reporte["balance"] == "revisar":
        texto = "Se identificaron diferencias de consistencia en el balance volumétrico. El reporte se genera como borrador y se recomienda revisar las intensidades o valores de origen antes de emitir una versión definitiva."
    elif reporte["balance"] == "redondeo":
        texto = "La posibilidad y el volumen residual fueron verificados. Las diferencias observadas corresponden al redondeo de los valores presentados."
    else:
        texto = "La posibilidad y el volumen residual fueron verificados respecto a las existencias iniciales. El balance volumétrico fue satisfactorio dentro de la tolerancia de redondeo configurada en SIMFI."
    agregar("EXI-07-BALANCE", {"estado": reporte["balance"], "tolerancia": reporte["tolerancia"]}, texto)
    return reglas


def datos_graficas_existencias(reporte):
    """Series normalizadas que alimentan por igual Word, PDF y la vista previa."""
    especies = reporte["especies"]
    graficas = [{"id": "volumen-especie", "titulo": "Existencias, posibilidad y residual por especie",
                 "unidad": "Volumen (m3 VTA)", "tipo": "barras_agrupadas",
                 "series": [("Existencias", "#1A5632", [(f["especie"], f["existencias"]) for f in especies]),
                            ("Posibilidad", "#6C9B4E", [(f["especie"], f["posibilidad"]) for f in especies]),
                            ("Residual", "#B9D8B5", [(f["especie"], f["residual"]) for f in especies])]},
                {"id": "composicion-especie", "titulo": "Composición volumétrica por especie",
                 "unidad": "Participación (%)", "tipo": "barras_horizontales",
                 "series": [("Participación", "#1A5632", [(f["especie"], f["participacion_vol"]) for f in especies])]},
                {"id": "intensidad-especie", "titulo": "Intensidad y residual por especie",
                 "unidad": "Porcentaje (%)", "tipo": "barras_apiladas_100",
                 "series": [("Posibilidad", "#6C9B4E", [(f["especie"], f["intensidad"]) for f in especies]),
                            ("Residual", "#B9D8B5", [(f["especie"], f["residual_pct"]) for f in especies])]}]
    if len(reporte["rodales"]) > 1:
        rodales = reporte["rodales"]
        graficas.append({"id": "comparativo-umm", "titulo": "Comparativo de existencias por UMM",
                         "unidad": "Indicadores por UMM", "tipo": "barras_horizontales" if len(rodales) > 6 else "barras_agrupadas",
                         "series": [("Existencias (m3 VTA/ha)", "#1A5632", [(f["id"], f["existencias_ha"]) for f in rodales]),
                                    ("Posibilidad (m3 VTA/ha)", "#6C9B4E", [(f["id"], f["posibilidad_ha"]) for f in rodales]),
                                    ("AB inicial (m2/ha)", "#7B9DBB", [(f["id"], f["ab"]) for f in rodales]),
                                    ("AB residual (m2/ha)", "#B9D8B5", [(f["id"], f["res_ab"]) for f in rodales]),
                                    ("Intensidad (%)", "#D4A843", [(f["id"], f["intensidad"]) for f in rodales])]})
    return graficas


def analisis_detallado_existencias(reporte, reglas):
    generales = reporte["generales"]
    dominante_vol = max(reporte["especies"], key=lambda fila: fila["existencias"], default=None)
    dominante_ab = max(reporte["especies"], key=lambda fila: fila["ab"], default=None)
    estado_balance = ("Balance volumétrico: verificado" if reporte["balance"] == "verificado"
                      else "Balance volumétrico: revisar")
    return {
        "titulo": "Interpretación técnica de existencias volumétricas",
        "indicadores": [("Superficie analizada", f"{generales['superficie']:,.3f} ha"),
                        ("Existencias reales estimadas", f"{generales['existencias']:,.3f} m3 VTA"),
                        ("Existencias medias", f"{generales['existencias_ha']:,.3f} m3 VTA/ha"),
                        ("Área basal inicial media", f"{generales['ab']:,.3f} m2/ha"),
                        ("Posibilidad total", f"{generales['posibilidad']:,.3f} m3 VTA"),
                        ("Volumen residual total", f"{generales['residual']:,.3f} m3 VTA"),
                        ("Intensidad global", f"{generales['intensidad']:.2f} %"),
                        ("Intensidad residual global", f"{generales['intensidad_residual']:.2f} %"),
                        ("Especie dominante por volumen", f"{dominante_vol['especie']} ({dominante_vol['participacion_vol']:.2f} %)" if dominante_vol else "No registrado en el proyecto"),
                        ("Especie dominante por área basal", f"{dominante_ab['especie']} ({dominante_ab['participacion_ab']:.2f} %)" if dominante_ab else "No registrado en el proyecto"),
                        ("Balance volumétrico", estado_balance)],
        "parrafos": [regla["texto_generado"] for regla in reglas],
        "hallazgos": [], "observaciones": [],
        "cautela": "La clasificación de condición por especie es descriptiva de SIMFI y no constituye una categoría normativa.",
        "grafica": [(fila["especie"], fila["existencias"]) for fila in reporte["especies"]],
        "titulo_grafica": "Existencias por especie (m3 VTA)",
        "leyenda_grafica": "Figura 1. Existencias reales por especie; fuente: motor oficial de existencias SIMFI.",
        "tabla": [(fila["especie"], f"{fila['existencias']:,.3f}", f"{fila['participacion_vol']:.2f}",
                   f"{fila['posibilidad']:,.3f}", f"{fila['intensidad']:.2f}", f"{fila['residual']:,.3f}",
                   f"{fila['residual_pct']:.2f}", f"{fila['ab']:,.3f}", f"{fila['res_ab']:,.3f}")
                  for fila in reporte["especies"]],
        "encabezados": ("Especie", "Existencias m3 VTA", "Participación %", "Posibilidad m3 VTA", "Intensidad %", "Residual m3 VTA", "Residual %", "AB inicial m2/ha", "AB residual m2/ha"),
        "nombres_cientificos": True,
        "estado_datos": "Calculado" if reporte["filas"] else "Dato insuficiente",
        "limitaciones": ["No registrado en el proyecto" for especie in reporte["especies"] if especie["ecuacion"] == "No registrada en el proyecto"],
        "fuentes": ["Inventario y concentrado de existencias vigentes del proyecto.",
                    "Intensidades por especie y UMM registradas en el proyecto."] +
                   [f"Ecuación {fila['especie']}: {fila['ecuacion']}" for fila in reporte["especies"]],
        "trazabilidad": (f"Fecha: {reporte['fecha'].isoformat(timespec='seconds')} | Usuario: {reporte['usuario']} | "
                           f"Versión del motor: {reporte['version']} | Modificado: {generales['modificado']}"),
    }


def enriquecer_analisis(analisis, contexto, modulo):
    """Aplica la trazabilidad común sin cambiar los cálculos propios del módulo."""
    analisis = dict(analisis)
    if not contexto:
        analisis["estado_datos"] = "Sin contexto de validación"
        analisis["limitaciones"] = []
        analisis["fuentes"] = []
        analisis["trazabilidad"] = "No disponible"
        return analisis
    estado = "Calculado" if contexto.get("filas") else "Dato insuficiente"
    if modulo == "incrementos" and not [f for f in contexto.get("incrementos", {}).get("filas", []) if not f.get("_type")]:
        estado = "Dato insuficiente"
    analisis["estado_datos"] = estado
    analisis["limitaciones"] = list(contexto.get("alertas", []))
    analisis["fuentes"] = list(contexto.get("fuentes", {}).values())
    analisis["trazabilidad"] = (f"Reglas {contexto.get('version_reglas', 'no registrada')} | "
                                 f"Confianza global: {contexto.get('confianza', 'no determinada')}")
    return analisis


def _mayor(filas, clave, etiqueta):
    filas = [fila for fila in filas if not fila.get("_type")]
    return max(filas, key=lambda fila: float(fila.get(clave, 0) or 0), default=None)


def analisis_existencias(data, resumen, contexto=None):
    filas = [fila for fila in data.get("filas", []) if not fila.get("_type")]
    total = float(data.get("total_vol_umm", 0) or 0)
    posibilidad = float(data.get("total_pos_umm", 0) or 0)
    residual = total - posibilidad
    intensidad_global = posibilidad * 100 / total if total else 0.0
    especies = list(resumen.get("filas", []))
    dominante = _mayor(especies, "existencias", "especie")
    por_genero = defaultdict(float)
    por_rodal = defaultdict(lambda: {"volumen": 0.0, "posibilidad": 0.0})
    for fila in especies:
        genero = str(fila.get("especie", "")).split(maxsplit=1)[0]
        if genero:
            por_genero[genero] += float(fila.get("existencias", 0) or 0)
    for fila in filas:
        rodal = por_rodal[fila["rodal"]]
        rodal["volumen"] += float(fila.get("vol_umm", 0) or 0)
        rodal["posibilidad"] += float(fila.get("pos_umm", 0) or 0)
    for rodal in por_rodal.values():
        rodal["residual"] = rodal["volumen"] - rodal["posibilidad"]

    intensidades = []
    sin_posibilidad = []
    for fila in especies:
        existencia = float(fila.get("existencias", 0) or 0)
        pos = float(fila.get("posibilidad", 0) or 0)
        intensidad = pos * 100 / existencia if existencia else None
        fila["intensidad"] = intensidad
        if intensidad is not None and intensidad > 0:
            intensidades.append((intensidad, fila["especie"]))
        elif existencia > 0 and pos == 0:
            sin_posibilidad.append(fila["especie"])
    intensidades.sort(reverse=True)
    mayor_residual = _mayor(especies, "residuales", "especie")
    umm_volumen = max(por_rodal.items(), key=lambda item: item[1]["volumen"], default=None)
    umm_posibilidad = max(por_rodal.items(), key=lambda item: item[1]["posibilidad"], default=None)
    umm_residual = max(por_rodal.items(), key=lambda item: item[1]["residual"], default=None)

    parrafos = []
    if total:
        primero = f"Las existencias reales del predio suman **{total:,.3f} m³ VTA**."
        if dominante:
            participacion = float(dominante["existencias"]) * 100 / total
            primero += (f" ***{dominante['especie']}*** concentra **{participacion:.2f} %** del volumen, "
                       "por lo que es la especie dominante en existencias.")
        if por_genero:
            genero, volumen_genero = max(por_genero.items(), key=lambda item: item[1])
            if sum(1 for especie in especies if str(especie.get("especie", "")).startswith(genero + " ")) > 1:
                primero += f" El género *{genero}* reúne **{volumen_genero * 100 / total:.2f} %** del volumen total."
        parrafos.append(primero)
    if total and posibilidad:
        segundo = (f"La posibilidad calculada es **{posibilidad:,.3f} m³ VTA**, equivalente a una intensidad global de "
                   f"**{intensidad_global:.2f} %**; el volumen residual es **{residual:,.3f} m³ VTA** "
                   f"(**{100 - intensidad_global:.2f} %** de las existencias iniciales).")
        if intensidades:
            especies_intensas = ", ".join(f"*{especie}*" for _, especie in intensidades[:3])
            segundo += f" Las mayores intensidades por especie corresponden a {especies_intensas}."
        if mayor_residual:
            segundo += f" ***{mayor_residual['especie']}*** conserva el mayor volumen residual."
        parrafos.append(segundo)
    elif total:
        parrafos.append("No se registra posibilidad de corta para las especies con existencias calculadas.")

    observaciones = []
    if sin_posibilidad:
        lista = ", ".join(f"*{especie}*" for especie in sin_posibilidad[:3])
        resto = len(sin_posibilidad) - 3
        observaciones.append(f"Sin posibilidad registrada: {lista}{f' y {resto} especie(s) adicional(es)' if resto > 0 else ''}.")
    comparacion_umm = []
    if len(por_rodal) > 1:
        if umm_volumen:
            comparacion_umm.append(f"La UMM {umm_volumen[0]} concentra el mayor volumen de existencias ({umm_volumen[1]['volumen']:,.3f} m³ VTA).")
        if umm_posibilidad and umm_posibilidad[1]["posibilidad"] > 0 and umm_posibilidad[0] != umm_volumen[0]:
            comparacion_umm.append(f"La UMM {umm_posibilidad[0]} registra la mayor posibilidad ({umm_posibilidad[1]['posibilidad']:,.3f} m³ VTA).")
        if umm_residual and umm_residual[0] not in {umm_volumen[0], umm_posibilidad[0]}:
            comparacion_umm.append(f"La UMM {umm_residual[0]} conserva el mayor volumen residual ({umm_residual[1]['residual']:,.3f} m³ VTA).")

    analisis = enriquecer_analisis({
        "titulo": "Interpretación técnica de existencias",
        "indicadores": [("Existencias reales", f"{total:,.3f} m³ VTA"), ("Posibilidad", f"{posibilidad:,.3f} m³ VTA"), ("Volumen residual", f"{residual:,.3f} m³ VTA"), ("Intensidad global", f"{intensidad_global:.2f} %")],
        "hallazgos": comparacion_umm,
        "parrafos": parrafos,
        "observaciones": observaciones,
        "cautela": "La posibilidad y el residual se derivan de las intensidades registradas por especie y UMM.",
        "grafica": [(fila["especie"], float(fila["existencias"])) for fila in resumen.get("filas", [])],
        "titulo_grafica": "Existencias reales por especie (m³ VTA)",
        "leyenda_grafica": "Figura 1. Existencias reales por especie en el predio evaluado.",
        "nombres_cientificos": True,
        "tabla": [(fila["especie"], f"{fila['existencias']:,.3f}", f"{fila['posibilidad']:,.3f}", f"{fila['residuales']:,.3f}", f"{fila['intensidad']:.2f}" if fila["intensidad"] is not None else "—") for fila in especies],
        "encabezados": ("Especie", "Existencias (m³ VTA)", "Posibilidad (m³ VTA)", "Residual (m³ VTA)", "Intensidad (%)"),
    }, contexto, "existencias")
    analisis["fuentes"] = ["Datos: inventario registrado en el proyecto SIMFI.", "Ecuaciones: ecuaciones de volumen asignadas al proyecto."]
    analisis["trazabilidad"] = "Resultados derivados del inventario y de las intensidades registradas en el proyecto."
    return analisis


def analisis_incrementos(data, contexto=None):
    filas = [fila for fila in data.get("filas", []) if not fila.get("_type")]
    mayor_ica = _mayor(filas, "ica", "especie")
    con_edad = sum(1 for fila in filas if fila.get("edad"))
    hallazgos = [
        f"El resumen integra {len(filas)} combinación(es) rodal-especie con inventario.",
        f"Se estimó edad para {con_edad} combinación(es) a partir de las ecuaciones disponibles.",
    ]
    if mayor_ica:
        hallazgos.append(f"El ICA más alto corresponde a {mayor_ica['especie']} en la UMM {mayor_ica['rodal']}: {mayor_ica['ica']:,.4f} m3/ha/año.")
    return enriquecer_analisis({
        "titulo": "Interpretación técnica de incrementos",
        "indicadores": [("ICA agregado", f"{data.get('total_ica', 0):,.4f} m3/ha/año"), ("IMA agregado", f"{data.get('total_ima', 0):,.4f} m3/ha/año"), ("Área basal agregada", f"{data.get('total_ab', 0):,.3f} m2/ha")],
        "hallazgos": hallazgos,
        "cautela": "ICA, IMA, tiempo de paso y edad son indicadores por especie y rodal. Los totales son descriptivos y no sustituyen un promedio ponderado ni la validación de las ecuaciones de crecimiento.",
        "grafica": [(f"{fila['rodal']} - {fila['especie']}", float(fila["ica"])) for fila in filas],
        "tabla": [(fila["rodal"], fila["especie"], f"{fila['ica']:,.4f}", f"{fila['ima']:,.4f}", f"{fila['edad']:,.1f}" if fila.get("edad") else "No estimada") for fila in filas],
        "encabezados": ("UMM", "Especie", "ICA m3/ha/año", "IMA m3/ha/año", "Edad"),
    }, contexto, "incrementos")


def analisis_carbono(data, captura, oxigeno, contexto=None, tab="contenido"):
    """Interpretación técnica de UN solo apartado (Contenido/Captura/Oxígeno).

    ``tab`` determina cuál de los tres conjuntos de datos (``data``, ``captura``
    u ``oxigeno``) se usa para indicadores, hallazgos, gráfica y tabla de
    apoyo; los otros dos se reciben pero no se mezclan en el resultado.
    """
    if tab == "captura":
        filas = [fila for fila in captura.get("filas", []) if not fila.get("_type")]
        dominante = _mayor(filas, "captura_co2", "especie")
        hallazgos = [f"La captura anual estimada es {captura.get('total_captura_co2', 0):,.3f} t CO2e/año "
                    f"({captura.get('total_captura_c', 0):,.3f} t C/año)."]
        if dominante:
            hallazgos.append(f"{dominante['especie']} en la UMM {dominante['rodal']} aporta la mayor captura "
                            f"individual: {dominante['captura_co2']:,.3f} t CO2e/año.")
        return enriquecer_analisis({
            "titulo": "Interpretación técnica de captura de CO₂",
            "indicadores": [("Captura de carbono", f"{captura.get('total_captura_c', 0):,.3f} t/año"),
                            ("Captura de CO2e", f"{captura.get('total_captura_co2', 0):,.3f} t CO2e/año")],
            "hallazgos": hallazgos,
            "cautela": "La captura anual depende del incremento corriente (ICA), la fracción de carbono y el factor de raíces disponibles para cada especie. No constituye una certificación de carbono sin el protocolo de medición y verificación correspondiente.",
            "grafica": [(f"{fila['rodal']} - {fila['especie']}", float(fila["captura_co2"])) for fila in filas],
            "tabla": [(fila["rodal"], fila["especie"], f"{fila['captura_c']:,.3f}", f"{fila['captura_co2']:,.3f}") for fila in filas],
            "encabezados": ("UMM", "Especie", "Captura C t/año", "Captura CO2e t/año"),
        }, contexto, "carbono")
    if tab == "oxigeno":
        filas = [fila for fila in oxigeno.get("filas", []) if not fila.get("_type")]
        dominante = _mayor(filas, "oxigeno", "especie")
        hallazgos = [f"La producción de oxígeno estimada es {oxigeno.get('total_oxigeno', 0):,.3f} t O2/año."]
        if dominante:
            hallazgos.append(f"{dominante['especie']} en la UMM {dominante['rodal']} aporta la mayor producción "
                            f"individual de oxígeno: {dominante['oxigeno']:,.3f} t O2/año.")
        return enriquecer_analisis({
            "titulo": "Interpretación técnica de producción de oxígeno",
            "indicadores": [("Captura de carbono", f"{oxigeno.get('total_captura_c', 0):,.3f} t/año"),
                            ("Producción de oxígeno", f"{oxigeno.get('total_oxigeno', 0):,.3f} t O2/año")],
            "hallazgos": hallazgos,
            "cautela": "La producción de oxígeno se deriva de la captura de carbono mediante el factor estequiométrico O2/C. No sustituye una medición directa de intercambio gaseoso.",
            "grafica": [(f"{fila['rodal']} - {fila['especie']}", float(fila["oxigeno"])) for fila in filas],
            "tabla": [(fila["rodal"], fila["especie"], f"{fila['captura_c']:,.3f}", f"{fila['oxigeno']:,.3f}") for fila in filas],
            "encabezados": ("UMM", "Especie", "Captura C t/año", "O2 t/año"),
        }, contexto, "carbono")
    filas = [fila for fila in data.get("filas", []) if not fila.get("_type")]
    dominante = _mayor(filas, "co2_total", "especie")
    hallazgos = [f"El contenido estimado equivale a {data.get('total_co2', 0):,.3f} t de CO2e "
                f"({data.get('total_carbono', 0):,.3f} t de carbono)."]
    if dominante:
        hallazgos.append(f"{dominante['especie']} en la UMM {dominante['rodal']} aporta la mayor estimación individual de CO2e: {dominante['co2_total']:,.3f} t.")
    return enriquecer_analisis({
        "titulo": "Interpretación técnica de contenido de carbono",
        "indicadores": [("Carbono", f"{data.get('total_carbono', 0):,.3f} t"), ("CO2 equivalente", f"{data.get('total_co2', 0):,.3f} t")],
        "hallazgos": hallazgos,
        "cautela": "Las estimaciones dependen de volumen, factores de biomasa y fracción de carbono disponibles. No constituyen una certificación de carbono sin el protocolo de medición y verificación correspondiente.",
        "grafica": [(f"{fila['rodal']} - {fila['especie']}", float(fila["co2_total"])) for fila in filas],
        "tabla": [(fila["rodal"], fila["especie"], f"{fila['carbono_total']:,.3f}", f"{fila['co2_total']:,.3f}") for fila in filas],
        "encabezados": ("UMM", "Especie", "Carbono t", "CO2e t"),
    }, contexto, "carbono")


def _drawing(datos, titulo="Distribución de los indicadores principales"):
    drawing = Drawing(460, 220)
    valores = [valor for _, valor in datos] or [0]
    chart = VerticalBarChart()
    chart.x, chart.y, chart.width, chart.height = 45, 35, 380, 150
    chart.data = [valores]
    chart.valueAxis.valueMin = 0
    chart.valueAxis.valueMax = max(valores) * 1.15 or 1
    chart.valueAxis.valueStep = max(chart.valueAxis.valueMax / 5, 1)
    chart.categoryAxis.categoryNames = [texto for texto, _ in datos] or ["Sin datos"]
    chart.categoryAxis.labels.angle = 30
    chart.categoryAxis.labels.fontSize = 6
    chart.bars[0].fillColor = colors.HexColor("#1A5632")
    drawing.add(chart)
    drawing.add(String(230, 202, titulo, textAnchor="middle", fontSize=10, fillColor=colors.HexColor("#0F3D23")))
    return drawing


def _grafica_word_png(datos, titulo="Distribución de los indicadores principales"):
    # Se recorta primero a las 10 barras que realmente se dibujan; si la altura
    # se calculara con la lista completa, el lienzo quedaría con un gran
    # espacio vacío debajo de las barras.
    datos = list(datos or [])[:10]
    ancho, alto, margen = 1000, max(360, 80 + len(datos) * 36), 55
    imagen = Image.new("RGB", (ancho, alto), "white")
    dibujo = ImageDraw.Draw(imagen)
    valores = [valor for _, valor in datos] or [0]
    maximo = max(valores) or 1
    dibujo.text((margen, 12), titulo, fill="#0F3D23")
    izquierda, derecha, superior = 290, ancho - 35, 52
    dibujo.line((izquierda, superior, izquierda, alto - margen), fill="#333333", width=2)
    for indice, (etiqueta, valor) in enumerate(datos):
        y1 = superior + indice * 34
        y2 = y1 + 20
        x2 = izquierda + (derecha - izquierda) * valor / maximo
        dibujo.rectangle((izquierda, y1, x2, y2), fill="#1A5632")
        dibujo.text((10, y1 + 3), etiqueta, fill="#222222")
        dibujo.text((min(x2 + 6, derecha - 60), y1 + 3), f"{valor:,.2f}", fill="#0F3D23")
    salida = io.BytesIO()
    imagen.save(salida, format="PNG")
    salida.seek(0)
    return salida


def _docx_tabla(documento, encabezados, filas):
    tabla = documento.add_table(rows=1, cols=len(encabezados))
    tabla.style = "Table Grid"
    for celda, texto in zip(tabla.rows[0].cells, encabezados):
        celda.text = texto
        for run in celda.paragraphs[0].runs:
            run.font.bold = True
            run.font.color.rgb = RGBColor(255, 255, 255)
    for fila in filas:
        for celda, texto in zip(tabla.add_row().cells, fila):
            celda.text = str(texto)
    return tabla


def _agregar_texto_rico(parrafo, texto):
    """Convierte marcas internas **negrita**, *cursiva* y ***ambas*** a runs DOCX."""
    partes = re.split(r"(\*\*\*.+?\*\*\*|\*\*.+?\*\*|\*.+?\*)", texto)
    for parte in partes:
        if not parte:
            continue
        run = parrafo.add_run(parte)
        if parte.startswith("***") and parte.endswith("***"):
            run.text, run.bold, run.italic = parte[3:-3], True, True
        elif parte.startswith("**") and parte.endswith("**"):
            run.text, run.bold = parte[2:-2], True
        elif parte.startswith("*") and parte.endswith("*"):
            run.text, run.italic = parte[1:-1], True
    return parrafo


def _texto_pdf_rico(texto):
    texto = escape(texto)
    texto = re.sub(r"\*\*\*(.+?)\*\*\*", r"<b><i>\1</i></b>", texto)
    texto = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", texto)
    return re.sub(r"\*(.+?)\*", r"<i>\1</i>", texto)


def _configurar_documento_institucional(documento, pmf, analisis):
    """Aplica la misma identidad documental usada por Guías de Densidad."""
    seccion = documento.sections[0]
    seccion.top_margin, seccion.bottom_margin = Cm(1.5), Cm(1.7)
    seccion.left_margin, seccion.right_margin = Cm(1.8), Cm(1.8)
    estilos = documento.styles
    estilos["Normal"].font.name, estilos["Normal"].font.size = "Aptos", Pt(9.5)
    estilos["Normal"].paragraph_format.space_after = Pt(5)
    for nombre, tamano in (("Title", 17), ("Heading 1", 13), ("Heading 2", 10.5)):
        estilos[nombre].font.name, estilos[nombre].font.size = "Aptos Display", Pt(tamano)
        estilos[nombre].font.color.rgb = RGBColor(15, 61, 35)
    fecha = datetime.datetime.now()
    documento.core_properties.title = analisis["titulo"]
    documento.core_properties.author = "Dr.PIFL"
    documento.core_properties.keywords = (f"reglas={analisis.get('trazabilidad', 'no registrada')}; "
                                         f"fecha={fecha.isoformat(timespec='seconds')}")

    cabecera = documento.add_table(1, 2)
    cabecera.alignment = WD_TABLE_ALIGNMENT.CENTER
    cabecera.autofit = False
    logo, titulo = cabecera.rows[0].cells
    logo.width, titulo.width = Cm(5.2), Cm(12.2)
    ruta_logo = os.path.join(os.path.dirname(__file__), "img", "SIMFI GDE.png")
    if os.path.isfile(ruta_logo):
        logo.paragraphs[0].add_run().add_picture(ruta_logo, width=Cm(4.8))
    p = titulo.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = p.add_run("SIMFI")
    run.bold, run.font.size, run.font.color.rgb = True, Pt(22), RGBColor(15, 61, 35)
    p.add_run("\nSistema para el Manejo Forestal Mejorado por Dr.PIFL").font.size = Pt(9)
    p.add_run("\n" + analisis["titulo"].upper()).bold = True
    for celda in cabecera.rows[0].cells:
        _margenes_celda(celda, 0, 0, 40, 0)
    documento.add_paragraph()

    info = documento.add_table(3, 4)
    info.alignment = WD_TABLE_ALIGNMENT.CENTER
    ubicacion = " / ".join(valor for valor in (pmf.estado, pmf.municipio) if valor) or "No registrado"
    valores = [
        ("Predio", pmf.predio or pmf.nombre or "No registrado", "Estado", analisis.get("estado_datos", "No disponible")),
        ("Propietario", pmf.propietario or "No registrado", "Fecha", fecha.strftime("%d/%m/%Y")),
        ("Estado / municipio", ubicacion, "Trazabilidad", analisis.get("trazabilidad", "No disponible")),
    ]
    for fila, valores_fila in zip(info.rows, valores):
        for indice, valor in enumerate(valores_fila):
            celda = fila.cells[indice]
            celda.text = str(valor)
            _margenes_celda(celda)
            if indice % 2 == 0:
                _sombrear(celda, VERDE_CLARO)
                celda.paragraphs[0].runs[0].bold = True
            for run in celda.paragraphs[0].runs:
                run.font.size = Pt(8)
    _configurar_pie(documento, analisis["titulo"])
    documento.add_paragraph()


def generar_word(pmf, analisis):
    documento = Document()
    _configurar_documento_institucional(documento, pmf, analisis)
    documento.add_heading("1. Indicadores principales", level=1)
    _tabla(documento, ("Indicador", "Resultado"), analisis["indicadores"], (8, 8),
           titulo="Indicadores principales", numero_tabla=1)
    documento.add_heading("2. Interpretación técnica", level=1)
    for texto in analisis.get("parrafos", analisis["hallazgos"]):
        _agregar_texto_rico(documento.add_paragraph(), texto)
    for texto in analisis.get("hallazgos", []):
        documento.add_paragraph(texto)
    for texto in analisis.get("observaciones", []):
        documento.add_paragraph(texto, style="List Bullet")
    documento.add_heading("3. Gráfica de apoyo", level=1)
    grafica = documento.add_paragraph()
    grafica.alignment = WD_ALIGN_PARAGRAPH.CENTER
    grafica.add_run().add_picture(_grafica_word_png(analisis["grafica"], analisis.get("titulo_grafica", "Distribución de los indicadores principales")), width=Cm(16.5))
    documento.add_paragraph(analisis.get("leyenda_grafica", "Figura 1. Distribución de los indicadores principales calculados."))
    documento.add_heading("4. Cuadro de apoyo", level=1)
    tabla_apoyo = _tabla(documento, analisis["encabezados"], analisis["tabla"],
                         titulo="Cuadro de apoyo", numero_tabla=2)
    if analisis.get("nombres_cientificos"):
        for fila in tabla_apoyo.rows[1:]:
            for run in fila.cells[0].paragraphs[0].runs:
                run.italic = True
    documento.add_heading("5. Consideración técnica", level=1)
    documento.add_paragraph(analisis["cautela"])
    documento.add_heading("6. Calidad, trazabilidad y fuentes", level=1)
    documento.add_paragraph(f"Estado de datos: {analisis.get('estado_datos', 'No disponible')}. {analisis.get('trazabilidad', '')}")
    for limitacion in analisis.get("limitaciones", []):
        documento.add_paragraph(limitacion, style="List Bullet")
    for fuente in analisis.get("fuentes", []):
        documento.add_paragraph(f"Fuente: {fuente}", style="List Bullet")
    salida = io.BytesIO()
    documento.save(salida)
    salida.seek(0)
    return salida


def generar_word_cuadro_existencias(pmf, data, analisis, resumen=None):
    """Genera el cuadro completo de existencias seguido de su interpretación."""
    documento = Document()
    seccion = documento.sections[0]
    seccion.orientation = WD_ORIENT.LANDSCAPE
    seccion.page_width, seccion.page_height = seccion.page_height, seccion.page_width
    _configurar_documento_institucional(documento, pmf, analisis)

    documento.add_heading("1. Cuadro de existencias por UMM", level=1)
    encabezados = [
        [{"texto": "Unidad Minima de Manejo (UMM)", "span": 2},
         {"texto": "Especie", "span": 1},
         {"texto": "Existencias Reales", "span": 3},
         {"texto": "Intensidad de Corta (%) Por UMM", "span": 1},
         {"texto": "Residuales", "span": 1},
         {"texto": "Posibilidad", "span": 3}],
        ["No.", "Superficie (ha)", "Especie", "m³ VTA por Ha", "m³ VTA por UMM",
         "Area basal m2/ha", "Intensidad de Corta (%) Por UMM", "m³ VTA por UMM",
         "Area basal m2/ha", "m³ VTA/ha", "m³ VTA/UMM"],
    ]
    filas_cuadro = []
    for fila in data.get("filas", []):
        if fila.get("_type") == "subtotal":
            filas_cuadro.append({
                "valores_fisicos": [f"{fila['rodal']} — Subtotal", None, None,
                                    fila.get("vol_ha", 0), fila.get("vol_umm", 0),
                                    fila.get("ab", 0), None, fila.get("res_vol", 0),
                                    fila.get("res_ab", 0), fila.get("pos_ha", 0),
                                    fila.get("pos_umm", 0)],
                "fusiones": [(0, 3)], "negrita": True, "sombra": GRIS_ENCABEZADO,
            })
        else:
            filas_cuadro.append([
                fila["rodal"], fila["superficie"], fila["especie"], fila["vol_ha"],
                fila["vol_umm"], fila["ab"],
                float(fila["intensidad"]) if fila.get("intensidad") is not None else None,
                fila["res_vol"],
                fila["res_ab"], fila["pos_ha"], fila["pos_umm"],
            ])
    if data.get("num_rodales", 1) > 1:
        filas_cuadro.append({
            "valores_fisicos": ["TOTAL", None, None,
                                data.get("total_vol_ha", 0), data.get("total_vol_umm", 0),
                                data.get("total_ab", 0), data.get("total_intensidad"),
                                data.get("total_res_vol", 0),
                                data.get("total_res_ab", 0), data.get("total_pos_ha", 0),
                                data.get("total_pos_umm", 0)],
            "fusiones": [(0, 3)], "negrita": True, "sombra": GRIS_TOTAL,
        })
    tabla_principal, _ = crear_cuadro(
        documento, titulo="Cuadro de existencias por UMM", numero_tabla=1,
        encabezados=encabezados, filas=filas_cuadro,
        anchos_relativos=[1.0, 1.6, 2.4, 1.45, 1.45, 1.45, 1.5,
                          1.45, 1.45, 1.45, 1.45],
        alineaciones={0: "left", 2: "left"},
        decimales={indice: (2 if indice == 6 else 3) for indice in range(1, 11)},
        columnas_verticales=(2, 6))
    _fusionar_rodal_superficie_word(tabla_principal, data)
    _sombrear_subtotales_word(tabla_principal, data)

    documento.add_heading("2. Indicadores principales", level=1)
    _tabla(documento, ("Indicador", "Resultado"), analisis["indicadores"], (8, 8),
           titulo="Indicadores principales", numero_tabla=2)
    documento.add_heading("3. Interpretación técnica", level=1)
    for texto in analisis.get("parrafos", analisis["hallazgos"]):
        _agregar_texto_rico(documento.add_paragraph(), texto)
    for texto in analisis.get("hallazgos", []):
        documento.add_paragraph(texto)
    for texto in analisis.get("observaciones", []):
        documento.add_paragraph(texto, style="List Bullet")
    documento.add_heading("4. Gráfica de apoyo", level=1)
    grafica = documento.add_paragraph()
    grafica.alignment = WD_ALIGN_PARAGRAPH.CENTER
    grafica.add_run().add_picture(_grafica_word_png(analisis["grafica"], analisis.get("titulo_grafica", "Distribución de los indicadores principales")), width=Cm(16.5))
    documento.add_paragraph(analisis.get("leyenda_grafica", "Figura 1. Distribución de los indicadores principales calculados."))
    documento.add_heading("5. Resumen de existencias", level=1)
    if resumen is not None:
        encabezados_resumen = ("Especie", "Existencias reales (m³ VTA)",
                               "Posibilidad (m³ VTA)", "Residuales (m³ VTA)",
                               "Intensidad (%)")
        filas_resumen = [
            (fila["especie"], f"{fila['existencias']:,.3f}",
             f"{fila['posibilidad']:,.3f}", f"{fila['residuales']:,.3f}",
             f"{fila['posibilidad'] * 100 / fila['existencias']:.2f}"
             if fila["existencias"] else "—")
            for fila in resumen.get("filas", [])
        ]
        filas_resumen.append(("Total", f"{resumen['totales']['existencias']:,.3f}",
                              f"{resumen['totales']['posibilidad']:,.3f}",
                              f"{resumen['totales']['residuales']:,.3f}",
                              f"{resumen['totales']['posibilidad'] * 100 / resumen['totales']['existencias']:.2f}"
                              if resumen['totales']['existencias'] else "—"))
        tabla_apoyo = _tabla(documento, encabezados_resumen, filas_resumen,
                             titulo="Resumen de existencias a nivel de predio",
                             numero_tabla=3)
    else:
        tabla_apoyo = _tabla(documento, analisis["encabezados"], analisis["tabla"],
                             titulo="Resumen por especie", numero_tabla=3)
    if analisis.get("nombres_cientificos"):
        for fila in tabla_apoyo.rows[1:]:
            for run in fila.cells[0].paragraphs[0].runs:
                run.italic = True
    documento.add_heading("6. Consideración técnica", level=1)
    documento.add_paragraph(analisis["cautela"])
    documento.add_heading("7. Calidad, trazabilidad y fuentes", level=1)
    documento.add_paragraph(f"Estado de datos: {analisis.get('estado_datos', 'No disponible')}. {analisis.get('trazabilidad', '')}")
    for limitacion in analisis.get("limitaciones", []):
        documento.add_paragraph(limitacion, style="List Bullet")
    for fuente in analisis.get("fuentes", []):
        documento.add_paragraph(f"Fuente: {fuente}", style="List Bullet")
    salida = io.BytesIO()
    documento.save(salida)
    salida.seek(0)
    return salida


def _seccion_apaisada(documento):
    seccion = documento.sections[0]
    seccion.orientation = WD_ORIENT.LANDSCAPE
    seccion.page_width, seccion.page_height = seccion.page_height, seccion.page_width


def _interpretacion_documento(documento, analisis, numero):
    """Secciones 2-5 del reporte estandar: interpretación, gráfica, cautela y trazabilidad."""
    documento.add_heading(f"{numero}. Interpretación técnica", level=1)
    for texto in analisis.get("parrafos", analisis.get("hallazgos", [])):
        _agregar_texto_rico(documento.add_paragraph(), texto)
    for texto in analisis.get("hallazgos", []):
        documento.add_paragraph(texto)
    for texto in analisis.get("observaciones", []):
        documento.add_paragraph(texto, style="List Bullet")
    numero += 1
    documento.add_heading(f"{numero}. Gráfica de apoyo", level=1)
    grafica = documento.add_paragraph()
    grafica.alignment = WD_ALIGN_PARAGRAPH.CENTER
    grafica.add_run().add_picture(
        _grafica_word_png(analisis["grafica"],
                          analisis.get("titulo_grafica",
                                       "Distribución de los indicadores principales")),
        width=Cm(16.5))
    documento.add_paragraph(analisis.get(
        "leyenda_grafica", "Figura 1. Distribución de los indicadores principales calculados."))
    numero += 1
    documento.add_heading(f"{numero}. Consideración técnica", level=1)
    documento.add_paragraph(analisis.get("cautela", ""))
    numero += 1
    documento.add_heading(f"{numero}. Calidad, trazabilidad y fuentes", level=1)
    documento.add_paragraph(f"Estado de datos: {analisis.get('estado_datos', 'No disponible')}. "
                            f"{analisis.get('trazabilidad', '')}")
    for limitacion in analisis.get("limitaciones", []):
        documento.add_paragraph(limitacion, style="List Bullet")
    for fuente in analisis.get("fuentes", []):
        documento.add_paragraph(f"Fuente: {fuente}", style="List Bullet")
    return numero


def generar_word_cuadro_incrementos(pmf, data, analisis):
    """Cuadro de incrementos estandar en Word, con la misma información que la pantalla."""
    documento = Document()
    _seccion_apaisada(documento)
    _configurar_documento_institucional(documento, pmf, analisis)

    documento.add_heading("1. Cuadro de incrementos por UMM", level=1)
    encabezados = [["UMM", "Especie", "Sup (ha)", "Arb/ha", "AB (m2/ha)", "TP",
                    "ICA (m3/ha/a)", "ICA%", "IMA (m3/ha/a)", "Edad"]]
    filas_cuadro = []
    numerico = lambda valor: float(valor) if valor not in (None, "") else None
    for fila in data.get("filas", []):
        if fila.get("_type") == "subtotal":
            filas_cuadro.append({
                "valores_fisicos": ["Subtotal", None, None,
                                    numerico(fila.get("arb_ha")), numerico(fila.get("ab")),
                                    None, numerico(fila.get("ica")), None,
                                    numerico(fila.get("ima")), None],
                "fusiones": [(0, 3)], "negrita": True,
            })
        else:
            filas_cuadro.append([
                fila["rodal"], fila["especie"], numerico(fila.get("superficie")),
                numerico(fila.get("arb_ha")), numerico(fila.get("ab")),
                numerico(fila.get("tp")), numerico(fila.get("ica")),
                numerico(fila.get("ica_pct")), numerico(fila.get("ima")),
                numerico(fila.get("edad")),
            ])
    filas_cuadro.append({
        "valores_fisicos": ["TOTAL", None, numerico(data.get('total_superficie')),
                            numerico(data.get("total_arb_ha")), numerico(data.get("total_ab")),
                            numerico(data.get("total_tp")), numerico(data.get("total_ica")),
                            numerico(data.get("total_ica_pct")), numerico(data.get("total_ima")),
                            numerico(data.get("total_edad"))],
        "fusiones": [(0, 3)], "negrita": True, "sombra": GRIS_TOTAL,
    })
    tabla_principal, _ = crear_cuadro(
        documento, titulo="Resumen de incrementos", numero_tabla=1,
        encabezados=encabezados, filas=filas_cuadro,
        anchos_relativos=[1.6, 2.6, 1.4, 1.2, 1.4, 1.0, 1.4, 1.2, 1.4, 1.2],
        alineaciones={0: "left", 1: "left"},
        decimales={2: 3, 3: 2, 4: 3, 5: 1, 6: 4, 7: 2, 8: 4, 9: 1})
    _fusionar_rodal_superficie_word(tabla_principal, data, fila_inicial=1,
                                    columnas=(0, 2))

    _interpretacion_documento(documento, analisis, numero=2)
    salida = io.BytesIO()
    documento.save(salida)
    salida.seek(0)
    return salida


def _filas_plan_cortas(datos_intervenciones, totales_anualidad, totales_generales):
    filas = []
    for indice, dato in enumerate(datos_intervenciones):
        intervencion = dato["intervencion"]
        for fila in dato["filas"]:
            filas.append([
                intervencion.anualidad, intervencion.rodal_id,
                intervencion.superficie_ha, intervencion.tratamiento,
                fila["especie"], fila["posibilidad"], fila["infraestructura"],
                fila["total"],
            ])
        if not dato["filas"]:
            filas.append({
                "valores_fisicos": [intervencion.anualidad, intervencion.rodal_id,
                                    intervencion.superficie_ha, intervencion.tratamiento,
                                    "Sin especies con posibilidad o infraestructura",
                                    None, None, None],
                "fusiones": [(4, 4)],
            })
        es_ultimo = indice == len(datos_intervenciones) - 1
        cambia_anualidad = (not es_ultimo and
                            datos_intervenciones[indice + 1]["intervencion"].anualidad
                            != intervencion.anualidad)
        if es_ultimo or cambia_anualidad:
            subtotal = totales_anualidad[intervencion.anualidad]
            filas.append({
                "valores_fisicos": [f"Subtotal Anualidad {intervencion.anualidad}", None,
                                    subtotal["superficie"], "Subtotal", None,
                                    subtotal["posibilidad"], subtotal["infraestructura"],
                                    subtotal["total"]],
                "fusiones": [(0, 2), (3, 2)], "negrita": True,
            })
    if totales_generales:
        filas.append({
            "valores_fisicos": ["TOTAL GENERAL", None, totales_generales.get("superficie", 0),
                                "TOTAL", None, totales_generales.get("posibilidad", 0),
                                totales_generales.get("infraestructura", 0),
                                totales_generales.get("total", 0)],
            "fusiones": [(0, 2), (3, 2)], "negrita": True, "sombra": GRIS_TOTAL,
        })
    return filas


def _filas_resumen_plan_cortas(resumen_plan, total_resumen_plan):
    filas = []
    for grupo in resumen_plan:
        etiqueta = (f"{grupo['numero']}-{grupo['anio']}"
                    if grupo.get("anio") else str(grupo["numero"]))
        for fila in grupo["filas"]:
            filas.append([etiqueta, fila["especie"], fila["posibilidad"],
                          fila["infraestructura"], fila["total"], fila["especie"]])
        subtotal = grupo["subtotal"]
        filas.append({
            "valores_fisicos": [f"Subtotal a Área de Corta {etiqueta}", None,
                                subtotal["posibilidad"], subtotal["infraestructura"],
                                subtotal["total"], None],
            "fusiones": [(0, 2)], "negrita": True,
        })
    filas.append({
        "valores_fisicos": ["Total a", None, total_resumen_plan.get("posibilidad", 0),
                            total_resumen_plan.get("infraestructura", 0),
                            total_resumen_plan.get("total", 0), None],
        "fusiones": [(0, 2)], "negrita": True, "sombra": GRIS_TOTAL,
    })
    return filas


def _filas_conciliacion_plan(conciliacion_plan):
    filas = []
    for fila in conciliacion_plan.get("filas", []):
        if fila["coincide"]:
            estado = "Coincide"
        elif fila["diferencia"] < 0:
            estado = f"Faltan {-fila['diferencia']:.3f} m³"
        else:
            estado = f"Excede {fila['diferencia']:.3f} m³"
        filas.append([fila["especie"], fila["existencias"], fila["plan"],
                      fila["diferencia"], estado])
    if filas:
        filas.append({
            "valores_fisicos": ["TOTAL GENERAL", conciliacion_plan.get("total_existencias", 0),
                                conciliacion_plan.get("total_plan", 0),
                                conciliacion_plan.get("diferencia", 0),
                                ("COINCIDE" if conciliacion_plan.get("coincide")
                                 else "REVISAR DIFERENCIAS")],
            "negrita": True, "sombra": GRIS_TOTAL,
        })
    return filas


def generar_word_plan_cortas(pmf, datos_intervenciones, totales_anualidad,
                             totales_generales, resumen_plan, total_resumen_plan,
                             conciliacion_plan):
    """Plan de cortas estandar en Word: Tabla 8, resumen (Tabla 9) y conciliación."""
    analisis = {"titulo": "Plan de Cortas",
                "trazabilidad": "Posibilidad anual y plan de cortas calculados con los "
                                "volúmenes capturados del proyecto activo."}
    documento = Document()
    _seccion_apaisada(documento)
    _configurar_documento_institucional(documento, pmf, analisis)

    documento.add_heading("1. Posibilidad anual y plan de cortas, por unidad mínima de manejo",
                          level=1)
    tabla_plan, _ = crear_cuadro(documento,
                 titulo="Posibilidad anual y plan de cortas, por unidad mínima de manejo",
                 numero_tabla=1,
                 encabezados=[
                     [{"texto": "Área de Corta", "span": 1},
                      {"texto": "Unidad Mínima de Manejo (UMM)", "span": 2},
                      {"texto": "Tratamiento Silvícola", "span": 1},
                      {"texto": "Posibilidad", "span": 2},
                      {"texto": "Volumen por infraestructura (m³ VTA)", "span": 1},
                      {"texto": "Posibilidad + volumen por infraestructura (m³ VTA)", "span": 1}],
                     ["No.", "No.", "Superficie (ha)", "", "Género", "m³ VTA", "", ""],
                 ],
                 filas=_filas_plan_cortas(datos_intervenciones, totales_anualidad,
                                          totales_generales),
                 anchos_relativos=[1.5, 1.6, 2.0, 2.6, 2.4, 1.6, 1.9, 1.9],
                 alineaciones={0: "center", 1: "left", 4: "left"},
                 decimales={2: 3, 5: 3, 6: 3, 7: 3},
                 columnas_verticales=(3, 6, 7))
    _fusionar_area_corta_word(tabla_plan, datos_intervenciones, fila_inicial=2)

    documento.add_heading("2. Posibilidad anual y plan de cortas (resumen)", level=1)
    tabla_resumen, _ = crear_cuadro(documento,
                 titulo="Posibilidad anual y plan de cortas (resumen)", numero_tabla=2,
                 encabezados=[
                     [{"texto": "Área de Corta No.", "span": 1},
                      {"texto": "Posibilidad", "span": 2},
                      {"texto": "Volumen por infraestructura (m³ VTA)", "span": 1},
                      {"texto": "Posibilidad + volumen por infraestructura (m³ VTA)", "span": 1},
                      {"texto": "Especies por aprovechar", "span": 1}],
                     ["", "Especie", "m³ VTA", "", "", ""],
                 ],
                 filas=_filas_resumen_plan_cortas(resumen_plan, total_resumen_plan),
                 anchos_relativos=[1.8, 2.6, 1.8, 2.2, 2.6, 2.6],
                 alineaciones={1: "left", 5: "left"},
                 decimales={2: 3, 3: 3, 4: 3},
                 columnas_verticales=(0, 3, 4, 5))
    _fusionar_area_resumen_word(tabla_resumen, resumen_plan, fila_inicial=2)
    for nota in ("a) Incluir subtotales por área de corta y totales para el predio.",
                 "b) Esta tabla debe incluirse en el cuerpo del Programa de Manejo Forestal."):
        p = documento.add_paragraph(nota)
        p.paragraph_format.space_before = Pt(0)

    documento.add_heading("3. Conciliación con el Cuadro de Existencias", level=1)
    crear_cuadro(documento,
                 titulo="Conciliación con el Cuadro de Existencias", numero_tabla=3,
                 encabezados=[["Especie", "Posibilidad en Existencias (m³ VTA)",
                               "Plan + infraestructura (m³ VTA)", "Diferencia (m³ VTA)",
                               "Estado"]],
                 filas=_filas_conciliacion_plan(conciliacion_plan),
                 anchos_relativos=[3.0, 2.4, 2.4, 2.0, 2.6],
                 alineaciones={0: "left"},
                 decimales={1: 3, 2: 3, 3: 3})
    salida = io.BytesIO()
    documento.save(salida)
    salida.seek(0)
    return salida


def generar_pdf_cuadro_existencias(pmf, data, analisis, resumen_datos=None):
    """Exporta cuadro, resumen e interpretación en un único PDF."""
    salida = io.BytesIO()
    documento = SimpleDocTemplate(
        salida, pagesize=landscape(letter), leftMargin=1.2 * cm,
        rightMargin=1.2 * cm, topMargin=1.2 * cm, bottomMargin=1.2 * cm)
    estilos = getSampleStyleSheet()
    estilos.add(ParagraphStyle("SimfiTitleExistencias", parent=estilos["Title"],
                               textColor=colors.HexColor("#0F3D23")))
    elementos = [
        Paragraph("Cuadro de existencias por UMM", estilos["SimfiTitleExistencias"]),
        Paragraph(pmf.predio or pmf.nombre or "Proyecto sin nombre", estilos["Heading2"]),
        Spacer(1, 8),
    ]

    encabezado_1 = ["Unidad Minima de Manejo (UMM)", "", "Especie",
                    "Existencias Reales", "", "", "Intensidad de Corta (%) Por UMM",
                    "Residuales", "Posibilidad", "", ""]
    encabezado_2 = ["No.", "Superficie (ha)", "Especie", "m³ VTA por Ha",
                    "m³ VTA por UMM", "Area basal m2/ha",
                    "Intensidad de Corta (%) Por UMM", "m³ VTA por UMM",
                    "Area basal m2/ha", "m³ VTA/ha", "m³ VTA/UMM"]
    filas = [encabezado_1, encabezado_2]
    fusiones = [
        (0, 0, 0, 1), (0, 2, 1, 2), (0, 3, 0, 5),
        (0, 6, 1, 6), (0, 7, 1, 7), (0, 8, 0, 10),
    ]
    fila_pdf = 2
    inicio_grupo = None
    rodal_actual = None
    filas_subtotal = []

    def numero(valor, decimales=3):
        if valor in (None, ""):
            return ""
        return f"{float(valor):,.{decimales}f}"

    for fila in data.get("filas", []):
        if fila.get("_type") == "subtotal":
            filas.append([f"{fila['rodal']} — Subtotal", "", "",
                          numero(fila.get("vol_ha", 0)), numero(fila.get("vol_umm", 0)),
                          numero(fila.get("ab", 0)), "", numero(fila.get("res_vol", 0)),
                          numero(fila.get("res_ab", 0)), numero(fila.get("pos_ha", 0)),
                          numero(fila.get("pos_umm", 0))])
            fusiones.append((fila_pdf, 0, fila_pdf, 2))
            filas_subtotal.append(fila_pdf)
            if inicio_grupo is not None:
                fusiones.extend(((inicio_grupo, 0, fila_pdf - 1, 0),
                                 (inicio_grupo, 1, fila_pdf - 1, 1)))
            inicio_grupo = None
            rodal_actual = None
        else:
            if inicio_grupo is None:
                inicio_grupo = fila_pdf
                rodal_actual = fila.get("rodal")
            elif fila.get("rodal") != rodal_actual:
                fusiones.extend(((inicio_grupo, 0, fila_pdf - 1, 0),
                                 (inicio_grupo, 1, fila_pdf - 1, 1)))
                inicio_grupo = fila_pdf
                rodal_actual = fila.get("rodal")
            filas.append([fila.get("rodal", ""), numero(fila.get("superficie", 0)),
                          fila.get("especie", ""), numero(fila.get("vol_ha", 0)),
                          numero(fila.get("vol_umm", 0)), numero(fila.get("ab", 0)),
                          numero(fila.get("intensidad", ""), 2), numero(fila.get("res_vol", 0)),
                          numero(fila.get("res_ab", 0)), numero(fila.get("pos_ha", 0)),
                          numero(fila.get("pos_umm", 0))])
        fila_pdf += 1
    if inicio_grupo is not None:
        fusiones.extend(((inicio_grupo, 0, fila_pdf - 1, 0),
                         (inicio_grupo, 1, fila_pdf - 1, 1)))

    tabla = Table(filas, colWidths=[2.0 * cm, 2.0 * cm, 3.0 * cm] + [2.1 * cm] * 8,
                  repeatRows=2)
    estilo = [
        ("GRID", (0, 0), (-1, -1), .35, colors.grey),
        ("BACKGROUND", (0, 0), (-1, 1), colors.HexColor("#D9D9D9")),
        ("TEXTCOLOR", (0, 0), (-1, 1), colors.black),
        ("FONTNAME", (0, 0), (-1, 1), "Helvetica-Bold"),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("FONTSIZE", (0, 0), (-1, -1), 6.5),
    ]
    for fila, inicio, fin, objetivo in fusiones:
        estilo.append(("SPAN", (inicio, fila), (objetivo, fin)))
    for fila in filas_subtotal:
        estilo.append(("BACKGROUND", (0, fila), (-1, fila), colors.HexColor("#D9D9D9")))
    tabla.setStyle(TableStyle(estilo))
    if resumen_datos is not None:
        encabezados_resumen = ["Especie", "Existencias reales (m³ VTA)",
                               "Posibilidad (m³ VTA)", "Residuales (m³ VTA)",
                               "Intensidad (%)"]
        filas_resumen = [[fila["especie"], f"{fila['existencias']:,.3f}",
                          f"{fila['posibilidad']:,.3f}", f"{fila['residuales']:,.3f}",
                          f"{fila['posibilidad'] * 100 / fila['existencias']:.2f}"
                          if fila["existencias"] else "—"]
                         for fila in resumen_datos.get("filas", [])]
        totales = resumen_datos["totales"]
        filas_resumen.append(["Total", f"{totales['existencias']:,.3f}",
                              f"{totales['posibilidad']:,.3f}", f"{totales['residuales']:,.3f}",
                              f"{totales['posibilidad'] * 100 / totales['existencias']:.2f}"
                              if totales["existencias"] else "—"])
        encabezados_pdf = encabezados_resumen
    else:
        encabezados_pdf = list(analisis["encabezados"])
        filas_resumen = [list(fila) for fila in analisis["tabla"]]
    elementos += [tabla, Spacer(1, 10), Paragraph("Resumen de existencias", estilos["Heading2"])]
    resumen = Table([encabezados_pdf] + filas_resumen,
                    repeatRows=1)
    resumen.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1A5632")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), .3, colors.grey),
        ("FONTSIZE", (0, 0), (-1, -1), 7),
        ("ALIGN", (1, 1), (-1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    elementos += [resumen, Spacer(1, 10), Paragraph("Interpretación técnica", estilos["Heading2"])]
    elementos += [Paragraph(_texto_pdf_rico(texto), estilos["BodyText"])
                  for texto in analisis.get("parrafos", analisis.get("hallazgos", []))]
    elementos += [Paragraph(texto, estilos["BodyText"])
                  for texto in analisis.get("hallazgos", [])]
    elementos += [Paragraph("- " + _texto_pdf_rico(texto), estilos["BodyText"])
                  for texto in analisis.get("observaciones", [])]
    elementos += [Paragraph("Consideración técnica", estilos["Heading2"]),
                  Paragraph(analisis.get("cautela", ""), estilos["BodyText"]),
                  Paragraph("Calidad, trazabilidad y fuentes", estilos["Heading2"]),
                  Paragraph(f"Estado de datos: {analisis.get('estado_datos', 'No disponible')}. "
                            f"{analisis.get('trazabilidad', '')}", estilos["BodyText"])]
    documento.build(elementos)
    salida.seek(0)
    return salida


def generar_pdf_cuadro_incrementos(pmf, data, analisis):
    """Exporta el cuadro de incrementos y su interpretación en un PDF."""
    salida = io.BytesIO()
    documento = SimpleDocTemplate(
        salida, pagesize=landscape(letter), leftMargin=1.2 * cm,
        rightMargin=1.2 * cm, topMargin=1.2 * cm, bottomMargin=1.2 * cm)
    estilos = getSampleStyleSheet()
    estilos.add(ParagraphStyle("SimfiTitleIncrementos", parent=estilos["Title"],
                               textColor=colors.HexColor("#0F3D23")))
    encabezados = ["UMM", "Especie", "Sup (ha)", "Arb/ha", "AB (m2/ha)", "TP",
                   "ICA (m3/ha/a)", "ICA%", "IMA (m3/ha/a)", "Edad"]
    filas = [encabezados]
    filas_subtotal = []
    fusiones_rodal = []
    fila_pdf = 1
    inicio_rodal = None
    rodal_actual = None

    def numero(valor, decimales):
        return "" if valor in (None, "") else f"{float(valor):,.{decimales}f}"

    for fila in data.get("filas", []):
        if fila.get("_type") == "subtotal":
            if inicio_rodal is not None:
                fusiones_rodal.extend(((inicio_rodal, 0, fila_pdf - 1, 0),
                                      (inicio_rodal, 2, fila_pdf - 1, 2)))
                inicio_rodal = None
                rodal_actual = None
            filas.append(["Subtotal", "", "", numero(fila.get("arb_ha"), 2),
                          numero(fila.get("ab"), 3), "", numero(fila.get("ica"), 4),
                          "", numero(fila.get("ima"), 4), ""])
            filas_subtotal.append(fila_pdf)
        else:
            if inicio_rodal is None:
                inicio_rodal = fila_pdf
                rodal_actual = fila.get("rodal")
            elif fila.get("rodal") != rodal_actual:
                fusiones_rodal.extend(((inicio_rodal, 0, fila_pdf - 1, 0),
                                      (inicio_rodal, 2, fila_pdf - 1, 2)))
                inicio_rodal = fila_pdf
                rodal_actual = fila.get("rodal")
            filas.append([fila.get("rodal", ""), fila.get("especie", ""),
                          numero(fila.get("superficie"), 3), numero(fila.get("arb_ha"), 2),
                          numero(fila.get("ab"), 3), numero(fila.get("tp"), 1),
                          numero(fila.get("ica"), 4), numero(fila.get("ica_pct"), 2),
                          numero(fila.get("ima"), 4), numero(fila.get("edad"), 1)])
        fila_pdf += 1
    if inicio_rodal is not None:
        fusiones_rodal.extend(((inicio_rodal, 0, fila_pdf - 1, 0),
                              (inicio_rodal, 2, fila_pdf - 1, 2)))
    filas.append(["TOTAL", "", numero(data.get("total_superficie"), 3),
                  numero(data.get("total_arb_ha"), 2), numero(data.get("total_ab"), 3),
                  numero(data.get("total_tp"), 1), numero(data.get("total_ica"), 4),
                  numero(data.get("total_ica_pct"), 2), numero(data.get("total_ima"), 4),
                  numero(data.get("total_edad"), 1)])
    fila_total = len(filas) - 1
    tabla = Table(filas, colWidths=[2.0 * cm, 3.3 * cm, 1.8 * cm, 1.8 * cm, 2.0 * cm,
                                   1.5 * cm, 2.2 * cm, 1.5 * cm, 2.2 * cm, 1.5 * cm],
                  repeatRows=1)
    estilo = [
        ("GRID", (0, 0), (-1, -1), .35, colors.grey),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#D9D9D9")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("FONTSIZE", (0, 0), (-1, -1), 7),
        ("BACKGROUND", (0, fila_total), (-1, fila_total), colors.HexColor("#D9D9D9")),
        ("FONTNAME", (0, fila_total), (-1, fila_total), "Helvetica-Bold"),
    ]
    for fila in filas_subtotal:
        estilo.append(("BACKGROUND", (0, fila), (-1, fila), colors.HexColor("#D9D9D9")))
    for fila, inicio, fin, objetivo in fusiones_rodal:
        estilo.append(("SPAN", (inicio, fila), (objetivo, fin)))
    tabla.setStyle(TableStyle(estilo))
    elementos = [Paragraph("Resumen de incrementos", estilos["SimfiTitleIncrementos"]),
                 Paragraph(pmf.predio or pmf.nombre or "Proyecto sin nombre", estilos["Heading2"]),
                 Spacer(1, 8), tabla, Spacer(1, 10),
                 Paragraph("Interpretación técnica", estilos["Heading2"])]
    elementos += [Paragraph(_texto_pdf_rico(texto), estilos["BodyText"])
                  for texto in analisis.get("parrafos", analisis.get("hallazgos", []))]
    elementos += [Paragraph(texto, estilos["BodyText"])
                  for texto in analisis.get("hallazgos", [])]
    elementos += [Paragraph("- " + _texto_pdf_rico(texto), estilos["BodyText"])
                  for texto in analisis.get("observaciones", [])]
    elementos += [Paragraph("Consideración técnica", estilos["Heading2"]),
                  Paragraph(analisis.get("cautela", ""), estilos["BodyText"])]
    documento.build(elementos)
    salida.seek(0)
    return salida


def generar_word_cuadro_carbono(pmf, titulo, encabezados, filas, data, analisis):
    """Exporta una pestaña de carbono/oxígeno con su cuadro e interpretación."""
    documento = Document()
    seccion = documento.sections[0]
    seccion.orientation = WD_ORIENT.LANDSCAPE
    seccion.page_width, seccion.page_height = seccion.page_height, seccion.page_width
    _configurar_documento_institucional(documento, pmf, analisis)
    filas_formateadas = []
    for fila in filas:
        if isinstance(fila, dict):
            copia = dict(fila)
            valores = copia.get("valores_fisicos", copia.get("valores", []))
            copia["valores_fisicos"] = [float(valor) if isinstance(valor, (int, float)) else valor
                                        for valor in valores]
            filas_formateadas.append(copia)
        else:
            filas_formateadas.append([float(valor) if isinstance(valor, (int, float)) else valor
                                      for valor in fila])
    tabla, _ = crear_cuadro(
        documento, titulo=titulo, numero_tabla=1,
        encabezados=[encabezados], filas=filas_formateadas,
        orientacion="portrait", tamano_fuente=7,
        alineaciones={0: "left", 1: "left"},
        anchos_relativos=[1.2, 2.8] + [1.15] * max(0, len(encabezados) - 2),
        decimales={indice: 3 for indice in range(len(encabezados))})
    columnas_fusion = (0, encabezados.index("Sup (ha)")) if "Sup (ha)" in encabezados else (0,)
    _fusionar_rodal_superficie_word(tabla, data, fila_inicial=1, columnas=columnas_fusion)
    _sombrear_subtotales_word(tabla, data, fila_inicial=1)
    _interpretacion_documento(documento, analisis, numero=2)
    salida = io.BytesIO()
    documento.save(salida)
    salida.seek(0)
    return salida


def generar_pdf_cuadro_carbono(pmf, titulo, encabezados, filas, data, analisis):
    """Exporta una pestaña de carbono/oxígeno con su cuadro e interpretación."""
    salida = io.BytesIO()
    documento = SimpleDocTemplate(
        salida, pagesize=letter, leftMargin=1.2 * cm,
        rightMargin=1.2 * cm, topMargin=1.2 * cm, bottomMargin=1.2 * cm)
    estilos = getSampleStyleSheet()
    estilos.add(ParagraphStyle("SimfiTitleCarbono", parent=estilos["Title"],
                               textColor=colors.HexColor("#0F3D23")))
    def formato_pdf(valor):
        return f"{float(valor):,.3f}" if isinstance(valor, (int, float)) else valor

    filas_pdf = [list(encabezados)] + [
        [formato_pdf(valor) for valor in
         (fila.get("valores_fisicos", fila) if isinstance(fila, dict) else fila)]
        for fila in filas]
    col_widths = [1.8 * cm, 3.0 * cm] + [1.45 * cm] * max(0, len(encabezados) - 2)
    tabla = Table(filas_pdf, colWidths=col_widths, repeatRows=1)
    estilo = [
        ("GRID", (0, 0), (-1, -1), .35, colors.grey),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#D9D9D9")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("FONTSIZE", (0, 0), (-1, -1), 7),
    ]
    fila_pdf = 1
    inicio = None
    rodal_actual = None
    columnas_span = [0]
    if "Sup (ha)" in encabezados:
        columnas_span.append(encabezados.index("Sup (ha)"))

    def agregar_span(hasta):
        for columna_span in columnas_span:
            estilo.append(("SPAN", (columna_span, inicio), (columna_span, hasta)))

    for raw in data.get("filas", []):
        if raw.get("_type") == "subtotal":
            if inicio is not None:
                agregar_span(fila_pdf - 1)
                inicio = None
                rodal_actual = None
            estilo.append(("BACKGROUND", (0, fila_pdf), (-1, fila_pdf), colors.HexColor("#D9D9D9")))
        else:
            if inicio is None:
                inicio = fila_pdf
                rodal_actual = raw.get("rodal")
            elif raw.get("rodal") != rodal_actual:
                agregar_span(fila_pdf - 1)
                inicio = fila_pdf
                rodal_actual = raw.get("rodal")
        fila_pdf += 1
    if inicio is not None:
        agregar_span(fila_pdf - 1)
    tabla.setStyle(TableStyle(estilo))
    elementos = [Paragraph(titulo, estilos["SimfiTitleCarbono"]),
                 Paragraph(pmf.predio or pmf.nombre or "Proyecto sin nombre", estilos["Heading2"]),
                 Spacer(1, 8), tabla, Spacer(1, 10),
                 Paragraph("Interpretación técnica", estilos["Heading2"])]
    elementos += [Paragraph(_texto_pdf_rico(texto), estilos["BodyText"])
                  for texto in analisis.get("parrafos", analisis.get("hallazgos", []))]
    elementos += [Paragraph(texto, estilos["BodyText"])
                  for texto in analisis.get("hallazgos", [])]
    elementos += [Paragraph("Consideración técnica", estilos["Heading2"]),
                  Paragraph(analisis.get("cautela", ""), estilos["BodyText"])]
    documento.build(elementos)
    salida.seek(0)
    return salida


def generar_pdf(pmf, analisis):
    salida = io.BytesIO()
    documento = SimpleDocTemplate(salida, pagesize=landscape(letter), leftMargin=1.2 * cm, rightMargin=1.2 * cm, topMargin=1.2 * cm, bottomMargin=1.2 * cm)
    estilos = getSampleStyleSheet()
    estilos.add(ParagraphStyle("SimfiTitle", parent=estilos["Title"], textColor=colors.HexColor("#0F3D23")))
    elementos = [Paragraph(analisis["titulo"], estilos["SimfiTitle"]), Paragraph(pmf.predio or pmf.nombre or "Proyecto sin nombre", estilos["Heading2"]), Spacer(1, 8)]
    indicadores = Table([["Indicador", "Resultado"]] + list(analisis["indicadores"]), colWidths=[8 * cm, 10 * cm])
    indicadores.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1A5632")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("GRID", (0, 0), (-1, -1), .4, colors.grey), ("PADDING", (0, 0), (-1, -1), 5)]))
    elementos += [Paragraph("Indicadores principales", estilos["Heading2"]), indicadores, Spacer(1, 8), Paragraph("Interpretación profesional", estilos["Heading2"])]
    elementos += [Paragraph(_texto_pdf_rico(texto), estilos["BodyText"]) for texto in analisis.get("parrafos", analisis["hallazgos"])]
    elementos += [Paragraph(texto, estilos["BodyText"]) for texto in analisis.get("hallazgos", [])]
    elementos += [Paragraph("- " + _texto_pdf_rico(texto), estilos["BodyText"]) for texto in analisis.get("observaciones", [])]
    elementos += [Spacer(1, 8), _drawing(analisis["grafica"], analisis.get("titulo_grafica", "Distribución de los indicadores principales")), Spacer(1, 8)]
    tabla = Table([list(analisis["encabezados"])] + [list(fila) for fila in analisis["tabla"]], repeatRows=1)
    tabla.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1A5632")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("GRID", (0, 0), (-1, -1), .3, colors.grey), ("FONTSIZE", (0, 0), (-1, -1), 7), ("PADDING", (0, 0), (-1, -1), 4)]))
    elementos += [Paragraph("Cuadro de apoyo", estilos["Heading2"]), tabla, Spacer(1, 8), Paragraph("Consideración técnica", estilos["Heading2"]), Paragraph(analisis["cautela"], estilos["BodyText"]), Paragraph("Calidad, trazabilidad y fuentes", estilos["Heading2"]), Paragraph(f"Estado de datos: {analisis.get('estado_datos', 'No disponible')}. {analisis.get('trazabilidad', '')}", estilos["BodyText"])]
    elementos += [Paragraph("- " + limitacion, estilos["BodyText"]) for limitacion in analisis.get("limitaciones", [])]
    elementos += [Paragraph("Fuente: " + fuente, estilos["BodyText"]) for fuente in analisis.get("fuentes", [])]
    elementos += [Spacer(1, 8), Paragraph(FIRMA, estilos["BodyText"])]
    documento.build(elementos)
    salida.seek(0)
    return salida


def interpretacion_reforestacion(datos):
    """Párrafos de interpretación del cuadro de reforestación."""
    parrafos = []
    areas = datos.get("areas", [])
    if not areas:
        return ["No hay especies seleccionadas para reforestar."]
    densidad = datos.get("densidad")
    if densidad:
        superficie = sum(a.get("superficie", 0.0) for a in areas)
        parrafos.append(f"Con la densidad de plantación de {densidad:,.0f} plantas/ha se "
                        f"requieren {datos.get('total_general', 0.0):,.0f} plantas para "
                        f"reforestar {superficie:,.3f} ha distribuidas en {len(areas)} "
                        "área(s) de regeneración.")
        totales = sorted(datos.get("totales_especie", {}).items(),
                         key=lambda par: (-par[1], par[0]))
        if totales and datos.get("total_general"):
            especie, plantas = totales[0]
            porcentaje = plantas / datos["total_general"] * 100.0
            parrafos.append(f"La especie con mayor requerimiento es {especie}, con "
                            f"{plantas:,.0f} plantas ({porcentaje:.1f}% del total).")
        detalle = "; ".join(
            f"{a.get('etiqueta', a.get('numero', ''))} ({a.get('anio', '')}: {a.get('subtotal_plantas', 0):,.0f} plantas)"
            for a in areas)
        parrafos.append(f"Distribución por área de regeneración: {detalle}.")
    else:
        parrafos.append("El cuadro aún no definió la densidad de plantación, por lo que solo "
                        "presenta las proporciones por especie; al registrarla, SIMFI "
                        "calculará el número de plantas por área y especie.")
    parrafos.append("La proporción de cada especie es su participación dentro de "
                    "su área de regeneración. Solo se establecen coníferas (Pinus, "
                    "Abies, Cupressus y Juniperus); las latifoliadas se regeneran "
                    "por rebrotes y no requieren plantas.")
    return parrafos


def generar_word_cuadro_reforestacion(pmf, datos, disponibles=None):
    """Cuadro de reforestación en Word, con totales por especie e interpretación."""
    analisis = {"titulo": "Cuadro de reforestación",
                "estado_datos": ("Con densidad definida" if datos.get("densidad")
                                 else "Pendiente de definir densidad"),
                "trazabilidad": "",
                "parrafos": interpretacion_reforestacion(datos),
                "hallazgos": [], "observaciones": []}
    documento = Document()
    _seccion_apaisada(documento)
    _configurar_documento_institucional(documento, pmf, analisis)

    documento.add_heading("1. Cuadro de reforestación", level=1)
    encabezados = [["Área de regeneración", "Superficie (ha)", "Especie",
                    "Proporción (%)", "Número de plantas", "Año de ejecución"]]
    filas_cuadro = []
    for area in datos.get("areas", []):
        for fila in area.get("filas", []):
            filas_cuadro.append([area.get("numero") if area.get("numero") is not None else area["etiqueta"], float(area["superficie"]),
                                 fila["especie"], float(fila["proporcion"]),
                                 (float(fila["plantas"]) if fila.get("plantas") is not None
                                  else None), area["anio"]])
        filas_cuadro.append({
            "valores_fisicos": [f"Subtotal {area['etiqueta']}", float(area["superficie"]),
                                None, float(area.get("subtotal_proporcion", 0.0)),
                                (float(area["subtotal_plantas"])
                                 if datos.get("densidad") else None), area["anio"]],
            "negrita": True, "sombra": GRIS_TOTAL})
    filas_cuadro.append({
        "valores_fisicos": ["TOTAL GENERAL", None, None,
                            None, (float(datos.get("total_general", 0.0))
                                   if datos.get("densidad") else None), None],
        "fusiones": [(0, 4)], "negrita": True, "sombra": GRIS_TOTAL})
    tabla_reforestacion, _ = crear_cuadro(
        documento, titulo="Cuadro de reforestación", numero_tabla=1,
        encabezados=encabezados, filas=filas_cuadro,
        anchos_relativos=[2.2, 1.8, 2.8, 1.8, 2.2, 2.2],
        alineaciones={2: "left"},
        decimales={1: 3, 3: 2, 4: 0})
    _fusionar_area_reforestacion_word(tabla_reforestacion, datos, fila_inicial=1)

    documento.add_heading("2. Totales por especie", level=1)
    filas_totales = []
    for especie, plantas in sorted(datos.get("totales_especie", {}).items(),
                                   key=lambda par: (-par[1], par[0])):
        filas_totales.append([especie, float(plantas)])
    filas_totales.append({"valores_fisicos": ["TOTAL", float(datos.get("total_general", 0.0))],
                          "negrita": True, "sombra": GRIS_TOTAL})
    crear_cuadro(documento, titulo="Totales por especie", numero_tabla=2,
                 encabezados=[["Especie", "Número de plantas"]],
                 filas=filas_totales,
                 anchos_relativos=[2.5, 2.0],
                 alineaciones={0: "left"},
                 decimales={1: 0})

    documento.add_heading("3. Interpretación del cuadro", level=1)
    for texto in interpretacion_reforestacion(datos):
        documento.add_paragraph(texto)
    documento.add_paragraph(FIRMA)
    salida = io.BytesIO()
    documento.save(salida)
    salida.seek(0)
    return salida


def _fusionar_area_reforestacion_word(tabla, datos, fila_inicial=1):
    """Une el área de regeneración (y su superficie y año) por área."""
    fila_tabla = fila_inicial
    for area in datos.get("areas", []):
        detalle = len(area.get("filas", []))
        if detalle > 1:
            _aplicar_vmerge(tabla, fila_tabla, fila_tabla + detalle - 1, (0, 1, 5))
        fila_tabla += detalle + 1


def generar_pdf_cuadro_reforestacion(pmf, datos, disponibles=None):
    """Cuadro de reforestación en PDF, con totales por especie e interpretación."""
    salida = io.BytesIO()
    documento = SimpleDocTemplate(
        salida, pagesize=letter, leftMargin=1.4 * cm, rightMargin=1.4 * cm,
        topMargin=1.4 * cm, bottomMargin=1.4 * cm)
    estilos = getSampleStyleSheet()
    estilos.add(ParagraphStyle("SimfiTitleReforestacion", parent=estilos["Title"],
                               textColor=colors.HexColor("#0F3D23")))
    encabezados = ["Área de regeneración", "Superficie (ha)", "Especie",
                   "Proporción (%)", "Número de plantas", "Año de ejecución"]
    filas = [encabezados]
    filas_subtotal = []
    fusiones = []
    fila_pdf = 1

    def numero(valor, decimales):
        if valor in (None, ""):
            return ""
        return f"{float(valor):,.{decimales}f}"

    for area in datos.get("areas", []):
        inicio = fila_pdf
        for fila in area.get("filas", []):
            filas.append([area.get("numero") if area.get("numero") is not None else area["etiqueta"], numero(area["superficie"], 3),
                          fila["especie"], numero(fila["proporcion"], 2),
                          numero(fila.get("plantas"), 0), area["anio"]])
            fila_pdf += 1
        if fila_pdf - 1 > inicio:
            fusiones.extend(((inicio, 0, fila_pdf - 1, 0),
                             (inicio, 1, fila_pdf - 1, 1),
                             (inicio, 5, fila_pdf - 1, 5)))
        filas.append([f"Subtotal {area['etiqueta']}", numero(area["superficie"], 3),
                      "", f"{float(area.get('subtotal_proporcion', 0.0)):,.2f}",
                      numero(area.get("subtotal_plantas"), 0) if datos.get("densidad") else "",
                      area["anio"]])
        filas_subtotal.append(fila_pdf)
        fila_pdf += 1
    filas.append(["TOTAL GENERAL", "", "", "",
                  numero(datos.get("total_general"), 0) if datos.get("densidad") else "", ""])
    fila_total = len(filas) - 1
    tabla = Table(filas, colWidths=[3.4 * cm, 2.9 * cm, 3.6 * cm, 2.7 * cm, 3.2 * cm, 2.6 * cm],
                  repeatRows=1)
    estilo = [
        ("GRID", (0, 0), (-1, -1), .35, colors.grey),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#D9D9D9")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("FONTSIZE", (0, 0), (-1, -1), 7),
        ("BACKGROUND", (0, fila_total), (-1, fila_total), colors.HexColor("#D9D9D9")),
        ("FONTNAME", (0, fila_total), (-1, fila_total), "Helvetica-Bold"),
    ]
    for fila in filas_subtotal:
        estilo.append(("BACKGROUND", (0, fila), (-1, fila), colors.HexColor("#D9D9D9")))
        estilo.append(("FONTNAME", (0, fila), (-1, fila), "Helvetica-Bold"))
    for fila, inicio, fin, objetivo in fusiones:
        estilo.append(("SPAN", (inicio, fila), (objetivo, fin)))
    tabla.setStyle(TableStyle(estilo))
    elementos = [Paragraph("Cuadro de reforestación", estilos["SimfiTitleReforestacion"]),
                 Paragraph(pmf.predio or pmf.nombre or "Proyecto sin nombre",
                           estilos["Heading2"]),
                 Spacer(1, 8), tabla, Spacer(1, 10),
                 Paragraph("Totales por especie", estilos["Heading2"])]
    filas_totales = [["Especie", "Número de plantas"]]
    for especie, plantas in sorted(datos.get("totales_especie", {}).items(),
                                   key=lambda par: (-par[1], par[0])):
        filas_totales.append([especie, numero(plantas, 0)])
    filas_totales.append(["TOTAL", numero(datos.get("total_general"), 0)
                          if datos.get("densidad") else ""])
    tabla_totales = Table(filas_totales, colWidths=[8.0 * cm, 3.6 * cm], repeatRows=1)
    tabla_totales.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), .3, colors.grey),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1A5632")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("FONTSIZE", (0, 0), (-1, -1), 7),
        ("BACKGROUND", (0, len(filas_totales) - 1), (-1, len(filas_totales) - 1),
         colors.HexColor("#D9D9D9")),
    ]))
    elementos.append(tabla_totales)
    elementos += [Spacer(1, 10), Paragraph("Interpretación del cuadro", estilos["Heading2"])]
    elementos += [Paragraph(_texto_pdf_rico(texto), estilos["BodyText"])
                  for texto in interpretacion_reforestacion(datos)]
    elementos += [Spacer(1, 8), Paragraph(FIRMA, estilos["BodyText"])]
    documento.build(elementos)
    salida.seek(0)
    return salida
