"""Proveedor en linea para Groq y APIs compatibles, sin acceso a calculos SIMFI."""

import json
import os
import time
import urllib.error

from ia_config import api_key_en_linea, normalizar_terminologia, registrar_ia
from ia_ollama import _http_get_json, _http_post_json


def _online(config):
    return config.get("en_linea", {})


def _es_groq(config):
    online = _online(config)
    return (online.get("proveedor") == "groq" or
            "api.groq.com" in str(online.get("servidor", "")).lower())


def _nombre_proveedor(config):
    proveedor = str(_online(config).get("proveedor", "")).strip().casefold()
    if proveedor == "groq" or _es_groq(config):
        return "Groq"
    if proveedor == "openrouter":
        return "OpenRouter"
    return "API compatible"


def _endpoint(config, ruta):
    """Compone una sola ruta API aunque la configuracion incluya un endpoint final."""
    servidor = str(_online(config).get("servidor", "")).strip().rstrip("/")
    if not servidor:
        return ""
    while servidor.endswith("/v1/v1"):
        servidor = servidor[:-3]
    if servidor.endswith(ruta):
        return servidor
    for final in ("/chat/completions", "/models"):
        if servidor.endswith(final):
            servidor = servidor[:-len(final)]
            break
    return servidor + ruta


def _timeout(config, clave, predeterminado):
    try:
        return max(1, int(_online(config).get(clave, predeterminado)))
    except (TypeError, ValueError):
        return predeterminado


def _limite_generacion(config):
    """Limite de tokens de salida: max_completion_tokens o max_tokens."""
    online = _online(config)
    for clave in ("max_completion_tokens", "max_tokens"):
        try:
            valor = int(online.get(clave) or 0)
            if valor > 0:
                return valor
        except (TypeError, ValueError):
            continue
    return 4000


def _clave_api(config):
    if not _es_groq(config):
        online = _online(config)
        nombre = str(online.get("api_key_env", "")).strip()
        clave = api_key_en_linea(config)
        if not nombre:
            return "", "No se configuró la variable de entorno para la API key."
        if not clave:
            return "", "Variable de entorno %s no encontrada o vacía." % nombre
        return clave, None
    clave = os.environ.get("GROQ_API_KEY")
    if clave is None:
        return "", "No se encontro la variable de entorno GROQ_API_KEY. Reinicie SIMFI despues de configurarla."
    clave = clave.strip()
    if not clave:
        return "", "La variable GROQ_API_KEY esta vacia."
    if not clave.startswith("gsk_") or '"' in clave or "'" in clave or clave.lower().startswith("bearer "):
        return "", "GROQ_API_KEY no tiene un formato valido. Debe iniciar con gsk_ y no incluir comillas ni Bearer."
    return clave, None


def _diagnostico_error(error, proveedor, uri, modelo):
    lineas = ["Proveedor: " + proveedor, "URL: " + uri, "Modelo: " + modelo]
    if isinstance(error, urllib.error.HTTPError):
        lineas.append("HTTP: " + str(error.code))
        cuerpo = ""
        try:
            cuerpo = error.read().decode("utf-8", errors="replace")
            datos = json.loads(cuerpo)
            detalle = datos.get("error", {}) if isinstance(datos, dict) else {}
            if isinstance(detalle, dict):
                if detalle.get("message"):
                    lineas.append("Mensaje del proveedor: " + str(detalle["message"]))
                if detalle.get("type"):
                    lineas.append("Tipo: " + str(detalle["type"]))
                if detalle.get("code") is not None:
                    lineas.append("Codigo: " + str(detalle["code"]))
            if cuerpo:
                lineas.append("Cuerpo de error: " + cuerpo)
        except Exception:
            lineas.append("Cuerpo de error: no disponible")
    else:
        lineas.append("Error: " + str(error))
    return "\n".join(lineas)


class OnlineAIProvider:
    nombre = "ia_en_linea"

    def _proveedor(self, config):
        return _nombre_proveedor(config)

    def _cabeceras(self, clave):
        return {"Authorization": "Bearer " + clave}

    def estado(self, config):
        online = _online(config)
        modelo = str(online.get("modelo", ""))
        uri = _endpoint(config, "/models")
        clave, error_clave = _clave_api(config)
        if not config.get("habilitada", True) or not online.get("habilitada"):
            return {"disponible": False, "mensaje": "La IA en linea esta deshabilitada.", "modelos": []}
        if not uri or not modelo or error_clave:
            return {"disponible": False, "mensaje": error_clave or "La IA en linea no esta configurada.", "modelos": []}
        inicio = time.monotonic()
        try:
            respuesta = _http_get_json(uri, _timeout(config, "timeout_disponibilidad_segundos", 5),
                                        self._cabeceras(clave))
            modelos = sorted({item.get("id") for item in respuesta.get("data", []) if item.get("id")})
            disponible = not modelos or modelo in modelos
            mensaje = "Servicio de %s disponible." % self._proveedor(config) if disponible else "El modelo en linea no esta disponible."
            registrar_ia("info", "online estado endpoint=%s modelo=%s duracion=%.3fs",
                         uri, modelo, time.monotonic() - inicio)
            return {"disponible": disponible, "mensaje": mensaje, "modelos": modelos}
        except Exception as error:
            diagnostico = _diagnostico_error(error, self._proveedor(config), uri, modelo)
            registrar_ia("error", "online estado endpoint=%s modelo=%s duracion=%.3fs error=%r",
                         uri, modelo, time.monotonic() - inicio, error, exc_info=True)
            return {"disponible": False, "modelos": [], "mensaje": diagnostico}

    def _solicitud(self, contenido, modulo, config):
        online = _online(config)
        modelo = str(online.get("modelo", ""))
        uri = _endpoint(config, "/chat/completions")
        clave, error_clave = _clave_api(config)
        if not uri or error_clave:
            return None, {"ok": False, "texto": None, "motor": self.nombre, "modelo": modelo,
                          "mensaje": error_clave or "La IA en linea no esta configurada."}
        # El prompt maestro (reglas y terminologia) se envia como mensaje de sistema,
        # identico al proveedor local, para que aplique a cualquier proveedor o modelo.
        mensajes = []
        sistema = str(config.get("prompt_sistema", "") or "")
        if sistema.strip():
            mensajes.append({"role": "system", "content": sistema.strip()})
        mensajes.append({"role": "user", "content": contenido})
        # groq gpt-oss-120b y endpoints compatibles OpenAI usan max_completion_tokens.
        cuerpo = {"model": modelo, "messages": mensajes,
                  "max_completion_tokens": _limite_generacion(config)}
        inicio = time.monotonic()
        try:
            respuesta = _http_post_json(uri, cuerpo, _timeout(config, "timeout_generacion_segundos", 180),
                                        self._cabeceras(clave))
            return respuesta, {"inicio": inicio, "uri": uri, "modelo": modelo, "modulo": modulo}
        except Exception as error:
            diagnostico = _diagnostico_error(error, self._proveedor(config), uri, modelo)
            registrar_ia("error", "online generacion endpoint=%s modelo=%s modulo=%s duracion=%.3fs error=%r",
                         uri, modelo, modulo, time.monotonic() - inicio, error, exc_info=True)
            return None, {"ok": False, "texto": None, "motor": self.nombre, "modelo": modelo,
                          "mensaje": diagnostico}

    def interpretar(self, datos, modulo="", contexto="", config=None):
        config = config or {}
        respuesta, meta = self._solicitud(contexto, modulo, config)
        if respuesta is None:
            return meta
        opciones = respuesta.get("choices", []) or []
        eleccion = opciones[0] if opciones else {}
        contenido = (eleccion.get("message") or {}).get("content")
        if not isinstance(contenido, str) or not contenido.strip():
            return {"ok": False, "texto": None, "motor": self.nombre, "modelo": meta["modelo"],
                    "mensaje": "La IA en linea respondio sin contenido de texto."}
        uso = respuesta.get("usage") or {}
        metadatos = {
            "finish_reason": eleccion.get("finish_reason"),
            "prompt_tokens": uso.get("prompt_tokens"),
            "completion_tokens": uso.get("completion_tokens"),
            "truncada": eleccion.get("finish_reason") == "length",
        }
        duracion = time.monotonic() - meta["inicio"]
        if metadatos["truncada"]:
            registrar_ia("warning",
                         "online generacion TRUNCADA por limite de tokens "
                         "finish_reason=length prompt_tokens=%r completion_tokens=%r "
                         "limite=%s endpoint=%s modelo=%s modulo=%s duracion=%.3fs",
                         metadatos["prompt_tokens"], metadatos["completion_tokens"],
                         _limite_generacion(config), meta["uri"], meta["modelo"],
                         modulo, duracion)
        else:
            registrar_ia("info", "online generacion finish_reason=%r prompt_tokens=%r "
                         "completion_tokens=%r endpoint=%s modelo=%s modulo=%s duracion=%.3fs",
                         metadatos["finish_reason"], metadatos["prompt_tokens"],
                         metadatos["completion_tokens"], meta["uri"], meta["modelo"],
                         modulo, duracion)
        texto = normalizar_terminologia(contenido.strip())
        return {"ok": True, "texto": texto, "motor": self.nombre,
                "modelo": meta["modelo"], "mensaje": None, "metadatos": metadatos}

    def probar_conexion(self, config):
        proveedor = _nombre_proveedor(config)
        resultado = self.interpretar({}, "prueba_en_linea", "Responde solamente: conexion correcta", config)
        if resultado["ok"] and "conexion correcta" in resultado["texto"].casefold():
            return {"ok": True, "mensaje": "%s: CONEXIÓN CORRECTA\nModelo: %s" %
                    (proveedor, resultado["modelo"])}
        if resultado["ok"]:
            return {"ok": False, "mensaje": "%s respondió, pero no confirmó la frase esperada.\nModelo: %s" %
                    (proveedor, resultado["modelo"])}
        return {"ok": False, "mensaje": resultado["mensaje"]}
