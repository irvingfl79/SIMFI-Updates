"""Orquestador de Dussan, asistente virtual de SIMFI.

REGLA FUNDAMENTAL
-----------------
SIMFI CALCULA Y VALIDA. DUSSAN CONSULTA, INTERPRETA Y ORIENTA.

Este modulo nunca calcula un indicador, nunca modifica ecuaciones ni
metodologias, nunca altera resultados oficiales y nunca escribe en el proyecto
ni en la base de datos. Todas sus lecturas provienen de resultados que SIMFI ya
calculo, obtenidos mediante funciones que ya existen en el sistema.

Cuando SIMFI no tiene el dato, la herramienta lo declara. Nunca lo inventa.
Las herramientas de escritura, ejecucion y eliminacion no se implementan.
"""

import json

try:
    from ai_interpretation_service import AIInterpretationService
    from ia_config import cargar_config as _cargar_config
    from ia_config import normalizar_terminologia, registrar_ia
    _BASE_IA_OK = True
except Exception:  # La ausencia de IA nunca debe impedir usar SIMFI.
    _BASE_IA_OK = False

    def _cargar_config(ruta=None):
        return {}

    def normalizar_terminologia(texto):
        return texto

    def registrar_ia(nivel, mensaje, *args, **kwargs):
        pass


_SERVICIO = AIInterpretationService() if _BASE_IA_OK else None

# SIMFI trata la UMM y el rodal como la MISMA unidad de manejo. No son dos niveles.
NOTA_UMM = ("En SIMFI la UMM (Unidad Minima de Manejo) y el rodal son la misma "
            "unidad de manejo: no existen dos niveles distintos.")

# Herramientas del contrato de Dussan que SIMFI no soporta. Se declaran como no
# disponibles en lugar de crear una implementacion alterna o inventar informacion.
NO_DISPONIBLES = {
    "consultar_remisiones": (
        "SIMFI no tiene un modulo de remisiones: no existe informacion de "
        "remisiones en este sistema y por lo tanto no hay nada que consultar."),
}

# Herramientas que Dussan no ejecuta nunca. SIMFI exige que la operacion se
# realice desde su propio modulo, con sus validaciones y su trazabilidad.
SENSIBLES = {
    "ejecutar_proceso": ("Dussan no ejecuta procesos. Abre el modulo de SIMFI "
                         "correspondiente y ejecuta la operacion ahi."),
    "modificar_datos": ("Dussan no modifica datos del proyecto. Edita el registro "
                        "en el modulo de SIMFI que le corresponde."),
    "eliminar_datos": ("Dussan no elimina datos. Elimina el registro desde el "
                       "modulo de SIMFI que le corresponde."),
}

# Modulos de SIMFI que Dussan puede abrir. Cada clave corresponde al endpoint
# real de Flask; el resolutor de URLs vive en la capa web (app.py).
MODULOS = {
    "inicio": ("Inicio", "index"),
    "superficies": ("Superficies", "superficies"),
    "rodales": ("Rodales (UMM)", "listar_rodales"),
    "inventario": ("Inventario por rodal", "listar_tablas"),
    "cartografia": ("Cartografia", "cartografia"),
    "crecimiento": ("Resumen de crecimiento", "ver_crecimiento"),
    "tiempo_paso": ("Tiempo de paso (Klepac)", "listar_tp"),
    "reportes": ("Centro de reportes", "reportes"),
    "interpretacion": ("Interpretacion integral", "reporte_interpretacion_integral"),
    "concentrado": ("Reporte concentrado", "reporte_concentrado"),
    "existencias": ("Cuadro de existencias", "reporte_cuadro_existencias"),
    "incrementos": ("Resumen de incrementos", "reporte_resumen_incrementos"),
    "carbono": ("Carbono y oxigeno", "reporte_carbono"),
    "graficas": ("Graficas", "graficas"),
    "aclareos": ("Aclareos", "aclareos"),
    "cortas": ("Plan de cortas", "ver_cortas"),
    "turnos": ("Turnos", "turnos"),
    "volumen": ("Volumen individual", "volumen_individual"),
    "muestreo": ("Error de muestreo", "error_muestreo"),
    "especies": ("Especies", "listar_especies"),
    "ajustes": ("Ajustes", "ajustes"),
    "archivos": ("Archivos de proyecto", "listar_archivos"),
}

# Endpoint de Flask -> modulo de Dussan. Permite saber en que modulo esta el
# usuario sin inventar un router en el frontend.
MODULOS_POR_ENDPOINT = {endpoint: modulo
                        for modulo, (_etiqueta, endpoint) in MODULOS.items()}

# Endpoint de Flask que sirve cada reporte en pantalla -> clave de reporte. Son
# las mismas claves que las vistas ya publican como ia_tipo.
REPORTE_POR_ENDPOINT = {
    "superficies": "superficies",
    "dashboard_rodal": "dashboard_rodal",
    "dashboard_rodal_especie": "dashboard_rodal",
    "reporte_tabla": "reporte_tabla",
    "reporte_klepac": "klepac",
    "interpretar_error_muestreo": "muestreo",
    "reporte_interpretacion_integral": "integral",
    "reporte_concentrado": "concentrado",
    "reporte_cuadro_existencias": "cuadro_existencias",
    "reporte_resumen_incrementos": "incrementos",
    "reporte_carbono": "carbono",
    "intensidad_corta_aclareos": "aclareos",
    "turnos": "turnos",
}


def reporte_desde_endpoint(endpoint):
    """Clave del reporte que se esta mostrando en la pagina actual."""
    return REPORTE_POR_ENDPOINT.get(str(endpoint or ""), "")


# Reportes que Dussan reconoce para reinterpretar con el motor de IA existente.# Las claves son las de ia_interpretacion.TITULOS.
REPORTES = {
    "proyecto": "Reporte general del proyecto",
    "integral": "Reporte integral de interpretacion",
    "concentrado": "Reporte concentrado",
    "cuadro_existencias": "Cuadro de existencias",
    "incrementos": "Resumen de incrementos",
    "carbono": "Carbono y oxigeno",
    "muestreo": "Analisis de error de muestreo",
    "reporte_tabla": "Reporte de tabla de inventario",
    "dashboard_rodal": "Resumen por rodal",
    "klepac": "Reporte Klepac",
    "superficies": "Cuadro de superficies",
    "aclareos": "Evaluacion de intensidad de corta por aclareos",
    "turnos": "Calculo de turno tecnico",
}

# Capa de estilo conversacional. Las prohibiciones forestales (no recalcular, no
# inventar, terminologia) NO se repiten aqui: provienen del prompt maestro de
# ia_config, que es la unica fuente de verdad para las reglas de la IA.
_CAPA_DUSSAN = (
    "Eres Dussan, el asistente virtual tecnico-operativo de SIMFI, con identidad "
    "de perro pastor aleman de estilo forestal profesional.\n"
    "SIMFI CALCULA Y VALIDA. TU SOLO CONSERVAS, INTERPRETAS Y ORIENTES.\n\n"
    "COMO RESPONDES:\n"
    "- Responde de forma breve, concreta y conversacional, en dos a seis frases.\n"
    "- No utilizes encabezados, listas, tablas, vinetas ni Markdown.\n"
    "- Usa exclusivamente los resultados de SIMFI que se entregan a continuacion: "
    "esos resultados son la unica fuente de verdad.\n"
    "- No recalcules, no completes valores ausentes y no deduzcas cifras que no "
    "esten entregadas.\n"
    "- Si la respuesta no esta en los datos entregados, dilo con claridad e indica "
    "en que modulo de SIMFI se revisa. No lo aproximes.\n"
    "- Distingue siempre entre el dato calculado por SIMFI y tu interpretacion "
    "tecnica de ese dato.\n"
    "- No emitas recomendaciones, prescripciones silvicolas ni decisiones de "
    "manejo que SIMFI no haya proporcionado.\n"
    "- No califiques los resultados como buenos, malos, optimos, adecuados, "
    "inadecuados, altos, bajos, sostenibles o deficientes salvo que SIMFI lo haya "
    "hecho explicitamente.\n"
    "- Terminologia: usa siempre predio y nunca finca; usa UMM o rodal para la "
    "unidad de manejo; usa diametro normal cuando corresponda.\n"
)


def dussan_habilitado(config=None):
    """Indica si el asistente Dussan debe mostrarse. Nunca hace llamadas de red."""
    config = config if config is not None else _cargar_config()
    if not config:
        return False
    if not config.get("habilitada", True):
        return False
    # Opt-in: desactivado por defecto para no ocupar espacio.
    return bool(config.get("dussan", {}).get("habilitado", False))


def voz_habilitada(config=None):
    """La voz se integra desde el inicio pero permanece desactivada por defecto."""
    config = config if config is not None else _cargar_config()
    if not config:
        return False
    return bool(config.get("dussan", {}).get("voz", False))


def _dato(valor, defecto="No registrado en el proyecto"):
    """Normaliza valores ausentes sin inventar contenido."""
    if valor is None:
        return defecto
    if isinstance(valor, str):
        return valor.strip() or defecto
    return valor


def _redondear(valor, decimales=3):
    try:
        return round(float(valor), decimales)
    except (TypeError, ValueError):
        return valor


def _contexto_predio(pmf):
    """Identidad del proyecto. Nunca incluye rutas del sistema de archivos."""
    return {
        "proyecto": _dato(pmf.nombre),
        "predio": _dato(pmf.predio or pmf.nombre),
        "municipio": _dato(pmf.municipio),
        "estado": _dato(pmf.estado),
        "propietario": _dato(pmf.propietario),
        "superficie_total_ha": _redondear(pmf.superficie_total_ha),
        "umm_evaluadas": pmf.num_rodales,
        "especies_registradas": len(pmf.especies),
    }


def _rodal_solicitado(argumentos, estado):
    """Resuelve el rodal/UMM solicitado validandolo contra los existentes."""
    solicitado = str((argumentos or {}).get("rodal", "") or "").strip()
    if not solicitado:
        return (estado.get("rodal_actual") or ""), None
    pmf = estado.get("pmf")
    for rodal in (pmf.rodales_visibles if pmf is not None else []):
        if rodal.id.casefold() == solicitado.casefold():
            return rodal.id, rodal
    return solicitado, None


def _consultar_predios(pmf, argumentos, estado):
    return {"proyecto": _contexto_predio(pmf), "nota": NOTA_UMM}


def _consultar_rodales(pmf, argumentos, estado):
    rodales = [{"id": r.id, "superficie_ha": _redondear(r.superficie_ha),
                "sitios": r.sitios, "tipo_inventario": _dato(r.tipo_inventario, "sitios")}
               for r in pmf.rodales_visibles]
    return {"proyecto": _dato(pmf.predio or pmf.nombre), "umm_evaluadas": len(rodales),
            "rodales": rodales, "nota": NOTA_UMM}


def _consultar_existencias(pmf, argumentos, estado):
    """Lee el cuadro de existencias oficial. No recalcula ningun indicador."""
    try:
        from reportes_tecnicos import construir_datos_reporte_existencias
        datos = construir_datos_reporte_existencias(pmf)
    except Exception as error:
        return {"ok": False,
                "mensaje": "No se pudo leer el cuadro de existencias: %s" % error}
    generales = datos.get("generales", {})
    _id_rodal, rodal = _rodal_solicitado(argumentos, estado)
    if rodal is not None:
        filas = [r for r in datos.get("rodales", []) if r.get("id") == rodal.id]
    else:
        filas = datos.get("rodales", [])
    return {
        "proyecto": generales.get("predio"),
        "balance_volumetrico": datos.get("balance"),
        "totales": {clave: _redondear(generales.get(clave)) for clave in
                    ("superficie", "existencias", "existencias_ha", "ab", "posibilidad",
                     "posibilidad_ha", "residual", "residual_ha", "res_ab",
                     "intensidad", "intensidad_residual")},
        "rodales": [{"id": r.get("id"), "superficie_ha": _redondear(r.get("superficie")),
                     "existencias_m3": _redondear(r.get("existencias")),
                     "existencias_ha": _redondear(r.get("existencias_ha")),
                     "posibilidad_m3": _redondear(r.get("posibilidad")),
                     "intensidad_pct": _redondear(r.get("intensidad"), 2),
                     "especie_dominante": r.get("dominante"),
                     "tratamiento": r.get("tratamiento")} for r in filas],
        "especies": [{"especie": e.get("especie"),
                      "existencias_m3": _redondear(e.get("existencias")),
                      "participacion_vol_pct": _redondear(e.get("participacion_vol"), 2),
                      "condicion": e.get("condicion")} for e in datos.get("especies", [])],
        "nota": NOTA_UMM,
    }


def _consultar_muestreo(pmf, argumentos, estado):
    """Lee los analisis de error de muestreo ya calculados por SIMFI."""
    registros = []
    for registro in reversed(list(getattr(pmf, "reportes_error_muestreo", []) or [])):
        if not isinstance(registro, dict):
            continue
        resultado = registro.get("resultado")
        general = (resultado.get("general") or {}) if isinstance(resultado, dict) else {}
        general = general if isinstance(general, dict) else {}
        registros.append({
            "id": registro.get("id", ""),
            "fecha": registro.get("fecha", ""),
            "usuario": registro.get("usuario", ""),
            "archivo": registro.get("archivo_nombre", ""),
            "version_motor": registro.get("version_motor", ""),
            "estado_comprobacion": registro.get("estado_comprobacion", ""),
            "media_m3_ha": _redondear(general.get("media_m3_ha"), 2),
            "error_relativo_pct": _redondear(
                general.get("error_relativo_final_pct",
                            general.get("error_relativo_pct")), 2),
            "estado": general.get("estado", ""),
            "rodales_excluidos": len(registro.get("rodales_excluidos") or []),
        })
    return {
        "proyecto": _dato(pmf.predio or pmf.nombre),
        "analisis_confirmados": len(registros),
        "analisis": registros,
        "borradores_en_trabajo": len(getattr(pmf, "muestreo_borradores", []) or []),
        "nota": ("El error de muestreo lo calcula y valida el motor de SIMFI; "
                 "Dussan solo lo lee y lo explica."),
    }


def _consultar_incremento(pmf, argumentos, estado):
    """Lee el resumen de incrementos oficial del proyecto."""
    try:
        resumen = pmf.resumen_incrementos()
    except Exception as error:
        return {"ok": False,
                "mensaje": "No se pudo leer el resumen de incrementos: %s" % error}
    crecimiento = pmf.crecimiento
    return {
        "proyecto": _dato(pmf.predio or pmf.nombre),
        "resumen": resumen,
        "crecimiento": {
            "volumen_actual_m3ha": _redondear(crecimiento.volumen_actual_m3ha),
            "edad_actual_anios": _redondear(crecimiento.edad_actual_anios, 1),
            "calidad_sitio": _dato(crecimiento.calidad_sitio),
            "ima_esperado": _redondear(crecimiento.ima_esperado),
        },
        "nota": "Los incrementos y el IMA ya fueron calculados por SIMFI.",
    }


def _consultar_turno(pmf, argumentos, estado):
    """Lee los calculos de turno ya guardados en el proyecto."""
    calculos = []
    for calculo in getattr(pmf, "calculos_turno", []) or []:
        if not isinstance(calculo, dict):
            continue
        calculos.append({clave: (_redondear(valor) if isinstance(valor, (int, float)) else valor)
                         for clave, valor in calculo.items()
                         if clave not in ("grafica_png", "ruta_archivo", "id")})
    return {
        "proyecto": _dato(pmf.predio or pmf.nombre),
        "calculos_guardados": len(calculos),
        "calculos": calculos,
        "tiempo_paso_registrado": bool(getattr(pmf, "tiempo_paso", None)),
        "nota": ("El turno tecnico se calcula en el modulo Turnos de SIMFI; "
                 "Dussan no calcula turnos."),
    }


def _abrir_modulo(pmf, argumentos, estado):
    modulo = str((argumentos or {}).get("modulo", "") or "").strip().casefold()
    if not modulo:
        return {"ok": False, "mensaje": "No se indico ningun modulo.",
                "modulos": sorted(MODULOS)}
    if modulo not in MODULOS:
        return {"ok": False, "modulos": sorted(MODULOS),
                "mensaje": "SIMFI no tiene un modulo llamado '%s'." % modulo}
    etiqueta, endpoint = MODULOS[modulo]
    return {"ok": True, "modulo": modulo, "etiqueta": etiqueta, "destino": endpoint,
            "mensaje": "Abriendo %s." % etiqueta}


_HERRAMIENTAS_LECTURA = {
    "consultar_predios": _consultar_predios,
    "consultar_rodales": _consultar_rodales,
    "consultar_existencias": _consultar_existencias,
    "consultar_muestreo": _consultar_muestreo,
    "consultar_incremento": _consultar_incremento,
    "consultar_turno": _consultar_turno,
    "abrir_modulo": _abrir_modulo,
}

# Contrato expuesto al frontend. Las herramientas no disponibles se declaran
# explicitamente para que Dussan responda que no existen en lugar de inventar.
CONTRATO = {
    "consultar_predios": {"permission": "read", "args": []},
    "consultar_rodales": {"permission": "read", "args": ["predio"]},
    "consultar_existencias": {"permission": "read", "args": ["predio", "umm", "rodal"]},
    "consultar_muestreo": {"permission": "read", "args": ["predio", "rodal"]},
    "consultar_incremento": {"permission": "read", "args": ["predio", "rodal"]},
    "consultar_turno": {"permission": "read", "args": ["predio"]},
    "consultar_remisiones": {"permission": "read", "args": ["predio"], "disponible": False},
    "abrir_modulo": {"permission": "navigate", "args": ["modulo"]},
    "generar_interpretacion": {"permission": "interpret", "args": ["reporte", "contexto"]},
    "exportar_reporte": {"permission": "export", "args": ["reporte", "formato"]},
    "ejecutar_proceso": {"permission": "execute", "requiere_confirmacion": True,
                         "args": ["proceso"], "disponible": False},
    "modificar_datos": {"permission": "write", "requiere_confirmacion": True,
                        "args": ["operacion"], "disponible": False},
    "eliminar_datos": {"permission": "delete", "requiere_confirmacion": True,
                       "args": ["objetivo"], "disponible": False},
}


def herramientas_disponibles():
    """Nombres de herramientas que Dussan puede ejecutar realmente."""
    return sorted(_HERRAMIENTAS_LECTURA)


def modulo_desde_endpoint(endpoint):
    """Modulo de Dussan que corresponde al endpoint de Flask que se esta sirviendo."""
    return MODULOS_POR_ENDPOINT.get(str(endpoint or ""), "inicio")


def contexto(pmf, modulo="", reporte_activo="", usuario="", rol="", version_sistema="",
             rodal_actual="", endpoint=""):
    """Construye el contexto que Dussan recibe en cada pagina de SIMFI."""
    modulo = str(modulo or "").strip()
    etiqueta = MODULOS.get(modulo, ("", ""))[0]
    reporte = str(reporte_activo or "").strip() or reporte_desde_endpoint(endpoint)
    if reporte and reporte not in REPORTES:
        reporte = ""
    rodales = [{"id": r.id, "superficie_ha": _redondear(r.superficie_ha), "sitios": r.sitios}
               for r in pmf.rodales_visibles]
    rodal_actual = str(rodal_actual or "").strip()
    if rodal_actual and not any(r["id"].casefold() == rodal_actual.casefold() for r in rodales):
        rodal_actual = ""
    estado = {
        "proyecto": _contexto_predio(pmf),
        "modulo": modulo,
        "modulo_etiqueta": etiqueta or "Inicio",
        "modulo_endpoint": str(endpoint or ""),
        "reporte_activo": reporte,
        "reporte_etiqueta": REPORTES.get(reporte, ""),
        "rodal_actual": rodal_actual,
        "usuario": str(usuario or ""),
        "rol": str(rol or ""),
        "version_sistema": str(version_sistema or ""),
        "nota_umm": NOTA_UMM,
    }
    return {"estado": estado, "rodales": rodales, "pmf": pmf}


def contexto_plano(contexto_envuelto):
    """Vista plana del contexto, con el proyecto disponible para las herramientas.

    Nunca se serializa a JSON: el objeto del proyecto no sale del servidor.
    """
    if not contexto_envuelto:
        return {}
    plano = dict(contexto_envuelto.get("estado") or {})
    plano["pmf"] = contexto_envuelto.get("pmf")
    plano["rodales"] = contexto_envuelto.get("rodales") or []
    return plano


def ejecutar_herramienta(nombre, argumentos, estado):
    """Ejecuta una herramienta de lectura sobre resultados ya calculados.

    Devuelve siempre un dict con ``ok``. Nunca escribe ni recalcula.
    """
    nombre = str(nombre or "").strip()
    if nombre in NO_DISPONIBLES:
        return {"ok": False, "no_disponible": True, "herramienta": nombre,
                "mensaje": NO_DISPONIBLES[nombre]}
    if nombre in SENSIBLES:
        return {"ok": False, "requiere_confirmacion": True, "herramienta": nombre,
                "mensaje": SENSIBLES[nombre]}
    funcion = _HERRAMIENTAS_LECTURA.get(nombre)
    if funcion is None:
        return {"ok": False, "herramienta": nombre,
                "mensaje": "La herramienta '%s' no existe o no esta habilitada." % nombre}
    pmf = estado.get("pmf")
    if pmf is None:
        return {"ok": False, "herramienta": nombre,
                "mensaje": "No hay un proyecto abierto en esta sesion."}
    try:
        resultado = funcion(pmf, argumentos or {}, estado)
    except Exception as error:  # Una consulta fallida nunca interrumpe SIMFI.
        registrar_ia("error", "dussan herramienta=%s error=%r", nombre, error, exc_info=True)
        return {"ok": False, "herramienta": nombre,
                "mensaje": "No se pudo consultar esa informacion en SIMFI: %s" % error}
    if not isinstance(resultado, dict):
        return {"ok": False, "herramienta": nombre,
                "mensaje": "La herramienta no devolvio datos."}
    if resultado.get("ok") is False:
        return {"ok": False, "herramienta": nombre, "datos": resultado,
                "mensaje": resultado.get("mensaje", "No hay informacion disponible.")}
    limpio = {clave: valor for clave, valor in resultado.items() if clave != "ok"}
    return {"ok": True, "herramienta": nombre, "datos": limpio,
            "mensaje": limpio.get("mensaje") or "Informacion consultada en SIMFI."}


def _descripcion(datos):
    try:
        return json.dumps(datos, ensure_ascii=False, indent=2, default=str)
    except (TypeError, ValueError):
        return str(datos)


# Enrutado por palabras clave. Solo decide QUE CONSULTA; nunca calcula.
_ROUTING = (
    (("remision", "remision"), "consultar_remisiones"),
    (("muestreo", "precision", "exactitud"), "consultar_muestreo"),
    (("turno",), "consultar_turno"),
    (("incremento", "ima", "crecimiento"), "consultar_incremento"),
    (("existencia", "volumen", "posibilidad", "residual", "area basal", "intensidad"),
     "consultar_existencias"),
    (("rodal", "umm"), "consultar_rodales"),
    (("predio", "proyecto", "superficie"), "consultar_predios"),
)

_MODULO_HERRAMIENTA = {
    "existencias": "consultar_existencias",
    "concentrado": "consultar_existencias",
    "interpretacion": "consultar_existencias",
    "muestreo": "consultar_muestreo",
    "incrementos": "consultar_incremento",
    "turnos": "consultar_turno",
    "rodales": "consultar_rodales",
    "inventario": "consultar_rodales",
}


def seleccionar_herramientas(pregunta, estado):
    """Decide que herramientas de lectura consultar para una pregunta."""
    texto = str(pregunta or "").casefold()
    nombres = []
    for claves, nombre in _ROUTING:
        if any(clave in texto for clave in claves) and nombre not in nombres:
            nombres.append(nombre)
    if nombres:
        return nombres
    # Sin palabra clave: se consulta lo que corresponde al modulo activo.
    return [_MODULO_HERRAMIENTA.get(estado.get("modulo"), "consultar_predios")]


def _resumen_deterministico(estado, resultados):
    """Redacta un resumen con valores ya calculados por SIMFI, sin IA."""
    proyecto = estado.get("proyecto", {})
    partes = ["Dussan consultó estos resultados de SIMFI para el predio %s."
              % _dato(proyecto.get("predio"), "No identificado")]
    for resultado in resultados:
        if not resultado.get("ok"):
            partes.append(resultado.get("mensaje") or "No hay información disponible.")
            continue
        datos = resultado.get("datos") or {}
        herramienta = resultado.get("herramienta")
        if herramienta == "consultar_predios":
            proyecto_ = datos.get("proyecto", {})
            partes.append(
                "El proyecto %s tiene %s ha registrados, %s UMM (rodales) y %s especies."
                % (_dato(proyecto_.get("proyecto"), "No identificado"),
                   _dato(proyecto_.get("superficie_total_ha"), 0),
                   _dato(proyecto_.get("umm_evaluadas"), 0),
                   _dato(proyecto_.get("especies_registradas"), 0)))
        elif herramienta == "consultar_rodales":
            rodales = datos.get("rodales") or []
            if rodales:
                partes.append("UMM evaluadas: %s." % ", ".join(
                    "%s (%s ha, %s sitios)" % (r.get("id"), r.get("superficie_ha"), r.get("sitios"))
                    for r in rodales))
            else:
                partes.append("No hay UMM registradas en el proyecto.")
        elif herramienta == "consultar_existencias":
            totales = datos.get("totales") or {}
            partes.append(
                "El cuadro de existencias calcula %s m3 VTA totales (%s m3/ha), con "
                "posibilidad de %s m3 VTA (%s m3/ha), residual de %s m3 VTA y una "
                "intensidad calculada de %s %%."
                % (_dato(totales.get("existencias"), 0), _dato(totales.get("existencias_ha"), 0),
                   _dato(totales.get("posibilidad"), 0), _dato(totales.get("posibilidad_ha"), 0),
                   _dato(totales.get("residual"), 0), _dato(totales.get("intensidad"), 0)))
            rodales = datos.get("rodales") or []
            if len(rodales) == 1:
                rodal = rodales[0]
                partes.append("En la UMM %s: %s m3 VTA, intensidad de %s %% y especie "
                              "dominante %s."
                              % (_dato(rodal.get("id"), "No identificada"),
                                 _dato(rodal.get("existencias_m3"), 0),
                                 _dato(rodal.get("intensidad_pct"), 0),
                                 _dato(rodal.get("especie_dominante"), "No registrada")))
        elif herramienta == "consultar_muestreo":
            analisis = datos.get("analisis") or []
            if not analisis:
                partes.append("No hay análisis de error de muestreo confirmados en el proyecto.")
            for registro in analisis[:3]:
                partes.append(
                    "Análisis %s del %s: media de %s m3/ha y error general de %s %% (%s)."
                    % (_dato(registro.get("archivo"), "sin nombre"),
                       _dato(registro.get("fecha"), "sin fecha"),
                       _dato(registro.get("media_m3_ha"), "no calculada"),
                       _dato(registro.get("error_relativo_pct"), "no calculable"),
                       _dato(registro.get("estado"), "sin estado")))
        elif herramienta == "consultar_incremento":
            crecimiento = datos.get("crecimiento") or {}
            partes.append(
                "El crecimiento registra %s m3/ha a los %s años, con calidad de sitio %s e "
                "IMA esperado de %s."
                % (_dato(crecimiento.get("volumen_actual_m3ha"), 0),
                   _dato(crecimiento.get("edad_actual_anios"), 0),
                   _dato(crecimiento.get("calidad_sitio"), "No registrada"),
                   _dato(crecimiento.get("ima_esperado"), "No registrado")))
        elif herramienta == "consultar_turno":
            calculos = datos.get("calculos") or []
            if not calculos:
                partes.append("No hay cálculos de turno guardados en el proyecto activo.")
            else:
                partes.append("El proyecto tiene %s cálculos de turno guardados."
                              % len(calculos))
    return " ".join(partes)


def consultar_y_responder(pregunta, estado, nombres=None, argumentos=None, config=None):
    """Flujo completo de Dussan: consultar SIMFI y responder con el motor de IA.

    Si el motor de IA no esta disponible, devuelve un resumen determinista
    formado unicamente con valores que SIMFI ya calculo.
    """
    estado = dict(estado or {})
    estado.setdefault("pmf", None)
    nombres = list(nombres) if nombres else seleccionar_herramientas(pregunta, estado)
    argumentos = dict(argumentos or {})
    if not argumentos.get("rodal") and estado.get("rodal_actual"):
        argumentos["rodal"] = estado["rodal_actual"]
    resultados = [ejecutar_herramienta(nombre, argumentos, estado) for nombre in nombres]
    exitosos = [r for r in resultados if r.get("ok")]
    base = {"herramientas": [{"herramienta": r.get("herramienta"), "ok": r.get("ok"),
                              "mensaje": r.get("mensaje")} for r in resultados],
            "datos": [r.get("datos") for r in exitosos]}
    if not exitosos:
        mensaje = " ".join(r.get("mensaje") or "No hay informacion disponible."
                           for r in resultados)
        return dict(base, ok=False, texto=None, mensaje=mensaje)
    respuesta = responder(pregunta, estado, [r.get("datos") for r in exitosos], config)
    if respuesta.get("ok"):
        return dict(base, ok=True, texto=respuesta.get("texto"),
                    motor=respuesta.get("motor"), modelo=respuesta.get("modelo"),
                    metadatos=respuesta.get("metadatos") or {})
    resumen = _resumen_deterministico(estado, exitosos)
    return dict(base, ok=True, texto=resumen, motor="determinista",
                aviso=respuesta.get("mensaje"))


def construir_mensaje(pregunta, estado, resultados):
    """Compone el mensaje del usuario con el contexto y los resultados leidos."""
    proyecto = estado.get("proyecto", {})
    return (
        "Contexto de la sesion de SIMFI:\n"
        "- Proyecto: %s\n"
        "- Predio: %s\n"
        "- Modulo: %s\n"
        "- UMM/rodal activo: %s\n"
        "- Usuario: %s (rol: %s)\n"
        "- %s\n\n"
        "Resultados de SIMFI para esta respuesta (unica fuente de verdad):\n%s"
        % (_dato(proyecto.get("proyecto"), "No identificado"),
           _dato(proyecto.get("predio"), "No identificado"),
           _dato(estado.get("modulo_etiqueta"), "Inicio"),
           estado.get("rodal_actual") or "ninguno seleccionado",
           _dato(estado.get("usuario"), "local"),
           _dato(estado.get("rol"), "consulta"),
           NOTA_UMM,
           _descripcion(resultados))
    )


def responder(pregunta, estado, resultados, config=None):
    """Responde con el motor de IA que ya existe en SIMFI.

    ``resultados`` es la lista de salidas de herramientas ya consultadas. La
    respuesta se limita a esa informacion: Dussan no accede al proyecto por su
    cuenta ni calcula nada.
    """
    if not _BASE_IA_OK or _SERVICIO is None:
        return {"ok": False, "texto": None,
                "mensaje": "El motor de IA no esta disponible en esta instalacion."}
    if not resultados:
        # Dussan no responde sin datos leidos de SIMFI: no inventa.
        return {"ok": False, "texto": None,
                "mensaje": ("No consulte todavia ningun resultado de SIMFI; "
                            "Dussan no responde sin datos de SIMFI.")}
    config = config if config is not None else _cargar_config()
    if not config or not config.get("habilitada", True):
        return {"ok": False, "texto": None,
                "mensaje": "La integracion de IA esta deshabilitada."}
    if not dussan_habilitado(config):
        return {"ok": False, "texto": None,
                "mensaje": "El asistente Dussan esta deshabilitado."}
    maestro = str(config.get("prompt_sistema", "") or "").strip()
    sistema = maestro + "\n\n" + _CAPA_DUSSAN if maestro else _CAPA_DUSSAN
    cuerpo = (sistema + "\n\nPregunta del usuario:\n" + str(pregunta or "").strip() +
              "\n\n" + construir_mensaje(pregunta, estado, resultados))
    resultado = _SERVICIO.interpret(resultados, "dussan", cuerpo, config)
    if not resultado.get("ok"):
        return {"ok": False, "texto": None,
                "mensaje": resultado.get("mensaje") or "No se pudo generar una respuesta."}
    texto = normalizar_terminologia(str(resultado.get("texto") or "").strip())
    if not texto:
        return {"ok": False, "texto": None,
                "mensaje": "El motor de IA no devolvio texto."}
    registrar_ia("info", "dussan respuesta ok motor=%s modelo=%s",
                 resultado.get("motor"), resultado.get("modelo"))
    return {"ok": True, "texto": texto, "motor": resultado.get("motor"),
            "modelo": resultado.get("modelo"),
            "metadatos": resultado.get("metadatos") or {}}
