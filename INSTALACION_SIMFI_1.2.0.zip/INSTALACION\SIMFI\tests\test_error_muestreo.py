import unittest
import io
import json
import re
import zipfile
from unittest.mock import patch

import app as app_module
from error_muestreo import ErrorMuestreoValidacion, calcular_error_muestreo, valor_t
from interpretacion_muestreo import interpretar_muestreo
from diagnostico_muestreo import diagnosticar_muestreo, _asignacion_incremental
from modelos import PMFProyecto


def sitio(identificador, numero, volumen, area=400, estado="completado_datos"):
    return {"id": identificador, "numero": numero, "rodal_id": 1, "estado": estado,
            "tamano_m2": area, "factor_expansion": 10000 / area,
            "volumen_sitio_m3": volumen / (10000 / area), "volumen_ha_m3": volumen,
            "volumen_especies": [] if volumen == 0 else [{"especie_id": 1, "volumen_sitio_m3": volumen / (10000 / area)}]}


def documento_prueba(sitios=None, fpc=False):
    sitios = sitios or [sitio(1, 1, 100), sitio(2, 2, 200)]
    return {"schema": "simfi.muestreo", "version": "1.0", "errores": [],
            "predio": {"id": 1, "nombre": "Prueba", "superficie_total_ha": 10},
            "configuracion": {"diseno_muestreo": "estratificado", "nivel_confianza": 95,
                              "error_objetivo_pct": 10, "variable_volumen": "VTACC", "unidad": "m3_ha",
                              "aplicar_correccion_poblacion_finita": fpc},
            "resumen_validacion": {"validos_para_simfi": len(sitios), "completados_cero": sum(s["estado"] == "completado_cero" for s in sitios)},
            "resumen_muestreo": {}, "advertencias": [],
            "trazabilidad": {"sitios_incluidos": [s["id"] for s in sitios]},
            "rodales": [{"id": 1, "clave": "R-1", "superficie_ha": 10, "sitios": sitios}]}


# Predio de referencia de la especificación (motor 3.0): 21 rodales, 103 sitios
# de 1000 m2, volúmenes en m3 por sitio (se multiplican por el factor de
# expansión x10 para obtener m3/ha). Confianza 95 %, objetivo 10 %.
DATOS_PREDIO_21_RODALES = [
    ("RODAL 1", 8.878, [25.79, 21.92, 18.27, 15.68]),
    ("RODAL 2", 13.869, [15.26, 16.23, 17.50]),
    ("RODAL 3", 21.575, [18.99, 14.02, 10.58, 14.69, 15.73]),
    ("RODAL 4", 20.350, [16.43, 1.04, 16.28, 17.80, 11.07, 10.80, 11.26, 9.99, 8.26, 14.97, 12.67, 4.09]),
    ("RODAL 5", 3.278, [22.00, 27.37, 18.47, 24.05]),
    ("RODAL 6", 7.367, [28.77, 29.99, 23.03, 15.99, 22.38]),
    ("RODAL 7", 24.923, [16.94, 28.97, 18.49, 19.62, 20.80, 24.44, 8.83, 17.85, 14.64, 14.70, 7.07]),
    ("RODAL 8", 2.949, [14.07, 18.25, 7.61, 19.14]),
    ("RODAL 9", 1.549, [30.88, 27.16, 24.25]),
    ("RODAL 10", 5.963, [14.39, 30.68, 14.70, 7.25, 4.43, 13.53, 6.65]),
    ("AR-1980-1CC", 5.727, [7.50, 2.15, 5.19, 8.38]),
    ("AR-1983-1CC", 2.823, [14.63, 10.93, 16.63, 20.01]),
    ("AR-1986-1CC", 5.568, [14.31, 15.30, 16.10, 18.48, 10.55, 15.72]),
    ("AR-1987-1CC", 5.507, [9.09, 8.55, 6.87]),
    ("AR-1988-1CC", 4.879, [6.34, 6.34, 2.83]),
    ("AR-1989-1CC", 8.752, [6.09, 9.56, 10.32, 5.48, 8.69]),
    ("AR-1990-1CC", 5.386, [7.35, 2.07, 7.86, 3.77, 4.42, 4.43]),
    ("AR-1-2CC", 3.801, [6.55, 6.36, 5.76, 5.85]),
    ("AR-2-2CC", 4.401, [1.33, 0.30, 0.55]),
    ("AR-3-2CC", 3.969, [0.84, 0.27, 0.57]),
    ("AR-4-2CC", 4.650, [1.62, 0.41, 0.35, 0.98]),
]


def documento_predio_21_rodales():
    area_m2 = 1000.0
    fe = 10000 / area_m2
    rodales, incluidos, sid = [], [], 1
    for idx, (clave, ha, vols) in enumerate(DATOS_PREDIO_21_RODALES, start=1):
        sitios = []
        for numero, vol_m3 in enumerate(vols, start=1):
            vol_ha = vol_m3 * fe
            sitios.append({"id": sid, "numero": numero, "rodal_id": idx, "estado": "completado_datos",
                           "tamano_m2": area_m2, "factor_expansion": fe,
                           "volumen_sitio_m3": vol_m3, "volumen_ha_m3": vol_ha,
                           "volumen_especies": [{"especie_id": 1, "volumen_sitio_m3": vol_m3}]})
            incluidos.append(sid)
            sid += 1
        rodales.append({"id": idx, "clave": clave, "superficie_ha": ha, "sitios": sitios})
    total_sitios = sum(len(v) for _, _, v in DATOS_PREDIO_21_RODALES)
    total_ha = sum(ha for _, ha, _ in DATOS_PREDIO_21_RODALES)
    return {"schema": "simfi.muestreo", "version": "1.0", "errores": [],
            "predio": {"id": 1, "nombre": "Predio 21 rodales", "superficie_total_ha": total_ha},
            "configuracion": {"diseno_muestreo": "estratificado", "nivel_confianza": 95,
                              "error_objetivo_pct": 10, "variable_volumen": "VTACC", "unidad": "m3_ha",
                              "aplicar_correccion_poblacion_finita": False},
            "resumen_validacion": {"validos_para_simfi": total_sitios, "completados_cero": 0},
            "resumen_muestreo": {}, "advertencias": [],
            "trazabilidad": {"sitios_incluidos": incluidos},
            "rodales": rodales}


class PredioReferencia21RodalesTest(unittest.TestCase):
    """Predio de aceptación de la especificación (motor 3.0, 103 sitios)."""

    @classmethod
    def setUpClass(cls):
        cls.resultado = calcular_error_muestreo(documento_predio_21_rodales())

    def test_resultado_general(self):
        general = self.resultado["resultado_general"]
        self.assertAlmostEqual(general["media_m3_ha"], 130.52, places=2)
        self.assertAlmostEqual(general["volumen_estimado_m3"], 21687.28, places=2)
        self.assertAlmostEqual(general["grados_libertad"], 34.78, places=2)
        self.assertAlmostEqual(general["t_critico"], 2.031, places=3)
        self.assertAlmostEqual(general["error_relativo_pct"], 6.78, places=2)
        self.assertEqual(general["estado"], "Cumple")

    def test_n_requerido_predio_44_sitios_sin_faltantes(self):
        # Cambio 5: n requerido a nivel predio con objetivo 10 % -> 44 sitios;
        # como ya hay 103 sitios válidos, no faltan sitios.
        general = self.resultado["resultado_general"]
        self.assertEqual(general["n_requerido_predio"], 44)
        self.assertEqual(general["n_faltantes_predio"], 0)
        self.assertEqual(self.resultado["validacion"]["sitios_validos"], 103)
        distribucion = general["distribucion_sugerida_por_rodal"]
        self.assertEqual(len(distribucion), 21)
        self.assertTrue(all(item["n_h"] >= 2 for item in distribucion))

    def test_error_por_rodal_primeros_tres(self):
        rodales = self.resultado["rodales"]
        self.assertAlmostEqual(rodales[0]["estadistica"]["error_relativo_pct"], 33.54, places=2)
        self.assertAlmostEqual(rodales[1]["estadistica"]["error_relativo_pct"], 16.90, places=2)
        self.assertAlmostEqual(rodales[2]["estadistica"]["error_relativo_pct"], 25.16, places=2)

    def test_no_division_general_y_todos_los_rodales(self):
        general = self.resultado["resultado_general"]
        self.assertEqual(general["error_relativo_final_pct"], general["error_relativo_pct"])
        for rodal in self.resultado["rodales"]:
            e = rodal["estadistica"]
            self.assertEqual(e["error_relativo_final_pct"], e["error_relativo_pct"])

    def test_interpretacion_no_asigna_cumple_por_rodal(self):
        analisis = interpretar_muestreo(self.resultado)
        texto_rodales = " ".join(p for p in analisis["parrafos"] if "RODAL 1 " in p or p.startswith("El rodal RODAL 1"))
        # Ningún párrafo de rodal debe usar el lenguaje de cumplimiento normativo.
        for parrafo in analisis["parrafos"]:
            if parrafo.startswith("El rodal "):
                self.assertNotIn(" cumple ", parrafo.lower())
                self.assertNotIn("no cumple", parrafo.lower())
                self.assertIn("resultado general del predio", parrafo.lower())

    def test_dimensionamiento_predio_en_interpretacion_y_pantalla(self):
        analisis = interpretar_muestreo(self.resultado)
        dim = analisis["dimensionamiento_predio"]
        self.assertEqual(dim["n_requerido_predio"], 44)
        self.assertEqual(dim["n_faltantes_predio"], 0)
        self.assertEqual(len(dim["distribucion_sugerida_por_rodal"]), 21)
        titulos = [t for t, _ in analisis["secciones"]]
        self.assertIn("10. Sitios adicionales sugeridos (predio)", titulos)

        proyecto = PMFProyecto("Prueba")
        proyecto.muestreo_error = [{"id": "a1", "resultado": self.resultado}]
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto), patch("app.save_pmf", return_value=True):
            pantalla = cliente.get("/error-muestreo")
            interpretacion = cliente.get("/error-muestreo/interpretacion")
            excel = cliente.get("/error-muestreo/exportar/excel")
        self.assertEqual(pantalla.status_code, 200)
        self.assertEqual(interpretacion.status_code, 200)
        self.assertEqual(excel.status_code, 200)
        html_pantalla = pantalla.get_data(as_text=True)
        self.assertIn("Sitios requeridos del predio", html_pantalla)
        m = re.search(r"Sitios requeridos del predio[^:]*:\s*(\d+)", html_pantalla)
        self.assertIsNotNone(m)
        self.assertEqual(m.group(1), "44")
        self.assertIn("Sitios adicionales sugeridos", interpretacion.get_data(as_text=True))
        from openpyxl import load_workbook
        libro = load_workbook(filename=io.BytesIO(excel.data))
        general = libro["Resultado general"]
        valores = [fila[0].value for fila in general.iter_rows()]
        self.assertIn("n_requerido_predio", valores)
        self.assertIn("Rodal", valores)


class DiagnosticoMuestreo21RodalesTest(unittest.TestCase):
    """Cambio 6: diagnóstico y recomendaciones sobre el predio de referencia."""

    @classmethod
    def setUpClass(cls):
        cls.resultado = calcular_error_muestreo(documento_predio_21_rodales())
        cls.diagnostico = diagnosticar_muestreo(cls.resultado)

    def _aporte(self, clave):
        for a in self.diagnostico["aporte_por_rodal"]:
            if a["clave"] == clave:
                return a
        raise AssertionError(f"{clave} no está en aporte_por_rodal")

    def test_es_funcion_pura_no_modifica_el_resultado(self):
        import copy
        antes = copy.deepcopy(self.resultado)
        diagnosticar_muestreo(self.resultado)
        self.assertEqual(antes, self.resultado)

    def test_aporte_rodal_7_3_4_prioritarios_72_32_acumulado(self):
        r7, r3, r4 = self._aporte("RODAL 7"), self._aporte("RODAL 3"), self._aporte("RODAL 4")
        self.assertAlmostEqual(r7["aporte_pct"], 40.77, places=2)
        self.assertAlmostEqual(r3["aporte_pct"], 15.96, places=2)
        self.assertAlmostEqual(r4["aporte_pct"], 15.59, places=2)
        self.assertAlmostEqual(r4["aporte_acumulado_pct"], 72.32, places=2)
        self.assertEqual(r7["clasificacion"], "Prioritario")
        self.assertEqual(r3["clasificacion"], "Prioritario")
        self.assertEqual(r4["clasificacion"], "Prioritario")
        # El orden descendente de aporte debe corresponder exactamente a estos tres primeros.
        primeros_tres = [a["clave"] for a in self.diagnostico["aporte_por_rodal"][:3]]
        self.assertEqual(primeros_tres, ["RODAL 7", "RODAL 3", "RODAL 4"])

    def test_rodal8_bajo_impacto_y_atipico_verificar(self):
        a = self._aporte("RODAL 8")
        self.assertAlmostEqual(a["aporte_pct"], 0.99, places=2)
        self.assertEqual(a["clasificacion"], "Bajo impacto")
        verificar_claves = [x["clave"] for x in self.diagnostico["sitios_atipicos_verificar"]]
        self.assertIn("RODAL 8", verificar_claves)

    def test_ar1980_bajo_impacto_y_atipico_revisar(self):
        a = self._aporte("AR-1980-1CC")
        self.assertAlmostEqual(a["aporte_pct"], 1.13, places=2)
        revisar_claves = [x["clave"] for x in self.diagnostico["sitios_atipicos_revisar"]]
        self.assertIn("AR-1980-1CC", revisar_claves)

    def test_predio_cumple_no_requiere_sitios_y_referencia_rodal7(self):
        sitios_adic = self.diagnostico["sitios_adicionales"]
        self.assertEqual(sitios_adic["estado"], "No se requieren sitios adicionales")
        referencia = {r["clave"]: r for r in sitios_adic["referencia_top3"]}
        self.assertIn("RODAL 7", referencia)
        self.assertAlmostEqual(referencia["RODAL 7"]["error_esperado_pct"], 6.64, places=2)

    def test_asignacion_objetivo_6_por_ciento(self):
        area_total = self.resultado["validacion"]["superficie_predio_ha"]
        adicionales, error_final, alcanzable, _ = _asignacion_incremental(
            self.resultado["rodales"], area_total, 95, 6)
        no_cero = {k: v for k, v in adicionales.items() if v > 0}
        self.assertTrue(alcanzable)
        self.assertEqual(sum(no_cero.values()), 9)
        self.assertEqual(no_cero, {"RODAL 7": 7, "RODAL 3": 2})
        self.assertAlmostEqual(error_final, 5.94, places=2)

    def test_asignacion_objetivo_5_por_ciento(self):
        area_total = self.resultado["validacion"]["superficie_predio_ha"]
        adicionales, error_final, alcanzable, _ = _asignacion_incremental(
            self.resultado["rodales"], area_total, 95, 5)
        no_cero = {k: v for k, v in adicionales.items() if v > 0}
        self.assertTrue(alcanzable)
        self.assertEqual(sum(no_cero.values()), 31)
        self.assertEqual(no_cero, {"RODAL 7": 14, "RODAL 3": 6, "RODAL 4": 5,
                                   "RODAL 1": 2, "RODAL 6": 2, "RODAL 10": 2})
        self.assertAlmostEqual(error_final, 4.99, places=2)

    def test_sitios_atipicos_revisar_orden_y_valores_exactos(self):
        esperado = [
            ("RODAL 7", 11, 7.07, 0.39, -2.06, 6.51),
            ("RODAL 4", 2, 1.04, 0.09, -2.74, 6.59),
            ("RODAL 10", 2, 30.68, 2.95, 4.51, 6.70),
            ("RODAL 4", 12, 4.09, 0.36, -1.65, 6.73),
            ("AR-1980-1CC", 2, 2.15, 0.29, -2.96, 6.74),
            ("RODAL 10", 5, 4.43, 0.32, -1.16, 6.79),
        ]
        revisar = self.diagnostico["sitios_atipicos_revisar"]
        self.assertEqual(len(revisar), len(esperado))
        for item, (clave, numero, vol, razon, z, error_sin) in zip(revisar, esperado):
            self.assertEqual(item["clave"], clave)
            self.assertEqual(item["numero_sitio"], numero)
            self.assertAlmostEqual(item["volumen_m3"], vol, places=2)
            self.assertAlmostEqual(item["razon"], razon, places=2)
            self.assertAlmostEqual(item["z"], z, places=2)
            self.assertAlmostEqual(item["error_general_sin_el_sitio_pct"], error_sin, places=2)
            self.assertEqual(item["nivel"], "Revisar")

    def test_sitios_atipicos_verificar_conjunto_exacto(self):
        esperado = {("RODAL 8", 3), ("AR-1986-1CC", 5), ("AR-2-2CC", 1), ("AR-2-2CC", 2),
                   ("AR-3-2CC", 2), ("AR-4-2CC", 1), ("AR-4-2CC", 3), ("AR-4-2CC", 4)}
        obtenido = {(a["clave"], a["numero_sitio"]) for a in self.diagnostico["sitios_atipicos_verificar"]}
        self.assertEqual(obtenido, esperado)
        # AR-3-2CC solo debe aparecer una vez (razón exactamente 2.0 no debe marcarse como atípica).
        claves_ar3 = [n for c, n in obtenido if c == "AR-3-2CC"]
        self.assertEqual(claves_ar3, [2])

    def test_resumen_menciona_cumple_y_rodales_prioritarios(self):
        resumen = self.diagnostico["resumen"].lower()
        self.assertIn("cumple", resumen)
        self.assertIn("rodal 7", resumen)


def _sitio_dos_rodales(identificador, numero, rodal_id, volumen_ha, area=400):
    fe = 10000 / area
    vol_sitio = volumen_ha / fe
    return {"id": identificador, "numero": numero, "rodal_id": rodal_id, "estado": "completado_datos",
            "tamano_m2": area, "factor_expansion": fe,
            "volumen_sitio_m3": vol_sitio, "volumen_ha_m3": volumen_ha,
            "volumen_especies": [{"especie_id": 1, "volumen_sitio_m3": vol_sitio}]}


def documento_dos_rodales(fpc=False):
    s1 = [_sitio_dos_rodales(1, 1, 1, 100), _sitio_dos_rodales(2, 2, 1, 200)]
    s2 = [_sitio_dos_rodales(3, 1, 2, 150), _sitio_dos_rodales(4, 2, 2, 250)]
    return {"schema": "simfi.muestreo", "version": "1.0", "errores": [],
            "predio": {"id": 1, "nombre": "Prueba", "superficie_total_ha": 20},
            "configuracion": {"diseno_muestreo": "estratificado", "nivel_confianza": 95,
                              "error_objetivo_pct": 10, "variable_volumen": "VTACC", "unidad": "m3_ha",
                              "aplicar_correccion_poblacion_finita": fpc},
            "resumen_validacion": {"validos_para_simfi": 4, "completados_cero": 0},
            "resumen_muestreo": {}, "advertencias": [],
            "trazabilidad": {"sitios_incluidos": [1, 2, 3, 4]},
            "rodales": [{"id": 1, "clave": "R-1", "superficie_ha": 10, "sitios": s1},
                        {"id": 2, "clave": "R-2", "superficie_ha": 10, "sitios": s2}]}


class ErrorMuestreoTest(unittest.TestCase):
    def test_estadistica_rodal_y_resultado_estratificado(self):
        resultado = calcular_error_muestreo(documento_prueba())
        rodal = resultado["rodales"][0]["estadistica"]
        self.assertAlmostEqual(rodal["media_m3_ha"], 150)
        self.assertAlmostEqual(rodal["varianza"], 5000)
        self.assertAlmostEqual(rodal["error_estandar"], 49.7995983920, places=6)
        self.assertAlmostEqual(rodal["poblacion_N"], 250.0)
        self.assertAlmostEqual(rodal["fpc_factor"], 0.995992, places=6)
        self.assertAlmostEqual(rodal["intensidad_muestreo_pct"], 0.8)
        self.assertAlmostEqual(rodal["t_critico"], 12.7062047364, places=6)
        self.assertAlmostEqual(resultado["validacion"]["intensidad_total_pct"], 0.8)
        self.assertEqual(resultado["comprobacion"]["estado"], "Coincide")
        self.assertAlmostEqual(resultado["diagnostico_conjunto"]["media_m3_ha"], 150)
        self.assertEqual(resultado["resultado_general"]["estado"], "No cumple")

    def test_caso_validacion_rodal_1_6ha_cuatro_sitios(self):
        # Caso de validación: rodal 1.6 ha, sitios de 0.1 ha (1000 m2), N = 16.
        # Con la fórmula histórica E = t*sqrt((s2/n)*(1-n/N))/media*100 el
        # resultado correcto es ~29.73 % relativo (~6.07 absoluto).
        sitios = [sitio(1, 1, 25.7939708365933, 1000), sitio(2, 2, 21.916753338678, 1000),
                  sitio(3, 3, 18.2651698159354, 1000), sitio(4, 4, 15.6837268217889, 1000)]
        doc = documento_prueba(sitios)
        doc["rodales"][0]["superficie_ha"] = 1.6
        doc["predio"]["superficie_total_ha"] = 1.6
        resultado = calcular_error_muestreo(doc)
        e = resultado["rodales"][0]["estadistica"]
        self.assertEqual(e["n"], 4)
        self.assertAlmostEqual(e["media_m3_ha"], 20.4149, places=3)
        self.assertAlmostEqual(e["desviacion_estandar"], 4.4044, places=3)
        self.assertAlmostEqual(e["cv_pct"], 21.57, places=1)
        self.assertAlmostEqual(e["poblacion_N"], 16.0)
        self.assertAlmostEqual(e["intensidad_muestreo_pct"], 25.0)
        self.assertEqual(e["grados_libertad"], 3)
        self.assertAlmostEqual(e["t_critico"], 3.1824, places=3)
        self.assertAlmostEqual(e["error_absoluto_m3_ha"], 6.07, places=1)
        self.assertAlmostEqual(e["error_relativo_pct"], 29.73, places=1)

    def test_caso_real_rodal_1_6930ha_tres_sitios(self):
        # Caso real: rodal 1.6930 ha, sitios de 500 m2 (0.05 ha) -> N = 33.86.
        # Fórmula histórica: E = t*sqrt((s2/n)*(1-n/N))/media*100 ~= 31.60 %.
        sitios = [sitio(1, 52, 9.674475, 500), sitio(2, 102, 7.969681, 500), sitio(3, 103, 7.564370, 500)]
        doc = documento_prueba(sitios)
        doc["rodales"][0]["superficie_ha"] = 1.6930
        doc["predio"]["superficie_total_ha"] = 1.6930
        resultado = calcular_error_muestreo(doc)
        e = resultado["rodales"][0]["estadistica"]
        self.assertEqual(e["n"], 3)
        self.assertAlmostEqual(e["media_m3_ha"], 8.402842, places=5)
        self.assertAlmostEqual(e["desviacion_estandar"], 1.119758, places=5)
        self.assertAlmostEqual(e["cv_pct"], 13.33, places=1)
        self.assertAlmostEqual(e["poblacion_N"], 33.86, places=1)
        self.assertEqual(e["grados_libertad"], 2)
        self.assertAlmostEqual(e["t_critico"], 4.302653, places=4)
        self.assertAlmostEqual(e["error_relativo_pct"], 31.60, places=1)

    def test_error_final_no_divide_y_es_igual_al_estadistico(self):
        import math as _math
        from error_muestreo import _estadistica
        valores = [9.674475, 7.969681, 7.564370]
        e = _estadistica(valores, 95, superficie_rodal_ha=1.6930, superficie_sitio_ha=0.05)
        n = 3
        media = sum(valores) / n
        varianza = sum((x - media) ** 2 for x in valores) / (n - 1)
        sd = _math.sqrt(varianza)
        # Nada de lo estadístico cambió: se verifica contra cálculo independiente.
        self.assertEqual(e["n"], n)
        self.assertAlmostEqual(e["media_m3_ha"], media)
        self.assertAlmostEqual(e["varianza"], varianza)
        self.assertAlmostEqual(e["desviacion_estandar"], sd)
        self.assertAlmostEqual(e["cv_pct"], sd / media * 100)
        self.assertAlmostEqual(e["error_estandar"], sd / _math.sqrt(n) * _math.sqrt(1 - n / 33.86))
        self.assertAlmostEqual(e["t_critico"], 4.302653, places=4)
        self.assertAlmostEqual(e["poblacion_N"], 33.86, places=2)
        self.assertAlmostEqual(e["error_relativo_pct"], 31.60, places=1)
        # Motor 3.0: ya no se divide entre 10; el campo final es idéntico al estadístico.
        self.assertAlmostEqual(e["error_relativo_final_pct"], e["error_relativo_pct"])
        self.assertEqual(e["error_relativo_final_pct"], e["error_relativo_pct"])

    def test_error_final_none_si_no_hay_error(self):
        from error_muestreo import _estadistica
        e = _estadistica([10.0], 95, superficie_rodal_ha=1.0, superficie_sitio_ha=0.05)
        self.assertIsNone(e["error_relativo_pct"])
        self.assertIsNone(e["error_relativo_final_pct"])

    def test_valores_vacios_no_participan(self):
        # None y "" (vacío) se ignoran; 0 es una observación válida (sitio en cero).
        from error_muestreo import _estadistica
        e = _estadistica([10.0, None, 0, "", 20.0], 95, superficie_rodal_ha=1.0, superficie_sitio_ha=0.05)
        self.assertEqual(e["n"], 3)
        self.assertAlmostEqual(e["media_m3_ha"], 10.0)

    def test_sitio_en_cero_se_incluye_en_media_y_n(self):
        # Prueba obligatoria de la especificación: [20, 0, 22] -> n=3, media=14.00
        # (no n=2, media=21.00, que era el resultado si se excluía el cero).
        from error_muestreo import _estadistica
        e = _estadistica([20, 0, 22], 95)
        self.assertEqual(e["n"], 3)
        self.assertAlmostEqual(e["media_m3_ha"], 14.00, places=2)

    def test_valores_negativos_y_booleanos_no_participan(self):
        from error_muestreo import _estadistica
        e = _estadistica([10.0, -5.0, True, False, 20.0, 0], 95)
        self.assertEqual(e["n"], 3)
        self.assertAlmostEqual(e["media_m3_ha"], 10.0)

    def test_rodal_grande_fpc_cercana_a_uno(self):
        doc = documento_prueba([sitio(1, 1, 100, 500), sitio(2, 2, 200, 500),
                                sitio(3, 3, 150, 500), sitio(4, 4, 180, 500)])
        doc["rodales"][0]["superficie_ha"] = 50.0
        doc["predio"]["superficie_total_ha"] = 50.0
        resultado = calcular_error_muestreo(doc)
        e = resultado["rodales"][0]["estadistica"]
        self.assertAlmostEqual(e["poblacion_N"], 1000.0)
        self.assertGreater(e["fpc_factor"], 0.99)
        self.assertIsNotNone(e["error_relativo_pct"])

    def test_n_insuficiente_no_calcula_error(self):
        resultado = calcular_error_muestreo(documento_prueba([sitio(1, 1, 100)]))
        e = resultado["rodales"][0]["estadistica"]
        self.assertEqual(e["n"], 1)
        self.assertIsNone(e["desviacion_estandar"])
        self.assertIsNone(e["error_relativo_pct"])
        self.assertIn("2 sitios válidos", e["mensaje"])

    def test_censo_n_igual_N_error_cero(self):
        sitios = [sitio(1, 1, 100, 400), sitio(2, 2, 200, 400), sitio(3, 3, 150, 400), sitio(4, 4, 180, 400)]
        doc = documento_prueba(sitios)
        doc["rodales"][0]["superficie_ha"] = 0.16
        doc["predio"]["superficie_total_ha"] = 0.16
        resultado = calcular_error_muestreo(doc)
        e = resultado["rodales"][0]["estadistica"]
        self.assertEqual(e["n"], 4)
        self.assertAlmostEqual(e["poblacion_N"], 4.0)
        self.assertAlmostEqual(e["error_relativo_pct"], 0.0)

    def test_n_mayor_que_N_advierte_y_no_calcula(self):
        sitios = [sitio(i, i, 100 + i, 400) for i in range(1, 6)]
        doc = documento_prueba(sitios)
        doc["rodales"][0]["superficie_ha"] = 0.16
        doc["predio"]["superficie_total_ha"] = 0.16
        resultado = calcular_error_muestreo(doc)
        e = resultado["rodales"][0]["estadistica"]
        self.assertEqual(e["n"], 5)
        self.assertIsNone(e["error_relativo_pct"])
        self.assertIn("supera el número", e["advertencia_fpc"])
        self.assertTrue(any("supera el número" in aviso for aviso in resultado["limitaciones"]))

    def test_superficie_sitio_variable_usa_promedio(self):
        doc = documento_prueba([sitio(1, 1, 100, 400), sitio(2, 2, 200, 600)])
        doc["rodales"][0]["superficie_ha"] = 1.0
        doc["predio"]["superficie_total_ha"] = 1.0
        resultado = calcular_error_muestreo(doc)
        e = resultado["rodales"][0]["estadistica"]
        self.assertAlmostEqual(e["poblacion_N"], 20.0)
        self.assertAlmostEqual(e["intensidad_muestreo_pct"], 10.0)

    def test_sitio_cero_es_valido_y_rodal_unitario_no_es_evaluable(self):
        # Un único sitio en cero es una observación válida (n=1), pero sigue
        # siendo insuficiente para estimar varianza (se requieren >= 2 sitios).
        resultado = calcular_error_muestreo(documento_prueba([sitio(1, 1, 0, estado="completado_cero")]))
        estadistica = resultado["rodales"][0]["estadistica"]
        self.assertEqual(resultado["validacion"]["sitios_cero"], 1)
        self.assertEqual(estadistica["n"], 1)
        self.assertEqual(estadistica["estado"], "No evaluable")
        self.assertIsNone(estadistica["varianza"])
        self.assertIsNone(estadistica["error_estandar"])
        self.assertIn("2 sitios válidos", estadistica["mensaje"])
        self.assertEqual(resultado["resultado_general"]["clasificacion"], "Provisional / No evaluable")

    def test_ceros_se_incluyen_en_media_y_n(self):
        # Motor 3.0: los sitios en cero (completado_cero) son observaciones
        # válidas y se incluyen en n, media y varianza.
        resultado = calcular_error_muestreo(documento_prueba([sitio(1, 1, 100), sitio(2, 2, 0, estado="completado_cero"), sitio(3, 3, 200)]))
        estadistica = resultado["rodales"][0]["estadistica"]
        self.assertEqual(estadistica["n"], 3)
        self.assertAlmostEqual(estadistica["media_m3_ha"], 100.0)
        self.assertEqual(resultado["validacion"]["sitios_cero"], 1)

    def test_tamano_muestra_aplica_fpc_cuando_hay_poblacion_n(self):
        # Cambio 4: con poblacion_N, el n requerido por rodal debe ser menor
        # o igual al de una población infinita (sin FPC), y nunca inferior a 2.
        from error_muestreo import _tamano_muestra
        sin_fpc = _tamano_muestra(cv_pct=25.0, error_objetivo=10.0, confianza=95)
        con_fpc = _tamano_muestra(cv_pct=25.0, error_objetivo=10.0, confianza=95, poblacion_N=50)
        self.assertIsNotNone(sin_fpc)
        self.assertIsNotNone(con_fpc)
        self.assertLessEqual(con_fpc, sin_fpc)
        self.assertGreaterEqual(con_fpc, 2)

    def test_n_requerido_por_rodal_usa_poblacion_n_del_rodal(self):
        # n_requerido en calcular_error_muestreo debe reflejar la FPC del rodal
        # (poblacion_N dinámica), no el valor sin FPC.
        from error_muestreo import _tamano_muestra
        doc = documento_prueba([sitio(1, 1, 100, 500), sitio(2, 2, 200, 500),
                                sitio(3, 3, 150, 500), sitio(4, 4, 180, 500)])
        doc["rodales"][0]["superficie_ha"] = 2.0
        doc["predio"]["superficie_total_ha"] = 2.0
        resultado = calcular_error_muestreo(doc)
        e = resultado["rodales"][0]["estadistica"]
        rodal = resultado["rodales"][0]
        esperado = _tamano_muestra(e["cv_pct"], 10, 95, e["poblacion_N"])
        self.assertEqual(rodal["n_requerido"], esperado)
        sin_fpc = _tamano_muestra(e["cv_pct"], 10, 95)
        self.assertLessEqual(rodal["n_requerido"], sin_fpc)

    def test_comprobacion_independiente_incluye_sitio_en_cero(self):
        # verificar_independiente() debe usar el mismo criterio >= 0 que
        # _estadistica(); si no, la comprobación divergiría del motor.
        resultado = calcular_error_muestreo(documento_prueba(
            [sitio(1, 1, 100), sitio(2, 2, 0, estado="completado_cero"), sitio(3, 3, 200)]))
        self.assertEqual(resultado["rodales"][0]["estadistica"]["n"], 3)
        self.assertEqual(resultado["comprobacion"]["estado"], "Coincide")
        self.assertEqual(resultado["comprobacion"]["resultados_comparados"], 2)

    def test_error_informativo_con_fpc_solicitada_no_aplicada(self):
        # Caso de la ventana Resumen principal: FPC solicitada y no aplicada.
        # El estado sigue No evaluable, pero se informa el error calculable.
        resultado = calcular_error_muestreo(documento_prueba(fpc=True), continuar_sin_fpc=True)
        general = resultado["resultado_general"]
        self.assertEqual(general["estado"], "No evaluable")
        self.assertEqual(general["clasificacion"], "Provisional / No evaluable")
        self.assertIsNotNone(general.get("error_relativo_informativo_pct"))
        self.assertEqual(general.get("motivo_informativo"), "FPC solicitada y no aplicada")
        # Con un solo estrato, el informativo coincide con el error del rodal.
        rodal = resultado["rodales"][0]["estadistica"]
        self.assertAlmostEqual(general["error_relativo_informativo_pct"], rodal["error_relativo_pct"])
        self.assertAlmostEqual(general["media_informativa_m3_ha"], rodal["media_m3_ha"])

    def test_sin_informativo_si_rodal_no_evaluable(self):
        # Si algún rodal no tiene varianza estimable, no hay error informativo.
        resultado = calcular_error_muestreo(documento_prueba([sitio(1, 1, 100)]))
        general = resultado["resultado_general"]
        self.assertEqual(general["estado"], "No evaluable")
        self.assertNotIn("error_relativo_informativo_pct", general)

    def test_sin_informativo_si_general_evaluable(self):
        # Con resultado oficial no se agrega el campo informativo.
        resultado = calcular_error_muestreo(documento_prueba())
        self.assertNotIn("error_relativo_informativo_pct", resultado["resultado_general"])

    def test_pantalla_muestra_error_informativo(self):
        resultado = calcular_error_muestreo(documento_prueba(fpc=True), continuar_sin_fpc=True)
        proyecto = PMFProyecto("Prueba")
        proyecto.muestreo_error = [{"id": "a1", "resultado": resultado}]
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto), patch("app.save_pmf", return_value=True):
            vista = cliente.get("/error-muestreo")
        self.assertEqual(vista.status_code, 200)
        html = vista.get_data(as_text=True)
        informativo = resultado["resultado_general"]["error_relativo_informativo_pct"]
        self.assertIn(f"{informativo:.2f} % (informativo)", html)
        self.assertIn("Provisional / No evaluable", html)

    def test_fpc_solicitada_requiere_confirmacion_o_nh(self):
        with self.assertRaises(ErrorMuestreoValidacion):
            calcular_error_muestreo(documento_prueba(fpc=True))
        resultado = calcular_error_muestreo(documento_prueba(fpc=True), continuar_sin_fpc=True)
        self.assertEqual(resultado["fpc_estado"], "Fue solicitada y no aplicada")
        resultado = calcular_error_muestreo(documento_prueba(fpc=True), fpc_nh={"1": 10})
        self.assertEqual(resultado["fpc_estado"], "Fue solicitada y aplicada")

    def test_valida_factor_y_trazabilidad(self):
        doc = documento_prueba()
        doc["rodales"][0]["sitios"][0]["factor_expansion"] = 1
        with self.assertRaises(ErrorMuestreoValidacion):
            calcular_error_muestreo(doc)

    def test_t_student_proviene_de_scipy(self):
        self.assertAlmostEqual(valor_t(95, 1), 12.7062047364, places=6)

    def test_exportaciones_pdf_y_excel(self):
        proyecto = PMFProyecto("Prueba")
        proyecto.muestreo_error = [{"resultado": calcular_error_muestreo(documento_prueba())}]
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto):
            vista = cliente.get("/error-muestreo")
            pdf = cliente.get("/error-muestreo/exportar/pdf")
            excel = cliente.get("/error-muestreo/exportar/excel")
        self.assertEqual(vista.status_code, 200)
        self.assertEqual(pdf.status_code, 200)
        self.assertTrue(pdf.data.startswith(b"%PDF"))
        self.assertEqual(excel.status_code, 200)
        self.assertTrue(excel.data.startswith(b"PK"))

    def test_interpretacion_y_word_son_reproducibles(self):
        resultado = calcular_error_muestreo(documento_prueba())
        analisis = interpretar_muestreo(resultado)
        self.assertTrue(analisis["reglas"])
        self.assertIn("error", " ".join(analisis["parrafos"]).lower())
        proyecto = PMFProyecto("Prueba")
        proyecto.muestreo_error = [{"id": "a1", "resultado": resultado}]
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto), patch("app.save_pmf", return_value=True):
            vista = cliente.get("/error-muestreo/interpretacion")
            word = cliente.get("/error-muestreo/interpretacion/word")
        self.assertEqual(vista.status_code, 200)
        self.assertTrue(word.data.startswith(b"PK"))
        with zipfile.ZipFile(io.BytesIO(word.data)) as paquete:
            texto = paquete.read("word/document.xml").decode("utf-8")
        self.assertIn("Resultados estadísticos por rodal", texto)
        self.assertIn("Volumen estimado por rodal", texto)
        self.assertEqual(len(proyecto.reportes_error_muestreo), 1)

    def test_interpretacion_sin_objetivo_no_falla(self):
        resultado = {"version_motor": "2.0", "predio": {"nombre": "X"},
                     "configuracion": {"nivel_confianza": 95}, "limitaciones": [],
                     "fpc_estado": "No fue solicitada",
                     "validacion": {"sitios_validos": 2, "sitios_cero": 0, "superficie_representada_ha": 1.0, "intensidad_total_pct": 1.0},
                     "resultado_general": {"estado": "Cumple", "clasificacion": "Cumple", "media_m3_ha": 10.0, "error_relativo_pct": 5.0, "li_m3_ha": 9.0, "ls_m3_ha": 11.0},
                     "rodales": [{"clave": "R", "superficie_ha": 1.0, "intensidad_pct": 1.0, "volumen_estimado_m3": 10.0,
                                  "estadistica": {"estado": "Evaluable", "n": 2, "media_m3_ha": 10.0, "desviacion_estandar": 1.0, "cv_pct": 10.0, "error_estandar": 0.7, "t_critico": 12.7, "error_relativo_pct": 5.0, "li_m3_ha": 9.0, "ls_m3_ha": 11.0}}]}
        analisis = interpretar_muestreo(resultado)
        self.assertIn("no hay objetivo definido", " ".join(analisis["parrafos"]).lower())

    def test_excel_incluye_interpretacion_y_cuadros(self):
        from openpyxl import load_workbook
        proyecto = PMFProyecto("Prueba")
        proyecto.muestreo_error = [{"id": "a1", "resultado": calcular_error_muestreo(documento_prueba())}]
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto):
            respuesta = cliente.get("/error-muestreo/exportar/excel")
        self.assertEqual(respuesta.status_code, 200)
        libro = load_workbook(filename=io.BytesIO(respuesta.data))
        self.assertIn("Interpretación", libro.sheetnames)
        self.assertIn("Cuadros", libro.sheetnames)
        cuadros = libro["Cuadros"]
        self.assertEqual(cuadros["A1"].value, "Rodal")
        self.assertEqual(cuadros["A2"].value, "R-1")

    def test_reedicion_conserva_solo_nombre_archivo(self):
        proyecto = PMFProyecto("Prueba")
        proyecto.muestreo_error = [{"id": "a1",
                                    "archivo_nombre": "SIMFI_MUESTREO_X_20260923.json (reedición) (reedición)",
                                    "resultado": calcular_error_muestreo(documento_prueba())}]
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto), patch("app.save_pmf", return_value=True):
            respuesta = cliente.get("/error-muestreo/volumenes/editar")
        self.assertEqual(respuesta.status_code, 302)
        nombre = proyecto.muestreo_borradores[0]["archivo_nombre"]
        self.assertEqual(nombre, "SIMFI_MUESTREO_X_20260923.json")
        self.assertNotIn("reedición", nombre)

    def test_matriz_muestra_panel_error_general_en_vivo(self):
        proyecto = PMFProyecto("Prueba")
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto), patch("app.save_pmf", return_value=True):
            cliente.post("/error-muestreo/importar", data={
                "archivo": (io.BytesIO(json.dumps(documento_prueba()).encode("utf-8")), "muestreo.json"),
            }, content_type="multipart/form-data")
            borrador = proyecto.muestreo_borradores[0]
            matriz = cliente.get(f"/error-muestreo/matriz/{borrador['id']}")
            self.assertEqual(matriz.status_code, 200)
            html = matriz.get_data(as_text=True)
            self.assertIn('id="panel-error-general"', html)
            self.assertIn('id="eg-valor"', html)
            self.assertIn('id="eg-estado"', html)
            previa = cliente.post(f"/error-muestreo/matriz/{borrador['id']}/previa", json={
                "celdas": {"volumen_1": "100", "volumen_2": "300"}, "unidad": "sitio",
                "nh_texto": "", "opcion_fpc": "sin_fpc", "rodales_nuevos": []})
        self.assertEqual(previa.status_code, 200)
        datos = previa.get_json()
        self.assertTrue(datos["ok"])
        self.assertIn("general", datos)
        self.assertIsNotNone(datos["general"]["error_relativo_pct"])

    def test_matriz_muestra_error_informativo_si_general_no_evaluable(self):
        doc = documento_prueba(fpc=True)
        proyecto = PMFProyecto("Prueba")
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto), patch("app.save_pmf", return_value=True):
            cliente.post("/error-muestreo/importar", data={
                "archivo": (io.BytesIO(json.dumps(doc).encode("utf-8")), "muestreo.json"),
            }, content_type="multipart/form-data")
            borrador = proyecto.muestreo_borradores[0]
            matriz = cliente.get(f"/error-muestreo/matriz/{borrador['id']}")
            self.assertEqual(matriz.status_code, 200)
            html = matriz.get_data(as_text=True)
            esperado = calcular_error_muestreo(doc, continuar_sin_fpc=True)
            informativo = esperado["resultado_general"]["error_relativo_informativo_pct"]
            self.assertIsNotNone(informativo)
            self.assertIn(f"{informativo:.2f} %", html)
            self.assertIn("Informativo", html)
            previa = cliente.post(f"/error-muestreo/matriz/{borrador['id']}/previa", json={
                "celdas": {"volumen_1": "100", "volumen_2": "300"}, "unidad": "sitio",
                "nh_texto": "", "opcion_fpc": "sin_fpc", "rodales_nuevos": []})
        self.assertEqual(previa.status_code, 200)
        datos = previa.get_json()
        self.assertTrue(datos["ok"])
        self.assertIsNotNone(datos["general"].get("error_relativo_informativo_pct"))

    def test_matriz_titulo_sin_reedicion_acumulada(self):
        proyecto = PMFProyecto("Prueba")
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto), patch("app.save_pmf", return_value=True):
            cliente.post("/error-muestreo/importar", data={
                "archivo": (io.BytesIO(json.dumps(documento_prueba()).encode("utf-8")), "muestreo.json"),
            }, content_type="multipart/form-data")
            borrador = proyecto.muestreo_borradores[0]
            borrador["archivo_nombre"] = "moredif_x_2409.json (reedición) (reedición)"
            matriz = cliente.get(f"/error-muestreo/matriz/{borrador['id']}")
        self.assertEqual(matriz.status_code, 200)
        html = matriz.get_data(as_text=True)
        self.assertIn("moredif_x_2409.json", html)
        self.assertNotIn("(reedición)", html)

    def test_previa_excluye_rodal_del_calculo_general(self):
        proyecto = PMFProyecto("Prueba")
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto), patch("app.save_pmf", return_value=True):
            cliente.post("/error-muestreo/importar", data={
                "archivo": (io.BytesIO(json.dumps(documento_dos_rodales()).encode("utf-8")), "muestreo.json"),
            }, content_type="multipart/form-data")
            borrador = proyecto.muestreo_borradores[0]
            previa = cliente.post(f"/error-muestreo/matriz/{borrador['id']}/previa", json={
                "celdas": {"volumen_1": "100", "volumen_2": "200",
                           "volumen_3": "150", "volumen_4": "250"},
                "unidad": "sitio", "nh_texto": "", "opcion_fpc": "sin_fpc",
                "rodales_nuevos": [], "excluidos": ["2"]})
        self.assertEqual(previa.status_code, 200)
        datos = previa.get_json()
        self.assertTrue(datos["ok"])
        self.assertEqual(datos["excluidos"], ["2"])
        self.assertEqual(len(datos["rodales"]), 1)
        self.assertEqual(datos["rodales"][0]["id"], 1)
        self.assertAlmostEqual(datos["general"]["error_relativo_pct"],
                               datos["rodales"][0]["error_relativo_pct"])

    def test_previa_sin_rodales_devuelve_error(self):
        proyecto = PMFProyecto("Prueba")
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto), patch("app.save_pmf", return_value=True):
            cliente.post("/error-muestreo/importar", data={
                "archivo": (io.BytesIO(json.dumps(documento_dos_rodales()).encode("utf-8")), "muestreo.json"),
            }, content_type="multipart/form-data")
            borrador = proyecto.muestreo_borradores[0]
            previa = cliente.post(f"/error-muestreo/matriz/{borrador['id']}/previa", json={
                "celdas": {}, "unidad": "sitio", "nh_texto": "",
                "opcion_fpc": "sin_fpc", "rodales_nuevos": [], "excluidos": ["1", "2"]})
        self.assertEqual(previa.status_code, 400)
        self.assertFalse(previa.get_json()["ok"])

    def test_confirmar_guarda_excluidos_y_permite_reincluir(self):
        proyecto = PMFProyecto("Prueba")
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto), patch("app.save_pmf", return_value=True):
            cliente.post("/error-muestreo/importar", data={
                "archivo": (io.BytesIO(json.dumps(documento_dos_rodales()).encode("utf-8")), "muestreo.json"),
            }, content_type="multipart/form-data")
            borrador = proyecto.muestreo_borradores[0]
            confirmado = cliente.post(f"/error-muestreo/matriz/{borrador['id']}/confirmar", data={
                "volumen_1": "100", "volumen_2": "200", "volumen_3": "150", "volumen_4": "250",
                "opcion_fpc": "sin_fpc", "excluidos_json": '["2"]'})
            self.assertEqual(confirmado.status_code, 302)
            registro = proyecto.muestreo_error[-1]
            self.assertEqual([r["id"] for r in registro["resultado"]["rodales"]], [1])
            self.assertEqual([r["id"] for r in registro["rodales_excluidos"]], [2])
            self.assertEqual(len(registro["rodales_excluidos"][0]["sitios"]), 2)
            self.assertIn("R-2", " ".join(registro["resultado"]["limitaciones"]))
            editado = cliente.get("/error-muestreo/volumenes/editar")
            self.assertEqual(editado.status_code, 302)
            nuevo = proyecto.muestreo_borradores[0]
            self.assertEqual(sorted(r["id"] for r in nuevo["datos"]["rodales"]), [1, 2])
            self.assertEqual(nuevo["excluidos"], ["2"])
            matriz = cliente.get(f"/error-muestreo/matriz/{nuevo['id']}")
            self.assertEqual(matriz.status_code, 200)
            html = matriz.get_data(as_text=True)
            self.assertIn("R-1", html)
            self.assertIn("R-2", html)
            self.assertIn('data-rodal="1" checked>', html)
            self.assertIn('data-rodal="2">', html)

    def test_editar_volumen_reabre_matriz_desde_calculo(self):
        proyecto = PMFProyecto("Prueba")
        proyecto.muestreo_error = [{"id": "a1", "archivo_nombre": "m.json", "resultado": calcular_error_muestreo(documento_prueba())}]
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto), patch("app.save_pmf", return_value=True):
            respuesta = cliente.get("/error-muestreo/volumenes/editar")
            self.assertEqual(respuesta.status_code, 302)
            self.assertEqual(len(proyecto.muestreo_borradores), 1)
            matriz = cliente.get(f"/error-muestreo/matriz/{proyecto.muestreo_borradores[0]['id']}")
        self.assertEqual(matriz.status_code, 200)
        self.assertIn("Revisión de matriz", matriz.get_data(as_text=True))

    def test_previa_matriz_devuelve_error_dinamico_por_rodal(self):
        proyecto = PMFProyecto("Prueba")
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto), patch("app.save_pmf", return_value=True):
            respuesta = cliente.post("/error-muestreo/importar", data={
                "archivo": (io.BytesIO(json.dumps(documento_prueba()).encode("utf-8")), "muestreo.json"),
            }, content_type="multipart/form-data")
            self.assertEqual(respuesta.status_code, 302)
            borrador = proyecto.muestreo_borradores[0]
            matriz = cliente.get(f"/error-muestreo/matriz/{borrador['id']}")
            self.assertEqual(matriz.status_code, 200)
            texto = matriz.get_data(as_text=True)
            self.assertIn("rodal-error", texto)
            self.assertIn("previa-estado", texto)
            previa = cliente.post(f"/error-muestreo/matriz/{borrador['id']}/previa", json={
                "celdas": {"volumen_1": "100", "volumen_2": "300"}, "unidad": "sitio",
                "nh_texto": "", "opcion_fpc": "sin_fpc", "rodales_nuevos": []})
        self.assertEqual(previa.status_code, 200)
        datos = previa.get_json()
        self.assertTrue(datos["ok"])
        self.assertEqual(datos["rodales"][0]["n"], 2)
        self.assertIsNotNone(datos["rodales"][0]["error_relativo_pct"])

    def test_vista_tolera_rodal_sin_estadistica(self):
        proyecto = PMFProyecto("Prueba")
        proyecto.muestreo_error = [{"id": "viejo", "archivo_nombre": "viejo.json", "resultado": {
            "version_motor": "1.0", "predio": {"nombre": "X"},
            "configuracion": {"diseno_muestreo": "e", "nivel_confianza": 95},
            "validacion": {"sitios_validos": 0, "sitios_cero": 0, "superficie_predio_ha": 1.0,
                           "superficie_representada_ha": 1.0, "intensidad_total_pct": 0.0},
            "fpc_estado": "No registrada", "rodales": [{"id": 1, "clave": "R-1"}],
            "resultado_general": {"estado": "X", "clasificacion": "X"},
            "limitaciones": []}}]
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto):
            vista = cliente.get("/error-muestreo")
            excel = cliente.get("/error-muestreo/exportar/excel")
            pdf = cliente.get("/error-muestreo/exportar/pdf")
            interpretacion = cliente.get("/error-muestreo/interpretacion")
        self.assertEqual(vista.status_code, 200)
        self.assertEqual(excel.status_code, 200)
        self.assertEqual(pdf.status_code, 200)
        self.assertEqual(interpretacion.status_code, 200)

    def test_vista_tolerante_evaluable_sin_error_relativo(self):
        proyecto = PMFProyecto("Prueba")
        estadistica = {"n": 2, "media_m3_ha": 10.0, "varianza": 4.0, "desviacion_estandar": 2.0,
                       "cv_pct": 20.0, "error_estandar": 1.4142, "t_critico": 12.706,
                       "error_absoluto_m3_ha": 17.97, "error_relativo_pct": None,
                       "estado": "Evaluable", "fpc_factor": 1.0, "li_m3_ha": None, "ls_m3_ha": None,
                       "li_practico_m3_ha": None}
        proyecto.muestreo_error = [{"id": "viejo2", "archivo_nombre": "viejo2.json", "resultado": {
            "version_motor": "1.0", "predio": {"nombre": "X"},
            "configuracion": {"diseno_muestreo": "e", "nivel_confianza": 95},
            "validacion": {"sitios_validos": 2, "sitios_cero": 0, "superficie_predio_ha": 2.0,
                           "superficie_representada_ha": 2.0, "intensidad_total_pct": 50.0},
            "fpc_estado": "No registrada",
            "rodales": [{"id": 1, "clave": "R-1", "superficie_ha": 1.0, "intensidad_pct": 50.0,
                         "volumen_estimado_m3": 20.0, "n_requerido": None,
                         "sitios": [{"numero": 1, "estado": "Válido", "volumen_sitio_m3": 10.0,
                                     "volumen_ha_m3": 10.0},
                                    {"numero": 2, "estado": "Válido", "volumen_sitio_m3": 10.0,
                                     "volumen_ha_m3": 10.0}],
                         "estadistica": estadistica}],
            "resultado_general": {"estado": "Evaluable", "clasificacion": "X"},
            "limitaciones": []}}]
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto):
            vista = cliente.get("/error-muestreo")
            excel = cliente.get("/error-muestreo/exportar/excel")
            interpretacion = cliente.get("/error-muestreo/interpretacion")
        self.assertEqual(vista.status_code, 200)
        self.assertEqual(excel.status_code, 200)
        self.assertEqual(interpretacion.status_code, 200)

    def test_vista_tolera_registro_sin_resultado(self):
        proyecto = PMFProyecto("Prueba")
        proyecto.muestreo_error = [{"id": "roto"}]
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto):
            excel = cliente.get("/error-muestreo/exportar/excel")
            vista = cliente.get("/error-muestreo")
        self.assertEqual(excel.status_code, 404)
        self.assertEqual(vista.status_code, 200)

    def test_diagnostico_se_calcula_y_guarda_en_proyecto_nuevo(self):
        proyecto = PMFProyecto("Prueba")
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto), patch("app.save_pmf", return_value=True):
            cliente.post("/error-muestreo/importar", data={
                "archivo": (io.BytesIO(json.dumps(documento_prueba()).encode("utf-8")), "muestreo.json"),
            }, content_type="multipart/form-data")
            borrador = proyecto.muestreo_borradores[0]
            confirmado = cliente.post(f"/error-muestreo/matriz/{borrador['id']}/confirmar", data={
                "volumen_1": "100", "volumen_2": "200", "opcion_fpc": "sin_fpc",
            })
            self.assertEqual(confirmado.status_code, 302)
            resultado = proyecto.muestreo_error[-1]["resultado"]
            self.assertIsInstance(resultado.get("diagnostico"), dict)
            self.assertTrue(resultado["diagnostico"]["disponible"])
            self.assertIn("aporte_por_rodal", resultado["diagnostico"])
            pantalla = cliente.get("/error-muestreo")
            excel = cliente.get("/error-muestreo/exportar/excel")
            word = cliente.get("/error-muestreo/interpretacion/word")
        self.assertEqual(pantalla.status_code, 200)
        self.assertIn("Diagnóstico y recomendaciones", pantalla.get_data(as_text=True))
        self.assertEqual(excel.status_code, 200)
        from openpyxl import load_workbook
        libro = load_workbook(filename=io.BytesIO(excel.data))
        self.assertIn("Diagnóstico", libro.sheetnames)
        self.assertEqual(word.status_code, 200)
        with zipfile.ZipFile(io.BytesIO(word.data)) as paquete:
            texto_word = paquete.read("word/document.xml").decode("utf-8")
        self.assertIn("Diagn", texto_word)  # "Diagnóstico y recomendaciones" (con o sin acentos por el XML)

    def test_diagnostico_no_disponible_para_registro_de_motor_anterior(self):
        proyecto = PMFProyecto("Prueba")
        estadistica = {"n": 2, "media_m3_ha": 10.0, "varianza": 4.0, "desviacion_estandar": 2.0,
                       "cv_pct": 20.0, "error_estandar": 1.4142, "t_critico": 12.706,
                       "error_absoluto_m3_ha": 17.97, "error_relativo_pct": 15.0,
                       "estado": "Evaluable", "fpc_factor": 1.0, "li_m3_ha": None, "ls_m3_ha": None,
                       "li_practico_m3_ha": None, "poblacion_N": None}
        proyecto.muestreo_error = [{"id": "viejo3", "archivo_nombre": "viejo3.json", "resultado": {
            "version_motor": "2.0", "predio": {"nombre": "X"},
            "configuracion": {"diseno_muestreo": "e", "nivel_confianza": 95, "error_objetivo_pct": 10},
            "validacion": {"sitios_validos": 2, "sitios_cero": 0, "superficie_predio_ha": 2.0,
                           "superficie_representada_ha": 2.0, "intensidad_total_pct": 50.0},
            "fpc_estado": "No registrada",
            "rodales": [{"id": 1, "clave": "R-1", "superficie_ha": 2.0, "intensidad_pct": 50.0,
                         "volumen_estimado_m3": 20.0, "n_requerido": None,
                         "sitios": [{"numero": 1, "estado": "Válido", "volumen_sitio_m3": 10.0,
                                     "volumen_ha_m3": 10.0},
                                    {"numero": 2, "estado": "Válido", "volumen_sitio_m3": 10.0,
                                     "volumen_ha_m3": 10.0}],
                         "estadistica": estadistica}],
            "resultado_general": {"estado": "Evaluable", "clasificacion": "X", "media_m3_ha": 10.0,
                                  "error_relativo_pct": 15.0, "volumen_estimado_m3": 20.0,
                                  "li_m3_ha": 9.0, "ls_m3_ha": 11.0},
            "limitaciones": []}}]
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto), patch("app.save_pmf", return_value=True):
            pantalla = cliente.get("/error-muestreo")
            excel = cliente.get("/error-muestreo/exportar/excel")
            word = cliente.get("/error-muestreo/interpretacion/word")
        self.assertEqual(pantalla.status_code, 200)
        self.assertIn("Diagnóstico disponible al recalcular.", pantalla.get_data(as_text=True))
        self.assertEqual(excel.status_code, 200)
        from openpyxl import load_workbook
        libro = load_workbook(filename=io.BytesIO(excel.data))
        self.assertIn("Diagnóstico", libro.sheetnames)
        hoja = libro["Diagnóstico"]
        self.assertEqual(hoja["A1"].value, "Diagnóstico disponible al recalcular.")
        self.assertEqual(word.status_code, 200)

    def test_importacion_requiere_confirmar_matriz_antes_del_calculo(self):
        proyecto = PMFProyecto("Prueba")
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=proyecto), patch("app.save_pmf", return_value=True):
            respuesta = cliente.post("/error-muestreo/importar", data={
                "archivo": (io.BytesIO(json.dumps(documento_prueba()).encode("utf-8")), "muestreo.json"),
            }, content_type="multipart/form-data")
            self.assertEqual(respuesta.status_code, 302)
            self.assertEqual(len(proyecto.muestreo_error), 0)
            self.assertEqual(len(proyecto.muestreo_borradores), 1)
            borrador = proyecto.muestreo_borradores[0]
            matriz = cliente.get(f"/error-muestreo/matriz/{borrador['id']}")
            self.assertEqual(matriz.status_code, 200)
            confirmado = cliente.post(f"/error-muestreo/matriz/{borrador['id']}/confirmar", data={
                "volumen_1": "100", "volumen_2": "200", "opcion_fpc": "sin_fpc",
            })
        self.assertEqual(confirmado.status_code, 302)
        self.assertEqual(len(proyecto.muestreo_error), 1)
        self.assertFalse(proyecto.muestreo_borradores)


if __name__ == "__main__":
    unittest.main()
