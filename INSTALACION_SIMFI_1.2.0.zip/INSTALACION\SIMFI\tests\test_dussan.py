"""Pruebas del asistente Dussan.

Verifican el contrato de la integracion: Dussan consulta resultados ya
calculados por SIMFI, no recalcula, no escribe, no inventa datos y nunca
expone credenciales.
"""

import json
import os
import tempfile
import unittest

import app as app_module
import dussan_backend
from modelos import ClaseDiametrica, PMFProyecto, Rodal, TablaInventarioRodal

_RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _leer(*partes):
    with open(os.path.join(_RAIZ, *partes), encoding="utf-8") as archivo:
        return archivo.read()


class UmmYRodalMismaUnidadTest(unittest.TestCase):
    """En SIMFI la UMM y el rodal son la misma unidad de manejo."""

    def test_la_nota_lo_declara_explicitamente(self):
        self.assertIn("UMM", dussan_backend.NOTA_UMM)
        self.assertIn("misma", dussan_backend.NOTA_UMM)

    def test_el_modulo_de_rodales_se_etiqueta_como_umm(self):
        etiqueta, endpoint = dussan_backend.MODULOS["rodales"]
        self.assertIn("UMM", etiqueta)
        self.assertEqual(endpoint, "listar_rodales")

    def test_el_contexto_no_separa_umm_de_rodal(self):
        proyecto = PMFProyecto("Predio")
        proyecto.agregar_rodal(Rodal("1", 3.0))
        estado = dussan_backend.contexto(proyecto, modulo="rodales")
        self.assertEqual(estado["estado"]["modulo_etiqueta"], "Rodales (UMM)")
        self.assertEqual([r["id"] for r in estado["rodales"]], ["1"])
        self.assertEqual(estado["estado"]["nota_umm"], dussan_backend.NOTA_UMM)


class HerramientasNoDisponiblesTest(unittest.TestCase):
    def test_remisiones_se_declara_no_disponible(self):
        self.assertIn("consultar_remisiones", dussan_backend.NO_DISPONIBLES)
        resultado = dussan_backend.ejecutar_herramienta("consultar_remisiones", {}, {})
        self.assertFalse(resultado["ok"])
        self.assertTrue(resultado["no_disponible"])
        self.assertIn("no tiene un modulo de remisiones", resultado["mensaje"])

    def test_las_herramientas_sensibles_nunca_se_ejecutan(self):
        for nombre in ("ejecutar_proceso", "modificar_datos", "eliminar_datos"):
            resultado = dussan_backend.ejecutar_herramienta(nombre, {}, {})
            self.assertFalse(resultado["ok"], nombre)
            self.assertTrue(resultado["requiere_confirmacion"], nombre)
            self.assertIn("modulo de SIMFI", resultado["mensaje"])

    def test_una_herramienta_inexistente_no_inventa_datos(self):
        resultado = dussan_backend.ejecutar_herramienta("consultar_inventario", {}, {})
        self.assertFalse(resultado["ok"])
        self.assertIsNone(resultado.get("datos"))


class SinProyectoAbiertoTest(unittest.TestCase):
    def test_avisa_que_no_hay_proyecto_en_vez_de_inventar(self):
        resultado = dussan_backend.ejecutar_herramienta("consultar_rodales", {}, {})
        self.assertFalse(resultado["ok"])
        self.assertIn("No hay un proyecto abierto", resultado["mensaje"])


class HabilitacionTest(unittest.TestCase):
    def test_dussan_esta_desactivado_por_defecto(self):
        self.assertFalse(dussan_backend.dussan_habilitado({"habilitada": True}))

    def test_se_apaga_con_el_interruptor(self):
        self.assertFalse(dussan_backend.dussan_habilitado(
            {"habilitada": True, "dussan": {"habilitado": False}}))

    def test_se_apaga_si_la_ia_esta_deshabilitada(self):
        self.assertFalse(dussan_backend.dussan_habilitado(
            {"habilitada": False, "dussan": {"habilitado": True}}))

    def test_la_voz_esta_desactivada_por_defecto(self):
        self.assertFalse(dussan_backend.voz_habilitada({"habilitada": True}))
        self.assertFalse(dussan_backend.voz_habilitada(
            {"habilitada": True, "dussan": {"habilitado": True}}))

    def test_la_voz_se_activa_solo_por_configuracion(self):
        self.assertTrue(dussan_backend.voz_habilitada(
            {"habilitada": True, "dussan": {"habilitado": True, "voz": True}}))

    def test_la_configuracion_predeterminada_no_activa_la_voz(self):
        from ia_config import cargar_config
        self.assertIn("dussan", cargar_config())
        self.assertFalse(cargar_config()["dussan"]["voz"])


class ConsultaDeResultadosTest(unittest.TestCase):
    """Las herramientas leen resultados de SIMFI, no los recalculan."""

    def setUp(self):
        self.proyecto = PMFProyecto("San Pedro", predio="San Pedro",
                                    municipio="Tlaxiaco", estado="Oaxaca")
        self.proyecto.agregar_rodal(Rodal("1", 4.0, sitios=2))
        self.proyecto.agregar_especie("Pinus pseudostrobus")
        from modelos import EcuacionVolumen
        self.proyecto.asignar_ecuacion("Pinus pseudostrobus",
                                       EcuacionVolumen(a0=0.0588, a1=0.0453, a2=0.0011,
                                                       b0=0.9819))
        tabla = TablaInventarioRodal("1", "Pinus pseudostrobus")
        tabla.agregar_clase(ClaseDiametrica(25.0, 18.0, 8))
        self.proyecto.tablas_inventario.append(tabla)
        self.estado = dussan_backend.contexto_plano(
            dussan_backend.contexto(self.proyecto, modulo="existencias"))

    def test_consultar_rodales_devuelve_las_umm_del_proyecto(self):
        resultado = dussan_backend.ejecutar_herramienta("consultar_rodales", {}, self.estado)
        self.assertTrue(resultado["ok"])
        self.assertEqual(resultado["datos"]["umm_evaluadas"], 1)
        self.assertEqual(resultado["datos"]["rodales"][0]["id"], "1")

    def test_consultar_existencias_coincide_con_simfi(self):
        resultado = dussan_backend.ejecutar_herramienta("consultar_existencias", {}, self.estado)
        self.assertTrue(resultado["ok"])
        oficial = self.proyecto.cuadro_existencias()
        self.assertAlmostEqual(resultado["datos"]["totales"]["existencias"],
                               float(oficial["total_vol_umm"]), places=3)

    def test_consultar_existencias_filtra_por_rodal_solicitado(self):
        resultado = dussan_backend.ejecutar_herramienta(
            "consultar_existencias", {"rodal": "1"}, self.estado)
        self.assertTrue(resultado["ok"])
        self.assertEqual(len(resultado["datos"]["rodales"]), 1)
        self.assertEqual(resultado["datos"]["rodales"][0]["id"], "1")

    def test_un_rodal_inexistente_no_se_inventa(self):
        resultado = dussan_backend.ejecutar_herramienta(
            "consultar_existencias", {"rodal": "99"}, self.estado)
        self.assertTrue(resultado["ok"])
        for fila in resultado["datos"]["rodales"]:
            self.assertNotEqual(fila["id"], "99")

    def test_consultar_muestreo_sin_analisis_no_inventa_error(self):
        resultado = dussan_backend.ejecutar_herramienta("consultar_muestreo", {}, self.estado)
        self.assertTrue(resultado["ok"])
        self.assertEqual(resultado["datos"]["analisis_confirmados"], 0)
        self.assertEqual(resultado["datos"]["analisis"], [])

    def test_consultar_turno_lee_lo_calculado_por_simfi(self):
        self.proyecto.calculos_turno.append({"id": "c1", "especie": "Pinus pseudostrobus",
                                             "turno_anios": 25})
        resultado = dussan_backend.ejecutar_herramienta("consultar_turno", {}, self.estado)
        self.assertTrue(resultado["ok"])
        self.assertEqual(resultado["datos"]["calculos_guardados"], 1)
        self.assertEqual(resultado["datos"]["calculos"][0]["turno_anios"], 25)

    def test_consultar_predios_no_expone_rutas_de_archivos(self):
        self.proyecto.ruta_archivo = r"C:\privado\proyecto.json"
        resultado = dussan_backend.ejecutar_herramienta("consultar_predios", {}, self.estado)
        self.assertNotIn("ruta", json.dumps(resultado["datos"]))

    def test_abrir_modulo_devuelve_el_destino_del_modulo(self):
        resultado = dussan_backend.ejecutar_herramienta(
            "abrir_modulo", {"modulo": "muestreo"}, self.estado)
        self.assertTrue(resultado["ok"])
        self.assertEqual(resultado["datos"]["destino"], "error_muestreo")

    def test_abrir_modulo_inexistente_no_inventa_destino(self):
        resultado = dussan_backend.ejecutar_herramienta(
            "abrir_modulo", {"modulo": "inventado"}, self.estado)
        self.assertFalse(resultado["ok"])
        self.assertNotIn("destino", resultado.get("datos", {}))


class EnrutadoTest(unittest.TestCase):
    def _estado(self, modulo):
        proyecto = PMFProyecto("P")
        return dussan_backend.contexto_plano(dussan_backend.contexto(proyecto, modulo=modulo))

    def test_detecta_la_consulta_por_palabra_clave(self):
        estado = self._estado("inicio")
        self.assertEqual(dussan_backend.seleccionar_herramientas(
            "cual es el error de muestreo", estado), ["consultar_muestreo"])
        self.assertEqual(dussan_backend.seleccionar_herramientas(
            "muéstrame las existencias", estado), ["consultar_existencias"])
        self.assertEqual(dussan_backend.seleccionar_herramientas(
            "y el turno", estado), ["consultar_turno"])
        self.assertEqual(dussan_backend.seleccionar_herramientas(
            "las remisiones", estado), ["consultar_remisiones"])

    def test_sin_palabra_clave_usa_el_modulo_activo(self):
        self.assertEqual(dussan_backend.seleccionar_herramientas(
            "y eso?", self._estado("turnos")), ["consultar_turno"])
        self.assertEqual(dussan_backend.seleccionar_herramientas(
            "ayudame", self._estado("inicio")), ["consultar_predios"])


class RespuestaConIaTest(unittest.TestCase):
    def setUp(self):
        self.servicio_original = dussan_backend._SERVICIO
        capturado = {}

        class ServicioPrueba:
            def interpret(self, datos, modulo, contexto, config):
                capturado.update({"datos": datos, "modulo": modulo,
                                  "contexto": contexto, "config": config})
                return {"ok": True, "texto": "La finca tiene 100 m3 VTA.",
                        "motor": "prueba", "modelo": "modelo-prueba", "metadatos": {}}

        self.capturado = capturado
        dussan_backend._SERVICIO = ServicioPrueba()
        self.proyecto = PMFProyecto("San Pedro", predio="San Pedro")
        self.proyecto.agregar_rodal(Rodal("1", 4.0))
        self.estado = dussan_backend.contexto_plano(
            dussan_backend.contexto(self.proyecto, modulo="existencias", usuario="prueba"))

    def tearDown(self):
        dussan_backend._SERVICIO = self.servicio_original

    def test_usa_el_prompt_maestro_de_simfi_mas_la_capa_de_dussan(self):
        config = {"habilitada": True, "dussan": {"habilitado": True},
                  "prompt_sistema": "SIMFI CALCULA, VALIDA Y GENERA LOS HALLAZGOS."}
        dussan_backend.responder("hola", self.estado, [{"volumen": 1}], config)
        contexto = self.capturado["contexto"]
        self.assertIn("SIMFI CALCULA, VALIDA Y GENERA LOS HALLAZGOS.", contexto)
        self.assertIn("Eres Dussan", contexto)
        self.assertEqual(self.capturado["modulo"], "dussan")

    def test_normaliza_la_terminologia_de_la_respuesta(self):
        config = {"habilitada": True, "dussan": {"habilitado": True}, "prompt_sistema": "x"}
        resultado = dussan_backend.responder("hola", self.estado, [{"volumen": 1}], config)
        self.assertTrue(resultado["ok"])
        self.assertIn("predio", resultado["texto"])
        self.assertNotIn("finca", resultado["texto"])

    def test_no_responde_sin_resultados_de_simfi(self):
        resultado = dussan_backend.responder("hola", self.estado, [], {})
        self.assertFalse(resultado["ok"])
        self.assertIsNone(resultado["texto"])
        self.assertIn("no responde sin datos", resultado["mensaje"])

    def test_respeta_el_interruptor_de_dussan(self):
        resultado = dussan_backend.responder(
            "hola", self.estado, [{"v": 1}],
            {"habilitada": True, "dussan": {"habilitado": False}, "prompt_sistema": "x"})
        self.assertFalse(resultado["ok"])
        self.assertIn("deshabilitado", resultado["mensaje"])


class ConsultaYRespuestaTest(unittest.TestCase):
    def setUp(self):
        self.servicio_original = dussan_backend._SERVICIO
        self.config_original = dussan_backend._cargar_config
        dussan_backend._SERVICIO = None
        # La suite no debe salir a la red: se fuerza el modo sin IA.
        dussan_backend._cargar_config = lambda ruta=None: {"habilitada": False}
        self.proyecto = PMFProyecto("San Pedro", predio="San Pedro")
        self.proyecto.agregar_rodal(Rodal("1", 4.0, sitios=2))
        self.estado = dussan_backend.contexto_plano(
            dussan_backend.contexto(self.proyecto, modulo="existencias"))

    def tearDown(self):
        dussan_backend._SERVICIO = self.servicio_original
        dussan_backend._cargar_config = self.config_original

    def test_sin_ia_responde_con_un_resumen_determinista(self):
        resultado = dussan_backend.consultar_y_responder(
            "dame las existencias", self.estado)
        self.assertTrue(resultado["ok"])
        self.assertEqual(resultado["motor"], "determinista")
        self.assertIn("m3 VTA", resultado["texto"])
        self.assertTrue(resultado["aviso"])

    def test_si_solo_hay_herramientas_no_disponibles_no_inventa(self):
        resultado = dussan_backend.consultar_y_responder(
            "las remisiones", self.estado)
        self.assertFalse(resultado["ok"])
        self.assertIn("remisiones", resultado["mensaje"])

    def test_el_resumen_no_incluye_el_proyecto_completo(self):
        resultado = dussan_backend.consultar_y_responder(
            "dame las existencias", self.estado)
        self.assertNotIn("tablas_inventario", json.dumps(resultado, default=str))


class DisenoVisualTest(unittest.TestCase):
    """El concepto aprobado: pastor alemán central, globo único, sin chat."""

    def test_el_avatar_es_el_pastor_aprobado(self):
        for nombre in ("dussan_idle.png", "dussan_listening.png", "dussan_thinking.png",
                       "dussan_speaking.png", "dussan_success.png", "dussan_warning.png",
                       "dussan_avatar.png", "dussan_minimized.png"):
            ruta = os.path.join(_RAIZ, "static", "img", "dussan", nombre)
            self.assertTrue(os.path.isfile(ruta), nombre)
            with open(ruta, "rb") as archivo:
                firma = archivo.read(8)
            self.assertEqual(firma[:4], b"\x89PNG", nombre)

    def test_no_queda_avatar_geometrico_provisional(self):
        self.assertFalse(os.path.exists(os.path.join(_RAIZ, "static", "img", "dussan.svg")))
        css = _leer("static", "css", "dussan.css")
        js = _leer("static", "js", "dussan.js")
        self.assertNotIn("dussan.svg", css)
        self.assertNotIn("dussan.svg", js)
        self.assertNotIn("ear left", js)
        self.assertNotIn("dussan_concept", js)

    def test_el_css_esta_acotado_y_sin_reglas_globales(self):
        fuente = _leer("static", "css", "dussan.css")
        self.assertIn(".dussan-root .dussan-globo", fuente)
        self.assertIn(".dussan-root .dussan-escena", fuente)
        self.assertIn(".dussan-root .dussan-quick button", fuente)
        self.assertIn(".dussan-root .dussan-composer button", fuente)
        self.assertIn("#dussan-flotante", fuente)
        self.assertIn(".dussan-punto", fuente)
        self.assertNotIn("body{", fuente)
        self.assertNotIn("*{", fuente)
        self.assertNotIn(".dussan-msg", fuente)
        self.assertNotIn(".dussan-chat", fuente)

    def test_el_css_usa_la_paleta_maestra(self):
        fuente = _leer("static", "css", "dussan.css")
        for color in ("#1b5e3f", "#2e7d32", "#a5d6a7"):
            self.assertIn(color, fuente.lower())

    def test_el_js_cambia_la_imagen_segun_el_estado(self):
        fuente = _leer("static", "js", "dussan.js")
        self.assertIn("mapaEstados", fuente)
        self.assertIn("SIMFI_DUSSAN.estados", fuente.replace("global.SIMFI_DUSSAN", "SIMFI_DUSSAN"))
        self.assertIn("punto-", fuente)
        self.assertIn("dussan-mini-marco", fuente)

    def test_los_seis_estados_estan_preparados_en_el_css(self):
        fuente = _leer("static", "css", "dussan.css")
        for estado in ("idle", "listening", "thinking", "speaking", "success", "warning"):
            self.assertIn("estado-" + estado, fuente)

    def test_el_minimizado_muestra_una_pildora_que_reabre(self):
        fuente = _leer("static", "js", "dussan.js")
        self.assertIn("minimizar", fuente)
        self.assertIn("restaurar", fuente)
        self.assertIn("historial", fuente)
        self.assertIn("flotante", fuente)

    def test_la_conversacion_se_conserva_en_memoria(self):
        fuente = _leer("static", "js", "dussan.js")
        self.assertIn("registrarIntercambio", fuente)
        self.assertIn("pendiente", fuente)


class SinCredencialesTest(unittest.TestCase):
    """Ninguna credencial puede llegar al frontend ni al modulo de Dussan."""

    def test_el_modulo_no_maneja_claves(self):
        fuente = _leer("dussan_backend.py")
        self.assertNotIn("api_key", fuente)
        self.assertNotIn("os.environ", fuente)

    def test_el_frontend_no_contiene_claves_ni_urls_de_proveedores(self):
        for nombre in ("dussan.js", "dussan-tools.js", "dussan-voice.js"):
            fuente = _leer("static", "js", nombre)
            self.assertNotIn("api_key", fuente)
            self.assertNotIn("sk-", fuente)
            self.assertNotIn("openrouter", fuente.lower())
            self.assertNotIn("ollama", fuente.lower())

    def test_el_frontend_solo_conoce_los_endpoints_de_simfi(self):
        fuente = _leer("static", "js", "dussan-tools.js")
        self.assertIn("SIMFI_DUSSAN", fuente)
        self.assertIn("same-origin", fuente)


class IntegracionFlaskTest(unittest.TestCase):
    def setUp(self):
        self.temporal = tempfile.TemporaryDirectory()
        self.originales = (app_module.DATA_DIR, app_module.PROJECTS_DIR,
                           app_module.PROJECT_STATE_DIR, app_module.LAST_PROJECT_FILE)
        self.config_original = dussan_backend._cargar_config
        self.servicio_original = dussan_backend._SERVICIO
        dussan_backend._SERVICIO = None
        # La suite no debe salir a la red: Dussan queda activo pero sin motor de IA.
        dussan_backend._cargar_config = lambda ruta=None: {
            "habilitada": True, "dussan": {"habilitado": True, "voz": False},
            "prompt_sistema": "SIMFI CALCULA, VALIDA Y GENERA LOS HALLAZGOS."}
        app_module.DATA_DIR = self.temporal.name
        app_module.PROJECTS_DIR = os.path.join(self.temporal.name, "projects")
        app_module.PROJECT_STATE_DIR = os.path.join(self.temporal.name, "state")
        app_module.LAST_PROJECT_FILE = os.path.join(
            app_module.PROJECT_STATE_DIR, "ultimo_proyecto.json")
        self.ruta = os.path.join(app_module.PROJECTS_DIR, "dussan.json")
        proyecto = PMFProyecto("San Pedro", predio="San Pedro")
        proyecto.agregar_rodal(Rodal("1", 4.0, sitios=2))
        self.assertTrue(proyecto.guardar(self.ruta))
        self.cliente = app_module.app.test_client()
        with self.cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["ruta_actual"] = self.ruta

    def tearDown(self):
        (app_module.DATA_DIR, app_module.PROJECTS_DIR,
         app_module.PROJECT_STATE_DIR, app_module.LAST_PROJECT_FILE) = self.originales
        dussan_backend._cargar_config = self.config_original
        dussan_backend._SERVICIO = self.servicio_original
        self.temporal.cleanup()

    def test_el_contexto_expone_predio_umm_modulo_y_usuario(self):
        respuesta = self.cliente.get("/api/dussan/contexto")
        self.assertEqual(respuesta.status_code, 200)
        cuerpo = respuesta.get_json()
        self.assertTrue(cuerpo["ok"])
        self.assertEqual(cuerpo["estado"]["proyecto"]["predio"], "San Pedro")
        self.assertEqual(cuerpo["estado"]["usuario"], "prueba")
        self.assertEqual(cuerpo["rodales"][0]["id"], "1")
        self.assertIn("consultar_rodales", cuerpo["herramientas"])

    def test_una_herramienta_de_lectura_responde_con_datos_de_simfi(self):
        respuesta = self.cliente.post("/api/dussan/herramienta",
                                      json={"herramienta": "consultar_rodales",
                                            "argumentos": {}})
        cuerpo = respuesta.get_json()
        self.assertTrue(cuerpo["ok"])
        self.assertEqual(cuerpo["datos"]["umm_evaluadas"], 1)

    def test_abrir_modulo_devuelve_una_url_real(self):
        respuesta = self.cliente.post("/api/dussan/herramienta",
                                      json={"herramienta": "abrir_modulo",
                                            "argumentos": {"modulo": "muestreo"}})
        cuerpo = respuesta.get_json()
        self.assertTrue(cuerpo["ok"])
        self.assertIn("/error-muestreo", cuerpo["datos"]["url"])

    def test_las_herramientas_sensibles_se_rechazan_por_http(self):
        respuesta = self.cliente.post("/api/dussan/herramienta",
                                      json={"herramienta": "eliminar_datos",
                                            "argumentos": {}})
        self.assertFalse(respuesta.get_json()["ok"])

    def test_el_chat_responde_aunque_no_haya_ia(self):
        respuesta = self.cliente.post("/api/dussan/chat",
                                      json={"pregunta": "dame las existencias"})
        self.assertEqual(respuesta.status_code, 200)
        cuerpo = respuesta.get_json()
        self.assertTrue(cuerpo["ok"])
        self.assertEqual(cuerpo["motor"], "determinista")

    def test_el_chat_exige_una_pregunta(self):
        respuesta = self.cliente.post("/api/dussan/chat", json={"pregunta": "  "})
        self.assertFalse(respuesta.get_json()["ok"])

    def test_el_chat_no_sale_a_la_red_en_la_suite(self):
        import ia_ollama
        import ia_online
        llamadas = []

        def trampa(*args, **kwargs):
            llamadas.append(args)
            raise AssertionError("La suite no debe llamar a un proveedor de IA.")

        originales = (ia_ollama._http_post_json, ia_ollama._http_get_json,
                      ia_online._http_post_json, ia_online._http_get_json)
        ia_ollama._http_post_json = trampa
        ia_ollama._http_get_json = trampa
        ia_online._http_post_json = trampa
        ia_online._http_get_json = trampa
        try:
            cuerpo = self.cliente.post("/api/dussan/chat",
                                       json={"pregunta": "dame las existencias"}).get_json()
        finally:
            (ia_ollama._http_post_json, ia_ollama._http_get_json,
             ia_online._http_post_json, ia_online._http_get_json) = originales
        self.assertEqual(llamadas, [])
        self.assertTrue(cuerpo["ok"])
        self.assertEqual(cuerpo["motor"], "determinista")

    def test_las_paginas_de_simfi_incorporan_dussan(self):
        html = self.cliente.get("/").get_data(as_text=True)
        self.assertIn("static/css/dussan.css", html)
        self.assertIn("static/js/dussan.js", html)
        self.assertIn("window.SIMFI_DUSSAN", html)
        self.assertIn("/api/dussan/chat", html)

    def test_el_arreglo_visual_declara_al_personaje_y_el_globo(self):
        html = self.cliente.get("/").get_data(as_text=True)
        # El panel lo construye el JS; el servidor publica el arranque y el avatar.
        # Admite los assets oficiales por estado en static/img/dussan/.
        self.assertIn("img/dussan/dussan_idle.png", html)
        self.assertIn("avatar", html)
        fuente = _leer("static", "js", "dussan.js")
        for identificador in ("dussan-panel", "dussan-escena", "dussan-avatar",
                              "dussan-globo", "dussan-pregunta", "dussan-respuesta",
                              "dussan-flotante", "dussan-quick", "dussan-composer"):
            self.assertIn(identificador, fuente)

    def test_el_saludo_y_los_iconos_siguen_la_referencia(self):
        fuente = _leer("static", "js", "dussan.js")
        self.assertIn("Soy Dussan", fuente)
        self.assertIn("asistente virtual de SIMFI", fuente)
        for etiqueta in ("Existencias", "Muestreo", "Incrementos", "UMM"):
            self.assertIn(etiqueta, fuente)

    def test_las_imagenes_oficiales_por_estado(self):
        with app_module.app.test_request_context("/"):
            self.assertEqual(app_module._dussan_avatar(),
                             "/static/img/dussan/dussan_idle.png")
            imagenes = app_module._dussan_imagenes()
        self.assertEqual(set(imagenes["estados"]),
                         {"idle", "listening", "thinking", "speaking", "success", "warning"})
        for estado, url in imagenes["estados"].items():
            self.assertEqual(url, "/static/img/dussan/dussan_%s.png" % estado)
        self.assertEqual(imagenes["mini"], "/static/img/dussan/dussan_idle.png")
        self.assertEqual(imagenes["avatar"], "/static/img/dussan/dussan_idle.png")

    def test_no_hay_estructura_de_chat_convencional(self):
        html = self.cliente.get("/").get_data(as_text=True)
        self.assertNotIn('id="dussan-chat"', html)
        self.assertNotIn("ear left", html)
        fuente = _leer("static", "js", "dussan.js")
        self.assertNotIn("dussan-msg", fuente)
        self.assertNotIn("dussan-chat", fuente)
        self.assertNotIn("ear left", fuente)

    def test_el_panel_aparece_en_distintos_modulos(self):
        for ruta in ("/rodales", "/reportes/cuadro_existencias", "/error-muestreo"):
            html = self.cliente.get(ruta).get_data(as_text=True)
            self.assertIn("window.SIMFI_DUSSAN", html, ruta)

    def test_el_login_no_muestra_dussan(self):
        html = self.cliente.get("/login").get_data(as_text=True)
        self.assertNotIn("dussan", html.lower())


if __name__ == "__main__":
    unittest.main()
