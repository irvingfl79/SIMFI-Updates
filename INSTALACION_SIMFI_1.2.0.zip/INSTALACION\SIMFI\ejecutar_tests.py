import subprocess, sys, os, glob
total = 0
ok = 0
fallos = []
for f in sorted(glob.glob(os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'test_*.py'))):
    total += 1
    r = subprocess.run([sys.executable, f], capture_output=True, text=True, cwd=os.path.dirname(__file__))
    if r.returncode != 0:
        fallos.append(os.path.basename(f))
    else:
        ok += 1
print(f"Total: {total} | OK: {ok} | Fallos: {len(fallos)}")
if fallos:
    print("Fallidos:", fallos)
