import datetime
import math
import re
import unicodedata

from guias_densidad import (calcular_diametro_cuadratico, construir_interpretacion,
                            evaluar_condicion, generar_datos_grafica,
                            seleccionar_modelo)


VERSION_MOTOR = "1.1.0"

# ============================================================
# BIBLIOTECA DE MODELOS DE CRECIMIENTO DIAMÉTRICO — VEIGA
# ============================================================
# Cada modelo contiene: identificador, especie de referencia,
# CE (calidad de estación), variable = D, y función de evaluación.
# Las ecuaciones CE2 (Pinus greggii) y CE3 (Juniperus deppeana)
# están pendientes de ser proporcionadas.

_VEIGA_MODELOS = {
    "patula_ce1": {
        "id": "patula_ce1",
        "especie_referencia": "Pinus patula",
        "ce": "CE1",
        "variable": "D",
        "eval": lambda e: 66.4998676 * math.exp(-20.15889937 / e),
    },
    "montezumae_ce1": {
        "id": "montezumae_ce1",
        "especie_referencia": "Pinus montezumae",
        "ce": "CE1",
        "variable": "D",
        "eval": lambda e: math.exp(4.935966066 - 11.35268725 * ((1.0 / e) ** 0.5434752)),
    },
    "teocote_ce1": {
        "id": "teocote_ce1",
        "especie_referencia": "Pinus teocote",
        "ce": "CE1",
        "variable": "D",
        "eval": lambda e: math.exp(5.219142952 - 11.5023248 * ((1.0 / e) ** 0.4678302)),
    },
    "rudis_ce1": {
        "id": "rudis_ce1",
        "especie_referencia": "Pinus rudis",
        "ce": "CE1",
        "variable": "D",
        "eval": lambda e: (e ** 2) / (34.163672 + 0.018922 * (e ** 2)),
    },
    # Pendientes: ecuaciones no proporcionadas en esta implementación.
    "patula_ce2": {
        "id": "patula_ce2",
        "especie_referencia": "Pinus patula",
        "ce": "CE2",
        "variable": "D",
        "eval": None,
    },
    "rudis_ce3": {
        "id": "rudis_ce3",
        "especie_referencia": "Pinus rudis",
        "ce": "CE3",
        "variable": "D",
        "eval": None,
    },
}

_MAPA_ESPECIE_VEIGA = {
    "pinus patula": "patula_ce1",
    "pinus montezumae": "montezumae_ce1",
    "pinus teocote": "teocote_ce1",
    "pinus rudis": "rudis_ce1",
    "pinus ayacahuite": "patula_ce1",
    "pinus greggii": "patula_ce2",
    "pinus leiophylla": "teocote_ce1",
    "pinus pseudostrobus": "montezumae_ce1",
    "abies religiosa": "patula_ce1",
    "cupressus lusitanica": "teocote_ce1",
    "juniperus deppeana": "rudis_ce3",
}


def _normalizar_especie_veiga(nombre):
    texto = unicodedata.normalize("NFKD", str(nombre or ""))
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", texto).strip().casefold()


def _modelo_veiga_para_especie(especie):
    return _MAPA_ESPECIE_VEIGA.get(_normalizar_especie_veiga(especie))


def _evaluar_modelo_veiga(modelo_id, edad):
    modelo = _VEIGA_MODELOS.get(modelo_id)
    if not modelo or modelo.get("eval") is None:
        return None
    try:
        return float(modelo["eval"](edad))
    except (ValueError, TypeError, ZeroDivisionError, OverflowError):
        return None


def clave_analisis(rodal_id, especie):
    return f"{rodal_id}||{especie}"


def _area_basal_individual(d_cm):
    """Área basal de un árbol con diámetro cuadrático d_cm (m²/árbol)."""
    return math.pi * (float(d_cm) / 100.0) ** 2 / 4.0


def intensidad_volumetrica_equivalente(escenario):
    """Devuelve el % volumetrico equivalente de un escenario disponible.

    Si la unidad del escenario ya es volumen, es su intensidad original; en
    otro caso se convierte con la extraccion simulada (extraida.v / actual.v).
    Devuelve (porcentaje, mensaje_error); el porcentaje es None si no se puede
    determinar.
    """
    if not isinstance(escenario, dict) or escenario.get("estado") != "disponible":
        return None, "El escenario no esta disponible para aplicar."
    if escenario.get("unidad_original") == "volumen":
        try:
            porcentaje = float(escenario.get("intensidad_original"))
        except (TypeError, ValueError):
            return None, "El escenario no trae una intensidad valida."
        if not math.isfinite(porcentaje):
            return None, "El escenario no trae una intensidad valida."
        return porcentaje, None
    equivalentes = escenario.get("intensidades_equivalentes") or {}
    try:
        porcentaje = float(equivalentes.get("v"))
    except (TypeError, ValueError):
        return None, "No se pudo convertir la intensidad a % volumetrico."
    if not math.isfinite(porcentaje):
        return None, "No se pudo convertir la intensidad a % volumetrico."
    return porcentaje, None


def _fila_intensidad(pmf, rid, esp, intensidad, criterio, fecha="", usuario=""):
    """Renglon del cuadro con la intensidad aplicada a N y V.

    Devuelve None si el renglón no tiene base dasométrica.
    """
    rodal = pmf.buscar_rodal(rid)
    if not rodal or rodal.oculto:
        return None
    resumen = resumen_rodal_especie(pmf, rid, esp)
    if resumen:
        nah = resumen.get("n") or 0
        vol_ha = resumen.get("v") or 0
    else:
        valores = pmf._calc_valores_rodal_especie(rid, esp)
        if not valores:
            return None
        nah = valores.get("Arb/ha", 0) or 0
        vol_ha = valores.get("ER m3/ha", 0) or 0
    sup = rodal.superficie_ha or 0
    try:
        intensidad = float(intensidad or 0)
    except (TypeError, ValueError):
        return None
    intensidad = min(100.0, max(0.0, intensidad))
    n_rem_ha = nah * intensidad / 100.0
    v_rem_ha = vol_ha * intensidad / 100.0
    return {
        "rodal": rid, "especie": esp,
        "criterio": criterio or "Sin aplicar",
        "intensidad": intensidad,
        "n_ha": nah, "n_total": nah * sup,
        "v_ha": vol_ha, "v_total": vol_ha * sup,
        "n_rem_ha": n_rem_ha, "n_rem_total": n_rem_ha * sup,
        "v_rem_ha": v_rem_ha, "v_rem_total": v_rem_ha * sup,
        "n_res_ha": nah - n_rem_ha, "n_res_total": (nah - n_rem_ha) * sup,
        "v_res_ha": vol_ha - v_rem_ha, "v_res_total": (vol_ha - v_rem_ha) * sup,
        "fecha": fecha, "usuario": usuario,
    }


def tabla_intensidades_aplicadas(pmf):
    """Filas del cuadro de intensidades aplicadas al cuadro de existencias.

    Por cada (rodal, especie) con procedencia registrada muestra la intensidad
    elegida aplicada a N y V (por ha y total) con remocion y residual.
    Usa los mismos valores del cuadro en pantalla (resumen_rodal_especie),
    con respaldo en el calculo directo, para que ambos cuadros coincidan.
    """
    filas = []
    origenes = getattr(pmf, "origen_intensidad", None) or {}
    for rid, especies in origenes.items():
        if not isinstance(especies, dict):
            continue
        for esp, dato in especies.items():
            if not isinstance(dato, dict):
                continue
            fila = _fila_intensidad(pmf, rid, esp, dato.get("intensidad", 0),
                                    dato.get("criterio", ""),
                                    dato.get("fecha", ""), dato.get("usuario", ""))
            if fila:
                filas.append(fila)
    return filas


def tabla_reporte_rodales(pmf):
    """Filas del reporte de rodales seleccionados, con intensidad aplicada o cero.

    Incluye todos los renglones con base dasométrica de las áreas
    seleccionadas; sin intensidad registrada usa 0 % ("Sin aplicar").
    """
    filas = []
    for rid in pmf.rodales_aclareo or []:
        rodal = pmf.buscar_rodal(rid)
        if not rodal or rodal.oculto:
            continue
        especies = set()
        for tabla in pmf.tablas_inventario:
            if tabla.rodal_id == rid:
                especies.add(tabla.especie)
        for registro in pmf.existencias_directas:
            if registro.rodal_id == rid:
                especies.add(registro.especie)
        for esp in sorted(especies, key=lambda especie: especie):
            dato = (pmf.origen_intensidad.get(rid, {}) or {}).get(esp, {})
            intensidad = dato.get("intensidad", 0) if isinstance(dato, dict) else 0
            fila = _fila_intensidad(
                pmf, rid, esp, intensidad,
                dato.get("criterio", "") if isinstance(dato, dict) else "",
                dato.get("fecha", "") if isinstance(dato, dict) else "",
                dato.get("usuario", "") if isinstance(dato, dict) else "")
            if fila:
                filas.append(fila)
    return filas


def resumen_rodal_especie(pmf, rodal_id, especie):
    rodal = pmf.buscar_rodal(rodal_id)
    if not rodal:
        return None
    if rodal.tipo_inventario == "existencias":
        directo = pmf.buscar_existencia_directa(rodal_id, especie)
        if not directo:
            return None
        inc = pmf.buscar_incremento_directo(rodal_id, especie)
        # Base de existencias, con respaldo en incrementos cuando es cero:
        # vincula lo capturado en ambos grupos.
        n = directo.arboles_ha or (inc.arboles_ha if inc else 0) or 0
        g = directo.ab_ha or (inc.ab_ha if inc else 0) or 0
        v = directo.vol_ha or 0
        dq = inc.dq_cm if inc and inc.dq_cm is not None else None
        h_prom = inc.h_m if inc and inc.h_m is not None else None
        ica = inc.ica_ha if inc and inc.ica_ha is not None else None
        return {
            "rodal": rodal_id, "especie": especie, "superficie": rodal.superficie_ha,
            "n": n, "g": g, "v": v,
            "dq": dq, "h_prom": h_prom, "clases": [],
            "tp": inc.tp if inc else None,
            "ica": ica,
            "ica_indicador_historico": inc.ica_pct if inc and inc.ica_pct is not None else None,
            "tasa_incremento_volumetrico_pct": (
                ica / v * 100.0
                if ica is not None and ica > 0 and v > 0 else None),
            "ima": inc.ima_ha if inc else None,
            "edad": inc.edad if inc else None,
        }
    tabla = pmf.buscar_tabla_inventario(rodal_id, especie)
    if not tabla:
        return None
    factor = pmf.obtener_factor_expansion(rodal)
    clases = []
    for clase in sorted(tabla.clases, key=lambda item: item.dncc):
        if clase.no_arboles <= 0:
            continue
        n = tabla.no_arb_ha(clase, factor, rodal.sitios, pmf.usar_factor_ajuste)
        g = tabla.area_basal_ha(clase, n)
        volumen_unitario = tabla.volumen_unitario(clase, pmf)
        clases.append({
            "dncc": clase.dncc, "altura": clase.altura_m,
            "n": n, "g": g, "v": volumen_unitario * n,
            "volumen_unitario": volumen_unitario,
        })
    if not clases:
        return None
    n = sum(clase["n"] for clase in clases)
    g = sum(clase["g"] for clase in clases)
    v = sum(clase["v"] for clase in clases)
    dq = math.sqrt(40000.0 * g / (math.pi * n)) if n > 0 and g > 0 else None
    h_prom = sum(clase["altura"] * clase["n"] for clase in clases) / n if n > 0 else None
    valores = pmf._calc_valores_rodal_especie(rodal_id, especie) or {}
    ica = valores.get("ICA m3")
    tasa_volumetrica = ica / v * 100.0 if ica is not None and ica > 0 and v > 0 else None
    tp = None
    if dq:
        diametros = [clase["dncc"] for clase in clases]
        cercano = min(diametros, key=lambda diametro: abs(diametro - dq))
        tp = pmf.calcular_tp(especie, cercano)
    edad = pmf.calcular_edad(especie, int(round(dq))) if dq else None
    return {
        "rodal": rodal_id, "especie": especie, "superficie": rodal.superficie_ha,
        "n": n, "g": g, "v": v, "dq": dq, "h_prom": h_prom, "clases": clases,
        "tp": tp, "ica": ica, "ica_indicador_historico": valores.get("ICA %"),
        "tasa_incremento_volumetrico_pct": tasa_volumetrica,
        "ima": v / edad if edad else None, "edad": edad,
    }


def simular_extraccion_clases(actual, objetivo, variable):
    if variable not in {"n", "g", "v"}:
        raise ValueError("La variable de intensidad no es válida.")
    total = actual[variable]
    if objetivo < 0 or objetivo >= total:
        raise ValueError("La extracción debe ser mayor o igual a cero y menor que la existencia actual.")
    if not actual.get("clases"):
        # Sin estructura diamétrica (valores directos): reparto proporcional.
        proporcion = objetivo / total if total > 0 else 0.0
        extraida = {clave: (actual.get(clave) or 0) * proporcion for clave in ("n", "g", "v")}
        residual = {clave: (actual.get(clave) or 0) - extraida[clave] for clave in ("n", "g", "v")}
        residual["dq"] = None
        return residual, extraida, [], []
    faltante = objetivo
    clases_residuales = []
    clases_extraidas = []
    for clase in actual["clases"]:
        disponible = clase[variable]
        proporcion = min(1.0, faltante / disponible) if disponible > 0 and faltante > 0 else 0.0
        extraida = {clave: clase[clave] * proporcion for clave in ("n", "g", "v")}
        residual = {clave: clase[clave] - extraida[clave] for clave in ("n", "g", "v")}
        clases_extraidas.append({"dncc": clase["dncc"], **extraida})
        clases_residuales.append({"dncc": clase["dncc"], **residual})
        faltante = max(0.0, faltante - extraida[variable])
    residual = {
        clave: sum(clase[clave] for clase in clases_residuales)
        for clave in ("n", "g", "v")
    }
    extraida = {clave: actual[clave] - residual[clave] for clave in ("n", "g", "v")}
    residual["dq"] = (math.sqrt(40000.0 * residual["g"] / (math.pi * residual["n"]))
                      if residual["n"] > 0 and residual["g"] > 0 else None)
    return residual, extraida, clases_residuales, clases_extraidas


def _evaluar_guia(condicion, modelo):
    if not modelo or condicion["n"] <= 0 or condicion["g"] <= 0:
        return {"estado": "sin_guia", "modelo_id": None, "resultado": None,
                "interpretacion": None, "alerta": False}
    resultado = evaluar_condicion(condicion["n"], condicion["g"], modelo)
    interpretacion = construir_interpretacion(resultado, modelo)
    tono = (interpretacion or {}).get("semaforo", {}).get("tono")
    return {
        "estado": "evaluado", "modelo_id": modelo["modelo_id"],
        "version_modelo": modelo.get("version_modelo"), "resultado": resultado,
        "interpretacion": interpretacion, "alerta": tono in {"bajo", "atencion"},
    }


def _completar_escenario(escenario, actual, modelo):
    residual = escenario["residual"]
    extraida = escenario["extraida"]
    escenario["intensidades_equivalentes"] = {
        clave: extraida[clave] / actual[clave] * 100.0
        if actual.get(clave) and extraida.get(clave) is not None else None
        for clave in ("n", "g", "v")
    }
    escenario["guia"] = _evaluar_guia(residual, modelo)
    return escenario


def escenario_mmobi(actual, ciclo_corta, modelo):
    ica_porcentaje = actual.get("ica_indicador_historico")
    if ica_porcentaje is None or not math.isfinite(ica_porcentaje) or ica_porcentaje < 0:
        return {"id": "mmobi", "nombre": "MMOBI", "estado": "pendiente",
                "mensaje": "No existe un ICA % válido para calcular MMOBI."}
    # MMOBI utiliza directamente el ICA % del cálculo de incrementos.
    p = ica_porcentaje / 100.0
    intensidad = (1.0 - 1.0 / ((1.0 + p) ** ciclo_corta)) * 100.0
    objetivo = actual["v"] * intensidad / 100.0
    residual, extraida, clases_residuales, clases_extraidas = simular_extraccion_clases(actual, objetivo, "v")
    return _completar_escenario({
        "id": "mmobi", "nombre": "MMOBI", "estado": "disponible",
        "intensidad_original": intensidad, "unidad_original": "volumen",
        "parametros": {"p_anual": p, "ica_porcentaje": ica_porcentaje,
                       "ciclo_corta": ciclo_corta,
                       "formula": "[1 - 1/(1+ICA%/100)^CC] * 100"},
        "residual": residual, "extraida": extraida,
        "clases_residuales": clases_residuales, "clases_extraidas": clases_extraidas,
        "supuesto_simulacion": (
            "Reparto proporcional por falta de estructura diamétrica."
            if not actual.get("clases") else
            "Extracción desde clases diamétricas menores hacia mayores."),
    }, actual, modelo)


def _validar_edad_retro(edad_actual, edad_retro_raw):
    if edad_retro_raw in (None, ""):
        return None, None
    try:
        edad_retro = float(edad_retro_raw)
    except (ValueError, TypeError):
        return None, "La edad de referencia debe ser numérica."
    if edad_retro <= 0:
        return None, "La edad de referencia debe ser mayor que cero."
    if edad_retro >= edad_actual:
        return None, "La edad de referencia debe ser menor que la edad actual."
    return edad_retro, None


def escenario_veiga(actual, parametros=None, modelo=None):
    """
    Escenario del método de Veiga.

    Separa claramente:
      - Diagnóstico de crecimiento (opcional): usa el modelo diamétrico y una
        edad de referencia para obtener DQ retroproyectado y el indicador T.
      - Regulación del rodal (opcional): a partir de un diámetro deseado y un
        área basal guía, calcula N residual, N a extraer e intensidad de corta.

    El indicador T se presenta únicamente como variación relativa del diámetro;
    nunca se usa como intensidad de corta.
    """
    especie = actual.get("especie")
    dq_actual = actual.get("dq")
    edad_actual = actual.get("edad")
    n_actual = actual.get("n")
    g_actual = actual.get("g")

    base = {"id": "veiga", "nombre": "Veiga"}

    if not especie:
        return {**base, "estado": "no_disponible",
                "mensaje": "No se dispone de especie para calcular Veiga."}

    modelo_id = _modelo_veiga_para_especie(especie)
    if not modelo_id:
        return {**base, "estado": "no_disponible",
                "mensaje": "No existe un modelo de crecimiento diamétrico asignado para esta especie."}

    modelo_veiga = _VEIGA_MODELOS.get(modelo_id)
    if modelo_veiga.get("eval") is None:
        return {**base, "estado": "no_disponible",
                "mensaje": f"La ecuación {modelo_veiga['especie_referencia']} {modelo_veiga['ce']} aún no ha sido proporcionada."}

    parametros = parametros or {}

    # ---------- Diagnóstico de crecimiento ----------
    diagnostico = None
    edad_retro_raw = parametros.get("edad_retroproyeccion")
    if edad_retro_raw not in (None, ""):
        edad_retro, error = _validar_edad_retro(edad_actual, edad_retro_raw)
        if error:
            return {**base, "estado": "no_disponible", "mensaje": error}
        dq_anterior = _evaluar_modelo_veiga(modelo_id, edad_retro)
        if dq_anterior is None or not math.isfinite(dq_anterior) or dq_anterior <= 0:
            return {**base, "estado": "no_disponible",
                    "mensaje": "El modelo no pudo retroproyectar un DQ válido para la edad indicada."}
        t_veiga = ((2.0 * (dq_actual - dq_anterior) / (dq_actual + dq_anterior))
                   * 100.0) if dq_actual and dq_actual > 0 else None
        diagnostico = {
            "modelo_referencia": modelo_veiga["especie_referencia"],
            "ce_modelo": modelo_veiga["ce"],
            "modelo_id": modelo_id,
            "edad_actual": edad_actual,
            "edad_retroproyeccion": edad_retro,
            "dq_actual": dq_actual,
            "dq_retroproyectado": dq_anterior,
            "t_veiga": t_veiga,
            "formula_t": "T = [2(D - d) / (D + d)] × 100",
            "interpretacion_t": ("El indicador T corresponde a la variación relativa del "
                                 "diámetro cuadrático entre las edades consideradas. No "
                                 "representa directamente el porcentaje de árboles a extraer."),
        }

    # ---------- Regulación del rodal ----------
    d_deseado_raw = parametros.get("diametro_deseado")
    densidad_objetivo_raw = parametros.get("densidad_objetivo")
    if d_deseado_raw not in (None, "") or densidad_objetivo_raw not in (None, ""):
        if d_deseado_raw in (None, "") or densidad_objetivo_raw in (None, ""):
            return {**base, "estado": "no_disponible",
                    "mensaje": "Para calcular la regulación indique el diámetro deseado y la densidad objetivo."}
        try:
            d_deseado = float(d_deseado_raw)
            densidad_objetivo = float(densidad_objetivo_raw)
        except (ValueError, TypeError):
            return {**base, "estado": "no_disponible",
                    "mensaje": "El diámetro deseado y la densidad objetivo deben ser numéricos."}

        if n_actual is None or n_actual <= 0 or g_actual is None or g_actual <= 0:
            return {**base, "estado": "no_disponible",
                    "mensaje": "Se requieren N y G actuales para calcular la regulación."}
        if dq_actual is None or dq_actual <= 0:
            return {**base, "estado": "no_disponible",
                    "mensaje": "Se requiere DQ actual para validar el diámetro deseado."}
        if d_deseado <= 0:
            return {**base, "estado": "no_disponible",
                    "mensaje": "El diámetro deseado debe ser mayor que cero."}
        if d_deseado <= dq_actual:
            return {**base, "estado": "no_disponible",
                    "mensaje": "El diámetro deseado debe ser mayor que el DQ actual."}
        if densidad_objetivo <= 0:
            return {**base, "estado": "no_disponible",
                    "mensaje": "La densidad objetivo debe ser mayor que cero."}

        ab_ind = _area_basal_individual(d_deseado)
        g_guia = densidad_objetivo * ab_ind
        n_residual = densidad_objetivo
        n_extraer = n_actual - n_residual

        if n_residual > n_actual:
            return {**base, "estado": "no_disponible",
                    "mensaje": "La densidad objetivo seleccionada no genera una extracción; supera la densidad actual."}
        if g_guia > g_actual:
            return {**base, "estado": "no_disponible",
                    "mensaje": "La combinación de densidad objetivo y diámetro deseado supera el área basal actual."}
        if n_residual < 0 or n_extraer < 0:
            return {**base, "estado": "no_disponible",
                    "mensaje": "Los parámetros de regulación producen valores negativos."}

        ic_numero = (n_extraer / n_actual) * 100.0 if n_actual > 0 else None
        if ic_numero is not None and not (0.0 <= ic_numero <= 100.0):
            return {**base, "estado": "no_disponible",
                    "mensaje": "La intensidad calculada está fuera del rango válido (0-100 %)."}

        g_residual = n_residual * ab_ind  # equivale a g_guia
        g_extraer = g_actual - g_residual

        # Construir escenario residual/extraído. Si hay distribución diamétrica,
        # se respeta; de lo contrario se reparte proporcional (valores directos).
        if actual.get("clases"):
            residual, extraida, clases_residuales, clases_extraidas = simular_extraccion_clases(
                actual, n_extraer, "n")
        else:
            v_actual = actual.get("v") or 0
            proporcion = n_extraer / n_actual if n_actual > 0 else 0.0
            v_extraer = v_actual * proporcion
            residual = {"n": n_residual, "g": g_residual, "v": v_actual - v_extraer,
                        "dq": d_deseado}
            extraida = {"n": n_extraer, "g": g_extraer, "v": v_extraer}
            clases_residuales = []
            clases_extraidas = []

        escenario = {
            **base,
            "estado": "disponible",
            "especie": especie,
            "n_actual": n_actual,
            "g_actual": g_actual,
            "dq_actual": dq_actual,
            "diametro_deseado": d_deseado,
            "densidad_objetivo": densidad_objetivo,
            "g_guia": g_guia,
            "ab_individual_deseado": ab_ind,
            "n_residual": n_residual,
            "n_extraer": n_extraer,
            "g_residual": g_residual,
            "g_extraer": g_extraer,
            "intensidad_original": ic_numero,
            "unidad_original": "numero_arboles",
            "intensidad_numero_pct": ic_numero,
            "n_residual_arboles_ha": n_residual,
            "n_extraer_arboles_ha": n_extraer,
            "residual": residual,
            "extraida": extraida,
            "clases_residuales": clases_residuales,
            "clases_extraidas": clases_extraidas,
            "parametros": {
                "diametro_deseado_cm": d_deseado,
                "densidad_objetivo_arboles_ha": densidad_objetivo,
                "area_basal_guia_m2_ha": g_guia,
                "area_basal_individual_deseado_m2": ab_ind,
                "formula_area_basal_guia": "G_guía = densidad_objetivo × AB_individual_deseado",
                "formula_n_residual": "N_residual = densidad_objetivo",
                "formula_intensidad": "IC = (N_extraer / N_actual) × 100",
                "modelo_id": modelo_id,
                "modelo_referencia": modelo_veiga["especie_referencia"],
                "ce_modelo": modelo_veiga["ce"],
            },
            "mensaje": "Intensidad de corta calculada a partir del diámetro deseado y el área basal guía.",
            "diagnostico_crecimiento": diagnostico,
        }
        return _completar_escenario(escenario, actual, modelo)

    # Solo diagnóstico (sin regulación)
    if diagnostico is not None:
        return {
            **base,
            "estado": "diagnostico",
            "especie": especie,
            "modelo_referencia": modelo_veiga["especie_referencia"],
            "ce_modelo": modelo_veiga["ce"],
            "edad_actual": diagnostico["edad_actual"],
            "edad_retroproyeccion": diagnostico["edad_retroproyeccion"],
            "dq_actual": diagnostico["dq_actual"],
            "dq_retroproyectado": diagnostico["dq_retroproyectado"],
            "t_veiga": diagnostico["t_veiga"],
            "intensidad_original": None,
            "unidad_original": None,
            "mensaje": "Diagnóstico de crecimiento calculado; la intensidad de corta requiere regulación residual.",
            "parametros": {
                "formula_veiga": "T = [2(D - d) / (D + d)] × 100",
                "modelo_id": modelo_id,
                "modelo_referencia": modelo_veiga["especie_referencia"],
                "ce_modelo": modelo_veiga["ce"],
            },
            "diagnostico_crecimiento": diagnostico,
        }

    return {**base, "estado": "no_disponible",
            "mensaje": "Indique el diámetro deseado y la densidad objetivo para calcular Veiga."}


def escenario_usuario(actual, intensidad, unidad, modelo):
    intensidad = float(intensidad)
    if intensidad < 0 or intensidad >= 100:
        raise ValueError("La intensidad propuesta debe estar entre 0 y menos de 100 %.")
    mapa = {"volumen": "v", "area_basal": "g", "numero_arboles": "n"}
    variable = mapa.get(unidad)
    if not variable:
        raise ValueError("Seleccione una variable válida para la propuesta.")
    objetivo = actual[variable] * intensidad / 100.0
    residual, extraida, clases_residuales, clases_extraidas = simular_extraccion_clases(actual, objetivo, variable)
    return _completar_escenario({
        "id": "usuario", "nombre": "Propuesta del usuario", "estado": "disponible",
        "intensidad_original": intensidad, "unidad_original": unidad,
        "parametros": {"variable_objetivo": variable},
        "residual": residual, "extraida": extraida,
        "clases_residuales": clases_residuales, "clases_extraidas": clases_extraidas,
        "supuesto_simulacion": (
            "Reparto proporcional por falta de estructura diamétrica."
            if not actual.get("clases") else
            "Extracción desde clases diamétricas menores hacia mayores."),
    }, actual, modelo)


def datos_grafica_aclareo(actual, modelo=None, resultado_actual=None):
    if modelo and resultado_actual:
        return generar_datos_grafica(modelo, resultado_actual)
    return {
        "curvas": [], "curvas_grado": [], "isolineas": [],
        "max_n": max(actual["n"] * 1.15, 100.0),
        "max_g": max(actual["g"] * 1.15, 1.0), "vista": None,
        "vistas": [], "zonas": [],
    }


def construir_evaluacion(pmf, rodal_id, especie, ciclo_corta, modelos=None,
                         parametros_veiga=None):
    actual = resumen_rodal_especie(pmf, rodal_id, especie)
    if not actual:
        raise ValueError("No existen datos de inventario para el rodal y especie.")
    modelo = seleccionar_modelo(especie, modelos=modelos)
    guia_actual = _evaluar_guia(actual, modelo)
    mmobi = escenario_mmobi(actual, ciclo_corta, modelo)
    veiga = escenario_veiga(actual, parametros=parametros_veiga, modelo=modelo)
    grafica = datos_grafica_aclareo(actual, modelo, guia_actual["resultado"])
    return {
        "version_motor": VERSION_MOTOR, "actual": actual, "guia_actual": guia_actual,
        "modelo": modelo, "escenarios": {"mmobi": mmobi, "veiga": veiga},
        "adoptado": None, "ciclo_corta": ciclo_corta, "grafica": grafica,
    }


def registrar_trazabilidad(evaluacion, usuario):
    evaluacion["fecha"] = datetime.datetime.now().isoformat(timespec="seconds")
    evaluacion["usuario"] = usuario
    modelo = evaluacion.get("modelo") or {}
    evaluacion["modelo_densidad_utilizado"] = modelo.get("modelo_id")
    evaluacion["version_modelo"] = modelo.get("version_modelo")
    return evaluacion
