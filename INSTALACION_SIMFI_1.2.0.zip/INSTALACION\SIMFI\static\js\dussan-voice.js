/* Dussan — voz (integrada desde el inicio, DESACTIVADA por defecto).
   La activacion es siempre explicita por el usuario. Si el navegador no
   ofrece dictado, Dussan lo informa y conserva el compositor de texto. */
(function (global) {
  'use strict';

  function DussanVoice() {
    this.habilitada = false;
    this.idioma = 'es-MX';
    this.velocidad = 0.95;
    this.reconocimiento = null;
    this.escuchando = false;
  }

  DussanVoice.prototype.sintesisDisponible = function () {
    return typeof global.speechSynthesis !== 'undefined' &&
      typeof global.SpeechSynthesisUtterance !== 'undefined';
  };

  DussanVoice.prototype.dictadoDisponible = function () {
    return !!(global.SpeechRecognition || global.webkitSpeechRecognition);
  };

  DussanVoice.prototype.habilitar = function () {
    if (!this.sintesisDisponible()) {
      return {ok: false, mensaje: 'Este navegador no ofrece lectura en voz.'};
    }
    this.habilitada = true;
    return {ok: true, mensaje: 'Voz activada. Dussan hablara sus respuestas.'};
  };

  DussanVoice.prototype.deshabilitar = function () {
    this.habilitada = false;
    this.cancelar();
    return {ok: true, mensaje: 'Voz desactivada.'};
  };

  DussanVoice.prototype.cancelar = function () {
    try {
      if (this.sintesisDisponible()) { global.speechSynthesis.cancel(); }
    } catch (error) { /* la voz nunca debe romper la conversacion */ }
  };

  DussanVoice.prototype.hablar = function (texto) {
    if (!this.habilitada || !this.sintesisDisponible() || !texto) { return false; }
    try {
      var utterance = new global.SpeechSynthesisUtterance(String(texto));
      utterance.lang = this.idioma;
      utterance.rate = this.velocidad;
      global.speechSynthesis.cancel();
      global.speechSynthesis.speak(utterance);
      return true;
    } catch (error) {
      return false;
    }
  };

  DussanVoice.prototype.esperar = function () {
    if (!this.habilitada) {
      return Promise.reject(new Error('La voz esta desactivada.'));
    }
    if (!this.dictadoDisponible()) {
      return Promise.reject(new Error(
        'El dictado por voz no esta disponible en este navegador. Escribe tu pregunta.'));
    }
    var Reconocimiento = global.SpeechRecognition || global.webkitSpeechRecognition;
    var voz = this;
    return new Promise(function (resolver, rechazar) {
      var reconocimiento = new Reconocimiento();
      voz.reconocimiento = reconocimiento;
      voz.escuchando = true;
      reconocimiento.lang = voz.idioma;
      reconocimiento.interimResults = false;
      reconocimiento.maxAlternatives = 1;
      reconocimiento.onresult = function (evento) {
        voz.escuchando = false;
        resolver(evento.results[0][0].transcript);
      };
      reconocimiento.onerror = function (evento) {
        voz.escuchando = false;
        rechazar(new Error(evento.error === 'not-allowed'
          ? 'No se concedio permiso para usar el microfono.'
          : 'No se pudo escuchar. Escribe tu pregunta.'));
      };
      reconocimiento.onend = function () { voz.escuchando = false; };
      try { reconocimiento.start(); } catch (error) {
        voz.escuchando = false;
        rechazar(error);
      }
    });
  };

  global.DussanVoice = DussanVoice;
}(window));
