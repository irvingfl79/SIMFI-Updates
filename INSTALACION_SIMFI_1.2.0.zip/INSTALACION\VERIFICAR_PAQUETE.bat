@echo off
setlocal
cd /d "%~dp0"
title Verificacion del paquete SIMFI

echo Verificando archivos y dependencias...
if not exist "SIMFI\python\python.exe" goto ERROR
if not exist "SIMFI\python\pythonw.exe" goto ERROR
if not exist "SIMFI\app.py" goto ERROR
if not exist "SIMFI\run.py" goto ERROR
if not exist "SIMFI\img\SIMFI_icon.ico" goto ERROR

"SIMFI\python\python.exe" -c "import flask, openpyxl, docx; from app import app; print('Paquete SIMFI correcto')"
if errorlevel 1 goto ERROR

echo.
echo El paquete esta completo y listo para copiar a otra PC.
pause
exit /b 0

:ERROR
echo.
echo ERROR: El paquete esta incompleto o alguna dependencia no funciona.
pause
exit /b 1
