import atexit
import ctypes
import json
import os
import subprocess
import sys
import threading
import time
import webbrowser
from ctypes import wintypes


BASE = os.path.dirname(os.path.abspath(__file__))
INSTALL_DIR = os.path.dirname(BASE) if os.path.basename(BASE).lower() == "app" else BASE
LOCAL_PYTHON = next((ruta for ruta in (
    os.path.join(BASE, "python", "python.exe"),
    os.path.join(INSTALL_DIR, "python", "python.exe"),
) if os.path.isfile(ruta)), "")
URL_SISTEMA = "http://127.0.0.1:5000"
BROWSER_PROFILE = os.path.join(os.environ.get("LOCALAPPDATA", BASE), "SIMFI", "BraveProfile")
# El servidor ya está enlazado antes de abrir el navegador; sólo se conserva un margen breve.
RETRASO_APERTURA_NAVEGADOR_S = 0.1

_browser_process = None
_browser_profile = None
_browser_job = None
_browser_lock = threading.Lock()
_browser_ready = threading.Event()
_instance_mutex = None


def _version_sistema():
    for ruta in (os.path.join(BASE, "version.json"), os.path.join(INSTALL_DIR, "version.json")):
        try:
            with open(ruta, "r", encoding="utf-8") as archivo:
                return json.load(archivo).get("version", "1.0")
        except (OSError, ValueError):
            pass
    return "1.0"


def _activar_ventana_existente():
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    encontrada = False
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    @callback_type
    def revisar(hwnd, _):
        nonlocal encontrada
        longitud = user32.GetWindowTextLengthW(hwnd)
        if not longitud:
            return True
        titulo = ctypes.create_unicode_buffer(longitud + 1)
        user32.GetWindowTextW(hwnd, titulo, longitud + 1)
        if "sistema para el manejo forestal" not in titulo.value.lower():
            return True
        user32.ShowWindow(hwnd, 3)  # SW_MAXIMIZE
        user32.SetForegroundWindow(hwnd)
        encontrada = True
        return False

    user32.EnumWindows(revisar, 0)
    return encontrada


def _maximizar_ventana_sistema():
    for _ in range(30):
        if _activar_ventana_existente():
            return True
        time.sleep(0.5)
    return False


def _adquirir_instancia_unica():
    global _instance_mutex
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
    kernel32.CreateMutexW.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    mutex = kernel32.CreateMutexW(None, False, "Local\\SIMFI_SingleInstance")
    if not mutex:
        return True
    if ctypes.get_last_error() == 183:  # ERROR_ALREADY_EXISTS
        kernel32.CloseHandle(mutex)
        _activar_ventana_existente()
        return False
    _instance_mutex = mutex
    return True


def _liberar_instancia():
    global _instance_mutex
    if _instance_mutex:
        ctypes.WinDLL("kernel32", use_last_error=True).CloseHandle(_instance_mutex)
        _instance_mutex = None


class _IO_COUNTERS(ctypes.Structure):
    _fields_ = [
        ("ReadOperationCount", ctypes.c_ulonglong),
        ("WriteOperationCount", ctypes.c_ulonglong),
        ("OtherOperationCount", ctypes.c_ulonglong),
        ("ReadTransferCount", ctypes.c_ulonglong),
        ("WriteTransferCount", ctypes.c_ulonglong),
        ("OtherTransferCount", ctypes.c_ulonglong),
    ]


class _JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("PerProcessUserTimeLimit", ctypes.c_longlong),
        ("PerJobUserTimeLimit", ctypes.c_longlong),
        ("LimitFlags", wintypes.DWORD),
        ("MinimumWorkingSetSize", ctypes.c_size_t),
        ("MaximumWorkingSetSize", ctypes.c_size_t),
        ("ActiveProcessLimit", wintypes.DWORD),
        ("Affinity", ctypes.c_size_t),
        ("PriorityClass", wintypes.DWORD),
        ("SchedulingClass", wintypes.DWORD),
    ]


class _JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("BasicLimitInformation", _JOBOBJECT_BASIC_LIMIT_INFORMATION),
        ("IoInfo", _IO_COUNTERS),
        ("ProcessMemoryLimit", ctypes.c_size_t),
        ("JobMemoryLimit", ctypes.c_size_t),
        ("PeakProcessMemoryUsed", ctypes.c_size_t),
        ("PeakJobMemoryUsed", ctypes.c_size_t),
    ]


def _buscar_navegador():
    local = os.environ.get("LOCALAPPDATA", "")
    program_files = os.environ.get("PROGRAMFILES", "")
    program_files_x86 = os.environ.get("PROGRAMFILES(X86)", "")
    candidatos = [
        ("Brave", os.path.join(program_files, "BraveSoftware", "Brave-Browser", "Application", "brave.exe")),
        ("Brave", os.path.join(program_files_x86, "BraveSoftware", "Brave-Browser", "Application", "brave.exe")),
        ("Brave", os.path.join(local, "BraveSoftware", "Brave-Browser", "Application", "brave.exe")),
        ("Edge", os.path.join(program_files_x86, "Microsoft", "Edge", "Application", "msedge.exe")),
        ("Edge", os.path.join(program_files, "Microsoft", "Edge", "Application", "msedge.exe")),
        ("Edge", os.path.join(local, "Microsoft", "Edge", "Application", "msedge.exe")),
        ("Chrome", os.path.join(program_files, "Google", "Chrome", "Application", "chrome.exe")),
        ("Chrome", os.path.join(program_files_x86, "Google", "Chrome", "Application", "chrome.exe")),
        ("Chrome", os.path.join(local, "Google", "Chrome", "Application", "chrome.exe")),
        ("Firefox", os.path.join(program_files, "Mozilla Firefox", "firefox.exe")),
        ("Firefox", os.path.join(program_files_x86, "Mozilla Firefox", "firefox.exe")),
        ("Firefox", os.path.join(local, "Mozilla Firefox", "firefox.exe")),
    ]
    return next(((nombre, ruta) for nombre, ruta in candidatos if ruta and os.path.isfile(ruta)), None)


def _asignar_job(proceso):
    # El trabajo de Windows cierra todo el arbol del navegador si termina el servidor.
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CreateJobObjectW.restype = wintypes.HANDLE
    kernel32.SetInformationJobObject.restype = wintypes.BOOL
    kernel32.AssignProcessToJobObject.restype = wintypes.BOOL
    kernel32.CloseHandle.restype = wintypes.BOOL
    job = kernel32.CreateJobObjectW(None, None)
    if not job:
        return None
    info = _JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
    info.BasicLimitInformation.LimitFlags = 0x00002000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
    if not kernel32.SetInformationJobObject(job, 9, ctypes.byref(info), ctypes.sizeof(info)):
        kernel32.CloseHandle(job)
        return None
    if not kernel32.AssignProcessToJobObject(job, wintypes.HANDLE(proceso._handle)):
        kernel32.CloseHandle(job)
        return None
    return job


def _abrir_navegador_privado():
    global _browser_process, _browser_profile, _browser_job
    navegador = _buscar_navegador()
    if not navegador:
        webbrowser.open(URL_SISTEMA)
        print("\n  Se abrio SIMFI en el navegador predeterminado del sistema.")
        _browser_ready.set()
        return
    nombre, ejecutable = navegador
    with _browser_lock:
        if _browser_process:
            return
        os.makedirs(BROWSER_PROFILE, exist_ok=True)
        _browser_profile = BROWSER_PROFILE
        argumentos = [ejecutable, URL_SISTEMA] if nombre == "Firefox" else [
            ejecutable, f"--app={URL_SISTEMA}", "--start-maximized", "--no-first-run",
            "--no-default-browser-check", "--disable-sync", "--disable-signin-promo",
            "--disable-background-mode", "--disable-extensions",
            "--disable-features=msEdgeStartupBoost,msEdgeFirstRunExperience,EdgeSigninIntercept,msEdgeAccountExtension,msEdgeSync",
            f"--user-data-dir={_browser_profile}",
        ]
        try:
            _browser_process = subprocess.Popen(
                argumentos,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
            )
            _browser_job = _asignar_job(_browser_process)
            threading.Thread(target=_maximizar_ventana_sistema, daemon=True).start()
            print(f"\n  Ventana de aplicación: {nombre}")
        except Exception as error:
            print(f"\n  No se pudo abrir la ventana de SIMFI: {error}")
            _browser_process = None
        finally:
            _browser_ready.set()


def _vigilar_cierre_navegador(servidor):
    _browser_ready.wait()
    with _browser_lock:
        proceso = _browser_process
    if not proceso:
        return
    proceso.wait()
    print("\n  Navegador cerrado. Deteniendo el sistema...")
    servidor.shutdown()


def _cerrar_navegador():
    global _browser_process, _browser_profile, _browser_job
    with _browser_lock:
        proceso = _browser_process
        job = _browser_job
        perfil = _browser_profile
        _browser_process = None
        _browser_job = None
        _browser_profile = None
    if job:
        ctypes.WinDLL("kernel32", use_last_error=True).CloseHandle(job)
    elif proceso and proceso.poll() is None:
        subprocess.run(["taskkill", "/PID", str(proceso.pid), "/T", "/F"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    if proceso:
        try:
            proceso.wait(timeout=5)
        except subprocess.TimeoutExpired:
            pass


atexit.register(_cerrar_navegador)
atexit.register(_liberar_instancia)


def main():
    os.chdir(BASE)
    if not _adquirir_instancia_unica():
        return
    python_exe = LOCAL_PYTHON if os.path.isfile(LOCAL_PYTHON) else sys.executable

    print("=" * 60)
    print(f"  Sistema para el manejo forestal intensivo V {_version_sistema()}")
    print(f"  Python: {python_exe}")
    print("=" * 60)

    try:
        import flask
    except ImportError:
        print("Instalando dependencias...")
        subprocess.check_call([python_exe, "-m", "pip", "install", "-r",
                               os.path.join(BASE, "requirements.txt")])

    from app import app
    from werkzeug.serving import make_server
    print(f"\n  Abriendo en modo privado: {URL_SISTEMA}")
    print("  Cierre esta ventana o presione Ctrl+C para detener")
    print("=" * 60)
    servidor = make_server("127.0.0.1", 5000, app, threaded=True)
    apertura = threading.Timer(RETRASO_APERTURA_NAVEGADOR_S, _abrir_navegador_privado)
    apertura.daemon = True
    apertura.start()
    vigilante = threading.Thread(target=_vigilar_cierre_navegador,
                                 args=(servidor,), daemon=True)
    vigilante.start()
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        apertura.cancel()
        _browser_ready.set()
        servidor.server_close()
        _cerrar_navegador()


if __name__ == "__main__":
    main()
