@echo off
setlocal
cd /d "%~dp0"
title Instalacion de SIMFI

echo ============================================================
echo   SIMFI - Instalador offline para Windows 64 bits
echo ============================================================
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar_simfi.ps1"
if errorlevel 1 (
  echo.
  echo La instalacion no se completo. Revise el mensaje anterior.
  pause
  exit /b 1
)

echo.
choice /C SN /N /M "Desea iniciar SIMFI ahora? [S/N]: "
if errorlevel 2 goto FIN
start "" "%LOCALAPPDATA%\SIMFI\python\pythonw.exe" "%LOCALAPPDATA%\SIMFI\run.py"

:FIN
echo.
echo Puede abrir SIMFI desde el acceso directo del Escritorio.
pause
exit /b 0
