"""Capa de indicadores, validacion y diagnostico para reportes forestales.

No modifica el proyecto. Sus resultados son datos simples para poder
persistir una instantanea reproducible junto con el reporte que la usa.
"""
from collections import defaultdict

from guias_densidad import cargar_modelos_densidad, seleccionar_modelo


VERSION_REGLAS = "1.0"
FUENTES = {
    "inventario": "Inventario y ecuaciones registrados en el proyecto SIMFI.",
    "densidad": "Catálogo de guías de densidad SIMFI; aplicar sólo dentro de su ámbito declarado.",
    "carbono": "Factores de biomasa y carbono configurados en el módulo SIMFI.",
}


def _filas(datos):
    return [fila for fila in datos.get("filas", []) if not fila.get("_type")]


def _numero(valor):
    try:
        return float(valor or 0)
    except (TypeError, ValueError):
        return 0.0


def validar_datos(pmf, filas, incrementos):
    """Devuelve limitaciones explícitas; nunca completa ausencias con supuestos."""
    alertas = []
    if not pmf.rodales_visibles:
        alertas.append("No hay UMM registradas en el proyecto.")
    if not filas:
        alertas.append("No existen registros suficientes de inventario para interpretar existencias, estructura o productividad.")
    return alertas


def _interpretar_rodal(rodal):
    """Redacción breve: hechos calculados, sin clasificaciones no respaldadas."""
    composicion = (f"{rodal['principal']} concentra el mayor volumen registrado"
                   if rodal["principal"] != "No determinada" else "No se identificó una especie principal")
    estructura = (f"La mayor frecuencia se concentra en la clase de {rodal['clase_dominante']:.1f} cm."
                 if rodal["clase_dominante"] is not None else "")
    caracterizacion = (f"En la UMM {rodal['id']}, {composicion}. El inventario calcula "
                       f"{rodal['n']:,.0f} árboles/ha, {rodal['g']:,.2f} m2/ha de área basal y "
                       f"{rodal['volumen']:,.3f} m3 VTA.")
    if estructura:
        caracterizacion += " " + estructura
    intervencion = ""
    if rodal["volumen"] > 0 and rodal["posibilidad"] > 0:
        intensidad = rodal["posibilidad"] * 100 / rodal["volumen"]
        intervencion = (f"La posibilidad calculada equivale a {intensidad:.2f} % del volumen registrado; "
                         f"el volumen residual calculado es {rodal['residual']:,.3f} m3 VTA.")
    return caracterizacion, intervencion


def construir_contexto_interpretacion(pmf):
    """Calcula un contexto normalizado, descriptivo y trazable para el reporte."""
    existencias = pmf.cuadro_existencias()
    resumen = pmf.resumen_existencias_predio()
    incrementos = pmf.resumen_incrementos()
    carbono = pmf.reporte_carbono()
    filas = _filas(existencias)
    por_rodal = defaultdict(list)
    for fila in filas:
        por_rodal[fila["rodal"]].append(fila)

    rodales = []
    for rodal_id, items in por_rodal.items():
        volumen = sum(_numero(item.get("vol_umm")) for item in items)
        posibilidad = sum(_numero(item.get("pos_umm")) for item in items)
        arboles = area_basal = 0.0
        clases, alturas = [], []
        for tabla in pmf.tablas_inventario:
            if tabla.rodal_id != rodal_id:
                continue
            valores = pmf._calc_valores_rodal_especie(rodal_id, tabla.especie) or {}
            arboles += _numero(valores.get("Arb/ha"))
            area_basal += _numero(valores.get("AB m2/ha"))
            for clase in tabla.clases:
                if clase.no_arboles > 0:
                    clases.append((clase.dncc, clase.no_arboles))
                    if _numero(clase.altura_m) > 0:
                        alturas.append((clase.altura_m, clase.no_arboles))
        principal = max(items, key=lambda item: _numero(item.get("vol_umm"))).get("especie", "No determinada")
        dominante = max(clases, key=lambda item: item[1])[0] if clases else None
        altura_media = (sum(valor * peso for valor, peso in alturas) / sum(peso for _, peso in alturas)
                        if alturas else None)
        rodales.append({"id": rodal_id, "especies": len(items), "principal": principal,
                        "volumen": volumen, "posibilidad": posibilidad, "residual": volumen - posibilidad,
                        "n": arboles, "g": area_basal, "clase_dominante": dominante,
                        "altura_media": altura_media, "clases": clases})
        rodales[-1]["interpretacion"], rodales[-1]["intervencion"] = _interpretar_rodal(rodales[-1])

    modelos = cargar_modelos_densidad()
    guias = []
    for fila in filas:
        modelo = seleccionar_modelo(fila["especie"], modelos=modelos)
        if modelo:
            guias.append({"rodal": fila["rodal"], "especie": fila["especie"],
                          "modelo": modelo.get("nombre_corto", modelo["modelo_id"]),
                          "region": modelo.get("region_aplicacion", "No indicada"),
                          "fuente": modelo.get("fuente", "Consultar catálogo de la guía")})

    alertas = validar_datos(pmf, filas, incrementos)
    if filas and not guias:
        alertas.append("No hay guía de densidad aplicable registrada; no se emite una clasificación sin referencia válida.")
    confianza = "Bajo" if not filas else ("Medio" if alertas else "Alto")
    total = _numero(existencias.get("total_vol_umm"))
    posibilidad = _numero(existencias.get("total_pos_umm"))
    indicadores = [
        {"id": "umm_evaluadas", "nombre": "UMM evaluadas", "valor": len(rodales), "unidad": "número", "escala": "predio", "fuente": FUENTES["inventario"], "estado": "calculado" if filas else "dato insuficiente"},
        {"id": "existencias", "nombre": "Existencias reales", "valor": total, "unidad": "m3 VTA", "escala": "predio", "fuente": FUENTES["inventario"], "estado": "calculado" if filas else "dato insuficiente"},
        {"id": "posibilidad", "nombre": "Posibilidad calculada", "valor": posibilidad, "unidad": "m3 VTA", "escala": "predio", "fuente": FUENTES["inventario"], "estado": "calculado" if filas else "dato insuficiente"},
        {"id": "co2", "nombre": "CO2 equivalente", "valor": _numero(carbono.get("total_co2")), "unidad": "t CO2e", "escala": "predio", "fuente": FUENTES["carbono"], "estado": "calculado" if filas else "dato insuficiente"},
    ]
    hallazgos = []
    if filas:
        if rodales:
            mayor = max(rodales, key=lambda rodal: rodal["volumen"])
            hallazgos.append(f"La mayor existencia registrada corresponde a la UMM {mayor['id']} con {mayor['volumen']:,.3f} m3 VTA.")
    return {"existencias": existencias, "resumen": resumen, "incrementos": incrementos,
            "carbono": carbono, "filas": filas, "rodales": rodales, "guias": guias,
            "alertas": alertas, "indicadores": indicadores, "hallazgos": hallazgos,
            "confianza": confianza, "version_reglas": VERSION_REGLAS, "fuentes": FUENTES}
