"""Pruebas de TP y Edad aprobados en el cuadro de incrementos.

El usuario puede corregir el TP y la Edad directamente en el cuadro; SIMFI
recalcula ICA e IMA con los valores aprobados. Vaciar restablece el calculado.
Las ecuaciones y tablas originales no se modifican.
"""

import json
import os
import tempfile
import unittest

import app as app_module
from modelos import (ClaseDiametrica, EcuacionVolumen, PMFProyecto, Rodal,
                     TablaInventarioRodal, _clave_categoria)


def _proyecto_incrementos(ruta):
    pmf = PMFProyecto("Incrementos", predio="Incrementos")
    pmf.agregar_rodal(Rodal("R1", 10, sitios=1, area_sitio_m2=10000))
    pmf.agregar_especie("Pinus patula")
    pmf.asignar_ecuacion("Pinus patula", EcuacionVolumen())
    pmf.tp_ecuaciones["Pinus patula"] = {"a": 5.0, "b": 0.2, "c": 0.0}
    pmf.edad_ecuaciones["Pinus patula"] = {"a": 10.0, "b": 0.5, "c": 0.0, "d": 0.0}
    pmf.agregar_tabla_inventario(TablaInventarioRodal(
        "R1", "Pinus patula", [ClaseDiametrica(20, 15, 10)]))
    assert pmf.guardar(ruta)
    return pmf


def _fila(pmf, rid="R1", esp="Pinus patula"):
    for fila in pmf.resumen_incrementos()["filas"]:
        if not fila.get("_type") and fila.get("rodal") == rid and fila.get("especie") == esp:
            return fila
    raise AssertionError("fila no encontrada en el resumen")


class ClaveCategoriaTest(unittest.TestCase):
    def test_normaliza_enteros_flotantes_y_cadenas(self):
        self.assertEqual(_clave_categoria(25), "25")
        self.assertEqual(_clave_categoria(25.0), "25")
        self.assertEqual(_clave_categoria("25"), "25")
        self.assertEqual(_clave_categoria(22.5), "22.5")
        self.assertEqual(_clave_categoria("22.50"), "22.5")


class ParametrosIncrementosTest(unittest.TestCase):
    def setUp(self):
        self.temporal = tempfile.TemporaryDirectory()
        self.originales = (app_module.DATA_DIR, app_module.PROJECTS_DIR,
                           app_module.PROJECT_STATE_DIR, app_module.LAST_PROJECT_FILE)
        app_module.DATA_DIR = self.temporal.name
        app_module.PROJECTS_DIR = os.path.join(self.temporal.name, "projects")
        app_module.PROJECT_STATE_DIR = os.path.join(self.temporal.name, "state")
        app_module.LAST_PROJECT_FILE = os.path.join(
            app_module.PROJECT_STATE_DIR, "ultimo_proyecto.json")
        os.makedirs(app_module.PROJECTS_DIR, exist_ok=True)
        self.ruta = os.path.join(app_module.PROJECTS_DIR, "incrementos.json")
        _proyecto_incrementos(self.ruta)
        self.cliente = app_module.app.test_client()
        with self.cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["ruta_actual"] = self.ruta

    def tearDown(self):
        (app_module.DATA_DIR, app_module.PROJECTS_DIR,
         app_module.PROJECT_STATE_DIR, app_module.LAST_PROJECT_FILE) = self.originales
        self.temporal.cleanup()

    def _pmf(self):
        return PMFProyecto.cargar(self.ruta)

    def _guardar(self, ajustes):
        return self.cliente.post("/reportes/resumen_incrementos/guardar_parametros",
                                 json={"ajustes": ajustes})

    def test_valores_iniciales_calculados(self):
        pmf = self._pmf()
        fila = _fila(pmf)
        self.assertAlmostEqual(fila["tp"], 9.0)
        self.assertAlmostEqual(fila["edad"], 20.0)
        vol_ha = pmf._calc_valores_rodal_especie("R1", "Pinus patula")["ER m3/ha"]
        self.assertAlmostEqual(fila["ima"], vol_ha / 20.0)
        self.assertEqual(fila["tp_categoria"], "20")

    def test_editar_tp_recalcula_ica(self):
        antes = _fila(self._pmf())
        respuesta = self._guardar([{"rodal": "R1", "especie": "Pinus patula",
                                    "tp": "18", "edad": ""}])
        self.assertEqual(respuesta.status_code, 200)
        self.assertTrue(respuesta.get_json()["success"])
        despues = _fila(self._pmf())
        self.assertAlmostEqual(despues["tp"], 18.0)
        # ICA escala con 1/TP al duplicarlo (una sola clase en la tabla).
        self.assertAlmostEqual(despues["ica"], antes["ica"] * (9.0 / 18.0))
        self.assertAlmostEqual(despues["ica_pct"], antes["ica_pct"] * (9.0 / 18.0))

    def test_editar_edad_recalcula_ima(self):
        antes = _fila(self._pmf())
        respuesta = self._guardar([{"rodal": "R1", "especie": "Pinus patula",
                                    "tp": "", "edad": "25"}])
        self.assertEqual(respuesta.status_code, 200)
        despues = _fila(self._pmf())
        self.assertAlmostEqual(despues["edad"], 25.0)
        self.assertAlmostEqual(despues["ima"], antes["ima"] * (20.0 / 25.0))
        # El TP no tocado sigue calculado.
        self.assertAlmostEqual(despues["tp"], 9.0)

    def test_vaciar_restablece_el_calculado(self):
        self._guardar([{"rodal": "R1", "especie": "Pinus patula", "tp": "18", "edad": "25"}])
        intermedio = _fila(self._pmf())
        self.assertAlmostEqual(intermedio["tp"], 18.0)
        self.assertAlmostEqual(intermedio["edad"], 25.0)
        respuesta = self._guardar([{"rodal": "R1", "especie": "Pinus patula",
                                    "tp": "", "edad": ""}])
        self.assertTrue(respuesta.get_json()["success"])
        final = _fila(self._pmf())
        self.assertAlmostEqual(final["tp"], 9.0)
        self.assertAlmostEqual(final["edad"], 20.0)
        pmf = self._pmf()
        self.assertEqual(pmf.tp_aprobados, {})
        self.assertEqual(pmf.edad_aprobada, {})

    def test_valores_invalidos_se_rechazan(self):
        for malo in ("0", "-3", "abc"):
            respuesta = self._guardar([{"rodal": "R1", "especie": "Pinus patula",
                                        "tp": malo, "edad": ""}])
            self.assertEqual(respuesta.status_code, 400, malo)
            respuesta = self._guardar([{"rodal": "R1", "especie": "Pinus patula",
                                        "tp": "", "edad": malo}])
            self.assertEqual(respuesta.status_code, 400, malo)
        fila = _fila(self._pmf())
        self.assertAlmostEqual(fila["tp"], 9.0)
        self.assertAlmostEqual(fila["edad"], 20.0)

    def test_fila_inexistente_se_ignora(self):
        respuesta = self._guardar([{"rodal": "RX", "especie": "Pino", "tp": "10", "edad": "10"}])
        cuerpo = respuesta.get_json()
        self.assertTrue(cuerpo["success"])
        self.assertEqual(cuerpo["actualizados"], 0)

    def test_tp_manual_sin_ecuacion_activa_ica(self):
        pmf = self._pmf()
        pmf.agregar_especie("Encino")
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Encino", [ClaseDiametrica(20, 12, 6)]))
        pmf.guardar(self.ruta)
        fila = _fila(pmf, esp="Encino")
        self.assertIsNone(fila["tp"])
        self.assertEqual(fila["ica"], 0)
        respuesta = self._guardar([{"rodal": "R1", "especie": "Encino",
                                    "tp": "15", "edad": ""}])
        self.assertEqual(respuesta.status_code, 200)
        fila = _fila(self._pmf(), esp="Encino")
        self.assertAlmostEqual(fila["tp"], 15.0)
        self.assertIsNotNone(fila["ica"])
        self.assertGreater(fila["ica"], 0)

    def test_aprobados_sobreviven_al_guardar_y_cargar(self):
        self._guardar([{"rodal": "R1", "especie": "Pinus patula", "tp": "18", "edad": "25"}])
        recargado = PMFProyecto.cargar(self.ruta)
        self.assertEqual(recargado.tp_aprobados, {"Pinus patula": {"20": 18.0}})
        self.assertEqual(recargado.edad_aprobada, {"R1": {"Pinus patula": 25.0}})
        fila = _fila(recargado)
        self.assertAlmostEqual(fila["tp"], 18.0)
        self.assertAlmostEqual(fila["edad"], 25.0)
        # Las fuentes originales no se modificaron.
        self.assertEqual(recargado.tp_ecuaciones["Pinus patula"], {"a": 5.0, "b": 0.2, "c": 0.0})

    def test_proyectos_anteriores_cargan_sin_aprobados(self):
        # Compatibilidad: un proyecto guardado sin las claves nuevas debe
        # cargarse igual por ambas vias y calcular identico a antes.
        import json
        datos = json.loads(open(self.ruta, encoding="utf-8").read())
        for clave in ("tp_aprobados", "edad_aprobada"):
            datos.pop(clave, None)
        pmf_viejo = PMFProyecto.desde_dict(datos)
        self.assertEqual(pmf_viejo.tp_aprobados, {})
        self.assertEqual(pmf_viejo.edad_aprobada, {})
        fila = _fila(pmf_viejo)
        self.assertAlmostEqual(fila["tp"], 9.0)
        self.assertAlmostEqual(fila["edad"], 20.0)
        self._guardar([{"rodal": "R1", "especie": "Pinus patula", "tp": "18", "edad": "25"}])
        recargado = PMFProyecto.cargar(self.ruta)
        self.assertEqual(recargado.tp_aprobados, {"Pinus patula": {"20": 18.0}})
        self.assertEqual(recargado.edad_aprobada, {"R1": {"Pinus patula": 25.0}})
        fila = _fila(recargado)
        self.assertAlmostEqual(fila["tp"], 18.0)
        self.assertAlmostEqual(fila["edad"], 25.0)
        # Las fuentes originales no se modificaron.
        self.assertEqual(recargado.tp_ecuaciones["Pinus patula"], {"a": 5.0, "b": 0.2, "c": 0.0})

    def test_exportaciones_reflejan_aprobados(self):
        self._guardar([{"rodal": "R1", "especie": "Pinus patula", "tp": "18", "edad": "25"}])
        for formato in ("excel", "word", "pdf"):
            respuesta = self.cliente.get(f"/reportes/incrementos/exportar/{formato}")
            self.assertEqual(respuesta.status_code, 200, formato)
            self.assertGreater(len(respuesta.data), 1000, formato)


if __name__ == "__main__":
    unittest.main()
