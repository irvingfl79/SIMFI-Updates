param()

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$PackageApp = Join-Path $PSScriptRoot "SIMFI"
$RootFiles = @(
    "app.py", "modelos.py", "exportar_excel.py", "data_municipios.py",
    "guias_densidad.py", "motor_aclareos.py", "reporte_densidad.py", "turnos.py",
    "run.py", "iniciar.bat", "requirements.txt", "catalogo_turnos.json", "version.json",
    "migrar_almacenamiento.ps1", "reportes_tecnicos.py", "reporte_integral.py",
    "error_muestreo.py", "interpretacion_muestreo.py", "reporte_error_muestreo.py", "interpretacion_forestal.py", "cartografia.py", "superficies.py", "reporte_superficies.py", "ia_config.py", "ia_ollama.py", "ia_online.py", "ai_interpretation_service.py", "ia_interpretacion.py", "ia_semantica.py", "ia_analisis.py", "config_ia.json", "cuadros_word.py",
    "diagnostico_muestreo.py", "dussan_backend.py", "respaldo_proyectos.py",
    "ed25519_puro.py", "firmas_actualizacion.py"
)
$AppDirectories = @("templates", "static", "img", "modelos_densidad")

foreach ($Relative in $RootFiles) {
    $Source = Join-Path $ProjectRoot $Relative
    if (-not (Test-Path -LiteralPath $Source -PathType Leaf)) {
        throw "Falta el archivo de aplicacion: $Relative"
    }
    Copy-Item -LiteralPath $Source -Destination (Join-Path $PackageApp $Relative) -Force
}
foreach ($Relative in $AppDirectories) {
    $Source = Join-Path $ProjectRoot $Relative
    if (-not (Test-Path -LiteralPath $Source -PathType Container)) {
        throw "Falta el directorio de aplicacion: $Relative"
    }
    Copy-Item -LiteralPath $Source -Destination $PackageApp -Recurse -Force
}

# El actualizador vive en actualizacion\, no en la raiz del repo:
# se incorpora para que la base conozca el mecanismo de verificacion.
$Actualizador = Join-Path $ProjectRoot "actualizacion\actualizar_simfi.ps1"
if (-not (Test-Path -LiteralPath $Actualizador -PathType Leaf)) {
    throw "Falta el actualizador: $Actualizador"
}
Copy-Item -LiteralPath $Actualizador -Destination (Join-Path $PackageApp "actualizar_simfi.ps1") -Force

# Consulta de actualizaciones en linea (canal de aviso e instalacion
# optativa). Acompana al actualizador: el verificador Ed25519 y las
# claves confiables viajan con la base.
$Consulta = Join-Path $ProjectRoot "actualizacion\consultar_actualizaciones.ps1"
if (-not (Test-Path -LiteralPath $Consulta -PathType Leaf)) {
    throw "Falta el consultor de actualizaciones: $Consulta"
}
Copy-Item -LiteralPath $Consulta -Destination (Join-Path $PackageApp "consultar_actualizaciones.ps1") -Force

$LanzadorConsulta = @'
@echo off
setlocal
cd /d "%~dp0"
title SIMFI - Buscar actualizaciones en linea
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0consultar_actualizaciones.ps1"
if errorlevel 1 (
  echo.
  echo Ocurrio un problema al consultar. La instalacion no cambio.
)
pause
exit /b 0
'@
[IO.File]::WriteAllText(
    (Join-Path $PackageApp "BUSCAR_ACTUALIZACION.bat"),
    ($LanzadorConsulta -replace "`r`n", "`n" -replace "`n", "`r`n"),
    (New-Object System.Text.ASCIIEncoding))

Write-Host "Fuente de instalacion preparada: $PackageApp"
