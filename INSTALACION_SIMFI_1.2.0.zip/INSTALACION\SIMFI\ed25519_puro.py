"""Ed25519 puro con solo la biblioteca estandar de Python (RFC 8032).

Este modulo existe porque el Python que incluye la distribucion de SIMFI
no tiene pynacl ni cryptography. La verificacion de firmas en las
computadoras de los usuarios no debe depender de instalar nada, asi que
el algoritmo se implementa aqui, se coteja en las pruebas contra la
biblioteca cryptography (cuando este presente en la maquina de
desarrollo) y, de este modo, queda referenciado a los vectores del
RFC 8032 con ellos comparados.

Seguridad:
- La decodificacion de puntos valida que esten en la curva (rechaza
  puntos fuera de curva y representaciones no canonicas), requisito
  necesario para evitar falsificaciones por malleabilidad.
- La componente S de la firma se rechaza si S >= L.
- Ninguna falla de verificacion puede interpretarse como exito: la
  funcion verifica solo regresa True cuando toda la logica valida.

Referencia: RFC 8032 (Edwards-Curve Digital Signature Algorithm
(EdDSA), seccion 5.1 Ed25519).
"""

import hashlib

# Parametros de la curva Curve25519 campo p = 2^255 - 19 (RFC 7748).
_Q = (1 << 255) - 19
_L = (1 << 252) + 27742317777372353535851937790883648493
_D = -121665 * pow(121666, _Q - 2, _Q) % _Q
_I = pow(2, (_Q - 1) // 4, _Q)

# Elemento neutro del grupo (x=0, y=1).
_IDENTITY = (0, 1)


def _inv(x):
    """Inverso multiplicativo en el campo."""
    return pow(x, _Q - 2, _Q)


def _edwards_add(p, q_point):
    """Suma de puntos en la curva -x^2 + y^2 = 1 + d*x^2*y^2."""
    x1, y1 = p
    x2, y2 = q_point
    temp = _D * x1 * x2 * y1 * y2
    x3 = (x1 * y2 + x2 * y1) * _inv(1 + temp) % _Q
    y3 = (y1 * y2 + x1 * x2) * _inv(1 - temp) % _Q
    return (x3, y3)


def _scalar_mult(punto, escalar):
    """Multiplicacion escalar (doblar y sumar, bits en orden menor)."""
    resultado = _IDENTITY
    agregado = punto
    while escalar > 0:
        if escalar & 1:
            resultado = _edwards_add(resultado, agregado)
        agregado = _edwards_add(agregado, agregado)
        escalar >>= 1
    return resultado


def _xrecover(y):
    """Recupera x a partir de y resolviendo la ecuacion de la curva."""
    xx = (y * y - 1) * _inv(_D * y * y + 1)
    x = pow(xx, (_Q + 3) // 8, _Q)
    if (x * x - xx) % _Q != 0:
        x = (x * _I) % _Q
    if x % 2 != 0:
        x = _Q - x
    return x


# Punto base B: el estandar usa By = 4/5 y Bx recuperado de la curva.
_By = 4 * _inv(5) % _Q
_B = (_xrecover(_By), _By)


def _encode_point(punto):
    """Codifica (x, y) en 32 bytes: 255 bits de y + bit de paridad de x."""
    x, y = punto
    bits = [(y >> i) & 1 for i in range(255)]
    bits.append(x & 1)
    salida = bytearray(32)
    for indice, bit in enumerate(bits):
        if bit:
            salida[indice >> 3] |= 1 << (indice & 7)
    return bytes(salida)


def _decode_point(datos):
    """Decodifica 32 bytes como punto, validando curva y canonicalidad."""
    if len(datos) != 32:
        raise ValueError("El punto debe ser de 32 bytes")
    y = int.from_bytes(datos, "little") & ((1 << 255) - 1)
    signo_x = datos[31] >> 7
    x = _xrecover(y)
    if x == 0 and signo_x:
        raise ValueError("Punto no canonico")
    if (x & 1) != signo_x:
        x = _Q - x
    # Ecuacion de la curva: -x^2 + y^2 = 1 + d*x^2*y^2 (mod q).
    if (-x * x + y * y - 1 - _D * x * x * y * y) % _Q != 0:
        raise ValueError("Punto fuera de la curva")
    return (x, y)


def derivar_clave_publica(semilla):
    """Devuelve la clave publica (32 bytes) para una semilla (32 bytes)."""
    if not isinstance(semilla, (bytes, bytearray)) or len(semilla) != 32:
        raise ValueError("La semilla debe tener 32 bytes")
    resumen = hashlib.sha512(bytes(semilla)).digest()
    h = bytearray(resumen[:32])
    # Recorte canonico del escalar (RFC 8032, 5.1.2).
    h[0] &= 248
    h[31] &= 127
    h[31] |= 64
    escalar = int.from_bytes(h, "little")
    return _encode_point(_scalar_mult(_B, escalar))


def firmar_bytes(semilla, mensaje):
    """Firma deterministamente un mensaje (Ed25519, RFC 8032, 5.1.6).

    Devuelve la firma de 64 bytes: R (32) + S (32). La firma es
    determinista: dos firmas de la misma semilla y mensaje son iguales.
    """
    if not isinstance(semilla, (bytes, bytearray)) or len(semilla) != 32:
        raise ValueError("La semilla debe tener 32 bytes")
    resumen = hashlib.sha512(bytes(semilla)).digest()
    h = bytearray(resumen[:32])
    h[0] &= 248
    h[31] &= 127
    h[31] |= 64
    escalar = int.from_bytes(h, "little")
    prefijo = resumen[32:64]
    # R = B * r con r aleatorio determinista derivado del mensaje.
    r = int.from_bytes(hashlib.sha512(prefijo + bytes(mensaje)).digest(), "little") % _L
    punto_r = _scalar_mult(_B, r)
    r_codificado = _encode_point(punto_r)
    clave_publica = _encode_point(_scalar_mult(_B, escalar))
    k = int.from_bytes(
        hashlib.sha512(r_codificado + clave_publica + bytes(mensaje)).digest(),
        "little") % _L
    s = (r + k * escalar) % _L
    return r_codificado + s.to_bytes(32, "little")


def verificar_firma_bytes(clave_publica, mensaje, firma):
    """Verifica una firma Ed25519 (RFC 8032, 5.1.7).

    Regresa True solo si la firma es completa y valida. Cualquier
    entrada malformada o fuera de la curva regresa False; nunca se
    lanza una excepcion en la via de rechazo.
    """
    try:
        if len(clave_publica) != 32 or len(firma) != 64:
            return False
        punto_a = _decode_point(bytes(clave_publica))
        r_codificado = bytes(firma[:32])
        s = int.from_bytes(firma[32:], "little")
        if s >= _L:
            return False
        punto_r = _decode_point(r_codificado)
    except ValueError:
        return False
    mensaje = bytes(mensaje)
    k = int.from_bytes(
        hashlib.sha512(r_codificado + clave_publica + mensaje).digest(),
        "little") % _L
    # Chequeo principal: S*B = R + k*A, cotejado multiplicando ambos
    # lados por el cofactor 8 (descarta diferencias de torsion como
    # sugiere el RFC como verificacion mas estricta).
    izquierda = _scalar_mult(_B, s * 8 % _L)
    derecha = _edwards_add(
        _scalar_mult(punto_r, 8), _scalar_mult(punto_a, k * 8 % _L))
    return izquierda == derecha
