"""Firmas de actualizacion de SIMFI (esquema 1, Ed25519).

Capa de aplicacion sobre `ed25519_puro`: define la representacion
canonica del manifiesto de actualizacion, el formato del objeto de
firma y la verificacion con claves distintas a las de prueba.

Formato del objeto de firma (JSON):
    {
      "esquema": 1,
      "algoritmo": "ed25519",
      "clave": "<hex de 64 caracteres: clave publica del emisor>",
      "firma": "<hex de 128 caracteres: firma Ed25519>"
    }

Contenido firmado:
La firma siempre cubre la representacion canonica del manifiesto:
    json.dumps(manifesto, sort_keys=True, separators=(",", ":"),
               ensure_ascii=False).encode("utf-8")
    esa representacion es determinista: mismo dict logico, mismos
    bytes. Por eso el manifiesto solo puede contener cadenas, enteros,
    booleanos y None; listas y dicts. Sin flotantes (no tienen forma
    canonica de texto en JSON).

Claves:
- NINGUNA clave privada pertenece aqui ni al repositorio.
- La clave privada de produccion se genera FUERA de linea, en una
  computadora aislada: una semilla de 32 bytes con os.urandom(32)
  usando la biblioteca cryptography; la semilla se custodia solo en
  medio cifrado (USB BitLocker) y no se imprime. La clave publica hex
  (64 caracteres) es lo unico que se integra, en una etapa posterior
  autorizada, en CLAVES_PUBLICAS_CONFIABLES.
- Mientras el registro este vacio, este modulo RECHAZA cualquier
  manifiesto con el error ClaveDesconocida: es el comportamiento que
  se espera en esta fase de preparacion.
- Las pruebas usan claves efimeras generadas en ejecucion; nunca
  reutilizan tampoco una clave de produccion.
"""

import json
import re

from ed25519_puro import derivar_clave_publica, firmar_bytes, verificar_firma_bytes

ESQUEMA_FIRMA = 1
ALGORITMO_FIRMA = "ed25519"
LONGITUD_CLAVE = 32
LONGITUD_FIRMA = 64

# Claves publicas (hex, 64 caracteres) autorizadas para firmar
# actualizaciones de SIMFI. La clave de produccion se genero fuera de
# linea y su semilla vive unicamente en custodia cifrada fuera del
# repositorio (carpeta de custodia del operador).
CLAVES_PUBLICAS_CONFIABLES = frozenset({
    "b7338ef372a5dcc51edfc09dac2e59ad9ad281682ee1f9c1eee60d254f9f31cc",
})

_PATRON_SEMVER = re.compile(r"^\d+\.\d+(\.\d+)?$")
_PATRON_HEX = re.compile(r"^[0-9a-f]+$")


class FirmaError(Exception):
    """Base de los errores de firma de actualizaciones."""


class ManifestoInvalido(FirmaError):
    """El manifiesto esta malformado o le faltan campos obligatorios."""


class EsquemaNoAdmitido(FirmaError):
    """El objeto de firma usa un esquema o algoritmo no soportado."""


class FirmaNoValida(FirmaError):
    """La firma esta vacia, malformada o no corresponde al contenido."""


class ClaveDesconocida(FirmaError):
    """La clave del emisor no esta en el registro de claves confiables."""


def _canonico(manifesto):
    """Representacion canonica del manifiesto (bytes deterministas)."""
    texto = json.dumps(manifesto, sort_keys=True, separators=(",", ":"),
                       ensure_ascii=False)
    return texto.encode("utf-8")


def firmar_manifesto(manifesto, clave_privada_hex):
    """Firma un manifiesto y devuelve el objeto de firma.

    Uso previsto: SOLO fuera de linea, en la computadora de
    publicacion, con la clave privada custodiada en medio cifrado.
    Las pruebas lo usan con claves efimeras. Nunca debe llamarse con
    una clave de produccion en una maquina conectada.
    """
    if not isinstance(clave_privada_hex, str):
        raise FirmaError("La clave privada debe ser texto hex")
    semilla = _hex_a_bytes(clave_privada_hex, LONGITUD_CLAVE,
                           "clave privada")
    clave_publica = derivar_clave_publica(semilla)
    firma = firmar_bytes(semilla, _canonico(manifesto))
    return {
        "esquema": ESQUEMA_FIRMA,
        "algoritmo": ALGORITMO_FIRMA,
        "clave": clave_publica.hex(),
        "firma": firma.hex(),
    }


def verificar_manifesto(manifesto, objeto_firma, claves_confiables=None):
    """Verifica el objeto de firma contra el manifiesto canonico.

    Regresa el manifiesto cuando todo valida. En cualquier rechazo
    lanza el error especifico (nunca acepta por silencio).
    """
    if not isinstance(objeto_firma, dict):
        raise FirmaNoValida("El objeto de firma debe ser un dict")
    if objeto_firma.get("esquema") != ESQUEMA_FIRMA:
        raise EsquemaNoAdmitido(
            f"Esquema de firma no admitido: {objeto_firma.get('esquema')!r}")
    if objeto_firma.get("algoritmo") != ALGORITMO_FIRMA:
        raise EsquemaNoAdmitido(
            f"Algoritmo no admitido: {objeto_firma.get('algoritmo')!r}")
    clave_hex = objeto_firma.get("clave")
    if not isinstance(clave_hex, str) or not _PATRON_HEX.fullmatch(clave_hex) \
            or len(clave_hex) != 2 * LONGITUD_CLAVE:
        raise FirmaNoValida("Formato de clave publica inválido")
    claves = (CLAVES_PUBLICAS_CONFIABLES if claves_confiables is None
              else claves_confiables)
    if clave_hex not in claves:
        raise ClaveDesconocida("La clave del emisor no es confiable")
    firma_hex = objeto_firma.get("firma")
    if not isinstance(firma_hex, str) or not _PATRON_HEX.fullmatch(firma_hex) \
            or len(firma_hex) != 2 * LONGITUD_FIRMA:
        raise FirmaNoValida("Formato de firma inválido")
    validar_estructura_manifesto(manifesto)
    if not verificar_firma_bytes(bytes.fromhex(clave_hex),
                                 _canonico(manifesto),
                                 bytes.fromhex(firma_hex)):
        raise FirmaNoValida(
            "La firma no corresponde al manifiesto canonizado")
    return manifesto


def validar_estructura_manifesto(manifesto):
    """Valida la estructura completa del manifiesto de actualizacion."""
    if not isinstance(manifesto, dict):
        raise ManifestoInvalido("El manifiesto debe ser un dict")
    if manifesto.get("sistema") != "SIMFI":
        raise ManifestoInvalido("El manifiesto no corresponde a SIMFI")
    version = manifesto.get("version")
    if not isinstance(version, str) or not _PATRON_SEMVER.fullmatch(version):
        raise ManifestoInvalido("Version de destino invalida")
    linea = manifesto.get("linea_version")
    if not isinstance(linea, int) or isinstance(linea, bool) or linea < 1:
        raise ManifestoInvalido("Linea de version invalida")
    if not isinstance(manifesto.get("fecha_compilacion"), str):
        raise ManifestoInvalido("Fecha de compilacion ausente")
    archivos = manifesto.get("archivos")
    if not isinstance(archivos, list) or not archivos:
        raise ManifestoInvalido("El manifiesto debe declarar archivos")
    for archivo in archivos:
        if not isinstance(archivo, dict):
            raise ManifestoInvalido("Registro de archivo invalido")
        ruta = archivo.get("ruta")
        if not isinstance(ruta, str) or not ruta.strip():
            raise ManifestoInvalido("Ruta de archivo invalida")
        if ruta.startswith(("/", "\\")) or (":" in ruta) \
                or any(parte == ".." for parte in ruta.replace("\\", "/").split("/")):
            raise ManifestoInvalido(f"Ruta no autorizada: {ruta}")
        hash_hex = archivo.get("sha256")
        if not isinstance(hash_hex, str) \
                or not _PATRON_HEX.fullmatch(hash_hex) or len(hash_hex) != 64:
            raise ManifestoInvalido(f"SHA256 invalido en {ruta}")
        if not isinstance(archivo.get("bytes"), int) \
                or isinstance(archivo.get("bytes"), bool) \
                or archivo.get("bytes") < 0:
            raise ManifestoInvalido(f"Tamano invalido en {ruta}")
    protegidas = manifesto.get("carpetas_protegidas")
    if not isinstance(protegidas, list) or \
            not all(isinstance(p, str) and p for p in protegidas):
        raise ManifestoInvalido("Carpetas protegidas invalidas")


def _hex_a_bytes(texto, longitud, etiqueta):
    if not isinstance(texto, str) or not _PATRON_HEX.fullmatch(texto) \
            or len(texto) != 2 * longitud:
        raise FirmaError(f"Formato de {etiqueta} inválido")
    return bytes.fromhex(texto)
