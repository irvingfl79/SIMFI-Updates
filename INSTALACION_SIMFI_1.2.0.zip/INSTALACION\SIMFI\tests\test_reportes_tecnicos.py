import unittest
import zipfile
from types import SimpleNamespace
from unittest.mock import patch

import app as app_module
from modelos import PMFProyecto
from reportes_tecnicos import (analisis_existencias, construir_datos_reporte_existencias,
                               analisis_detallado_existencias, datos_graficas_existencias,
                               generar_pdf, generar_word, generar_word_cuadro_existencias,
                               generar_word_cuadro_carbono,
                               generar_word_cuadro_incrementos, generar_word_plan_cortas,
                               interpretar_reporte_existencias, analisis_carbono, _grafica_word_png)
from reporte_integral import generar_pdf_integral, generar_word_integral


ANALISIS = {
    "titulo": "Interpretación de prueba",
    "indicadores": [("Indicador", "10.000")],
    "hallazgos": ["Hallazgo calculado."],
    "cautela": "Consideración técnica de prueba.",
    "grafica": [("Dato A", 10.0), ("Dato B", 5.0)],
    "tabla": [("Dato A", "10.000"), ("Dato B", "5.000")],
    "encabezados": ("Elemento", "Valor"),
}


class ReportesTecnicosTest(unittest.TestCase):
    def test_generadores_entregan_word_y_pdf_con_grafica(self):
        proyecto = PMFProyecto("Prueba", predio="Predio prueba")
        word = generar_word(proyecto, ANALISIS)
        self.assertTrue(word.getvalue().startswith(b"PK"))
        with zipfile.ZipFile(word) as paquete:
            documento = paquete.read("word/document.xml").decode("utf-8")
            pie = paquete.read("word/footer1.xml").decode("utf-8")
        self.assertIn("SIMFI", documento)
        self.assertIn("Indicadores principales", documento)
        self.assertIn("Sistema para el Manejo Forestal Mejorado", pie)
        self.assertTrue(generar_pdf(proyecto, ANALISIS).getvalue().startswith(b"%PDF"))

    def test_grafica_word_ajusta_alto_a_barras_dibujadas(self):
        from PIL import Image
        datos = [(f"R{i}", float(i + 1)) for i in range(30)]
        with Image.open(_grafica_word_png(datos)) as imagen:
            self.assertEqual(imagen.size, (1000, 440))
        with Image.open(_grafica_word_png(datos[:4])) as imagen:
            self.assertEqual(imagen.size, (1000, 360))
        with Image.open(_grafica_word_png([])) as imagen:
            self.assertEqual(imagen.size, (1000, 360))

    def test_word_carbono_grafica_compacta_en_los_tres_apartados(self):
        from PIL import Image
        combos = [(f"R{i}", f"Esp{i}", 10.0 + i) for i in range(12)]
        data = {"filas": [{"rodal": r, "especie": e, "carbono_total": v, "co2_total": v * 3.67}
                          for r, e, v in combos],
                "total_carbono": 1.0, "total_co2": 3.67}
        captura = {"filas": [{"rodal": r, "especie": e, "captura_c": v, "captura_co2": v * 3.67}
                             for r, e, v in combos],
                   "total_captura_c": 1.0, "total_captura_co2": 3.67}
        oxigeno = {"filas": [{"rodal": r, "especie": e, "captura_c": v, "oxigeno": v * 2.67}
                             for r, e, v in combos],
                   "total_captura_c": 1.0, "total_oxigeno": 2.67}
        for tab in ("contenido", "captura", "oxigeno"):
            analisis = analisis_carbono(data, captura, oxigeno, None, tab=tab)
            self.assertEqual(len(analisis["grafica"]), 12)
            documento = generar_word_cuadro_carbono(
                PMFProyecto("Prueba"), "T", ["Rodal", "Especie", "X"],
                [[r, e, v] for r, e, v in combos], {"filas": []}, analisis)
            with zipfile.ZipFile(documento) as paquete:
                tamanos = []
                for nombre in paquete.namelist():
                    if nombre.startswith("word/media/"):
                        with Image.open(paquete.open(nombre)) as imagen:
                            tamanos.append(imagen.size)
                self.assertIn((1000, 440), tamanos)

    def test_existencias_incorpora_trazabilidad_cuando_recibe_contexto(self):
        analisis = analisis_existencias({"filas": [], "total_vol_umm": 0, "total_pos_umm": 0}, {"filas": []}, {"filas": [], "alertas": ["Falta inventario"], "fuentes": {"inventario": "Fuente de prueba"}, "version_reglas": "1.0", "confianza": "Bajo"})
        self.assertEqual(analisis["estado_datos"], "Dato insuficiente")
        self.assertIn("inventario", analisis["trazabilidad"])

    def test_existencias_deriva_participacion_intensidad_y_residual(self):
        data = {"total_vol_umm": 1000, "total_pos_umm": 100, "filas": [
            {"rodal": "UMM 1", "especie": "Pinus patula", "vol_umm": 700, "pos_umm": 100},
            {"rodal": "UMM 2", "especie": "Quercus rugosa", "vol_umm": 300, "pos_umm": 0},
        ]}
        resumen = {"filas": [
            {"especie": "Pinus patula", "existencias": 700, "posibilidad": 100, "residuales": 600},
            {"especie": "Quercus rugosa", "existencias": 300, "posibilidad": 0, "residuales": 300},
        ]}
        analisis = analisis_existencias(data, resumen)
        self.assertIn("70.00 %", analisis["parrafos"][0])
        self.assertIn("10.00 %", analisis["parrafos"][1])
        self.assertIn("Quercus rugosa", analisis["observaciones"][0])
        self.assertEqual(analisis["tabla"][0][-1], "14.29")
        salida = generar_word(PMFProyecto("Prueba"), analisis)
        with zipfile.ZipFile(salida) as paquete:
            xml = paquete.read("word/document.xml").decode("utf-8")
        self.assertIn("Existencias reales por especie", xml)
        self.assertNotIn("***", xml)

    def test_word_cuadro_existencias_incluye_tabla_e_interpretacion(self):
        proyecto = PMFProyecto("Prueba", predio="Predio prueba")
        data = {"filas": [{"rodal": "UMM 1", "superficie": 10, "especie": "Pinus patula",
                            "vol_ha": 20, "vol_umm": 200, "ab": 8, "intensidad": 10,
                            "res_vol": 180, "res_ab": 7.2, "pos_ha": 2, "pos_umm": 20}],
                "total_vol_ha": 20, "total_vol_umm": 200, "total_ab": 8,
                "total_res_vol": 180, "total_res_ab": 7.2, "total_pos_ha": 2, "total_pos_umm": 20}
        resumen = {"filas": [{"especie": "Pinus patula", "existencias": 200,
                               "posibilidad": 20, "residuales": 180}]}
        salida = generar_word_cuadro_existencias(proyecto, data, analisis_existencias(data, resumen))
        with zipfile.ZipFile(salida) as paquete:
            xml = paquete.read("word/document.xml").decode("utf-8")
        self.assertIn("Cuadro de existencias por UMM", xml)
        self.assertIn("UMM 1", xml)
        self.assertIn("Pinus patula", xml)
        self.assertIn("Interpretación técnica", xml)

    def test_word_existencias_usa_encabezados_agrupados_y_totales_fusionados(self):
        from io import BytesIO
        from docx import Document
        from docx.oxml.ns import qn
        proyecto = PMFProyecto("Prueba", predio="Predio prueba")
        data = {"num_rodales": 2, "filas": [
            {"rodal": "UMM 1", "superficie": 10, "especie": "Pinus patula",
             "vol_ha": 20, "vol_umm": 200, "ab": 8, "intensidad": 10,
             "res_vol": 180, "res_ab": 7.2, "pos_ha": 2, "pos_umm": 20},
            {"_type": "subtotal", "rodal": "UMM 1", "vol_ha": 20, "vol_umm": 200, "ab": 8,
             "res_vol": 180, "res_ab": 7.2, "pos_ha": 2, "pos_umm": 20},
            {"rodal": "UMM 2", "superficie": 8, "especie": "Quercus rugosa",
             "vol_ha": 15, "vol_umm": 120, "ab": 6, "intensidad": 5,
             "res_vol": 114, "res_ab": 5.7, "pos_ha": 1.5, "pos_umm": 12},
        ], "total_vol_ha": 35, "total_vol_umm": 320, "total_ab": 14,
           "total_res_vol": 294, "total_res_ab": 12.9, "total_pos_ha": 3.5, "total_pos_umm": 32}
        resumen = {"filas": [{"especie": "Pinus patula", "existencias": 200,
                               "posibilidad": 20, "residuales": 180},
                              {"especie": "Quercus rugosa", "existencias": 120,
                               "posibilidad": 12, "residuales": 114}]}
        salida = generar_word_cuadro_existencias(proyecto, data, analisis_existencias(data, resumen))
        documento = Document(BytesIO(salida.getvalue()))
        principal = next(t for t in documento.tables
                         if t.rows[0].cells[0].text == "Unidad Minima de Manejo (UMM)")
        self.assertEqual(len(principal.columns), 11)
        fila_0 = [c.text for c in principal.rows[0].cells]
        self.assertEqual(fila_0, ["Unidad Minima de Manejo (UMM)"] * 2 +
                         ["Especie"] + ["Existencias Reales"] * 3 +
                         ["Intensidad de Corta (%) Por UMM", "Residuales"] +
                         ["Posibilidad"] * 3)
        def vmerge(celda):
            nodo = celda._tc.get_or_add_tcPr().find(qn("w:vMerge"))
            return None if nodo is None else nodo.get(qn("w:val"))
        self.assertEqual(vmerge(principal.rows[0].cells[2]), "restart")
        self.assertEqual(vmerge(principal.rows[0].cells[6]), "restart")
        self.assertEqual(principal.rows[2].cells[6].text, "10.00")
        self.assertIn("— Subtotal", principal.rows[3].cells[0].text)
        self.assertEqual(principal.rows[-1].cells[0].text, "TOTAL")

    def test_word_existencias_fusiona_rodal_y_superficie_en_varias_especies(self):
        from io import BytesIO
        from docx import Document
        from docx.oxml.ns import qn
        proyecto = PMFProyecto("Prueba", predio="Predio prueba")
        data = {"num_rodales": 1, "filas": [
            {"rodal": "UMM 1", "superficie": 10, "especie": "Pinus patula",
             "vol_ha": 20, "vol_umm": 200, "ab": 8, "intensidad": 10,
             "res_vol": 180, "res_ab": 7.2, "pos_ha": 2, "pos_umm": 20},
            {"rodal": "UMM 1", "superficie": 10, "especie": "Pinus teocote",
             "vol_ha": 15, "vol_umm": 150, "ab": 6, "intensidad": 10,
             "res_vol": 135, "res_ab": 5.4, "pos_ha": 1.5, "pos_umm": 15},
            {"_type": "subtotal", "rodal": "UMM 1", "vol_ha": 35,
             "vol_umm": 350, "ab": 14, "res_vol": 315, "res_ab": 12.6,
             "pos_ha": 3.5, "pos_umm": 35},
        ], "total_vol_ha": 35, "total_vol_umm": 350, "total_ab": 14,
            "total_res_vol": 315, "total_res_ab": 12.6,
            "total_pos_ha": 3.5, "total_pos_umm": 35}
        resumen = {"filas": [{"especie": "Pinus patula", "existencias": 200,
                              "posibilidad": 20, "residuales": 180}]}
        salida = generar_word_cuadro_existencias(
            proyecto, data, analisis_existencias(data, resumen))
        documento = Document(BytesIO(salida.getvalue()))
        principal = next(t for t in documento.tables
                         if t.rows[0].cells[0].text == "Unidad Minima de Manejo (UMM)")

        def vmerge(celda):
            nodo = celda._tc.get_or_add_tcPr().find(qn("w:vMerge"))
            return None if nodo is None else nodo.get(qn("w:val"))

        def vmerge_raw(numero_fila, columna):
            celda = principal.rows[numero_fila]._tr.tc_lst[columna]
            nodo = celda.get_or_add_tcPr().find(qn("w:vMerge"))
            return None if nodo is None else nodo.get(qn("w:val"))

        self.assertEqual(vmerge_raw(2, 0), "restart")
        self.assertEqual(vmerge_raw(3, 0), "continue")
        self.assertEqual(vmerge_raw(2, 1), "restart")
        self.assertEqual(vmerge_raw(3, 1), "continue")

    def test_word_cuadro_incrementos_incluye_cuadro_completo_de_10_columnas(self):
        from io import BytesIO
        from docx import Document
        proyecto = PMFProyecto("Prueba", predio="Predio prueba")
        data = {"filas": [
            {"rodal": "UMM 1", "especie": "Pinus patula", "superficie": 10.0, "arb_ha": 400,
             "ab": 20.0, "tp": 8.0, "ica": 12.5, "ica_pct": 5.2, "ima": 10.0, "edad": 25.0},
            {"_type": "subtotal", "arb_ha": 400, "ab": 20.0, "ica": 12.5, "ima": 10.0},
        ], "total_arb_ha": 400, "total_ab": 20.0, "total_ica": 12.5, "total_ima": 10.0}
        analisis = {
            "titulo": "Incrementos de prueba",
            "parrafos": ["Crecimiento rico medio-pronóstico."],
            "grafica": [("ICA", 12.5), ("IMA", 10.0)],
            "cautela": "Consideración técnica.",
            "estado_datos": "Datos completos",
            "trazabilidad": "reglas v1",
            "limitaciones": ["Limitación de prueba"],
            "fuentes": ["Fuente de prueba"],
        }
        salida = generar_word_cuadro_incrementos(proyecto, data, analisis)
        documento = Document(BytesIO(salida.getvalue()))
        cuadro = documento.tables[-1]
        self.assertEqual(len(cuadro.columns), 10)
        self.assertEqual([c.text for c in cuadro.rows[0].cells],
                         ["UMM", "Especie", "Sup (ha)", "Arb/ha", "AB (m2/ha)", "TP",
                          "ICA (m3/ha/a)", "ICA%", "IMA (m3/ha/a)", "Edad"])
        textos = [c.text for fila in cuadro.rows for c in fila.cells]
        self.assertIn("Subtotal", textos)
        self.assertIn("ICA (m3/ha/a)", textos)
        self.assertIn("400.00", textos)  # Arb/ha formateado con dos decimales
        self.assertEqual(cuadro.rows[-1].cells[0].text, "TOTAL")
        parrafos = [p.text for p in documento.paragraphs]
        self.assertTrue(any("Crecimiento rico medio-pron" in p for p in parrafos))

    def test_word_plan_cortas_incluye_tablas_8_9_y_conciliacion(self):
        from io import BytesIO
        from docx import Document
        proyecto = PMFProyecto("Prueba", predio="Predio prueba")
        def intervencion(anualidad, rodal_id):
            return SimpleNamespace(anualidad=anualidad, rodal_id=rodal_id,
                                   superficie_ha=10.0, tratamiento="Corta de regeneración")
        datos = [
            {"intervencion": intervencion(1, "UMM 1"),
             "filas": [{"especie": "Pinus patula", "posibilidad": 5.0,
                        "infraestructura": 1.0, "total": 6.0}]},
            {"intervencion": intervencion(2, "UMM 2"),
             "filas": [{"especie": "Quercus rugosa", "posibilidad": 3.0,
                        "infraestructura": 0.0, "total": 3.0}]},
        ]
        totales_anualidad = {
            1: {"superficie": 10.0, "posibilidad": 5.0, "infraestructura": 1.0, "total": 6.0},
            2: {"superficie": 10.0, "posibilidad": 3.0, "infraestructura": 0.0, "total": 3.0},
        }
        totales_generales = {"superficie": 20.0, "posibilidad": 8.0,
                             "infraestructura": 1.0, "total": 9.0}
        resumen = [{"numero": 1,
                    "filas": [{"especie": "Pinus patula", "posibilidad": 5.0,
                               "infraestructura": 1.0, "total": 6.0}],
                    "subtotal": {"posibilidad": 5.0, "infraestructura": 1.0, "total": 6.0}}]
        total_resumen = {"posibilidad": 5.0, "infraestructura": 1.0, "total": 6.0}
        conciliacion = {"coincide": True, "diferencia": 0.0, "total_existencias": 6.0,
                        "total_plan": 6.0,
                        "filas": [{"especie": "Pinus patula", "existencias": 6.0, "plan": 6.0,
                                   "diferencia": 0.0, "coincide": True}]}
        salida = generar_word_plan_cortas(proyecto, datos, totales_anualidad,
                                          totales_generales, resumen, total_resumen,
                                          conciliacion)
        documento = Document(BytesIO(salida.getvalue()))
        principal, resumen_tabla, conciliacion_tabla = documento.tables[-3:]
        self.assertEqual(len(principal.columns), 8)
        self.assertEqual(principal.rows[0].cells[0].text, "Área de Corta")
        self.assertEqual(principal.rows[0].cells[1].text,
                         "Unidad Mínima de Manejo (UMM)")
        self.assertIn("Subtotal Anualidad 1", [c.text for r in principal.rows for c in r.cells])
        self.assertEqual(principal.rows[-1].cells[0].text, "TOTAL GENERAL")
        textos_resumen = [c.text for r in resumen_tabla.rows for c in r.cells]
        self.assertIn("Subtotal a Área de Corta 1", textos_resumen)
        self.assertIn("Especies por aprovechar",
                      [c.text for c in resumen_tabla.rows[0].cells])
        self.assertTrue(any(p.startswith("3.") and "Conciliaci" in p
                            for p in [p.text for p in documento.paragraphs]))
        self.assertEqual([c.text for c in conciliacion_tabla.rows[0].cells][0], "Especie")
        self.assertIn("COINCIDE", [c.text for r in conciliacion_tabla.rows for c in r.cells])

    def test_datos_reporte_valida_balance_y_promedios_ponderados(self):
        proyecto = PMFProyecto("Prueba")
        with patch.object(proyecto, "cuadro_existencias", return_value={"filas": [
            {"rodal": "R1", "superficie": 1, "especie": "Pinus patula", "vol_ha": 100,
             "vol_umm": 100, "ab": 10, "intensidad": 20, "pos_ha": 20, "pos_umm": 20,
             "res_vol": 80, "res_ab": 8},
            {"rodal": "R2", "superficie": 9, "especie": "Quercus rugosa", "vol_ha": 10,
             "vol_umm": 90, "ab": 2, "intensidad": 0, "pos_ha": 0, "pos_umm": 0,
             "res_vol": 90, "res_ab": 2}]},):
            datos = construir_datos_reporte_existencias(proyecto, usuario="prueba", version="1.0")
        self.assertEqual(datos["balance"], "verificado")
        self.assertAlmostEqual(datos["generales"]["existencias_ha"], 19)
        self.assertAlmostEqual(datos["generales"]["ab"], 2.8)
        self.assertEqual(datos["especies"][0]["condicion"], "Dominante")

    def test_datos_reporte_identifica_diferencia_mayor_a_tolerancia(self):
        proyecto = PMFProyecto("Prueba")
        with patch.object(proyecto, "cuadro_existencias", return_value={"filas": [
            {"rodal": "R1", "superficie": 1, "especie": "Pinus patula", "vol_ha": 100,
             "vol_umm": 100, "ab": 10, "intensidad": 20, "pos_ha": 20, "pos_umm": 20,
             "res_vol": 70, "res_ab": 8}]},):
            datos = construir_datos_reporte_existencias(proyecto)
        self.assertEqual(datos["balance"], "revisar")

    def test_interpretacion_registra_reglas_y_tratamiento_faltante(self):
        proyecto = PMFProyecto("Prueba")
        with patch.object(proyecto, "cuadro_existencias", return_value={"filas": [
            {"rodal": "R1", "superficie": 1, "especie": "Pinus patula", "vol_ha": 100,
             "vol_umm": 100, "ab": 10, "intensidad": 0, "pos_ha": 0, "pos_umm": 0,
             "res_vol": 100, "res_ab": 10}]},):
            reglas = interpretar_reporte_existencias(construir_datos_reporte_existencias(proyecto))
        self.assertEqual(reglas[0]["codigo_regla"], "EXI-01-INTEGRACION")
        self.assertIn("No se identificó un tratamiento", reglas[-2]["texto_generado"])
        self.assertTrue(all(regla["valores_utilizados"] for regla in reglas))

    def test_graficas_incluyen_series_y_comparativo_solo_con_varias_umm(self):
        reporte = {"especies": [{"especie": "Pinus patula", "existencias": 100, "posibilidad": 20,
                                  "residual": 80, "participacion_vol": 100, "intensidad": 20, "residual_pct": 80}],
                   "rodales": [{"id": "R1", "existencias_ha": 100, "posibilidad_ha": 20, "ab": 10,
                                "res_ab": 8, "intensidad": 20}]}
        self.assertEqual(len(datos_graficas_existencias(reporte)), 3)
        reporte["rodales"].append({"id": "R2", "existencias_ha": 90, "posibilidad_ha": 0, "ab": 8,
                                    "res_ab": 8, "intensidad": 0})
        self.assertEqual(datos_graficas_existencias(reporte)[-1]["id"], "comparativo-umm")

    def test_analisis_detallado_incluye_indicadores_y_ecuaciones(self):
        proyecto = PMFProyecto("Prueba")
        with patch.object(proyecto, "cuadro_existencias", return_value={"filas": [
            {"rodal": "R1", "superficie": 1, "especie": "Pinus patula", "vol_ha": 100,
             "vol_umm": 100, "ab": 10, "intensidad": 0, "pos_ha": 0, "pos_umm": 0,
             "res_vol": 100, "res_ab": 10}]},):
            reporte = construir_datos_reporte_existencias(proyecto, usuario="prueba", version="1.0")
        analisis = analisis_detallado_existencias(reporte, interpretar_reporte_existencias(reporte))
        self.assertIn("Balance volumétrico: verificado", [valor for _, valor in analisis["indicadores"]])
        self.assertIn("No registrada en el proyecto", analisis["fuentes"][-1])

    def test_reporte_integral_genera_tres_niveles_y_dos_formatos(self):
        proyecto = PMFProyecto("Prueba", predio="Predio prueba")
        for nivel in ("ejecutivo", "tecnico", "completo"):
            self.assertTrue(generar_word_integral(proyecto, nivel).getvalue().startswith(b"PK"))
            self.assertTrue(generar_pdf_integral(proyecto, nivel).getvalue().startswith(b"%PDF"))

    @patch("app.get_pmf", return_value=PMFProyecto("Prueba"))
    def test_rutas_incluidas_exportan_ambos_formatos(self, _):
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        for ruta, firma in (
            ("/reportes/existencias/exportar/word", b"PK"),
            ("/reportes/cuadro_existencias/exportar/word", b"PK"),
            ("/reportes/existencias/exportar/pdf", b"%PDF"),
            ("/reportes/incrementos/exportar/word", b"PK"),
            ("/reportes/incrementos/exportar/pdf", b"%PDF"),
            ("/reportes/carbono/exportar/word", b"PK"),
            ("/reportes/carbono/exportar/pdf", b"%PDF"),
            ("/cortas/exportar/word", b"PK"),
        ):
            respuesta = cliente.get(ruta)
            self.assertEqual(respuesta.status_code, 200, ruta)
            self.assertTrue(respuesta.data.startswith(firma), ruta)

    @patch("app.get_pmf", return_value=PMFProyecto("Prueba"))
    def test_reporte_integral_tiene_nivel_tecnico_predeterminado_y_exporta(self, _):
        cliente = app_module.app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        respuesta = cliente.get("/reportes/interpretacion")
        self.assertEqual(respuesta.status_code, 200)
        self.assertIn("Técnico", respuesta.get_data(as_text=True))
        for nivel in ("ejecutivo", "tecnico", "completo"):
            for formato, firma in (("word", b"PK"), ("pdf", b"%PDF")):
                respuesta = cliente.get(f"/reportes/interpretacion/exportar/{formato}?nivel={nivel}")
                self.assertEqual(respuesta.status_code, 200)
                self.assertTrue(respuesta.data.startswith(firma))


if __name__ == "__main__":
    unittest.main()
