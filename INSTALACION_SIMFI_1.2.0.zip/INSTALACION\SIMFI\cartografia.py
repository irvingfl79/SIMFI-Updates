"""Lectores y exportadores de capas de rodales para Cartografía."""
import json
import logging
import math
import re
import struct
import unicodedata
import xml.etree.ElementTree as ET
import zipfile
from datetime import date
from io import BytesIO


MAX_CAPA_BYTES = 25 * 1024 * 1024
LOG = logging.getLogger(__name__)


def _numero(texto):
    try:
        return float(texto)
    except (TypeError, ValueError):
        return texto


def _poligonos(geometria):
    tipo = (geometria or {}).get("type", "")
    coordenadas = (geometria or {}).get("coordinates", [])
    if tipo == "Polygon":
        return [coordenadas]
    if tipo == "MultiPolygon":
        return coordenadas
    return []


def _normalizar(features, crs="No registrado en la capa"):
    salida = []
    for indice, feature in enumerate(features, 1):
        geometria = feature.get("geometry", feature)
        poligonos = _poligonos(geometria)
        if not poligonos:
            continue
        salida.append({"id": str(feature.get("id", indice)), "geometry": {"type": "MultiPolygon", "coordinates": poligonos},
                       "properties": dict(feature.get("properties") or {})})
    if not salida:
        raise ValueError("La capa no contiene polígonos de rodales.")
    return {"type": "FeatureCollection", "features": salida, "crs": crs}


def leer_geojson(datos):
    try:
        contenido = json.loads(datos.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("El archivo GeoJSON no es válido.") from exc
    if contenido.get("type") == "FeatureCollection":
        features = contenido.get("features", [])
    elif contenido.get("type") == "Feature":
        features = [contenido]
    else:
        features = [{"geometry": contenido, "properties": {}}]
    crs = contenido.get("crs", {}).get("properties", {}).get("name", "EPSG:4326")
    return _normalizar(features, crs)


def leer_kml(datos):
    try:
        raiz = ET.fromstring(datos)
    except ET.ParseError as exc:
        raise ValueError("El archivo KML no es válido.") from exc
    features = []
    for indice, marca in enumerate((n for n in raiz.iter() if n.tag.endswith("Placemark")), 1):
        propiedades = {}
        for hijo in marca.iter():
            etiqueta = hijo.tag.rsplit("}", 1)[-1]
            if etiqueta in {"name", "description"} and (hijo.text or "").strip():
                propiedades[etiqueta] = hijo.text.strip()
            if etiqueta == "Data" and hijo.attrib.get("name"):
                valor = next((n.text for n in hijo if n.tag.endswith("value")), "")
                propiedades[hijo.attrib["name"]] = (valor or "").strip()
        poligonos = []
        for poligono in (n for n in marca.iter() if n.tag.endswith("Polygon")):
            anillos = []
            for nodo in poligono.iter():
                if nodo.tag.endswith("coordinates") and (nodo.text or "").strip():
                    anillo = []
                    for punto in nodo.text.replace("\n", " ").split():
                        valores = punto.split(",")
                        if len(valores) >= 2:
                            anillo.append([float(valores[0]), float(valores[1])])
                    if anillo:
                        anillos.append(anillo)
            if anillos:
                poligonos.append(anillos)
        if poligonos:
            features.append({"id": str(indice), "geometry": {"type": "MultiPolygon", "coordinates": poligonos}, "properties": propiedades})
    return _normalizar(features, "EPSG:4326")


def _leer_dbf(datos):
    if not datos or len(datos) < 32:
        return []
    cantidad = struct.unpack_from("<I", datos, 4)[0]
    inicio = struct.unpack_from("<H", datos, 8)[0]
    longitud = struct.unpack_from("<H", datos, 10)[0]
    campos, posicion = [], 32
    while posicion + 32 <= len(datos) and datos[posicion] != 13:
        descriptor = datos[posicion:posicion + 32]
        nombre = descriptor[:11].split(b"\0", 1)[0].decode("latin1").strip()
        campos.append((nombre, chr(descriptor[11]), descriptor[16]))
        posicion += 32
    registros = []
    for indice in range(cantidad):
        registro = inicio + indice * longitud
        if registro >= len(datos) or datos[registro:registro + 1] == b"*":
            continue
        valores, cursor = {}, registro + 1
        for nombre, tipo, ancho in campos:
            texto = datos[cursor:cursor + ancho].decode("latin1", "replace").strip()
            valores[nombre] = _numero(texto) if tipo in {"N", "F"} and texto else texto
            cursor += ancho
        registros.append(valores)
    return registros


def leer_shp(datos_shp, datos_dbf=b"", prj="No registrado en la capa"):
    if len(datos_shp) < 100 or struct.unpack_from(">I", datos_shp, 0)[0] != 9994:
        raise ValueError("El archivo SHP no es válido.")
    atributos, features, posicion = _leer_dbf(datos_dbf), [], 100
    numero_registro = 0
    while posicion + 8 <= len(datos_shp):
        numero_registro += 1
        longitud = struct.unpack_from(">I", datos_shp, posicion + 4)[0] * 2
        if longitud < 4 or posicion + 8 + longitud > len(datos_shp):
            raise ValueError(f"El registro {numero_registro} del SHP está incompleto.")
        contenido = datos_shp[posicion + 8:posicion + 8 + longitud]
        posicion += 8 + longitud
        tipo = struct.unpack_from("<I", contenido, 0)[0]
        if tipo == 0:
            continue
        if tipo not in {5, 15, 25}:
            LOG.warning("Cartografía: se omitió registro SHP %s de tipo %s.", numero_registro, tipo)
            continue
        if len(contenido) < 44:
            raise ValueError(f"El polígono del registro {numero_registro} está incompleto.")
        partes, puntos = struct.unpack_from("<2I", contenido, 36)
        inicio_partes = 44
        if not partes or not puntos or inicio_partes + partes * 4 + puntos * 16 > len(contenido):
            raise ValueError(f"El polígono del registro {numero_registro} tiene una estructura inválida.")
        indices = list(struct.unpack_from("<" + "I" * partes, contenido, inicio_partes))
        inicio_puntos = inicio_partes + partes * 4
        coordenadas = [list(struct.unpack_from("<2d", contenido, inicio_puntos + punto * 16)) for punto in range(puntos)]
        anillos = [coordenadas[inicio:(indices[numero + 1] if numero + 1 < len(indices) else puntos)]
                   for numero, inicio in enumerate(indices)]
        features.append({"geometry": {"type": "Polygon", "coordinates": anillos}, "properties": atributos[len(features)] if len(features) < len(atributos) else {}})
    return _normalizar(features, prj or "No registrado en la capa")


def _texto_prj(datos):
    for codificacion in ("utf-8-sig", "latin1"):
        try:
            return datos.decode(codificacion).strip()
        except UnicodeDecodeError:
            continue
    return ""


def identificar_crs(prj):
    normalizado = (prj or "").upper()
    if "32614" in normalizado or re.search(r"UTM[^\n]*ZONE[ _]?14N?", normalizado):
        return "EPSG:32614"
    if "4326" in normalizado or ("WGS" in normalizado and "UTM" not in normalizado):
        return "EPSG:4326"
    return "No identificado"


def utm14n_a_wgs84(este, norte):
    """Transformación local EPSG:32614 a EPSG:4326 para la vista web."""
    a, ecc2, k0 = 6378137.0, 0.00669438, 0.9996
    e1 = (1 - math.sqrt(1 - ecc2)) / (1 + math.sqrt(1 - ecc2))
    x, y = float(este) - 500000.0, float(norte)
    m = y / k0
    mu = m / (a * (1 - ecc2 / 4 - 3 * ecc2 ** 2 / 64 - 5 * ecc2 ** 3 / 256))
    phi1 = (mu + (3 * e1 / 2 - 27 * e1 ** 3 / 32) * math.sin(2 * mu) +
            (21 * e1 ** 2 / 16 - 55 * e1 ** 4 / 32) * math.sin(4 * mu) +
            (151 * e1 ** 3 / 96) * math.sin(6 * mu))
    eccp2 = ecc2 / (1 - ecc2)
    n1 = a / math.sqrt(1 - ecc2 * math.sin(phi1) ** 2)
    t1, c1 = math.tan(phi1) ** 2, eccp2 * math.cos(phi1) ** 2
    r1 = a * (1 - ecc2) / (1 - ecc2 * math.sin(phi1) ** 2) ** 1.5
    d = x / (n1 * k0)
    latitud = phi1 - (n1 * math.tan(phi1) / r1) * (d ** 2 / 2 -
        (5 + 3 * t1 + 10 * c1 - 4 * c1 ** 2 - 9 * eccp2) * d ** 4 / 24 +
        (61 + 90 * t1 + 298 * c1 + 45 * t1 ** 2 - 252 * eccp2 - 3 * c1 ** 2) * d ** 6 / 720)
    longitud = (d - (1 + 2 * t1 + c1) * d ** 3 / 6 +
        (5 - 2 * c1 + 28 * t1 - 3 * c1 ** 2 + 8 * eccp2 + 24 * t1 ** 2) * d ** 5 / 120) / math.cos(phi1)
    return [math.degrees(longitud) - 99.0, math.degrees(latitud)]


def preparar_visor(capa):
    crs = identificar_crs(capa.get("crs", ""))
    visor = {"type": "FeatureCollection", "crs": "EPSG:4326", "features": []}
    for feature in capa.get("features", []):
        coordenadas = feature["geometry"]["coordinates"]
        if crs == "EPSG:32614":
            coordenadas = [[[utm14n_a_wgs84(*punto) for punto in anillo] for anillo in poligono] for poligono in coordenadas]
        elif crs != "EPSG:4326":
            continue
        visor["features"].append({"type": "Feature", "id": feature["id"],
                                  "properties": dict(feature["properties"]),
                                  "geometry": {"type": "MultiPolygon", "coordinates": coordenadas}})
    capa["crs_identificado"] = crs
    capa["visor"] = visor
    return capa


def leer_shp_zip(datos):
    try:
        with zipfile.ZipFile(BytesIO(datos)) as archivo:
            detectados = [nombre for nombre in archivo.namelist() if not nombre.endswith("/")]
            nombres = {nombre.rsplit("/", 1)[-1].lower(): nombre for nombre in detectados}
            LOG.warning("Cartografía: archivos detectados en ZIP: %s", detectados)
            shp = next((nombre for nombre in nombres if nombre.endswith(".shp") and not nombre.endswith(".shp.xml")), None)
            if not shp:
                raise ValueError("El ZIP no contiene un archivo .shp.")
            base = shp[:-4]
            shp_archivo = nombres[shp]
            dbf_archivo = nombres.get(base + ".dbf", "")
            prj_archivo = nombres.get(base + ".prj", "")
            shx_archivo = nombres.get(base + ".shx", "")
            LOG.warning("Cartografía: SHP seleccionado=%s; SHX=%s; DBF=%s; PRJ=%s", shp_archivo, shx_archivo, dbf_archivo, prj_archivo)
            prj_texto = _texto_prj(archivo.read(prj_archivo)) if prj_archivo else ""
            LOG.warning("Cartografía: CRS identificado=%s", identificar_crs(prj_texto))
            capa = leer_shp(archivo.read(shp_archivo), archivo.read(dbf_archivo) if dbf_archivo else b"", prj_texto)
            LOG.warning("Cartografía: geometrías leídas=%s", len(capa["features"]))
            return preparar_visor(capa)
    except zipfile.BadZipFile as exc:
        raise ValueError("Para SHP cargue un archivo ZIP con .shp y, de ser posible, .dbf y .prj.") from exc
    except Exception:
        LOG.exception("Cartografía: error completo al leer ZIP-SHP")
        raise


def cargar_capa(nombre, datos):
    if not datos or len(datos) > MAX_CAPA_BYTES:
        raise ValueError("La capa está vacía o excede el límite de 25 MB.")
    extension = nombre.rsplit(".", 1)[-1].lower() if "." in nombre else ""
    try:
        if extension in {"geojson", "json"}:
            capa = leer_geojson(datos)
        elif extension == "kml":
            capa = leer_kml(datos)
        elif extension == "shp":
            capa = leer_shp(datos)
        elif extension == "zip":
            capa = leer_shp_zip(datos)
        else:
            raise ValueError("Use GeoJSON, KML, SHP o un ZIP que contenga SHP, DBF y PRJ.")
    except (IndexError, KeyError, struct.error, UnicodeError) as exc:
        raise ValueError("No fue posible leer la capa. Verifique que el ZIP contenga un SHP válido y sus archivos DBF y PRJ correspondientes.") from exc
    capa["nombre"] = nombre
    return preparar_visor(capa)


def campos_atributos(capa):
    return sorted({str(campo) for feature in capa.get("features", []) for campo in feature.get("properties", {})})


def geometria_geografica(capa):
    puntos = [punto for feature in capa.get("visor", capa).get("features", []) for poligono in feature["geometry"]["coordinates"]
              for anillo in poligono for punto in anillo]
    return bool(puntos) and all(-180 <= punto[0] <= 180 and -90 <= punto[1] <= 90 for punto in puntos)


PARAMETROS = [
    ("superficie_ha", "Superficie (ha)"),
    ("existencias_m3", "Existencias (m3)"),
    ("volumen_ha_m3", "Volumen/ha (m3/ha)"),
    ("arboles_ha", "Arboles/ha (arb/ha)"),
    ("area_basal_ha_m2", "Area basal (m2/ha)"),
    ("intensidad_corta", "Intensidad de corta (%)"),
    ("tratamientos", "Tratamiento silvicultural"),
    ("error_muestreo_pct", "Error de muestreo (%)"),
    ("estado_error_muestreo", "Estado del error de muestreo"),
]

PARAMETROS_DBF = [
    ("SUP_HA", "N", 12, 3, "superficie_ha"),
    ("EXIST_M3", "N", 14, 3, "existencias_m3"),
    ("VOL_HA_M3", "N", 12, 3, "volumen_ha_m3"),
    ("ARB_HA", "N", 12, 2, "arboles_ha"),
    ("AB_HA_M2", "N", 12, 3, "area_basal_ha_m2"),
    ("INT_CORTA", "C", 254, 0, "intensidad_corta"),
    ("TRATAM_SL", "C", 254, 0, "tratamientos"),
    ("ERROR_PCT", "N", 10, 3, "error_muestreo_pct"),
    ("EST_ERROR", "C", 32, 0, "estado_error_muestreo"),
]

CRS_WKT = {
    "EPSG:32614": ('PROJCS["WGS_1984_UTM_Zone_14N",GEOGCS["GCS_WGS_1984",'
                   'DATUM["D_WGS_1984",SPHEROID["WGS_1984",6378137.0,298.257223563]],'
                   'PRIMEM["Greenwich",0.0],UNIT["Degree",0.0174532925199433]],'
                   'PROJECTION["Transverse_Mercator"],PARAMETER["False_Easting",500000.0],'
                   'PARAMETER["False_Northing",0.0],PARAMETER["Central_Meridian",-99.0],'
                   'PARAMETER["Scale_Factor",0.9996],PARAMETER["Latitude_Of_Origin",0.0],'
                   'UNIT["Meter",1.0]]'),
    "EPSG:4326": ('GEOGCS["GCS_WGS_1984",DATUM["D_WGS_1984",'
                  'SPHEROID["WGS_1984",6378137.0,298.257223563]],'
                  'PRIMEM["Greenwich",0.0],UNIT["Degree",0.0174532925199433]]'),
}


def _aplanar_texto(valor):
    return unicodedata.normalize("NFKD", str(valor or "")).encode("ascii", "ignore").decode("ascii")


def _cadena_intensidad(intensidad):
    return "; ".join("%s: %s%%" % (item.get("especie", ""), item.get("porcentaje") or 0) for item in intensidad or [])


def _cadena_tratamientos(tratamientos):
    return ", ".join(str(item) for item in tratamientos or [])


def _parametros_exportables(datos):
    estructurados = {}
    planos = {}
    for clave, _ in PARAMETROS:
        if clave not in datos or datos[clave] is None:
            continue
        valor = datos[clave]
        if clave == "intensidad_corta":
            estructurados[clave] = valor
            planos[clave] = _cadena_intensidad(valor)
        elif clave == "tratamientos":
            estructurados[clave] = valor
            planos[clave] = _cadena_tratamientos(valor)
        else:
            estructurados[clave] = valor
            planos[clave] = valor
    return estructurados, planos


def exportar_geojson(capa, datos_por_rodal):
    features = []
    for indice, feature in enumerate(capa.get("features", [])):
        propiedades = dict(feature.get("properties") or {})
        datos = datos_por_rodal.get(indice)
        propiedades["enlazado_simfi"] = bool(datos)
        if datos:
            estructurados, _ = _parametros_exportables(datos)
            propiedades.update(estructurados)
        features.append({"type": "Feature", "id": feature.get("id"),
                         "geometry": feature.get("geometry"), "properties": propiedades})
    salida = {"type": "FeatureCollection", "features": features}
    crs = identificar_crs(capa.get("crs", ""))
    if crs in CRS_WKT:
        salida["crs"] = {"type": "name", "properties": {"name": crs}}
    return json.dumps(salida, ensure_ascii=False).encode("utf-8")


def _nombre_dbf(texto, usados):
    base = re.sub(r"[^A-Z0-9_]", "", _aplanar_texto(texto).upper().replace(" ", "_"))[:10] or "COL"
    nombre, sufijo = base, 1
    while nombre in usados:
        sufijo_texto = str(sufijo)
        nombre = base[:10 - len(sufijo_texto)] + sufijo_texto
        sufijo += 1
    usados.add(nombre)
    return nombre


def _campos_dbf(registros, columnas):
    usados = set()
    campos = []
    for columna in columnas:
        valores = [registro.get(columna) for registro in registros]
        presentes = [valor for valor in valores if valor not in (None, "")]
        numericos = [valor for valor in presentes if isinstance(valor, (int, float))]
        if presentes and len(numericos) == len(presentes):
            texto = ["%s" % valor for valor in numericos]
            decimales = max((len(valor.rsplit(".", 1)[1]) for valor in texto if "." in valor), default=0)
            enteros = max((len(valor.split(".")[0]) for valor in texto), default=1)
            decimales = min(decimales, 6)
            ancho = min(enteros + decimales + 1, 18)
            campos.append((_nombre_dbf(columna, usados), "N", ancho, decimales))
        else:
            largos = [len(_aplanar_texto(valor)) for valor in presentes]
            ancho = min(max(largos or [1]), 254)
            campos.append((_nombre_dbf(columna, usados), "C", ancho, 0))
    return campos


def _escribir_dbf(registros, campos):
    hoy = date.today()
    largo_encabezado = 32 + 32 * len(campos) + 1
    largo_registro = 1 + sum(longitud for _, _, longitud, _ in campos)
    cuerpo = struct.pack("<B", 3)
    cuerpo += bytes([hoy.year - 2000, hoy.month, hoy.day])
    cuerpo += struct.pack("<IHH", len(registros), largo_encabezado, largo_registro)
    cuerpo += b"\0" * 20
    for nombre, tipo, longitud, decimales in campos:
        cuerpo += nombre.encode("latin1", "replace")[:11].ljust(11, b"\0")
        cuerpo += bytes([ord(tipo)]) + b"\0" * 4 + bytes([longitud, decimales]) + b"\0" * 14
    cuerpo += b"\r"
    for registro in registros:
        fila = b" "
        for nombre, tipo, longitud, decimales in campos:
            valor = registro.get(nombre)
            if tipo in {"N", "F"}:
                if valor in (None, ""):
                    texto = ""
                elif isinstance(valor, int):
                    texto = ("%*d" % (longitud, valor))[-longitud:]
                else:
                    texto = ("%*.*f" % (longitud, decimales, float(valor)))[-longitud:]
                fila += texto.encode("latin1", "replace").rjust(longitud, b" ")
            else:
                fila += _aplanar_texto(valor).encode("ascii", "ignore")[:longitud].ljust(longitud, b" ")
        cuerpo += fila
    return cuerpo + b"\x1a"


def _orientar_anillo(anillo, exterior):
    puntos = [(float(punto[0]), float(punto[1])) for punto in anillo]
    if len(puntos) < 4:
        return puntos
    if puntos[0] != puntos[-1]:
        puntos.append(puntos[0])
    area = sum(puntos[i][0] * puntos[i + 1][1] - puntos[i + 1][0] * puntos[i][1] for i in range(len(puntos) - 1)) / 2
    if (exterior and area > 0) or (not exterior and area < 0):
        puntos.reverse()
    return puntos


def _contenido_poligono(feature):
    anillos = []
    for indice, poligono in enumerate(feature["geometry"]["coordinates"]):
        for anillo in poligono:
            anillo = _orientar_anillo(anillo, indice == 0)
            if len(anillo) >= 4:
                anillos.append(anillo)
    if not anillos:
        return None
    puntos = [punto for anillo in anillos for punto in anillo]
    xs = [punto[0] for punto in puntos]
    ys = [punto[1] for punto in puntos]
    contenido = struct.pack("<i4d2i", 5, min(xs), min(ys), max(xs), max(ys), len(anillos), len(puntos))
    offset = 0
    for anillo in anillos:
        contenido += struct.pack("<i", offset)
        offset += len(anillo)
    for punto in puntos:
        contenido += struct.pack("<2d", *punto)
    return contenido


def _encabezado_archivo(contenidos, puntos, es_indice):
    xs = [punto[0] for punto in puntos]
    ys = [punto[1] for punto in puntos]
    if es_indice:
        longitud_total = 50 + 4 * len(contenidos)
    else:
        longitud_total = 50 + 4 * len(contenidos) + sum(len(contenido) // 2 for contenido in contenidos)
    encabezado = struct.pack(">I5I", 9994, 0, 0, 0, 0, 0)
    encabezado += struct.pack(">I", longitud_total)
    encabezado += struct.pack("<2i", 1000, 5)
    encabezado += struct.pack("<4d", min(xs), min(ys), max(xs), max(ys))
    encabezado += struct.pack("<4d", 0.0, 0.0, 0.0, 0.0)
    return encabezado


def _base_archivo(capa):
    nombre = re.sub(r"[^A-Za-z0-9_.-]", "_", (capa.get("nombre") or "capa").rsplit(".", 1)[0]) or "capa"
    return nombre


def exportar_shp_zip(capa, datos_por_rodal):
    features = capa.get("features", [])
    if not features:
        raise ValueError("La capa no contiene geometrías para exportar.")
    dbs_brutos = []
    contenidos = []
    for indice, feature in enumerate(features):
        contenido = _contenido_poligono(feature)
        if contenido is None:
            continue
        datos = datos_por_rodal.get(indice)
        contenidos.append(contenido)
        dbs_brutos.append((dict(feature.get("properties") or {}), datos))
    if not contenidos:
        raise ValueError("La capa no contiene polígonos válidos para exportar.")
    columnas = campos_atributos(capa) or []
    campos = _campos_dbf([propiedades for propiedades, _ in dbs_brutos], columnas)
    usados = {nombre for nombre, _, _, _ in campos}
    parametros_campos = []
    for nombre, tipo, longitud, decimales, clave in PARAMETROS_DBF:
        asignado = _nombre_dbf(nombre, usados)
        usados.add(asignado)
        campos.append((asignado, tipo, longitud, decimales))
        parametros_campos.append((clave, asignado))
    registros = []
    for propiedades, datos in dbs_brutos:
        registro = dict(propiedades)
        if datos:
            _, planos = _parametros_exportables(datos)
            for clave, asignado in parametros_campos:
                if clave in planos:
                    registro[asignado] = planos[clave]
        registros.append(registro)
    puntos = [punto for contenido in contenidos for punto in _puntos_de(contenido)]
    shp = _encabezado_archivo(contenidos, puntos, False)
    shx = _encabezado_archivo(contenidos, puntos, True)
    offset = 100
    for numero, contenido in enumerate(contenidos, 1):
        shp += struct.pack(">2I", numero, len(contenido) // 2) + contenido
        shx += struct.pack(">2I", offset // 2, len(contenido) // 2)
        offset += 8 + len(contenido)
    base = _base_archivo(capa)
    salida = BytesIO()
    with zipfile.ZipFile(salida, "w", zipfile.ZIP_DEFLATED) as archivo:
        archivo.writestr(base + ".shp", shp)
        archivo.writestr(base + ".shx", shx)
        archivo.writestr(base + ".dbf", _escribir_dbf(registros, campos))
        crs = identificar_crs(capa.get("crs", ""))
        if crs in CRS_WKT:
            archivo.writestr(base + ".prj", CRS_WKT[crs])
        archivo.writestr(base + ".cpg", "UTF-8")
    return salida.getvalue()


def _puntos_de(contenido):
    partes, cantidad = struct.unpack_from("<2I", contenido, 36)
    inicio = 44 + partes * 4
    return [struct.unpack_from("<2d", contenido, inicio + punto * 16) for punto in range(cantidad)]


def exportar_excel_atributos(capa, datos_por_rodal, firma="SIMFI - Sistema para el Manejo Forestal Mejorado por Dr.PIFL"):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    from openpyxl.utils import get_column_letter
    columnas = campos_atributos(capa) or []
    encabezados = list(columnas) + [titulo for _, titulo in PARAMETROS] + ["Enlace SIMFI"]
    libro = Workbook()
    hoja = libro.active
    hoja.title = "Atributos_capa"
    libro.properties.creator = firma
    hoja.oddFooter.center.text = firma
    hoja.append(encabezados)
    negrita = Font(bold=True)
    relleno = PatternFill("solid", start_color="D9E1F2")
    for celda in hoja[1]:
        celda.font = negrita
        celda.fill = relleno
    for indice, feature in enumerate(capa.get("features", [])):
        propiedades = feature.get("properties") or {}
        datos = datos_por_rodal.get(indice)
        fila = [propiedades.get(columna, "") for columna in columnas]
        if datos:
            for clave, _ in PARAMETROS:
                valor = datos.get(clave)
                if clave == "intensidad_corta":
                    fila.append(_cadena_intensidad(valor))
                elif clave == "tratamientos":
                    fila.append(_cadena_tratamientos(valor))
                else:
                    fila.append("" if valor is None else valor)
        else:
            fila.extend([""] * len(PARAMETROS))
        fila.append("Sí" if datos else "No")
        hoja.append(fila)
    for numero, encabezado in enumerate(encabezados, 1):
        hoja.column_dimensions[get_column_letter(numero)].width = min(max(len(str(encabezado)) + 4, 10), 40)
    salida = BytesIO()
    libro.save(salida)
    return salida.getvalue()
