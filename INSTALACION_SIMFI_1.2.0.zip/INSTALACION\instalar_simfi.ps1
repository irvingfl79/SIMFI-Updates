param(
    [string]$Destination = "",
    [switch]$SkipShortcuts
)

$ErrorActionPreference = "Stop"

$PackageRoot = $PSScriptRoot
$Source = Join-Path $PackageRoot "SIMFI"
$InstallDir = if ($Destination) { $Destination } else { Join-Path $env:LOCALAPPDATA "SIMFI" }
$Pythonw = Join-Path $InstallDir "python\pythonw.exe"
$RunScript = Join-Path $InstallDir "run.py"
$Icon = Join-Path $InstallDir "img\SIMFI_icon.ico"

Write-Host "Verificando paquete..." -ForegroundColor Cyan
$Required = @(
    (Join-Path $Source "app.py"),
    (Join-Path $Source "run.py"),
    (Join-Path $Source "python\python.exe"),
    (Join-Path $Source "python\pythonw.exe"),
    (Join-Path $Source "img\SIMFI_icon.ico")
)
foreach ($Path in $Required) {
    if (-not (Test-Path -LiteralPath $Path)) {
        throw "El paquete esta incompleto. Falta: $Path"
    }
}

Write-Host "Instalando en $InstallDir ..." -ForegroundColor Cyan
New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null

# Data is copied separately so project files and users survive an update.
& robocopy.exe $Source $InstallDir /E /R:2 /W:1 /XD data __pycache__ /XF *.pyc | Out-Null
if ($LASTEXITCODE -gt 7) {
    throw "No fue posible copiar los archivos de SIMFI. Codigo Robocopy: $LASTEXITCODE"
}

$DataDir = Join-Path $InstallDir "data"
New-Item -ItemType Directory -Path $DataDir -Force | Out-Null
$DefaultUsers = Join-Path $Source "data\usuarios.json"
$InstalledUsers = Join-Path $DataDir "usuarios.json"
if ((Test-Path -LiteralPath $DefaultUsers) -and -not (Test-Path -LiteralPath $InstalledUsers)) {
    Copy-Item -LiteralPath $DefaultUsers -Destination $InstalledUsers
}

$MigrationScript = Join-Path $InstallDir "migrar_almacenamiento.ps1"
if (Test-Path -LiteralPath $MigrationScript) {
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $MigrationScript -InstallDir $InstallDir
    if ($LASTEXITCODE -ne 0) {
        throw "La migracion de almacenamiento no se completo."
    }
}

Write-Host "Verificando Python y dependencias..." -ForegroundColor Cyan
$Python = Join-Path $InstallDir "python\python.exe"
& $Python -c "import flask, openpyxl, docx; from app import app; print('SIMFI OK')"
if ($LASTEXITCODE -ne 0) {
    throw "La verificacion de Python o de las dependencias fallo."
}

if (-not $SkipShortcuts) {
    $Shell = New-Object -ComObject WScript.Shell
    $Desktop = [Environment]::GetFolderPath("Desktop")
    $DesktopShortcut = $Shell.CreateShortcut((Join-Path $Desktop "SIMFI.lnk"))
    $DesktopShortcut.TargetPath = $Pythonw
    $DesktopShortcut.Arguments = '"' + $RunScript + '"'
    $DesktopShortcut.WorkingDirectory = $InstallDir
    $DesktopShortcut.IconLocation = $Icon + ",0"
    $DesktopShortcut.Description = "Sistema para el Manejo Forestal Intensivo"
    $DesktopShortcut.WindowStyle = 7
    $DesktopShortcut.Save()

    $Programs = [Environment]::GetFolderPath("Programs")
    $MenuDir = Join-Path $Programs "SIMFI"
    New-Item -ItemType Directory -Path $MenuDir -Force | Out-Null
    $MenuShortcut = $Shell.CreateShortcut((Join-Path $MenuDir "SIMFI.lnk"))
    $MenuShortcut.TargetPath = $Pythonw
    $MenuShortcut.Arguments = '"' + $RunScript + '"'
    $MenuShortcut.WorkingDirectory = $InstallDir
    $MenuShortcut.IconLocation = $Icon + ",0"
    $MenuShortcut.Description = "Sistema para el Manejo Forestal Intensivo"
    $MenuShortcut.WindowStyle = 7
    $MenuShortcut.Save()
}

Write-Host "" 
Write-Host "Instalacion completada correctamente." -ForegroundColor Green
Write-Host "Carpeta: $InstallDir"
if (-not $SkipShortcuts) {
    Write-Host "Acceso directo: $(Join-Path $Desktop 'SIMFI.lnk')"
}
