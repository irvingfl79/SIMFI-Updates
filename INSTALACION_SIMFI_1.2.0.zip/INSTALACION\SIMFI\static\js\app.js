document.addEventListener('DOMContentLoaded', function() {
  // Flash auto-dismiss
  document.querySelectorAll('.flash-close').forEach(function(el) {
    el.addEventListener('click', function() {
      this.parentElement.remove();
    });
  });
  setTimeout(function() {
    document.querySelectorAll('.flash').forEach(function(el) {
      el.style.opacity = '0';
      el.style.transition = 'opacity 0.5s';
      setTimeout(function() { el.remove(); }, 500);
    });
  }, 5000);

  document.querySelectorAll('.nav-group-toggle').forEach(function(toggle) {
    toggle.addEventListener('click', function() {
      var submenu = document.getElementById(this.getAttribute('aria-controls'));
      var abierto = this.getAttribute('aria-expanded') === 'true';
      this.setAttribute('aria-expanded', String(!abierto));
      submenu.hidden = abierto;
      this.querySelector('.nav-group-indicator').textContent = abierto ? '+' : '−';
    });
  });
});

function toggleEditForm() {
  var form = document.getElementById('editProyectoForm');
  form.style.display = form.style.display === 'none' ? 'block' : 'none';
}
