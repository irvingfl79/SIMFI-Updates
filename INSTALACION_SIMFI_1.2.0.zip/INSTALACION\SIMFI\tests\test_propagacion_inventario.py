"""Prueba de propagacion: al actualizar el inventario por rodal (cualquier rodal
y especie), todos los cuadros ligados a esos datos deben actualizarse.

Los cuadros de SIMFI se calculan en vivo desde tablas_inventario en cada
vista; esta prueba lo verifica por HTTP como un usuario real: edita una
tabla, elimina otra y comprueba que cada cuadro refleja el cambio.
"""

import re
import tempfile
import unittest

import app as app_module
from modelos import (ClaseDiametrica, EcuacionVolumen, PMFProyecto, Rodal,
                     TablaInventarioRodal)


def _proyecto_propagacion(ruta):
    pmf = PMFProyecto("Propagacion", predio="Propagacion")
    pmf.agregar_rodal(Rodal("R1", 10, sitios=1, area_sitio_m2=10000))
    pmf.agregar_rodal(Rodal("R2", 5, sitios=1, area_sitio_m2=10000))
    for especie in ("Pinus patula", "Pinus montezumae"):
        pmf.agregar_especie(especie)
        pmf.asignar_ecuacion(especie, EcuacionVolumen())
    pmf.agregar_tabla_inventario(TablaInventarioRodal(
        "R1", "Pinus patula", [ClaseDiametrica(20, 15, 10)]))
    pmf.agregar_tabla_inventario(TablaInventarioRodal(
        "R1", "Pinus montezumae", [ClaseDiametrica(30, 20, 5)]))
    pmf.agregar_tabla_inventario(TablaInventarioRodal(
        "R2", "Pinus patula", [ClaseDiametrica(20, 15, 4)]))
    assert pmf.guardar(ruta)
    return pmf


def _clases_guardadas(ruta, rid="R1", esp="Pinus patula"):
    from modelos import PMFProyecto
    tabla = PMFProyecto.cargar(ruta).buscar_tabla_inventario(rid, esp)
    if not tabla:
        return None
    return sorted((c.dncc, c.altura_m, c.no_arboles) for c in tabla.clases)


def _total_existencias(html):
    # Total visible del cuadro (el HTML tambien incrusta un contexto semantico
    # en JSON con otros valores; se ancla a la celda visible).
    coincidencia = re.search(r"Existencias reales</span><strong>([\d,]+\.\d{3})", html)
    assert coincidencia, "no se encontro el total de existencias en el cuadro"
    return float(coincidencia.group(1).replace(",", ""))


class PropagacionInventarioTest(unittest.TestCase):
    def setUp(self):
        self.temporal = tempfile.TemporaryDirectory()
        self.originales = (app_module.DATA_DIR, app_module.PROJECTS_DIR,
                           app_module.PROJECT_STATE_DIR, app_module.LAST_PROJECT_FILE)
        app_module.DATA_DIR = self.temporal.name
        app_module.PROJECTS_DIR = self.temporal.name + "/projects"
        app_module.PROJECT_STATE_DIR = self.temporal.name + "/state"
        app_module.LAST_PROJECT_FILE = app_module.PROJECT_STATE_DIR + "/ultimo_proyecto.json"
        import os
        os.makedirs(app_module.PROJECTS_DIR, exist_ok=True)
        self.ruta = app_module.PROJECTS_DIR + "/propagacion.json"
        _proyecto_propagacion(self.ruta)
        self.cliente = app_module.app.test_client()
        with self.cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["ruta_actual"] = self.ruta

    def tearDown(self):
        (app_module.DATA_DIR, app_module.PROJECTS_DIR,
         app_module.PROJECT_STATE_DIR, app_module.LAST_PROJECT_FILE) = self.originales
        self.temporal.cleanup()

    def _cuerpos(self):
        paginas = [
            "/reportes/cuadro_existencias",
            "/reportes/concentrado",
            "/reportes/resumen_incrementos",
            "/reportes/carbono",
            "/reportes/interpretacion",
            "/reportes/graficas",
            "/inventario/dashboard/rodal/R1",
            "/inventario/rodal/reporte/R1/Pinus%20patula",
        ]
        cuerpos = {}
        for pagina in paginas:
            respuesta = self.cliente.get(pagina)
            self.assertEqual(respuesta.status_code, 200, pagina)
            cuerpos[pagina] = respuesta.get_data(as_text=True)
        cuerpos["api_graficas_R1"] = self.cliente.get("/api/graficas/datos/R1").get_json()
        return cuerpos

    def test_editar_clases_actualiza_todos_los_cuadros(self):
        antes = self._cuerpos()
        total_antes = _total_existencias(antes["/reportes/cuadro_existencias"])

        # El usuario duplica los arboles de R1 / Pinus patula (10 -> 20).
        respuesta = self.cliente.post("/inventario/rodal/guardar_clases/R1/Pinus%20patula",
                                      data={"alt_20": "15", "arb_20": "20"})
        self.assertEqual(respuesta.status_code, 302)

        despues = self._cuerpos()
        total_despues = _total_existencias(despues["/reportes/cuadro_existencias"])

        # El cuadro de existencias refleja el cambio.
        self.assertGreater(total_despues, total_antes)
        # El resto de los cuadros tambien cambiaron (incluyen numeros calculados).
        for pagina in ("/reportes/concentrado", "/reportes/resumen_incrementos",
                       "/reportes/carbono", "/reportes/interpretacion",
                       "/inventario/dashboard/rodal/R1",
                       "/inventario/rodal/reporte/R1/Pinus%20patula"):
            self.assertNotEqual(antes[pagina], despues[pagina], pagina)
        # La API de graficas devuelve los arboles por hectarea actualizados
        # (factor 1: 20 arboles en 1 sitio de 10000 m2).
        arboles = [fila["arb_ha"] for fila in despues["api_graficas_R1"]
                   if fila["dncc"] == 20.0]
        self.assertEqual(arboles, [20.0])

    def test_eliminar_tabla_actualiza_todos_los_cuadros(self):
        antes = self._cuerpos()
        total_antes = _total_existencias(antes["/reportes/cuadro_existencias"])
        self.assertIn("R2", antes["/reportes/cuadro_existencias"])

        # El usuario elimina la unica tabla de R2.
        respuesta = self.cliente.get("/inventario/rodal/eliminar/R2/Pinus%20patula")
        self.assertEqual(respuesta.status_code, 302)

        despues = self._cuerpos()
        total_despues = _total_existencias(despues["/reportes/cuadro_existencias"])
        self.assertLess(total_despues, total_antes)
        # R2 ya no aporta filas de datos al cuadro (el control de orden
        # manual sigue listando el rodal porque el rodal existe; eso no es un dato).
        self.assertNotIn("<strong>R2</strong></td>", despues["/reportes/cuadro_existencias"])
        self.assertNotIn("R2 &mdash; Subtotal", despues["/reportes/cuadro_existencias"])
        for pagina in ("/reportes/concentrado", "/reportes/resumen_incrementos",
                       "/reportes/carbono"):
            self.assertNotEqual(antes[pagina], despues[pagina], pagina)

    def test_modificar_clase_guarda_los_valores_nuevos(self):
        self.assertEqual(_clases_guardadas(self.ruta), [(20, 15.0, 10)])
        respuesta = self.cliente.post("/inventario/rodal/guardar_clases/R1/Pinus%20patula",
                                      data={"alt_20": "16", "arb_20": "12"})
        self.assertEqual(respuesta.status_code, 302)
        self.assertEqual(_clases_guardadas(self.ruta), [(20, 16.0, 12)])

    def test_vaciar_fila_elimina_la_clase(self):
        # Regresion: antes, vaciar Altura y No. Arboles no tenia efecto y los
        # valores anteriores reaparecian al volver a abrir la tabla.
        self.assertEqual(_clases_guardadas(self.ruta), [(20, 15.0, 10)])
        total_antes = _total_existencias(
            self.cliente.get("/reportes/cuadro_existencias").get_data(as_text=True))
        respuesta = self.cliente.post("/inventario/rodal/guardar_clases/R1/Pinus%20patula",
                                      data={"alt_20": "", "arb_20": ""})
        self.assertEqual(respuesta.status_code, 302)
        self.assertEqual(_clases_guardadas(self.ruta), [])
        # Y el cuadro de existencias refleja la eliminacion.
        despues = self.cliente.get("/reportes/cuadro_existencias").get_data(as_text=True)
        self.assertLess(_total_existencias(despues), total_antes)
        filas_patula = re.findall(
            r"Pinus patula</td>\s*<td>([\d.]+)</td>\s*<td>([\d.]+)</td>", despues)
        self.assertIn(("0.000", "0.000"), filas_patula)

    def test_vaciar_fila_inexistente_no_afecta_nada(self):
        respuesta = self.cliente.post("/inventario/rodal/guardar_clases/R1/Pinus%20patula",
                                      data={"alt_20": "15", "arb_20": "10",
                                            "alt_25": "", "arb_25": ""})
        self.assertEqual(respuesta.status_code, 302)
        self.assertEqual(_clases_guardadas(self.ruta), [(20, 15.0, 10)])


if __name__ == "__main__":
    unittest.main()
