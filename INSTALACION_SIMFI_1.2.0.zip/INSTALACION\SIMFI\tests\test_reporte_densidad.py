import base64
import io
import math
import os
import unittest
import zipfile

from guias_densidad import construir_analisis_densidad
from modelos import ClaseDiametrica, PMFProyecto, Rodal, TablaInventarioRodal
from motor_aclareos import construir_evaluacion, registrar_trazabilidad
from reporte_densidad import (decodificar_png, generar_reporte_densidad,
                              generar_reporte_aclareos, nombre_archivo_aclareos,
                              nombre_archivo_reporte)


PNG_PRUEBA = (
    "data:image/png;base64,"
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M/wHwAF/gL+G2V0WQAAAABJRU5ErkJggg=="
)
BASE = os.path.dirname(os.path.dirname(__file__))
LOGO = os.path.join(BASE, "img", "SIMFI GDE.png")


def proyecto_especie(especie, n, dq, mixto=False):
    pmf = PMFProyecto("Proyecto de prueba", predio="Predio de prueba")
    pmf.agregar_rodal(Rodal("RODAL 1", 10, sitios=1, area_sitio_m2=10000))
    pmf.agregar_tabla_inventario(
        TablaInventarioRodal("RODAL 1", especie, [ClaseDiametrica(dq, 18, int(n))]))
    if mixto:
        pmf.agregar_tabla_inventario(
            TablaInventarioRodal("RODAL 1", "Pinus patula", [ClaseDiametrica(10, 10, 10)]))
    return pmf


def xml_docx(salida):
    with zipfile.ZipFile(salida) as paquete:
        return (paquete.read("word/document.xml").decode("utf-8"), paquete.namelist())


class InterpretacionDensidadTest(unittest.TestCase):
    def test_cada_especie_usa_su_interpretacion(self):
        casos = [
            ("Pinus teocote", 620, 25, "líneas A y B"),
            ("Pinus montezumae", 800, 25, "ocupación plena"),
            ("Pinus patula", 831, 20, "crecimiento constante"),
            ("Pinus rudis", 800, 25, "Factor de Competencia de Copas"),
        ]
        for especie, n, dq, texto in casos:
            analisis = construir_analisis_densidad(proyecto_especie(especie, n, dq), "RODAL 1")
            self.assertIsNone(analisis["error"])
            contenido = (analisis["interpretacion"]["texto"] + " " +
                         analisis["interpretacion"]["consideracion"] + " " +
                         str(analisis["modelo"].get("metodologia", {})))
            self.assertIn(texto, contenido)

    def test_comparacion_y_remociones_son_deterministicas(self):
        dq = math.sqrt(40000 * 38.27 / (math.pi * 2045))
        pmf = proyecto_especie("Pinus rudis", 2045, dq)
        analisis = construir_analisis_densidad(
            pmf, "RODAL 1", n_residual=1500, g_residual=30.01, grado_objetivo=75)
        self.assertEqual(len(analisis["escenarios"]), 1)
        self.assertAlmostEqual(analisis["remocion"]["n"], 545)
        self.assertAlmostEqual(analisis["remocion"]["g"], 8.26, places=2)
        self.assertIn("96.1 %", analisis["comparacion"])
        self.assertIn("74.2 %", analisis["comparacion"])


class ReporteWordDensidadTest(unittest.TestCase):
    def _generar(self, analisis, pmf):
        return generar_reporte_densidad(pmf, analisis, decodificar_png(PNG_PRUEBA), LOGO)

    def test_sin_escenario_incluye_datos_grafica_interpretacion_y_fuente(self):
        pmf = proyecto_especie("Pinus patula", 831, 20)
        analisis = construir_analisis_densidad(pmf, "RODAL 1")
        salida = self._generar(analisis, pmf)
        xml, archivos = xml_docx(salida)
        self.assertIn("Datos dasométricos", xml)
        self.assertIn("Gráfica de densidad", xml)
        self.assertIn("Interpretación de la condición actual", xml)
        self.assertIn("Santiago-García", xml)
        self.assertIn("Sistema para el Manejo Forestal Mejorado por Dr.PIFL", xml)
        self.assertNotIn("Evaluación de escenarios", xml)
        self.assertEqual(len([a for a in archivos if a.startswith("word/media/")]), 2)
        self.assertIn("w:i", xml)

    def test_reporte_aclareos_incluye_metodos_comparacion_y_trazabilidad(self):
        pmf = proyecto_especie("Pinus patula", 831, 20)
        pmf.tiempo_paso["Pinus patula"] = {20: 6}
        evaluacion = construir_evaluacion(pmf, "RODAL 1", "Pinus patula", 10)
        registrar_trazabilidad(evaluacion, "prueba")
        salida = generar_reporte_aclareos(
            pmf, evaluacion, decodificar_png(PNG_PRUEBA), LOGO)
        xml, archivos = xml_docx(salida)
        self.assertIn("MMOBI", xml)
        self.assertIn("Veiga", xml)
        self.assertIn("diámetro deseado", xml)
        self.assertIn("Comparación de escenarios", xml)
        self.assertIn("Tasa volumétrica anual", xml)
        self.assertIn("modelo", xml)
        self.assertEqual(len([a for a in archivos if a.startswith("word/media/")]), 2)
        self.assertTrue(nombre_archivo_aclareos("Pinus patula", "RODAL 1").startswith("SIMFI_Escenarios_Aclareo_"))

    def test_con_escenario_incluye_residual_diferencias_y_clasificaciones(self):
        dq = math.sqrt(40000 * 38.27 / (math.pi * 2045))
        pmf = proyecto_especie("Pinus rudis", 2045, dq)
        analisis = construir_analisis_densidad(
            pmf, "RODAL 1", n_residual=1500, g_residual=30.01, grado_objetivo=75)
        xml, _ = xml_docx(self._generar(analisis, pmf))
        self.assertIn("Evaluación de escenarios", xml)
        self.assertIn("545", xml)
        self.assertIn("8.26", xml)
        self.assertIn("Suficiente", xml)
        self.assertIn("10.29298/rmcf.v12i64.822", xml)

    def test_masa_mezclada_conserva_advertencia(self):
        pmf = proyecto_especie("Pinus rudis", 800, 25, mixto=True)
        analisis = construir_analisis_densidad(pmf, "RODAL 1")
        self.assertTrue(analisis["datos_rodal"]["es_mixto"])
        xml, _ = xml_docx(self._generar(analisis, pmf))
        self.assertIn("Nota de aplicación", xml)
        self.assertIn("composición diferente", xml)

    def test_word_conserva_interpretacion_y_fuente_de_cada_modelo(self):
        casos = [
            ("Pinus teocote", 620, 25, "Densidad completa", "Hernández Ramos"),
            ("Pinus montezumae", 800, 25, "Densidad suficiente", "Rodríguez Laguna"),
            ("Pinus patula", 831, 20, "Zona de crecimiento constante", "Santiago-García"),
            ("Pinus rudis", 800, 25, "Densidad suficiente", "Martínez Santiago"),
        ]
        for especie, n, dq, interpretacion, fuente in casos:
            pmf = proyecto_especie(especie, n, dq)
            analisis = construir_analisis_densidad(pmf, "RODAL 1")
            xml, _ = xml_docx(self._generar(analisis, pmf))
            self.assertIn(interpretacion, xml)
            self.assertIn(fuente, xml)

    def test_nombre_de_archivo_se_sanitiza(self):
        nombre = nombre_archivo_reporte("Pinus rüdis", "Rodal: 12/Este", "2026-08-16")
        self.assertEqual(nombre, "SIMFI_Guia_Densidad_Pinus_rudis_Rodal_12_Este_2026-08-16.docx")


if __name__ == "__main__":
    unittest.main()
