import unittest

from app import _calc_captura, _calc_oxigeno, app
from modelos import (ArbolCenso, EcuacionVolumen, IntervencionCorta,
                     PMFProyecto, Rodal)


class CensoTotalTest(unittest.TestCase):
    def setUp(self):
        self.pmf = PMFProyecto("Censo")
        self.pmf.agregar_rodal(Rodal("R1", 0.65))
        self.pmf.agregar_especie("Pinus patula")
        self.pmf.asignar_ecuacion("Pinus patula", EcuacionVolumen(
            a0=0.001, a1=2, a2=1, especie="Pinus patula"))

    def test_calcula_volumen_directo_y_existencias_por_hectarea(self):
        self.pmf.agregar_arbol_censo(ArbolCenso("R1", "Pinus patula", 20, 10, no_arboles=3))
        self.pmf.agregar_arbol_censo(ArbolCenso("R1", "Pinus patula", 30, 12))

        resumen = self.pmf.resumen_censo_total("R1")
        esperado = self.pmf.volumen_arbol("Pinus patula", 20, 10) * 3 + self.pmf.volumen_arbol("Pinus patula", 30, 12)
        self.assertEqual(resumen["arboles"], 4)
        self.assertAlmostEqual(resumen["volumen_m3"], esperado)
        self.assertAlmostEqual(resumen["volumen_ha"], esperado / 0.65)
        self.assertAlmostEqual(resumen["filas"][0]["volumen_ha"], esperado / 0.65)

    def test_serializa_y_recupera_arboles_censados(self):
        self.pmf.agregar_arbol_censo(ArbolCenso("R1", "Pinus patula", 20, 10))

        recuperado = PMFProyecto.desde_dict(self.pmf.serializar())

        self.assertEqual(len(recuperado.censos_totales), 1)
        self.assertEqual(recuperado.censos_totales[0].rodal_id, "R1")
        self.assertAlmostEqual(recuperado.censos_totales[0].dap_cm, 20)

    def test_rechaza_arbol_sin_dap_o_altura(self):
        with self.assertRaises(ValueError):
            self.pmf.agregar_arbol_censo(ArbolCenso("R1", "Pinus patula", 0, 10))

    def test_rodal_censo_total_conserva_modalidad_sin_sitios(self):
        rodal = Rodal("CENSO", 0.65, sitios=0, area_sitio_m2=0, tipo_inventario="censo_total")
        self.pmf.agregar_rodal(rodal)

        recuperado = PMFProyecto.desde_dict(self.pmf.serializar()).buscar_rodal("CENSO")

        self.assertEqual(recuperado.tipo_inventario, "censo_total")
        self.assertEqual(recuperado.sitios, 0)
        self.assertEqual(recuperado.area_sitio_m2, 0)

    def test_cuadricula_guarda_arboles_por_diametro_y_altura(self):
        self.pmf.agregar_rodal(Rodal("CENSO", 0.65, sitios=0, area_sitio_m2=0,
                                     tipo_inventario="censo_total"))
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba_censo"
            sesion["pmf_data"] = self.pmf.serializar()

        pagina = cliente.get("/inventario/censo-total?rid=CENSO&esp=Pinus%20patula")
        respuesta = cliente.post("/inventario/censo-total/guardar/CENSO/Pinus%20patula", data={
            "censo_40__20": "3", "censo_40__25": "5", "censo_40__30": "2"})

        self.assertEqual(pagina.status_code, 200)
        self.assertIn('name="censo_40__20"', pagina.get_data(as_text=True))
        self.assertIn('name="censo_40__25"', pagina.get_data(as_text=True))
        self.assertIn('name="censo_40__30"', pagina.get_data(as_text=True))
        self.assertEqual(respuesta.status_code, 302)
        with cliente.session_transaction() as sesion:
            recuperado = PMFProyecto.cargar(sesion["ruta_actual"])
        registros = recuperado.arboles_censo("CENSO", "Pinus patula")
        self.assertEqual([(arbol.dap_cm, arbol.altura_m, arbol.no_arboles) for arbol in registros],
                         [(40.0, 20.0, 3), (40.0, 25.0, 5), (40.0, 30.0, 2)])

    def test_plan_cortas_calcula_posibilidad_para_censo_total(self):
        self.pmf.agregar_rodal(Rodal("CENSO", 0.5, sitios=0, area_sitio_m2=0,
                                     tipo_inventario="censo_total"))
        self.pmf.agregar_arbol_censo(ArbolCenso("CENSO", "Pinus patula", 40, 20, no_arboles=3))
        self.pmf.intensidad_corta["CENSO"] = {"Pinus patula": 30}
        intervencion = IntervencionCorta("censo-1", 1, "CENSO", 0.5,
                                         "Corta de Selección", superficie_completa=True)

        datos = self.pmf.datos_intervencion_corta(intervencion)

        self.assertEqual(datos["especies"], ["Pinus patula"])
        self.assertEqual(len(datos["filas"]), 1)
        self.assertEqual(datos["filas"][0]["especie"], "Pinus patula")
        self.assertGreater(datos["filas"][0]["posibilidad"], 0)

    def test_plan_cortas_muestra_y_agrega_rodal_censo_total(self):
        self.pmf.agregar_rodal(Rodal("CENSO", 0.5, sitios=0, area_sitio_m2=0,
                                     tipo_inventario="censo_total"))
        self.pmf.agregar_arbol_censo(ArbolCenso("CENSO", "Pinus patula", 40, 20, no_arboles=3))
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba_censo"
            sesion["pmf_data"] = self.pmf.serializar()

        pagina_plan = cliente.get("/cortas")
        pagina_intensidades = cliente.get("/cortas/intensidades")
        respuesta = cliente.post("/cortas/intervenciones/agregar", data={
            "anualidad": "1", "tratamiento": "Corta de Selección",
            "modo_intervencion": "nueva", "rodal_id": "CENSO",
            "tipo_superficie": "completa", "superficie_ha": "0.5",
        })

        self.assertEqual(pagina_plan.status_code, 200)
        self.assertIn('value="CENSO"', pagina_plan.get_data(as_text=True))
        self.assertIn('name="int_CENSO_Pinus patula"', pagina_intensidades.get_data(as_text=True))
        self.assertEqual(respuesta.status_code, 302)
        with cliente.session_transaction() as sesion:
            recuperado = PMFProyecto.cargar(sesion["ruta_actual"])
        self.assertEqual(len(recuperado.plan_cortas.intervenciones), 1)
        self.assertEqual(recuperado.plan_cortas.intervenciones[0].rodal_id, "CENSO")

    def test_carbono_captura_y_oxigeno_incluyen_censo_total(self):
        self.pmf.agregar_rodal(Rodal("CENSO", 0.5, sitios=0, area_sitio_m2=0,
                                     tipo_inventario="censo_total"))
        self.pmf.agregar_arbol_censo(ArbolCenso("CENSO", "Pinus patula", 40, 20, no_arboles=4))
        self.pmf.tp_ecuaciones["Pinus patula"] = {"a": 9.4322, "b": -0.9294, "c": 0.02695}

        carbono = self.pmf.reporte_carbono()
        captura = _calc_captura(self.pmf)
        oxigeno = _calc_oxigeno(self.pmf)

        self.assertGreater(carbono["total_carbono"], 0)
        self.assertGreater(captura["total_captura_c"], 0)
        self.assertGreater(captura["total_captura_co2"], 0)
        self.assertGreater(oxigeno["total_oxigeno"], 0)
        self.assertAlmostEqual(oxigeno["total_oxigeno"],
                               oxigeno["total_captura_c"] * 2.67)

    def test_editar_inventario_abre_cuadricula_para_rodal_censado(self):
        self.pmf.agregar_rodal(Rodal("CENSO", 0.65, sitios=0, area_sitio_m2=0,
                                     tipo_inventario="censo_total"))
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba_censo"
            sesion["pmf_data"] = self.pmf.serializar()

        respuesta = cliente.get("/inventario/rodal/editar/CENSO/Pinus%20patula")

        self.assertEqual(respuesta.status_code, 302)
        self.assertIn("/inventario/censo-total?rid=CENSO&esp=Pinus+patula", respuesta.location)

    def test_importa_datos_multiespecie_con_cd_repetido(self):
        self.pmf.agregar_rodal(Rodal("CENSO", 0.65, sitios=0, area_sitio_m2=0,
                                     tipo_inventario="censo_total"))
        self.pmf.agregar_especie("Quercus rugosa")
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba_censo"
            sesion["pmf_data"] = self.pmf.serializar()
        texto = (
            "CD\tPinus patula (ARB)\tPinus patula (ALT)\tQuercus rugosa (ARB)\tQuercus rugosa (ALT)\n"
            "40\t3\t20\t1\t15\n40\t5\t25\t0\t\n40\t2\t30\t0\t")

        previa = cliente.post("/inventario/censo-total/importar-datos/CENSO", json={
            "texto": texto, "confirmar": False})
        respuesta = cliente.post("/inventario/censo-total/importar-datos/CENSO", json={
            "texto": texto, "confirmar": True})

        self.assertEqual(previa.status_code, 200)
        self.assertTrue(previa.get_json()["vista_previa"])
        self.assertEqual(respuesta.status_code, 200)
        with cliente.session_transaction() as sesion:
            recuperado = PMFProyecto.cargar(sesion["ruta_actual"])
        pinos = recuperado.arboles_censo("CENSO", "Pinus patula")
        quercus = recuperado.arboles_censo("CENSO", "Quercus rugosa")
        self.assertEqual([(arbol.dap_cm, arbol.altura_m, arbol.no_arboles) for arbol in pinos],
                         [(40.0, 20.0, 3), (40.0, 25.0, 5), (40.0, 30.0, 2)])
        self.assertEqual([(arbol.dap_cm, arbol.altura_m, arbol.no_arboles) for arbol in quercus],
                         [(40.0, 15.0, 1)])


class OrdenRegistroPlanCortasTest(unittest.TestCase):
    def _pmf_orden(self):
        from modelos import ClaseDiametrica, TablaInventarioRodal
        pmf = PMFProyecto("Orden")
        for rid in ("R1", "R2"):
            pmf.agregar_rodal(Rodal(rid, 10, sitios=1, area_sitio_m2=10000))
            pmf.agregar_tabla_inventario(TablaInventarioRodal(
                rid, "Pinus patula", [ClaseDiametrica(20, 15, 10)]))
            pmf.intensidad_corta[rid] = {"Pinus patula": 10}
        return pmf

    def _ids_en_tabla8(self, pmf):
        from app import _contexto_plan_cortas
        return [dato["intervencion"].id
                for dato in _contexto_plan_cortas(pmf)["datos_intervenciones"]]

    def test_tabla_8_agrupa_por_area_de_corta(self):
        pmf = self._pmf_orden()
        pmf.plan_cortas.intervenciones.append(IntervencionCorta(
            "area-dos", 2, "R2", 10.0, "Aclareo", superficie_completa=True))
        pmf.plan_cortas.intervenciones.append(IntervencionCorta(
            "area-uno", 1, "R1", 10.0, "Aclareo", superficie_completa=True))
        self.assertEqual(self._ids_en_tabla8(pmf), ["area-uno", "area-dos"])

    def test_tabla_8_respeta_orden_de_registro_dentro_del_area(self):
        pmf = self._pmf_orden()
        pmf.plan_cortas.intervenciones.append(IntervencionCorta(
            "primera", 1, "R1", 10.0, "Aclareo", superficie_completa=True))
        pmf.plan_cortas.intervenciones.append(IntervencionCorta(
            "segunda", 1, "R2", 10.0, "Aclareo", superficie_completa=True))
        self.assertEqual(self._ids_en_tabla8(pmf), ["primera", "segunda"])

    def test_subir_y_bajar_reordenan_dentro_del_area(self):
        import os
        import tempfile
        import app as app_module
        temporal = tempfile.TemporaryDirectory()
        originales = (app_module.DATA_DIR, app_module.PROJECTS_DIR,
                      app_module.PROJECT_STATE_DIR, app_module.LAST_PROJECT_FILE)
        try:
            app_module.DATA_DIR = temporal.name
            app_module.PROJECTS_DIR = os.path.join(temporal.name, "projects")
            app_module.PROJECT_STATE_DIR = os.path.join(temporal.name, "state")
            app_module.LAST_PROJECT_FILE = os.path.join(
                app_module.PROJECT_STATE_DIR, "ultimo_proyecto.json")
            os.makedirs(app_module.PROJECTS_DIR, exist_ok=True)
            pmf = self._pmf_orden()
            pmf.plan_cortas.intervenciones.append(IntervencionCorta(
                "primera", 1, "R1", 10.0, "Aclareo", superficie_completa=True))
            pmf.plan_cortas.intervenciones.append(IntervencionCorta(
                "segunda", 1, "R2", 10.0, "Aclareo", superficie_completa=True))
            ruta = os.path.join(app_module.PROJECTS_DIR, "orden.json")
            self.assertTrue(pmf.guardar(ruta))
            cliente = app_module.app.test_client()
            with cliente.session_transaction() as sesion:
                sesion["usuario"] = "prueba"
                sesion["ruta_actual"] = ruta
            respuesta = cliente.post("/cortas/intervenciones/primera/bajar")
            self.assertEqual(respuesta.status_code, 302)
            self.assertEqual(self._ids_en_tabla8(PMFProyecto.cargar(ruta)),
                             ["segunda", "primera"])
            respuesta = cliente.post("/cortas/intervenciones/primera/subir")
            self.assertEqual(respuesta.status_code, 302)
            self.assertEqual(self._ids_en_tabla8(PMFProyecto.cargar(ruta)),
                             ["primera", "segunda"])
            html = cliente.get("/cortas").get_data(as_text=True)
            self.assertIn("Ordenar manualmente", html)
            self.assertIn("/cortas/orden-manual/activar", html)
        finally:
            (app_module.DATA_DIR, app_module.PROJECTS_DIR,
             app_module.PROJECT_STATE_DIR,
             app_module.LAST_PROJECT_FILE) = originales
            temporal.cleanup()

    def test_tabla_9_se_actualiza_al_cambiar_de_area(self):
        from app import _contexto_plan_cortas
        pmf = self._pmf_orden()
        pmf.plan_cortas.intervenciones.append(IntervencionCorta(
            "movil", 1, "R1", 10.0, "Aclareo", superficie_completa=True))
        antes = _contexto_plan_cortas(pmf)["resumen_plan"]
        self.assertEqual([grupo["numero"] for grupo in antes], [1])
        pmf.plan_cortas.intervenciones[0].anualidad = 2
        despues = _contexto_plan_cortas(pmf)["resumen_plan"]
        self.assertEqual([grupo["numero"] for grupo in despues], [2])
        self.assertEqual(self._ids_en_tabla8(pmf), ["movil"])


class OrdenManualCortasTest(unittest.TestCase):
    def setUp(self):
        import os
        import tempfile
        import app as app_module
        from modelos import ClaseDiametrica, TablaInventarioRodal
        self.app_module = app_module
        self.temporal = tempfile.TemporaryDirectory()
        self.originales = (app_module.DATA_DIR, app_module.PROJECTS_DIR,
                           app_module.PROJECT_STATE_DIR, app_module.LAST_PROJECT_FILE)
        app_module.DATA_DIR = self.temporal.name
        app_module.PROJECTS_DIR = os.path.join(self.temporal.name, "projects")
        app_module.PROJECT_STATE_DIR = os.path.join(self.temporal.name, "state")
        app_module.LAST_PROJECT_FILE = os.path.join(
            app_module.PROJECT_STATE_DIR, "ultimo_proyecto.json")
        os.makedirs(app_module.PROJECTS_DIR, exist_ok=True)
        pmf = PMFProyecto("Manual")
        for rid in ("R1", "R2"):
            pmf.agregar_rodal(Rodal(rid, 10, sitios=1, area_sitio_m2=10000))
            pmf.agregar_tabla_inventario(TablaInventarioRodal(
                rid, "Pinus patula", [ClaseDiametrica(20, 15, 10)]))
            pmf.intensidad_corta[rid] = {"Pinus patula": 10}
        self.ruta = os.path.join(app_module.PROJECTS_DIR, "manual.json")
        self.assertTrue(pmf.guardar(self.ruta))
        self.cliente = app_module.app.test_client()
        with self.cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["ruta_actual"] = self.ruta

    def tearDown(self):
        (self.app_module.DATA_DIR, self.app_module.PROJECTS_DIR,
         self.app_module.PROJECT_STATE_DIR,
         self.app_module.LAST_PROJECT_FILE) = self.originales
        self.temporal.cleanup()

    def _agregar(self, anualidad, rodal, extra=None, parcial=None):
        datos = {"anualidad": str(anualidad), "modo_intervencion": "nueva",
                 "rodal_id": rodal, "tipo_superficie": "completa",
                 "tratamiento": "Corta de Selección"}
        if parcial is not None:
            datos["tipo_superficie"] = "parcial"
            datos["superficie_ha"] = str(parcial)
        if extra:
            datos.update(extra)
        return self.cliente.post("/cortas/intervenciones/agregar", data=datos)

    def _intervenciones(self):
        return PMFProyecto.cargar(self.ruta).plan_cortas.intervenciones

    def test_anualidad_se_queda_en_ultima_registrada(self):
        self.assertEqual(self._agregar(2, "R1").status_code, 302)
        html = self.cliente.get("/cortas").get_data(as_text=True)
        self.assertIn('value="2" selected', html)

    def test_modo_manual_persiste_hasta_aceptar(self):
        self._agregar(1, "R1")
        self._agregar(1, "R2")
        self.assertEqual(self.cliente.post("/cortas/orden-manual/activar").status_code, 302)
        html = self.cliente.get("/cortas").get_data(as_text=True)
        self.assertIn("Aceptar orden", html)
        self.assertIn("orden-manual", html)
        primera = self._intervenciones()[0].id
        self.assertEqual(
            self.cliente.post(f"/cortas/intervenciones/{primera}/bajar").status_code, 302)
        html = self.cliente.get("/cortas").get_data(as_text=True)
        self.assertIn("Aceptar orden", html)
        self.assertEqual(self.cliente.post("/cortas/orden-manual/terminar").status_code, 302)
        html = self.cliente.get("/cortas").get_data(as_text=True)
        self.assertNotIn("Aceptar orden", html)
        self.assertIn("Ordenar manualmente", html)

    def test_aviso_umm_duplicada_y_destacado(self):
        self.assertEqual(self._agregar(1, "R1", parcial=5).status_code, 302)
        self.assertEqual(len(self._intervenciones()), 1)
        respuesta = self._agregar(1, "R1", parcial=5)
        self.assertEqual(respuesta.status_code, 302)
        self.assertEqual(len(self._intervenciones()), 1)
        with self.cliente.session_transaction() as sesion:
            avisos = [mensaje for _, mensaje in sesion.get("_flashes", [])]
        self.assertTrue(any("ya tiene 1" in mensaje for mensaje in avisos))
        html = self.cliente.get("/cortas").get_data(as_text=True)
        self.assertIn("font-weight:bold;color:#B26A00", html)
        respuesta = self._agregar(1, "R1", parcial=5,
                                  extra={"confirmar_duplicada": "1"})
        self.assertEqual(respuesta.status_code, 302)
        self.assertEqual(len(self._intervenciones()), 2)

    def test_guardar_orden_arrastre(self):
        self._agregar(1, "R1")
        self._agregar(1, "R2")
        ids = [i.id for i in self._intervenciones()]
        respuesta = self.cliente.post("/cortas/orden-manual/guardar", json={
            "anualidad": 1, "orden": [ids[1], ids[0]]})
        self.assertEqual(respuesta.status_code, 200)
        self.assertTrue(respuesta.get_json()["ok"])
        recargado = PMFProyecto.cargar(self.ruta)
        self.assertEqual([i.orden for i in recargado.plan_cortas.intervenciones
                          if i.id in ids], [1, 0])
        respuesta = self.cliente.post("/cortas/orden-manual/guardar", json={
            "anualidad": 1, "orden": [ids[0]]})
        self.assertEqual(respuesta.status_code, 400)


class AreaAnioMilesCortasTest(unittest.TestCase):
    def setUp(self):
        import os
        import tempfile
        import app as app_module
        from modelos import ClaseDiametrica, TablaInventarioRodal
        self.app_module = app_module
        self.temporal = tempfile.TemporaryDirectory()
        self.originales = (app_module.DATA_DIR, app_module.PROJECTS_DIR,
                           app_module.PROJECT_STATE_DIR, app_module.LAST_PROJECT_FILE)
        app_module.DATA_DIR = self.temporal.name
        app_module.PROJECTS_DIR = os.path.join(self.temporal.name, "projects")
        app_module.PROJECT_STATE_DIR = os.path.join(self.temporal.name, "state")
        app_module.LAST_PROJECT_FILE = os.path.join(
            app_module.PROJECT_STATE_DIR, "ultimo_proyecto.json")
        os.makedirs(app_module.PROJECTS_DIR, exist_ok=True)
        pmf = PMFProyecto("Miles")
        pmf.agregar_rodal(Rodal("R1", 1500, sitios=1, area_sitio_m2=10000))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Pinus patula", [ClaseDiametrica(20, 15, 10)]))
        pmf.intensidad_corta["R1"] = {"Pinus patula": 10}
        pmf.plan_cortas.anualidades[0].anio = 2027
        pmf.plan_cortas.intervenciones.append(IntervencionCorta(
            "area-uno", 1, "R1", 1500.0, "Aclareo", superficie_completa=True))
        self.ruta = os.path.join(app_module.PROJECTS_DIR, "miles.json")
        self.assertTrue(pmf.guardar(self.ruta))
        self.cliente = app_module.app.test_client()
        with self.cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["ruta_actual"] = self.ruta

    def tearDown(self):
        (self.app_module.DATA_DIR, self.app_module.PROJECTS_DIR,
         self.app_module.PROJECT_STATE_DIR,
         self.app_module.LAST_PROJECT_FILE) = self.originales
        self.temporal.cleanup()

    def test_filtro_miles(self):
        from app import formato_miles
        self.assertEqual(formato_miles(2314.254), "2,314.254")
        self.assertEqual(formato_miles(10, 2), "10.00")
        self.assertEqual(formato_miles(-5.2, 1, True), "-5.2")
        self.assertEqual(formato_miles(5.2, 1, True), "+5.2")
        self.assertEqual(formato_miles(None), "")
        self.assertEqual(formato_miles(""), "")

    def test_tabla_9_muestra_area_con_anio(self):
        from openpyxl import load_workbook
        from io import BytesIO
        html = self.cliente.get("/cortas").get_data(as_text=True)
        self.assertIn("1-2027", html)
        self.assertIn("Subtotal<sup>a</sup> Área de Corta 1-2027", html)
        respuesta = self.cliente.get("/cortas/resumen/exportar/excel")
        self.assertEqual(respuesta.status_code, 200)
        libro = load_workbook(BytesIO(respuesta.data))
        hoja = libro["Resumen Plan de Cortas"]
        self.assertEqual(hoja["A4"].value, "1-2027")
        self.assertIn("1-2027", hoja["A5"].value)
        self.assertEqual(hoja["C4"].number_format, "#,##0.000")

    def test_miles_en_tabla_8_pantalla_y_excel(self):
        from openpyxl import load_workbook
        from io import BytesIO
        html = self.cliente.get("/cortas").get_data(as_text=True)
        self.assertIn("1,500.000", html)
        respuesta = self.cliente.get("/cortas/exportar/excel")
        self.assertEqual(respuesta.status_code, 200)
        libro = load_workbook(BytesIO(respuesta.data))
        hoja = libro.active
        formatos = {celda.number_format for fila in hoja.iter_rows(min_row=4)
                    for celda in fila if isinstance(celda.value, (int, float))}
        self.assertIn("#,##0.000", formatos)
        self.assertNotIn("0.000", formatos)

    def _dos_intervenciones_misma_area(self):
        from modelos import ClaseDiametrica, TablaInventarioRodal, IntervencionCorta
        pmf = PMFProyecto.cargar(self.ruta)
        pmf.agregar_rodal(Rodal("R2", 10, sitios=1, area_sitio_m2=10000))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R2", "Pinus montezumae", [ClaseDiametrica(20, 15, 10)]))
        pmf.intensidad_corta["R2"] = {"Pinus montezumae": 10}
        pmf.plan_cortas.intervenciones.append(IntervencionCorta(
            "area-uno-b", 1, "R2", 10.0, "Aclareo", superficie_completa=True))
        self.assertTrue(pmf.guardar(self.ruta))

    def test_excel_tabla_8_fusiona_area(self):
        from openpyxl import load_workbook
        from io import BytesIO
        self._dos_intervenciones_misma_area()
        respuesta = self.cliente.get("/cortas/exportar/excel")
        self.assertEqual(respuesta.status_code, 200)
        libro = load_workbook(BytesIO(respuesta.data))
        rangos = {str(rango) for rango in libro.active.merged_cells.ranges}
        self.assertIn("A4:A5", rangos)

    def test_word_fusiona_area_en_ambas_tablas(self):
        import zipfile
        from io import BytesIO
        from lxml import etree
        self._dos_intervenciones_misma_area()
        respuesta = self.cliente.get("/cortas/exportar/word")
        self.assertEqual(respuesta.status_code, 200)
        with zipfile.ZipFile(BytesIO(respuesta.data)) as comprimido:
            xml = comprimido.read("word/document.xml")
        raiz = etree.fromstring(xml)
        ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
        tablas = [t for t in raiz.xpath("//w:tbl", namespaces=ns)
                  if any("Subtotal Anualidad" in (c.xpath("string(.)") or "")
                         or "Subtotal a Área de Corta" in (c.xpath("string(.)") or "")
                         for r in t.xpath("./w:tr", namespaces=ns)
                         for c in r.xpath("./w:tc", namespaces=ns))]
        self.assertEqual(len(tablas), 2)

        def fusiones_columna_cero(tabla):
            valores = []
            for fila in tabla.xpath("./w:tr", namespaces=ns)[2:]:
                celdas = fila.xpath("./w:tc", namespaces=ns)
                if not celdas:
                    continue
                nodo = celdas[0].xpath("./w:tcPr/w:vMerge", namespaces=ns)
                valores.append(nodo[0].get(
                    "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val")
                    if nodo else None)
            return valores

        for tabla in tablas:
            vals = fusiones_columna_cero(tabla)
            self.assertEqual(vals[0], "restart")
            self.assertEqual(vals[1], "continue")

    def test_word_resumen_usa_area_con_anio(self):
        from reportes_tecnicos import _filas_resumen_plan_cortas
        filas = _filas_resumen_plan_cortas(
            [{"numero": 1, "anio": 2027, "filas": [{"especie": "Pino", "posibilidad": 1.0,
                                                   "infraestructura": 0.0, "total": 1.0}],
              "subtotal": {"posibilidad": 1.0, "infraestructura": 0.0, "total": 1.0}}],
            {"posibilidad": 1.0, "infraestructura": 0.0, "total": 1.0})
        self.assertEqual(filas[0][0], "1-2027")
        self.assertIn("1-2027", filas[1]["valores_fisicos"][0])
        filas = _filas_resumen_plan_cortas(
            [{"numero": 2, "filas": [], "subtotal": {"posibilidad": 0.0,
                                                   "infraestructura": 0.0, "total": 0.0}}],
            {"posibilidad": 0.0, "infraestructura": 0.0, "total": 0.0})
        self.assertIn("2", filas[0]["valores_fisicos"][0])
        self.assertNotIn("-", filas[0]["valores_fisicos"][0])


if __name__ == "__main__":
    unittest.main()
