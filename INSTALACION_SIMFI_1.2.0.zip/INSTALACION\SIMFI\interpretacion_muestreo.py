"""Reglas reproducibles de interpretación para el error de muestreo."""

VERSION_PLANTILLA = "2.0"


def _es_numero(valor):
    return isinstance(valor, (int, float)) and not isinstance(valor, bool)


def _motor_anterior_a_3(version_motor):
    """True si el registro fue calculado con un motor anterior a la versión 3.0
    (por ejemplo, sin diagnóstico disponible)."""
    try:
        partes = [int(p) for p in str(version_motor).split(".")[:2]]
    except (TypeError, ValueError):
        return True
    while len(partes) < 2:
        partes.append(0)
    return tuple(partes[:2]) < (3, 0)


def _formato(valor, plantilla):
    if not _es_numero(valor):
        return "No calculable"
    try:
        return plantilla.format(float(valor))
    except (TypeError, ValueError):
        return "No calculable"


def _error_final(fuente):
    """Valor reportado como error de muestreo: siempre error_relativo_pct.

    Se ignora cualquier error_relativo_final_pct almacenado: en registros
    calculados con el motor anterior a la versión 3.0 ese campo contiene el
    valor dividido entre 10. Mostrar el estadístico es una operación de
    lectura; no reescribe el registro guardado.
    """
    fuente = fuente or {}
    base = fuente.get("error_relativo_pct")
    return base if _es_numero(base) else None


def clasificar_cv(cv):
    if cv is None:
        return "No calculable"
    if cv < 15:
        return "baja"
    if cv < 30:
        return "moderada"
    if cv < 50:
        return "alta"
    return "muy alta"


def interpretar_muestreo(resultado, correcciones=None):
    resultado = resultado or {}
    reglas, parrafos, limitaciones = [], [], list(dict.fromkeys(resultado.get("limitaciones", []) or []))
    general = resultado.get("resultado_general") or {}
    diagnostico = resultado.get("diagnostico_conjunto", {}) or {}
    comprobacion = resultado.get("comprobacion", {}) or {}
    config = resultado.get("configuracion") or {}
    objetivo = config.get("error_objetivo_pct")
    confianza = config.get("nivel_confianza")
    confianza_txt = f"{confianza} %" if _es_numero(confianza) else "nivel de confianza no definido"
    if general.get("estado") in {"Cumple", "No cumple"}:
        media = general.get("media_m3_ha")
        error_estadistico = general.get("error_relativo_pct")
        error = _error_final(general)
        estado = "cumple" if general.get("estado") == "Cumple" else "no cumple"
        if not _es_numero(media) or not _es_numero(error):
            parrafos.append("El resultado general está marcado como evaluable, pero faltan la media o el error relativo almacenados; por trazabilidad no se interpreta como definitivo hasta recalcular.")
            reglas.append({"codigo_interpretacion": "GENERAL_SIN_INTERVALO", "regla": "resultado evaluable sin media o error almacenados", "valores_utilizados": {}, "version_plantilla": VERSION_PLANTILLA})
        elif _es_numero(objetivo):
            parrafos.append(f"La media estratificada del volumen total fue de {media:.2f} m3/ha. Con {confianza_txt} de confianza, el error de muestreo fue de {error:.2f} %, por lo que {estado} el objetivo de {objetivo:.2f} %.")
            parrafos.append(f"El intervalo de confianza de la media se ubicó entre {_formato(general.get('li_m3_ha'), '{:.2f}')} y {_formato(general.get('ls_m3_ha'), '{:.2f}')} m3/ha; bajo los supuestos del diseño, se espera que la media poblacional se encuentre en ese intervalo con el nivel de confianza seleccionado.")
            reglas.append({"codigo_interpretacion": "GENERAL_" + str(general.get("estado")).upper(), "regla": "error relativo frente a objetivo", "valores_utilizados": {"error_estadistico": error_estadistico, "error_final": error, "objetivo": objetivo}, "version_plantilla": VERSION_PLANTILLA})
        else:
            parrafos.append(f"La media estratificada del volumen total fue de {media:.2f} m3/ha. Con {confianza_txt} de confianza, el error de muestreo fue de {error:.2f} %; no hay objetivo definido, por lo que no se clasifica como cumple o no cumple.")
            parrafos.append(f"El intervalo de confianza de la media se ubicó entre {_formato(general.get('li_m3_ha'), '{:.2f}')} y {_formato(general.get('ls_m3_ha'), '{:.2f}')} m3/ha; bajo los supuestos del diseño, se espera que la media poblacional se encuentre en ese intervalo con el nivel de confianza seleccionado.")
            reglas.append({"codigo_interpretacion": "GENERAL_" + str(general.get("estado")).upper(), "regla": "error relativo sin objetivo definido", "valores_utilizados": {"error_estadistico": error_estadistico, "error_final": error, "objetivo": None}, "version_plantilla": VERSION_PLANTILLA})
    else:
        parrafos.append("El resultado general es provisional y no evaluable. Uno o más estratos carecen de información suficiente para estimar su varianza, por lo que no debe interpretarse como una estimación definitiva del predio.")
        reglas.append({"codigo_interpretacion": "GENERAL_NO_EVALUABLE", "regla": "estrato sin muestra o varianza no estimable", "valores_utilizados": {}, "version_plantilla": VERSION_PLANTILLA})
    if diagnostico.get("n", 0) >= 2:
        clase_conjunto = clasificar_cv(diagnostico.get("cv_pct"))
        parrafos.insert(0, f"Como diagnóstico descriptivo bajo aproximación de muestra simple, los {diagnostico['n']} sitios presentaron media de {diagnostico['media_m3_ha']:.2f} m3/ha, desviación estándar de {diagnostico['desviacion_estandar']:.2f} m3/ha, CV de {diagnostico['cv_pct']:.2f} % ({clase_conjunto}), y rango de {diagnostico['minimo_m3_ha']:.2f} a {diagnostico['maximo_m3_ha']:.2f} m3/ha. Este diagnóstico no sustituye el estimador estratificado.")

    rodales = [r for r in (resultado.get("rodales", []) or []) if isinstance(r, dict)]
    evaluables = [r for r in rodales if (r.get("estadistica") or {}).get("estado") == "Evaluable"]
    no_evaluables = [r for r in rodales if r not in evaluables]
    for rodal in evaluables:
        e = rodal.get("estadistica") or {}
        clase = clasificar_cv(e.get("cv_pct"))
        error_final = _error_final(e)
        parrafos.append(f"El rodal {rodal.get('clave', 'sin clave')} presentó media de {_formato(e.get('media_m3_ha'), '{:.2f}')} m3/ha, CV de {_formato(e.get('cv_pct'), '{:.2f}')} % ({clase}) y error de muestreo de {_formato(error_final, '{:.2f}')} %. El criterio de precisión se evalúa sobre el resultado general del predio.")
        reglas.append({"codigo_interpretacion": "RODAL_" + str(rodal.get("clave", "SIN_CLAVE")), "regla": "CV y error relativo (informativo por rodal)", "valores_utilizados": {"cv": e.get("cv_pct"), "error_relativo_pct": error_final}, "version_plantilla": VERSION_PLANTILLA})
    for rodal in no_evaluables:
        n = (rodal.get("estadistica") or {}).get("n")
        mensaje = "no cuenta con sitios activos" if n == 0 else "cuenta con una sola observación"
        parrafos.append(f"El rodal {rodal.get('clave', 'sin clave')} {mensaje}; puede describirse el volumen observado, pero no es posible estimar de manera válida la varianza ni el error de muestreo.")
    if "no aplicada" in str(resultado.get("fpc_estado", "")):
        limitaciones.append(f"FPC: {resultado.get('fpc_estado', 'No registrada')}. La superficie en hectáreas no se utilizó como sustituto de N_h.")
    tabla = [(r.get("clave", "sin clave"), _formato(r.get("superficie_ha"), "{:.3f}"),
              (r.get("estadistica") or {}).get("n") if (r.get("estadistica") or {}).get("n") is not None else "No calculable",
              _formato((r.get("estadistica") or {}).get("poblacion_N"), "{:.1f}"),
              _formato((r.get("estadistica") or {}).get("media_m3_ha"), "{:.2f}"),
              _formato((r.get("estadistica") or {}).get("varianza"), "{:.4f}"),
              _formato((r.get("estadistica") or {}).get("desviacion_estandar"), "{:.2f}"),
              _formato((r.get("estadistica") or {}).get("cv_pct"), "{:.2f}"),
              _formato((r.get("estadistica") or {}).get("error_estandar"), "{:.2f}"),
              _formato((r.get("estadistica") or {}).get("t_critico"), "{:.4f}"),
              (r.get("estadistica") or {}).get("grados_libertad") if (r.get("estadistica") or {}).get("grados_libertad") is not None else "No calculable",
              _formato(_error_final(r.get("estadistica")), "{:.2f}"),
              _formato((r.get("estadistica") or {}).get("intensidad_muestreo_pct"), "{:.2f}"),
              (r.get("estadistica") or {}).get("estado", "No evaluable"))
             for r in rodales]
    validacion = resultado.get("validacion") or {}
    indicadores = [
        ("Predio", (resultado.get("predio") or {}).get("nombre", "No registrado")),
        ("Estado general", general.get("clasificacion", "No evaluable")),
        ("Sitios utilizados", str(validacion.get("sitios_validos", 0))),
        ("Superficie representada", f"{_formato(validacion.get('superficie_representada_ha', 0), '{:.3f}')} ha"),
        ("Intensidad total", f"{_formato(validacion.get('intensidad_total_pct', 0), '{:.2f}')} %"),
        ("FPC", resultado.get("fpc_estado", "No registrada")),
        ("Comprobación interna", comprobacion.get("estado", "No registrada")),
    ]
    if _es_numero(_error_final(general)):
        indicadores.append(("Error de muestreo general", f"{_error_final(general):.2f} %"))
    n_requerido_predio = general.get("n_requerido_predio")
    n_faltantes_predio = general.get("n_faltantes_predio")
    distribucion_predio = general.get("distribucion_sugerida_por_rodal") or []
    dimensionamiento_predio = None
    if _es_numero(n_requerido_predio):
        indicadores.append(("Sitios requeridos (predio)", str(n_requerido_predio)))
        indicadores.append(("Sitios faltantes (predio)", str(n_faltantes_predio)))
        dimensionamiento_predio = {"n_requerido_predio": n_requerido_predio,
                                   "n_faltantes_predio": n_faltantes_predio,
                                   "distribucion_sugerida_por_rodal": distribucion_predio}
    correcciones = correcciones or []
    activos = sum(((r.get("estadistica") or {}).get("n") or 0) for r in rodales)
    resumen = [
        f"El análisis integró {activos} sitios activos en {len(rodales)} rodales. Se incluyeron {validacion.get('sitios_cero', 0)} sitios confirmados en cero.",
        f"La superficie representada fue de {_formato(validacion.get('superficie_representada_ha', 0), '{:.3f}')} ha y la intensidad de muestreo de {_formato(validacion.get('intensidad_total_pct', 0), '{:.2f}')} %.",
        parrafos[0],
    ]
    secciones = [
        ("1. Resumen ejecutivo", resumen),
        ("2. Integración y calidad de la muestra", [f"Las celdas vacías no representan sitios; los sitios en cero son observaciones válidas y se incluyen en el cálculo de media, varianza, desviación estándar, CV y error. Se registraron {len(correcciones)} cambios en la matriz de trabajo."]),
        ("3. Metodología", ["La variable principal fue el volumen total por hectárea (m3/ha). Para cada sitio se aplicó FE = 10000/a; y = V_sitio × FE. Por rodal se calcularon media, varianza muestral, desviación estándar y CV con los sitios válidos, incluidos los de volumen cero; N = superficie del rodal / superficie del sitio; intensidad = n/N × 100; SE con la corrección histórica por población finita sx = √((s²/n) × (1−n/N)); error de muestreo = t × SE con gl = n-1. El resultado general, cuando fue evaluable, usó ponderación por superficie y grados de libertad de Welch-Satterthwaite. El criterio de cumplimiento frente al objetivo se evalúa únicamente sobre el resultado general del predio."]),
        ("4. Diagnóstico descriptivo general", parrafos[:1]),
        ("5. Análisis general y precisión", parrafos[1:3]),
        ("6. Análisis por rodal", parrafos[3:]),
        ("7. Comprobación de resultados", [f"Método principal: {comprobacion.get('metodo_principal', 'No registrado')}. Método independiente: {comprobacion.get('metodo_independiente', 'No registrado')}. Resultados comparados: {comprobacion.get('resultados_comparados', 0)}. Estado: {comprobacion.get('estado', 'No registrado')}." ]),
        ("8. Limitaciones", limitaciones),
        ("9. Conclusiones", [f"Estado general: {general.get('clasificacion', 'No evaluable')}.", "La intensidad de muestreo (n/N) describe la fracción muestreada y no sustituye la evaluación del error.", "Las recomendaciones se limitan a completar rodales sin muestra y aumentar observaciones en rodales insuficientes."]),
    ]
    if dimensionamiento_predio is not None:
        if n_faltantes_predio:
            texto_n = (f"Se estima que el predio requiere {n_requerido_predio} sitios para el objetivo de "
                       f"{_formato(objetivo, '{:.2f}')} % de error de muestreo (asignación proporcional a la superficie); "
                       f"con los {validacion.get('sitios_validos', 0)} sitios válidos actuales faltan "
                       f"{n_faltantes_predio} sitios adicionales.")
        else:
            texto_n = (f"Se estima que el predio requiere {n_requerido_predio} sitios para el objetivo de "
                       f"{_formato(objetivo, '{:.2f}')} % de error de muestreo (asignación proporcional a la superficie); "
                       f"con los {validacion.get('sitios_validos', 0)} sitios válidos actuales no faltan sitios adicionales.")
        texto_distribucion = "; ".join(f"{item.get('clave')}: {item.get('n_h')}" for item in distribucion_predio)
        texto_distribucion = (f"Distribución sugerida por rodal (mínimo 2 por rodal): {texto_distribucion}."
                              if texto_distribucion else "No fue posible calcular una distribución sugerida por rodal.")
        secciones.append(("10. Sitios adicionales sugeridos (predio)", [texto_n, texto_distribucion,
                          "Esta cifra es orientativa: no modifica, excluye ni recalcula la matriz confirmada."]))
    return {"titulo": "Análisis del error de muestreo", "parrafos": parrafos,
            "indicadores": indicadores, "dimensionamiento_predio": dimensionamiento_predio,
            "diagnostico": resultado.get("diagnostico"),
            "diagnostico_motor_anterior": _motor_anterior_a_3(resultado.get("version_motor")),
            "hallazgos": ["La intensidad de muestreo (n/N) expresa la fracción muestreada y no sustituye la evaluación estadística del error."],
            "observaciones": limitaciones, "limitaciones": limitaciones, "reglas": reglas,
            "tabla": tabla, "encabezados": ("Rodal", "Sup. ha", "n", "N", "Media m3/ha", "Var", "s", "CV %", "SE", "t", "gl", "Error de muestreo %", "Intensidad %", "Estado"),
            "grafica": [(r.get("clave", "sin clave"), (r.get("estadistica") or {}).get("media_m3_ha") or 0) for r in rodales if (r.get("estadistica") or {}).get("media_m3_ha") is not None],
            "titulo_grafica": "Media de volumen por rodal", "cautela": "Los resultados se derivan de la matriz de trabajo confirmada; los cambios posteriores exigen recalcular.",
            "estado_datos": general.get("clasificacion", "No evaluable"),
            "trazabilidad": f"Motor {resultado.get('version_motor', 'no registrado')}; plantilla {VERSION_PLANTILLA}; FPC: {resultado.get('fpc_estado', 'No registrada')}",
            "fuentes": ["Matriz de trabajo confirmada", "Resultados estadísticos SIMFI"],
            "secciones": secciones, "correcciones": correcciones}
