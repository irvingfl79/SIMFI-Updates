param([string]$InstallDir = "")

$ErrorActionPreference = "Stop"

if (-not $InstallDir) {
    $ScriptDir = $PSScriptRoot
    $InstallDir = if ((Split-Path -Leaf $ScriptDir) -ieq "app") { Split-Path -Parent $ScriptDir } else { $ScriptDir }
}
$InstallDir = [IO.Path]::GetFullPath($InstallDir)
$DataDir = Join-Path $InstallDir "data"
$ProjectsDir = Join-Path $DataDir "projects"
$UsersDir = Join-Path $DataDir "users"
$StateDir = Join-Path $DataDir "state"
$BackupDir = Join-Path $InstallDir ("backups\SIMFI_migracion_" + (Get-Date -Format "yyyyMMdd_HHmmss"))

function Copy-VerifiedFile {
    param([string]$Source, [string]$Target)
    New-Item -ItemType Directory -Path (Split-Path -Parent $Target) -Force | Out-Null
    if (Test-Path -LiteralPath $Target) {
        $same = (Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash -eq (Get-FileHash -LiteralPath $Target -Algorithm SHA256).Hash
        if ($same) { return "ya_existia" }
        $base = [IO.Path]::GetFileNameWithoutExtension($Target)
        $ext = [IO.Path]::GetExtension($Target)
        $Target = Join-Path (Split-Path -Parent $Target) ("{0}_MIGRADO_{1}{2}" -f $base, (Get-Date -Format "yyyyMMdd_HHmmss"), $ext)
    }
    Copy-Item -LiteralPath $Source -Destination $Target
    if ((Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $Target -Algorithm SHA256).Hash) {
        throw "La verificacion SHA-256 fallo: $Source"
    }
    return $Target
}

New-Item -ItemType Directory -Path $ProjectsDir, $UsersDir, $StateDir, $BackupDir,
    (Join-Path $InstallDir "exports"), (Join-Path $InstallDir "config"),
    (Join-Path $InstallDir "logs"), (Join-Path $InstallDir "updates") -Force | Out-Null

$records = @()
$legacyUsers = Join-Path $DataDir "usuarios.json"
if (Test-Path -LiteralPath $legacyUsers) {
    $target = Join-Path $UsersDir "usuarios.json"
    $records += [ordered]@{ origen = $legacyUsers; destino = (Copy-VerifiedFile $legacyUsers $target) }
}

Get-ChildItem -LiteralPath $DataDir -File -Filter "*.json" | Where-Object { $_.Name -ine "usuarios.json" } | ForEach-Object {
    $target = Join-Path $ProjectsDir $_.Name
    $records += [ordered]@{ origen = $_.FullName; destino = (Copy-VerifiedFile $_.FullName $target) }
}

$legacyState = Join-Path $DataDir ".simfi"
if (Test-Path -LiteralPath $legacyState) {
    Get-ChildItem -LiteralPath $legacyState -File -Recurse | ForEach-Object {
        $relative = $_.FullName.Substring($legacyState.Length + 1)
        $target = Join-Path $StateDir $relative
        $records += [ordered]@{ origen = $_.FullName; destino = (Copy-VerifiedFile $_.FullName $target) }
    }
}

$lastProject = Join-Path $StateDir "ultimo_proyecto.json"
if (Test-Path -LiteralPath $lastProject) {
    $state = Get-Content -LiteralPath $lastProject -Raw | ConvertFrom-Json
    $oldPrefix = $DataDir.TrimEnd('\') + '\'
    if ($state.ruta -and $state.ruta.StartsWith($oldPrefix, [StringComparison]::OrdinalIgnoreCase)) {
        $candidate = Join-Path $ProjectsDir ([IO.Path]::GetFileName($state.ruta))
        if (Test-Path -LiteralPath $candidate) {
            @{ ruta = $candidate } | ConvertTo-Json | Set-Content -LiteralPath $lastProject -Encoding UTF8
        }
    }
}

@{ sistema = "SIMFI"; fecha = (Get-Date).ToString("s"); instalacion = $InstallDir; archivos = $records } |
    ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $BackupDir "MANIFIESTO_MIGRACION.json") -Encoding UTF8
Write-Host "Migracion completada. Los archivos originales se conservaron en $DataDir."
