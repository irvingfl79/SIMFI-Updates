import unittest
import os
import json
import shutil
import datetime
import tempfile

from app import app
from modelos import PMFProyecto, Rodal
import respaldo_proyectos as respaldos


class RespaldosProyectosTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.data = os.path.join(self.tmp.name, "data")
        os.makedirs(self.data, exist_ok=True)
        self.ruta = os.path.join(self.data, "romeros.json")
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba_respaldos"
            sesion["ruta_actual"] = self.ruta
        self.cliente = cliente
        # Fecha simulada para la retención.
        self._ahora_original = datetime.datetime.now

    def tearDown(self):
        self.tmp.cleanup()

    def _proyecto(self, nombre="R", prefijo=""):
        pmf = PMFProyecto(nombre)
        pmf.especies = ["Pinus patula"]
        pmf.rodales.append(Rodal(f"{prefijo}R1", 12.0))
        pmf.guardar(self.ruta)
        return pmf

    def test_respaldo_aparece_al_guardar(self):
        self._proyecto()
        hecho = respaldos.respaldar(self.ruta, self.data)
        self.assertTrue(hecho)
        lista = respaldos.listar_respaldos(self.ruta, self.data)
        self.assertEqual(len(lista), 1)
        self.assertTrue(lista[0]["archivo"].startswith("respaldo_"))
        with open(os.path.join(
                respaldos.carpeta_proyecto(self.data, self.ruta),
                lista[0]["archivo"]), encoding="utf-8") as f:
            datos = json.load(f)
        self.assertEqual(datos["nombre"], "R")

    def test_sin_cambios_no_copia_duplicada(self):
        self._proyecto()
        self.assertTrue(respaldos.respaldar(self.ruta, self.data))
        self.assertFalse(respaldos.respaldar(self.ruta, self.data))
        self.assertEqual(len(respaldos.listar_respaldos(self.ruta, self.data)), 1)

    def test_intervalo_minimo_entre_respaldos(self):
        self._proyecto()
        ahora = datetime.datetime.now()
        self.assertTrue(respaldos.respaldar(self.ruta, self.data, ahora))
        pmf = PMFProyecto.cargar(self.ruta)
        pmf.predio = "Predio nuevo"
        pmf.guardar(self.ruta)
        # Dentro del intervalo de 15 minutos no se respalda de nuevo.
        self.assertFalse(respaldos.respaldar(
            self.ruta, self.data, ahora + datetime.timedelta(minutes=5)))
        self.assertTrue(respaldos.respaldar(
            self.ruta, self.data, ahora + datetime.timedelta(minutes=20)))
        self.assertEqual(len(respaldos.listar_respaldos(self.ruta, self.data)), 2)

    def test_retencion_limita_el_historico(self):
        self._proyecto()
        ahora = datetime.datetime.now()
        base = ahora - datetime.timedelta(days=45)
        marca = base.strftime("%Y%m%d_%H%M%S")
        carpeta = respaldos.carpeta_proyecto(self.data, self.ruta)
        os.makedirs(carpeta, exist_ok=True)
        # 40 respaldos antiguos en días distintos.
        for indice in range(40):
            fecha = base - datetime.timedelta(days=indice)
            nombre = f"respaldo_{fecha.strftime('%Y%m%d_%H%M%S')}.json"
            shutil.copy2(self.ruta, os.path.join(carpeta, nombre))
        respaldos._limpiar(carpeta, ahora)
        lista = respaldos.listar_respaldos(self.ruta, self.data)
        nombres = [r["archivo"] for r in lista]
        self.assertLessEqual(len(nombres), respaldos._MAXIMO_POR_PROYECTO)
        # Los 6 más recientes siguen presentes.
        esperado = [f"respaldo_{(base - datetime.timedelta(days=i)).strftime('%Y%m%d_%H%M%S')}.json"
                    for i in range(respaldos._RETENER_ULTIMOS)]
        for nombre in esperado:
            self.assertIn(nombre, nombres)
        # Los anteriores a 30 días fuera de anchors se eliminan.
        viejo = f"respaldo_{(base - datetime.timedelta(days=45)).strftime('%Y%m%d_%H%M%S')}.json"
        self.assertNotIn(viejo, nombres)

    def test_restaurar_devuelve_version_anterior(self):
        self._proyecto("Original")
        self.assertTrue(respaldos.respaldar(self.ruta, self.data))
        lista = respaldos.listar_respaldos(self.ruta, self.data)
        valor_respaldo = lista[0]["archivo"]
        pmf = PMFProyecto.cargar(self.ruta)
        pmf.nombre = "MODIFICADO"
        pmf.guardar(self.ruta)
        self.assertEqual(
            PMFProyecto.cargar(self.ruta).nombre, "MODIFICADO")
        self.assertTrue(respaldos.restaurar(self.ruta, valor_respaldo, self.data))
        restaurado = PMFProyecto.cargar(self.ruta)
        self.assertEqual(restaurado.nombre, "Original")
        # La copia previa a la restauración quedó protegida.
        carpeta = respaldos.carpeta_proyecto(self.data, self.ruta)
        previas = [a for a in os.listdir(carpeta)
                   if a.startswith("pre_restauracion_")]
        self.assertEqual(len(previas), 1)
        with open(os.path.join(carpeta, previas[0]), encoding="utf-8") as f:
            self.assertEqual(json.load(f)["nombre"], "MODIFICADO")
        con_pre = respaldos.listar_respaldos(self.ruta, self.data)
        self.assertFalse(any(a["archivo"].startswith("pre_restauracion_")
                             for a in con_pre))

    def test_guardado_por_aplicacion_crea_respaldo(self):
        import app as app_module
        app_module.DATA_DIR = self.data
        app_module.PROJECTS_DIR = os.path.join(self.data, "projects")
        app_module.PROJECT_STATE_DIR = os.path.join(self.data, "state")
        os.makedirs(app_module.PROJECTS_DIR, exist_ok=True)
        os.makedirs(app_module.PROJECT_STATE_DIR, exist_ok=True)
        self._proyecto()
        with self.cliente as cliente:
            with cliente.session_transaction() as sesion:
                sesion["ruta_actual"] = self.ruta
            respuesta = cliente.post("/editar_proyecto", data={"predio": "TEST"})
            self.assertEqual(respuesta.status_code, 302)
        lista = respaldos.listar_respaldos(self.ruta, self.data)
        self.assertGreaterEqual(len(lista), 1)

    def test_panel_restaurar_y_descargar(self):
        import app as app_module
        app_module.DATA_DIR = self.data
        self._proyecto("Original")
        self.assertTrue(respaldos.respaldar(self.ruta, self.data))
        nombre = respaldos.listar_respaldos(self.ruta, self.data)[0]["archivo"]
        pmf = PMFProyecto.cargar(self.ruta)
        pmf.nombre = "MODIFICADO"
        pmf.guardar(self.ruta)

        panel = self.cliente.get("/respaldos")
        self.assertEqual(panel.status_code, 200)
        self.assertIn("respaldo_", panel.get_data(as_text=True))

        descarga = self.cliente.get("/respaldos/descargar",
                                    query_string={"archivo": nombre})
        self.assertEqual(descarga.status_code, 200)
        self.assertEqual(descarga.get_json()["nombre"], "Original")

        restaurar = self.cliente.post(
            "/respaldos/restaurar",
            data={"archivo": nombre, "origen": "respaldos"})
        self.assertEqual(restaurar.status_code, 302)
        self.assertEqual(PMFProyecto.cargar(self.ruta).nombre, "Original")

        intruso = self.cliente.get("/respaldos/descargar",
                                   query_string={"archivo": "../romeros.json"})
        self.assertEqual(intruso.status_code, 302)

    def test_respaldo_no_modifica_projecto_serializado(self):
        self._proyecto()
        ante = open(self.ruta, encoding="utf-8").read()
        self.assertTrue(respaldos.respaldar(self.ruta, self.data))
        despues = open(self.ruta, encoding="utf-8").read()
        self.assertEqual(ante, despues)


if __name__ == "__main__":
    unittest.main()
