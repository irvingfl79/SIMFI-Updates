import os
import json
import datetime
import secrets
import functools
import math
import re
import threading
import unicodedata
import base64
import copy
import subprocess
import respaldo_proyectos as respaldos
from flask import (Flask, render_template, request, redirect, url_for, flash,
                   session, jsonify, send_from_directory, send_file)
from modelos import *
from modelos import (_ECUACIONES_PREDET, _orden_especies, _orden_especie_volumen,
                     _FACTOR_MS, _FACTOR_RAICES, _FACTOR_CO2, _promedio_simple)
from data_municipios import MUNICIPIOS
from guias_densidad import (cargar_modelos_densidad, construir_analisis_densidad,
                             generar_datos_grafica, obtener_datos_rodal, seleccionar_modelo)
from reporte_densidad import (decodificar_png, generar_reporte_densidad,
                              generar_excel_intensidades_aplicadas,
                              generar_pdf_intensidades_aplicadas,
                              generar_reporte_aclareos, generar_reporte_aclareos_multirodal,
                              generar_word_intensidades_aplicadas,
                              _COLUMNAS_REPORTE_RODALES,
                              nombre_archivo_aclareos, nombre_archivo_aclareos_multirodal,
                              generar_reporte_turno, nombre_archivo_reporte,
                              nombre_archivo_turno)
from motor_aclareos import (clave_analisis, construir_evaluacion, datos_grafica_aclareo,
                            escenario_usuario, escenario_veiga,
                            intensidad_volumetrica_equivalente,
                            registrar_trazabilidad, resumen_rodal_especie,
                            tabla_intensidades_aplicadas, tabla_reporte_rodales)
from turnos import (ErrorTurno, calcular_turno_tecnico, cargar_catalogo_turnos,
                    generar_datos_grafica_turno)
from reportes_tecnicos import (analisis_existencias, analisis_incrementos, analisis_carbono,
                                analisis_detallado_existencias, construir_datos_reporte_existencias, datos_graficas_existencias,
                                generar_word, generar_word_cuadro_existencias, generar_word_cuadro_incrementos,
                                generar_word_plan_cortas, generar_pdf, generar_pdf_cuadro_existencias,
                                generar_pdf_cuadro_incrementos,
                                generar_word_cuadro_reforestacion, generar_pdf_cuadro_reforestacion,
                                generar_word_cuadro_carbono, generar_pdf_cuadro_carbono,
                                interpretar_reporte_existencias)
from reporte_integral import construir_contexto, generar_word_integral, generar_pdf_integral, NIVELES
from error_muestreo import (VERSION_MOTOR as VERSION_MOTOR_MUESTREO, ErrorMuestreoValidacion,
                            calcular_error_muestreo, hash_archivo, normalizar_documento)
from interpretacion_muestreo import interpretar_muestreo, VERSION_PLANTILLA as VERSION_PLANTILLA_MUESTREO
from diagnostico_muestreo import diagnosticar_muestreo
from reporte_error_muestreo import generar_word_error_muestreo
from cartografia import campos_atributos, cargar_capa, exportar_excel_atributos, exportar_geojson, exportar_shp_zip, geometria_geografica
from superficies import calcular_cuadro, exportar_excel, formato_numero, leer_captura
from reporte_superficies import generar_word_superficies
from werkzeug.security import generate_password_hash, check_password_hash
from ia_semantica import (contexto_existencias as contexto_semantico_existencias,
                          contexto_incrementos as contexto_semantico_incrementos,
                          contexto_carbono_contenido, contexto_carbono_captura,
                          contexto_carbono_oxigeno)
from modelos import es_conifera

try:
    from ia_ollama import (cargar_config as cargar_config_ia,
                            estado_servicio as estado_servicio_ia,
                            interpretar_resultados as interpretar_resultados_ia,
                            DATOS_PRUEBA_IA)
    from ia_config import guardar_config as guardar_config_ia
    from ai_interpretation_service import AIInterpretationService
    _SERVICIO_INTERPRETACION_IA = AIInterpretationService()
    _MODULO_IA_DISPONIBLE = True
except ImportError:
    _MODULO_IA_DISPONIBLE = False

try:
    from ia_interpretacion import (interpretar as interpretar_ia_reporte_engine,
                                   habilitada as ia_reportes_habilitada,
                                   TITULOS as _TIPOS_IA_REPORTES)
    _MODULO_IA_REPORTES_DISPONIBLE = True
except ImportError:
    _MODULO_IA_REPORTES_DISPONIBLE = False

try:
    import dussan_backend
    _MODULO_DUSSAN_DISPONIBLE = True
except ImportError:
    _MODULO_DUSSAN_DISPONIBLE = False

app = Flask(__name__)
app.secret_key = secrets.token_hex(32)

APP_DIR = os.path.dirname(os.path.abspath(__file__))
# An installed build may keep the executable code in an ``app`` subdirectory.
INSTALL_DIR = (os.path.dirname(APP_DIR)
               if os.path.basename(APP_DIR).lower() == "app" else APP_DIR)
DATA_DIR = os.path.abspath(os.environ.get("SIMFI_DATA_DIR", os.path.join(INSTALL_DIR, "data")))
PROJECTS_DIR = os.path.join(DATA_DIR, "projects")
USERS_DIR = os.path.join(DATA_DIR, "users")
PROJECT_STATE_DIR = os.path.join(DATA_DIR, "state")
LEGACY_STATE_DIR = os.path.join(DATA_DIR, ".simfi")
IMG_DIR = os.path.join(APP_DIR, "img")
os.makedirs(DATA_DIR, exist_ok=True)
USERS_FILE = os.path.join(USERS_DIR, "usuarios.json")
LEGACY_USERS_FILE = os.path.join(DATA_DIR, "usuarios.json")
LAST_PROJECT_FILE = os.path.join(PROJECT_STATE_DIR, "ultimo_proyecto.json")
FIRMA_EXPORTACION = "SIMFI — Sistema para el Manejo Forestal Mejorado por Dr.PIFL"


@app.template_filter("miles")
def formato_miles(valor, decimales=3, signo=False):
    """Formatea un número con separador de miles (2,314.254)."""
    if valor in (None, ""):
        return ""
    try:
        texto = f"{float(valor):,.{int(decimales)}f}"
    except (TypeError, ValueError):
        return valor
    if signo and float(valor) >= 0:
        texto = "+" + texto
    return texto
try:
    with open(os.path.join(os.path.dirname(__file__), "version.json"), "r", encoding="utf-8") as f:
        SISTEMA_VERSION = json.load(f).get("version", "1.0")
except (OSError, ValueError):
    SISTEMA_VERSION = "1.0"


@app.context_processor
def version_sistema():
    return {"sistema_version": SISTEMA_VERSION}


@app.context_processor
def contexto_ia_reportes():
    habilitado = False
    if _MODULO_IA_DISPONIBLE and _MODULO_IA_REPORTES_DISPONIBLE:
        try:
            habilitado = bool(ia_reportes_habilitada())
        except Exception:
            habilitado = False
    return {"ia_reporte_habil": habilitado}


def _dussan_habilitado():
    """Dussan se muestra solo si el modulo existe y la configuracion lo permite."""
    if not _MODULO_DUSSAN_DISPONIBLE:
        return False
    try:
        return bool(dussan_backend.dussan_habilitado())
    except Exception:
        return False


def _dussan_voz():
    """La voz existe desde el inicio, pero se entrega desactivada."""
    if not _MODULO_DUSSAN_DISPONIBLE:
        return False
    try:
        return bool(dussan_backend.voz_habilitada())
    except Exception:
        return False


def _dussan_avatar():
    """Imagen del personaje: asset oficial de Dussan en estado idle."""
    try:
        return url_for("static", filename="img/dussan/dussan_idle.png")
    except Exception:
        return ""


_ESTADOS_DUSSAN = ("idle", "listening", "thinking", "speaking", "success", "warning")


def _dussan_imagenes():
    """Mapa estado -> imagen oficial de Dussan + miniatura de la pildora.

    Cada entrada puede sustituirse despues por un asset final sin tocar codigo:
    basta reemplazar el archivo PNG con el mismo nombre.
    """
    try:
        estados = {estado: url_for("static", filename="img/dussan/dussan_%s.png" % estado)
                   for estado in _ESTADOS_DUSSAN}
        avatar = url_for("static", filename="img/dussan/dussan_idle.png")
        return {"estados": estados, "mini": avatar, "avatar": avatar}
    except Exception:
        return {"estados": {}, "mini": "", "avatar": ""}


def _dussan_estado(pmf):
    """Estado de Dussan para la pagina que se esta sirviendo (solo lectura)."""
    try:
        return dussan_backend.contexto(
            pmf,
            modulo=dussan_backend.modulo_desde_endpoint(request.endpoint),
            usuario=session.get("usuario", ""),
            rol=session.get("rol", ""),
            version_sistema=SISTEMA_VERSION,
            endpoint=request.endpoint or "")
    except Exception:
        return None


@app.context_processor
def contexto_dussan():
    """Inyecta en todas las paginas los datos minimos que necesita Dussan."""
    if not _dussan_habilitado():
        return {"dussan_habilitado": False}
    estado = None
    try:
        estado = _dussan_estado(get_pmf())
    except Exception:
        estado = None
    try:
        imagenes = _dussan_imagenes()
    except Exception:
        imagenes = {"estados": {}, "mini": "", "avatar": ""}
    return {
        "dussan_habilitado": True,
        "dussan_voz": _dussan_voz(),
        "dussan_avatar": imagenes["avatar"],
        "dussan_estados": imagenes["estados"],
        "dussan_mini": imagenes["mini"],
        "dussan_modulo": dussan_backend.modulo_desde_endpoint(request.endpoint),
        "dussan_estado": (estado or {}).get("estado", {}),
        "dussan_rodales": (estado or {}).get("rodales", []),
    }

def _cargar_usuarios():
    ruta = USERS_FILE if os.path.isfile(USERS_FILE) else LEGACY_USERS_FILE
    if os.path.isfile(ruta):
        with open(ruta, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def _guardar_usuarios(usuarios):
    _guardar_json_atomico(USERS_FILE, usuarios)


def _guardar_json_atomico(ruta, datos):
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    temporal = ruta + ".tmp"
    with open(temporal, "w", encoding="utf-8") as archivo:
        json.dump(datos, archivo, indent=2, ensure_ascii=False)
        archivo.flush()
        os.fsync(archivo.fileno())
    os.replace(temporal, ruta)


def _asegurar_admin():
    usuarios = _cargar_usuarios()
    if not usuarios:
        usuarios["DR.PIFL"] = {"password": generate_password_hash("2211"), "rol": "admin"}
        _guardar_usuarios(usuarios)


def _limpiar_temporales_antiguos(dias=30):
    """Borra sesiones temporales huérfanas de data/state con más de 'dias' días."""
    if not os.path.isdir(PROJECT_STATE_DIR):
        return
    limite = datetime.datetime.now() - datetime.timedelta(days=dias)
    for nombre in os.listdir(PROJECT_STATE_DIR):
        if not nombre.lower().endswith(".json") or nombre == "ultimo_proyecto.json":
            continue
        ruta = os.path.join(PROJECT_STATE_DIR, nombre)
        try:
            if datetime.datetime.fromtimestamp(os.path.getmtime(ruta)) < limite:
                os.remove(ruta)
        except OSError:
            continue


_asegurar_admin()
try:
    _limpiar_temporales_antiguos()
except Exception:
    pass


_PUBLICAS = {"login", "logout", "static", "imagen_sistema", "api_municipios", "api_seleccionar_directorio"}


@app.route("/imagen-sistema/<path:archivo>")
def imagen_sistema(archivo):
    return send_from_directory(IMG_DIR, archivo)


def login_required(f):
    @functools.wraps(f)
    def wrap(*args, **kwargs):
        if "usuario" not in session:
            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                return jsonify({"error": "no_auth"}), 401
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrap


@app.before_request
def check_auth():
    if request.endpoint and request.endpoint not in _PUBLICAS:
        if "usuario" not in session:
            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                return jsonify({"error": "no_auth"}), 401
            return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("usuario", "").strip()
        password = request.form.get("password", "")
        usuarios = _cargar_usuarios()
        user = usuarios.get(username)
        if user and check_password_hash(user["password"], password):
            session["usuario"] = username
            session["rol"] = user.get("rol", "consulta")
            flash(f"Bienvenido {username}", "success")
            return redirect(url_for("index"))
        flash("Usuario o contraseña incorrectos", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Sesión cerrada", "success")
    return redirect(url_for("login"))


@app.context_processor
def inject_global_vars():
    try:
        pmf = get_pmf()
        return {"project_name": pmf.nombre, "usuario": session.get("usuario"),
                "rol": session.get("rol"), "firma_exportacion": FIRMA_EXPORTACION}
    except Exception:
        return {"project_name": None, "usuario": session.get("usuario"),
                "rol": session.get("rol"), "firma_exportacion": FIRMA_EXPORTACION}


def _cargar_especies_si_vacio(pmf):
    if not pmf.especies:
        for especie, params in _ECUACIONES_PREDET.items():
            pmf.agregar_especie(especie)
            pmf.asignar_ecuacion(especie, EcuacionVolumen(**params))
    if not pmf.tp_ecuaciones:
        pmf.cargar_tp_predeterminadas()
    if not pmf.edad_ecuaciones:
        pmf.cargar_edad_predeterminadas()
    return pmf

def _guardar_ultimo_proyecto(ruta):
    if not ruta or not os.path.isfile(ruta):
        return
    try:
        _guardar_json_atomico(LAST_PROJECT_FILE, {"ruta": os.path.abspath(ruta)})
    except OSError:
        pass


def _rutas_proyectos_guardados():
    rutas = []
    for directorio in (PROJECTS_DIR, DATA_DIR):
        if not os.path.isdir(directorio):
            continue
        rutas.extend(os.path.join(directorio, nombre) for nombre in os.listdir(directorio)
                     if nombre.lower().endswith(".json") and
                     os.path.join(directorio, nombre) not in (USERS_FILE, LEGACY_USERS_FILE))
    return sorted(set(rutas), key=lambda ruta: os.path.getmtime(ruta), reverse=True)


def _cargar_ultimo_proyecto():
    candidatos = []
    for estado in (LAST_PROJECT_FILE, os.path.join(LEGACY_STATE_DIR, "ultimo_proyecto.json")):
        try:
            with open(estado, "r", encoding="utf-8") as archivo:
                ruta = json.load(archivo).get("ruta", "")
            if ruta:
                candidatos.append(ruta)
        except (OSError, ValueError, AttributeError):
            pass
    candidatos.extend(ruta for ruta in _rutas_proyectos_guardados() if ruta not in candidatos)
    for ruta in candidatos:
        if not os.path.isfile(ruta):
            continue
        try:
            pmf = _cargar_especies_si_vacio(PMFProyecto.cargar(ruta))
            session["ruta_actual"] = ruta
            session.modified = True
            _guardar_ultimo_proyecto(ruta)
            return pmf
        except (OSError, ValueError, TypeError, KeyError, AttributeError):
            continue
    return None


_CACHE_PMF = {}
_CACHE_PMF_LOCK = threading.Lock()


def _cargar_pmf_cacheado(ruta):
    ruta_abs = os.path.abspath(ruta)
    try:
        stat = os.stat(ruta_abs)
        clave = (stat.st_mtime_ns, stat.st_size)
    except OSError:
        cacheado = None
        with _CACHE_PMF_LOCK:
            cacheado = _CACHE_PMF.pop(ruta_abs, None)
        return PMFProyecto.cargar(ruta_abs)
    with _CACHE_PMF_LOCK:
        cacheado = _CACHE_PMF.get(ruta_abs)
        if cacheado is not None and cacheado[0] == clave:
            return cacheado[1]
    pmf = PMFProyecto.cargar(ruta_abs)
    with _CACHE_PMF_LOCK:
        _CACHE_PMF[ruta_abs] = (clave, pmf)
    return pmf


def get_pmf() -> PMFProyecto:
    if "ruta_actual" in session:
        try:
            return _cargar_especies_si_vacio(_cargar_pmf_cacheado(session["ruta_actual"]))
        except:
            pass
    if "pmf_data" in session:
        datos_anteriores = session.pop("pmf_data")
        session.modified = True
        try:
            pmf = _cargar_especies_si_vacio(PMFProyecto.desde_dict(datos_anteriores))
            save_pmf(pmf)
            return pmf
        except Exception:
            pass
    ultimo = _cargar_ultimo_proyecto()
    if ultimo is not None:
        return ultimo
    return _cargar_especies_si_vacio(PMFProyecto())


def save_pmf(pmf: PMFProyecto):
    session.pop("pmf_data", None)
    ruta = pmf.ruta_archivo
    if not ruta:
        usuario = re.sub(r"[^A-Za-z0-9_.-]+", "_", session.get("usuario", "local"))
        os.makedirs(PROJECT_STATE_DIR, exist_ok=True)
        temporal_id = session.get("proyecto_temporal_id")
        if not temporal_id:
            temporal_id = secrets.token_urlsafe(12)
            session["proyecto_temporal_id"] = temporal_id
        ruta = os.path.join(PROJECT_STATE_DIR, f"proyecto_temporal_{usuario}_{temporal_id}.json")
    try:
        respaldos.respaldar(ruta, DATA_DIR)
    except Exception:
        pass
    if not pmf.guardar(ruta):
        session.modified = True
        return False
    if ruta:
        try:
            stat = os.stat(os.path.abspath(ruta))
            with _CACHE_PMF_LOCK:
                _CACHE_PMF[os.path.abspath(ruta)] = ((stat.st_mtime_ns, stat.st_size), pmf)
        except OSError:
            pass
    session["ruta_actual"] = ruta
    session.modified = True
    _guardar_ultimo_proyecto(ruta)
    return True


def pmf_to_dict(pmf):
    return {
        "nombre": pmf.nombre,
        "predio": pmf.predio,
        "municipio": pmf.municipio,
        "propietario": pmf.propietario,
        "estado": pmf.estado,
        "ruta_archivo": pmf.ruta_archivo,
        "num_rodales": pmf.num_rodales,
        "superficie_total": pmf.superficie_total_ha,
        "area_sitio_m2": pmf.area_sitio_m2,
        "especies": pmf.especies,
        "factor_expansion": pmf.obtener_factor_expansion(),
        "usar_factor_ajuste": pmf.usar_factor_ajuste,
        "creado": pmf.creado,
        "modificado": pmf.modificado,
    }


# =============== RUTAS PRINCIPALES ===============

@app.route("/")
def index():
    pmf = get_pmf()
    ctx = pmf_to_dict(pmf)
    archivos = [os.path.basename(ruta) for ruta in _rutas_proyectos_guardados()
                if os.path.dirname(ruta) == PROJECTS_DIR]
    ctx["archivos"] = sorted(archivos)
    ctx["estados"] = sorted(MUNICIPIOS.keys())
    ctx["data_dir"] = PROJECTS_DIR
    ctx["num_especies_con_datos"] = len({t.especie for t in pmf.tablas_inventario})
    return render_template("index.html", **ctx)


@app.route("/nuevo", methods=["POST"])
def nuevo_pmf():
    predio = request.form.get("predio", "").strip()
    estado = request.form.get("estado", "").strip()
    municipio = request.form.get("municipio", "").strip()
    propietario = request.form.get("propietario", "").strip()
    ruta_guardado = request.form.get("ruta_guardado", "").strip()
    pmf = PMFProyecto(nombre=predio or "Sin nombre",
                      predio=predio, estado=estado,
                      municipio=municipio, propietario=propietario)
    for especie, params in _ECUACIONES_PREDET.items():
        pmf.agregar_especie(especie)
        pmf.asignar_ecuacion(especie, EcuacionVolumen(**params))
    pmf.cargar_tp_predeterminadas()
    pmf.cargar_edad_predeterminadas()
    if not ruta_guardado:
        nombre_archivo = predio.lower().replace(" ", "_") + ".json" if predio else "proyecto.json"
        ruta_guardado = os.path.join(PROJECTS_DIR, nombre_archivo)
    pmf.ruta_archivo = ruta_guardado
    session.pop("ruta_actual", None)
    if pmf.guardar(ruta_guardado):
        session["ruta_actual"] = ruta_guardado
        flash(f"Proyecto guardado en {ruta_guardado}", "success")
    else:
        flash("Error al guardar el archivo", "error")
    save_pmf(pmf)
    return redirect(url_for("index"))


@app.route("/abrir/<archivo>")
def abrir_pmf(archivo):
    ruta = os.path.join(PROJECTS_DIR, archivo)
    if not os.path.isfile(ruta):
        flash("Archivo no encontrado", "error")
        return redirect(url_for("index"))
    try:
        pmf = PMFProyecto.cargar(ruta)
        pmf = _cargar_especies_si_vacio(pmf)
        session["ruta_actual"] = ruta
        save_pmf(pmf)
        flash(f"Proyecto '{pmf.nombre}' cargado", "success")
    except Exception as e:
        flash(f"Error al cargar: {e}", "error")
    return redirect(url_for("index"))


def _ejecutar_dialogo_windows(comando: str):
    proceso = subprocess.run(
        ["powershell.exe", "-NoProfile", "-STA", "-Command", comando],
        capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if proceso.returncode != 0:
        raise RuntimeError(proceso.stderr.strip() or "No fue posible abrir el selector de Windows")
    return proceso.stdout.strip() or None


def _seleccionar_archivo_proyecto(guardar=False, nombre_inicial="proyecto.json"):
    titulo = json.dumps("Guardar proyecto SIMFI como" if guardar else "Abrir proyecto SIMFI")
    if guardar:
        nombre = json.dumps(nombre_inicial)
        comando = (
            "Add-Type -AssemblyName System.Windows.Forms;"
            "$d=New-Object System.Windows.Forms.SaveFileDialog;"
            f"$d.Title={titulo};$d.Filter='Proyecto SIMFI (*.json)|*.json|Todos los archivos (*.*)|*.*';"
            f"$d.DefaultExt='json';$d.AddExtension=$true;$d.FileName={nombre};"
            "if($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){[Console]::Out.Write($d.FileName)}"
        )
    else:
        comando = (
            "Add-Type -AssemblyName System.Windows.Forms;"
            "$d=New-Object System.Windows.Forms.OpenFileDialog;"
            f"$d.Title={titulo};$d.Filter='Proyecto SIMFI (*.json)|*.json|Todos los archivos (*.*)|*.*';"
            "$d.Multiselect=$false;"
            "if($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){[Console]::Out.Write($d.FileName)}"
        )
    return _ejecutar_dialogo_windows(comando)


def _seleccionar_directorio():
    comando = (
        "Add-Type -AssemblyName System.Windows.Forms;"
        "$d=New-Object System.Windows.Forms.FolderBrowserDialog;"
        "$d.Description='Seleccionar carpeta de destino';"
        "if($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){[Console]::Out.Write($d.SelectedPath)}"
    )
    return _ejecutar_dialogo_windows(comando)


@app.route("/proyecto/seleccionar-abrir")
def seleccionar_abrir_proyecto():
    try:
        return jsonify({"ruta": _seleccionar_archivo_proyecto() or None})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.route("/proyecto/abrir-externo", methods=["POST"])
def abrir_proyecto_externo():
    ruta = request.form.get("ruta", "").strip()
    if not ruta.lower().endswith(".json") or not os.path.isfile(ruta):
        flash("Seleccione un archivo de proyecto JSON válido", "error")
        return redirect(url_for("index"))
    try:
        pmf = _cargar_especies_si_vacio(PMFProyecto.cargar(ruta))
        save_pmf(pmf)
        flash(f"Proyecto '{pmf.nombre}' abierto correctamente", "success")
    except (OSError, ValueError, TypeError, KeyError) as exc:
        flash(f"No fue posible abrir el proyecto: {exc}", "error")
    return redirect(url_for("index"))


@app.route("/proyecto/abrir-cargado", methods=["POST"])
def abrir_proyecto_cargado():
    archivo = request.files.get("archivo")
    if not archivo or not archivo.filename or not archivo.filename.lower().endswith(".json"):
        flash("Seleccione un archivo de proyecto JSON válido", "error")
        return redirect(url_for("index"))
    try:
        contenido = archivo.read()
        if len(contenido) > 25_000_000:
            raise ValueError("El proyecto excede el tamaño permitido")
        datos = json.loads(contenido.decode("utf-8-sig"))
        if not isinstance(datos, dict):
            raise ValueError("El archivo no contiene un proyecto válido")
        pmf = _cargar_especies_si_vacio(PMFProyecto.desde_dict(datos))
        nombre = os.path.basename(archivo.filename)
        base, extension = os.path.splitext(nombre)
        ruta = os.path.join(PROJECTS_DIR, nombre)
        consecutivo = 2
        while os.path.exists(ruta):
            ruta = os.path.join(PROJECTS_DIR, f"{base}_{consecutivo}{extension}")
            consecutivo += 1
        if not pmf.guardar(ruta):
            raise OSError("No fue posible guardar la copia importada")
        session["ruta_actual"] = ruta
        session.pop("pmf_data", None)
        session.modified = True
        _guardar_ultimo_proyecto(ruta)
        flash(f"Proyecto '{pmf.nombre}' abierto correctamente", "success")
    except (OSError, UnicodeDecodeError, ValueError, TypeError, KeyError) as exc:
        flash(f"No fue posible abrir el proyecto: {exc}", "error")
    return redirect(url_for("index"))


@app.route("/proyecto/seleccionar-guardar")
def seleccionar_guardar_proyecto():
    pmf = get_pmf()
    nombre = re.sub(r"[^A-Za-z0-9_.-]+", "_", pmf.nombre).strip("_") or "proyecto"
    try:
        return jsonify({"ruta": _seleccionar_archivo_proyecto(True, f"{nombre}.json") or None})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.route("/proyecto/guardar-como", methods=["POST"])
def guardar_proyecto_como():
    pmf = get_pmf()
    ruta = request.form.get("ruta", "").strip()
    if not ruta:
        flash("No se seleccionó una ubicación para guardar", "error")
        return redirect(url_for("index"))
    if not ruta.lower().endswith(".json"):
        ruta += ".json"
    try:
        if not pmf.guardar(ruta):
            raise OSError("No fue posible escribir el archivo")
        session["ruta_actual"] = ruta
        session.pop("pmf_data", None)
        session.modified = True
        _guardar_ultimo_proyecto(ruta)
        flash(f"Proyecto completo guardado en {ruta}", "success")
    except (OSError, ValueError, TypeError) as exc:
        flash(f"No fue posible guardar el proyecto: {exc}", "error")
    return redirect(url_for("index"))


@app.route("/proyecto/descargar")
def descargar_proyecto():
    from io import BytesIO
    pmf = get_pmf()
    nombre = re.sub(r"[^A-Za-z0-9_.-]+", "_", pmf.nombre).strip("_") or "proyecto"
    contenido = json.dumps(pmf.serializar(), indent=2, ensure_ascii=False).encode("utf-8")
    return send_file(BytesIO(contenido), as_attachment=True,
                     download_name=f"{nombre}.json", mimetype="application/json")


@app.route("/guardar", methods=["POST"])
def guardar_pmf():
    pmf = get_pmf()
    nombre_archivo = request.form.get("nombre_archivo", "").strip()
    if not nombre_archivo:
        nombre_archivo = f"{pmf.nombre.replace(' ', '_')}.json"
    if not nombre_archivo.endswith(".json"):
        nombre_archivo += ".json"
    ruta = os.path.join(PROJECTS_DIR, nombre_archivo)
    pmf.ruta_archivo = ruta
    try:
        respaldos.respaldar(ruta, DATA_DIR)
    except Exception:
        pass
    if pmf.guardar(ruta):
        session["ruta_actual"] = ruta
        save_pmf(pmf)
        flash(f"Guardado como {nombre_archivo}", "success")
    else:
        flash("Error al guardar", "error")
    return redirect(url_for("index"))


@app.route("/editar_proyecto", methods=["POST"])
def editar_proyecto():
    pmf = get_pmf()
    predio = request.form.get("predio", "").strip()
    estado = request.form.get("estado", "").strip()
    municipio = request.form.get("municipio", "").strip()
    propietario = request.form.get("propietario", "").strip()
    if predio:
        pmf.predio = predio
        pmf.nombre = predio
    if estado:
        pmf.estado = estado
    if municipio:
        pmf.municipio = municipio
    if propietario:
        pmf.propietario = propietario
    save_pmf(pmf)
    flash("Proyecto actualizado", "success")
    return redirect(url_for("index"))


@app.route("/info_proyecto")
def info_proyecto():
    pmf = get_pmf()
    return render_template("proyecto/info.html", pmf=pmf)


# =============== RODALES ===============

_COLUMNAS_RODALES = {
    "id": "id", "rodal": "id", "umm": "id", "identificador": "id",
    "superficie": "superficie_ha", "superficieha": "superficie_ha",
    "area": "superficie_ha", "areaha": "superficie_ha",
    "sitios": "sitios", "numerodesitios": "sitios", "numsitios": "sitios",
    "areasitio": "area_sitio_m2", "areasitiom2": "area_sitio_m2",
    "areaporsitio": "area_sitio_m2", "areaporsitiom2": "area_sitio_m2",
}


def _normalizar_columna_rodal(valor):
    texto = unicodedata.normalize("NFKD", str(valor or ""))
    texto = "".join(caracter for caracter in texto if not unicodedata.combining(caracter))
    return re.sub(r"[^a-z0-9]", "", texto.casefold())


def _numero_rodal_importado(valor, fila, columna, entero=False, opcional=False):
    if valor is None or str(valor).strip() == "":
        if opcional:
            return None
        raise ValueError(f"Fila {fila}, {columna}: el valor es obligatorio")
    try:
        numero = float(str(valor).strip().replace(",", "."))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Fila {fila}, {columna}: valor no numérico '{valor}'") from exc
    if not math.isfinite(numero) or numero <= 0:
        raise ValueError(f"Fila {fila}, {columna}: el valor debe ser mayor que cero")
    if entero:
        if not numero.is_integer():
            raise ValueError(f"Fila {fila}, {columna}: debe ser un número entero")
        return int(numero)
    return numero


def _parsear_filas_rodales(encabezados, filas, pmf):
    columnas = {}
    desconocidas = []
    for indice, encabezado in enumerate(encabezados):
        normalizado = _normalizar_columna_rodal(encabezado)
        if not normalizado:
            continue
        campo = _COLUMNAS_RODALES.get(normalizado)
        if not campo:
            desconocidas.append(str(encabezado).strip())
            continue
        if campo in columnas:
            raise ValueError(f"La columna '{encabezado}' está repetida o equivale a otra columna")
        columnas[campo] = indice
    if desconocidas:
        raise ValueError("Columnas no reconocidas: " + ", ".join(desconocidas))
    faltantes = [nombre for nombre in ("id", "superficie_ha") if nombre not in columnas]
    if faltantes:
        raise ValueError("La tabla debe incluir las columnas ID y Superficie (ha)")

    existentes = {rodal.id.casefold() for rodal in pmf.rodales}
    ids_importados = set()
    resultado = []
    for numero_fila, valores in enumerate(filas, start=2):
        valores = list(valores)
        if not any(valor is not None and str(valor).strip() for valor in valores):
            continue

        def celda(campo, default=None):
            indice = columnas.get(campo)
            return valores[indice] if indice is not None and indice < len(valores) else default

        valor_id = celda("id")
        if isinstance(valor_id, float) and valor_id.is_integer():
            valor_id = int(valor_id)
        rid = " ".join(str(valor_id or "").strip().split())
        if not rid:
            raise ValueError(f"Fila {numero_fila}, ID: el identificador es obligatorio")
        if len(rid) > 120 or any(ord(caracter) < 32 for caracter in rid):
            raise ValueError(f"Fila {numero_fila}, ID: identificador no válido")
        clave = rid.casefold()
        if clave in ids_importados:
            raise ValueError(f"Fila {numero_fila}: el rodal '{rid}' está repetido en la importación")
        ids_importados.add(clave)

        superficie = _numero_rodal_importado(
            celda("superficie_ha"), numero_fila, "Superficie (ha)")
        sitios = _numero_rodal_importado(
            celda("sitios"), numero_fila, "Sitios", entero=True, opcional=True) or 1
        area_sitio = _numero_rodal_importado(
            celda("area_sitio_m2"), numero_fila,
            "Área/sitio (m²)", opcional=True) or (pmf.area_sitio_m2 or 500)
        resultado.append({
            "id": rid, "superficie_ha": superficie, "sitios": sitios,
            "area_sitio_m2": area_sitio,
            "existente": clave in existentes,
        })
    if not resultado:
        raise ValueError("La tabla no contiene rodales para importar")
    if len(resultado) > 1000:
        raise ValueError("La importación no puede contener más de 1000 rodales")
    return resultado


def _parsear_rodales_pegados(texto, pmf):
    if not isinstance(texto, str) or not texto.strip():
        raise ValueError("Pegue la tabla copiada desde Excel")
    if len(texto) > 1_000_000:
        raise ValueError("La tabla pegada supera el tamaño permitido")
    lineas = [linea.rstrip("\r") for linea in texto.splitlines() if linea.strip()]
    if len(lineas) < 2 or "\t" not in lineas[0]:
        raise ValueError("Copie encabezados y filas directamente desde Excel")
    if len(lineas) > 1001:
        raise ValueError("La importación no puede contener más de 1000 rodales")
    encabezados = [valor.strip() for valor in lineas[0].split("\t")]
    encabezados[0] = encabezados[0].lstrip("\ufeff")
    filas = [linea.split("\t") for linea in lineas[1:]]
    return _parsear_filas_rodales(encabezados, filas, pmf)


def _parsear_rodales_excel(archivo, pmf):
    from openpyxl import load_workbook
    nombre = (archivo.filename or "").lower()
    if not nombre.endswith(".xlsx"):
        raise ValueError("Seleccione un archivo Excel con extensión .xlsx")
    libro = load_workbook(archivo, read_only=True, data_only=True)
    try:
        hoja = libro.active
        if hoja.max_row > 1001:
            raise ValueError("La importación no puede contener más de 1000 rodales")
        filas = hoja.iter_rows(values_only=True)
        encabezados = next(filas, None)
        if not encabezados:
            raise ValueError("El archivo Excel está vacío")
        return _parsear_filas_rodales(encabezados, filas, pmf)
    finally:
        libro.close()

@app.route("/rodales")
def listar_rodales():
    pmf = get_pmf()
    return render_template("rodales/listar.html", pmf=pmf)


@app.route("/rodales/agregar", methods=["POST"])
def agregar_rodal():
    pmf = get_pmf()
    try:
        rid = request.form.get("id", "").strip()
        if pmf.buscar_rodal(rid):
            flash(f"Ya existe un rodal con ID '{rid}'", "error")
            return redirect(url_for("listar_rodales"))
        sup = float(request.form.get("superficie_ha", 0))
        if sup <= 0:
            raise ValueError("La superficie debe ser mayor que cero")
        tipo_inventario = request.form.get("tipo_inventario", "sitios").strip()
        if tipo_inventario not in ("sitios", "censo_total", "existencias"):
            raise ValueError("Seleccione un tipo de inventario válido")
        sit = 0 if tipo_inventario in ("censo_total", "existencias") else int(request.form.get("sitios", 1))
        area_sit = 0 if tipo_inventario in ("censo_total", "existencias") else float(
            request.form.get("area_sitio_m2", pmf.area_sitio_m2 or 500))
        tipo = request.form.get("tipo_bosque", "").strip()
        calidad = request.form.get("calidad_sitio", "Media").strip()
        despues_de = request.form.get("despues_de", "").strip() or None
        pmf.agregar_rodal(Rodal(id=rid, superficie_ha=sup, sitios=sit,
                                 area_sitio_m2=area_sit, tipo_bosque=tipo,
                                 calidad_sitio=calidad, tipo_inventario=tipo_inventario), despues_de=despues_de)
        save_pmf(pmf)
        flash(f"Rodal {rid} agregado", "success")
    except Exception as e:
        flash(f"Error: {e}", "error")
    return redirect(url_for("listar_rodales"))


@app.route("/rodales/importar", methods=["POST"])
def importar_rodales():
    pmf = get_pmf()
    modo = request.form.get("modo", "").strip()
    try:
        sitios_lote = request.form.get("sitios_lote", "").strip()
        area_sitio_lote = request.form.get("area_sitio_m2_lote", "").strip()
        if sitios_lote or area_sitio_lote:
            if not sitios_lote or not area_sitio_lote:
                raise ValueError("Indique el número de sitios y el tamaño del sitio.")
            sitios_lote_num = float(sitios_lote)
            area_sitio_lote_num = float(area_sitio_lote)
            if sitios_lote_num <= 0 or not sitios_lote_num.is_integer():
                raise ValueError("El número de sitios debe ser un entero mayor que cero.")
            if area_sitio_lote_num <= 0:
                raise ValueError("El tamaño del sitio debe ser mayor que cero.")
            sitios_lote_num = int(sitios_lote_num)
        else:
            sitios_lote_num = None
            area_sitio_lote_num = None
        if modo == "pegado":
            rodales = _parsear_rodales_pegados(request.form.get("texto", ""), pmf)
        elif modo == "excel":
            archivo = request.files.get("archivo")
            if not archivo or not archivo.filename:
                raise ValueError("Seleccione un archivo Excel para importar")
            rodales = _parsear_rodales_excel(archivo, pmf)
        else:
            raise ValueError("Seleccione un método de importación válido")
    except (ValueError, TypeError, OSError) as exc:
        return jsonify({"error": str(exc)}), 400

    if sitios_lote_num is not None:
        for datos in rodales:
            datos["sitios"] = sitios_lote_num
            datos["area_sitio_m2"] = area_sitio_lote_num

    nuevos = [rodal for rodal in rodales if not rodal["existente"]]
    if request.form.get("confirmar") != "true":
        return jsonify({
            "success": True, "vista_previa": True, "rodales": rodales,
            "total": len(rodales), "nuevos": len(nuevos),
            "existentes": len(rodales) - len(nuevos),
        })

    for datos in nuevos:
        pmf.agregar_rodal(Rodal(
            id=datos["id"], superficie_ha=datos["superficie_ha"],
            sitios=datos["sitios"], area_sitio_m2=datos["area_sitio_m2"],
        ))
    if nuevos:
        save_pmf(pmf)
    return jsonify({
        "success": True, "importados": len(nuevos),
        "omitidos": len(rodales) - len(nuevos), "rodales": rodales,
    })


@app.route("/rodales/factor-correccion", methods=["POST"])
def guardar_factor_correccion_general():
    pmf = get_pmf()
    try:
        usar = request.form.get("usar_factor_ajuste") == "on"
        valor = request.form.get("factor_ajuste", "").strip()
        if usar:
            if not valor:
                raise ValueError("Capture el factor de corrección general")
            factor = float(valor)
            if not math.isfinite(factor) or factor <= 0:
                raise ValueError("El factor de corrección debe ser finito y mayor que cero")
            pmf.factor_ajuste = factor
        else:
            pmf.factor_ajuste = 0
        pmf.usar_factor_ajuste = usar
        for rodal in pmf.rodales:
            rodal.factor_correccion = None
        save_pmf(pmf)
        flash("Factor de corrección general actualizado para todos los rodales", "success")
    except (TypeError, ValueError) as exc:
        flash(str(exc), "error")
    return redirect(url_for("listar_rodales"))


@app.route("/rodales/editar/<rid>", methods=["POST"])
def editar_rodal(rid):
    pmf = get_pmf()
    r = pmf.buscar_rodal(rid)
    if not r:
        flash("Rodal no encontrado", "error")
        return redirect(url_for("listar_rodales"))
    try:
        nuevo_id = request.form.get("id", "").strip()
        sup = request.form.get("superficie_ha", "").strip()
        sit = request.form.get("sitios", "").strip()
        area_sit = request.form.get("area_sitio_m2", "").strip()
        tipo_inventario = request.form.get("tipo_inventario", "sitios").strip()
        tipo = request.form.get("tipo_bosque", "").strip()
        calidad = request.form.get("calidad_sitio", "").strip()
        if not nuevo_id:
            raise ValueError("El nombre del rodal es obligatorio")
        pmf.renombrar_rodal(rid, nuevo_id)
        if tipo_inventario not in ("sitios", "censo_total", "existencias"):
            raise ValueError("Seleccione un tipo de inventario válido")
        r.tipo_inventario = tipo_inventario
        if sup:
            superficie = float(sup)
            if superficie <= 0:
                raise ValueError("La superficie debe ser mayor que cero")
            r.superficie_ha = superficie
        if tipo_inventario in ("censo_total", "existencias"):
            r.sitios = 0
            r.area_sitio_m2 = 0
        elif sit:
            r.sitios = int(sit)
        if tipo_inventario == "sitios" and area_sit:
            r.area_sitio_m2 = float(area_sit)
        if tipo:
            r.tipo_bosque = tipo
        if calidad:
            r.calidad_sitio = calidad
        save_pmf(pmf)
        flash(f"Rodal actualizado: {rid} → {r.id}", "success")
    except Exception as e:
        flash(f"Error: {e}", "error")
    return redirect(url_for("listar_rodales"))


@app.route("/rodales/ocultar/<rid>", methods=["POST"])
def ocultar_rodal(rid):
    pmf = get_pmf()
    rodal = pmf.buscar_rodal(rid)
    if not rodal:
        flash("Rodal no encontrado", "error")
    else:
        rodal.oculto = not rodal.oculto
        pmf.rodales_aclareo = [seleccionado for seleccionado in pmf.rodales_aclareo
                                if seleccionado.casefold() != rodal.id.casefold() or not rodal.oculto]
        save_pmf(pmf)
        accion = "oculto y excluido de cálculos" if rodal.oculto else "restaurado para cálculos"
        flash(f"Rodal {rodal.id}: {accion}", "success")
    return redirect(url_for("listar_rodales"))


@app.route("/rodales/eliminar/<rid>")
def eliminar_rodal(rid):
    pmf = get_pmf()
    if pmf.eliminar_rodal(rid):
        save_pmf(pmf)
        flash(f"Rodal {rid} eliminado", "success")
    else:
        flash("Rodal no encontrado", "error")
    return redirect(url_for("listar_rodales"))


# =============== ESPECIES ===============

@app.route("/especies")
def listar_especies():
    pmf = get_pmf()
    return render_template("especies/listar.html", pmf=pmf,
                           nueva_especie=request.args.get("nueva", "").strip(),
                           volver=request.args.get("volver", "").strip())


@app.route("/especies/agregar", methods=["POST"])
def agregar_especie():
    pmf = get_pmf()
    nombre = request.form.get("nombre", "").strip()
    if not nombre:
        flash("Nombre invalido", "error")
        return redirect(url_for("listar_especies"))
    pmf.agregar_especie(nombre)
    save_pmf(pmf)
    flash(f"Especie '{nombre}' agregada", "success")
    volver = request.form.get("volver", "").strip()
    if volver.startswith("/") and not volver.startswith("//"):
        return redirect(volver)
    return redirect(url_for("listar_especies"))


@app.route("/especies/eliminar/<nombre>")
def eliminar_especie(nombre):
    pmf = get_pmf()
    if pmf.eliminar_especie(nombre):
        pmf.eliminar_ecuacion(nombre)
        save_pmf(pmf)
        flash(f"Especie '{nombre}' eliminada", "success")
    else:
        flash("Especie no encontrada", "error")
    return redirect(url_for("listar_especies"))


@app.route("/especies/asignar_ecuacion", methods=["POST"])
def asignar_ecuacion():
    pmf = get_pmf()
    esp = request.form.get("especie", "").strip()
    try:
        a0 = float(request.form.get("a0", 0.0001))
        a1 = float(request.form.get("a1", 1.8))
        a2 = float(request.form.get("a2", 0.9))
        b0 = float(request.form.get("b0", 0.0))
        ec = EcuacionVolumen(a0=a0, a1=a1, a2=a2, b0=b0, especie=esp)
        pmf.asignar_ecuacion(esp, ec)
        save_pmf(pmf)
        flash(f"Ecuacion asignada a '{esp}'", "success")
    except Exception as e:
        flash(f"Error: {e}", "error")
    return redirect(url_for("listar_especies"))


@app.route("/especies/cargar_predeterminadas")
def cargar_predeterminadas():
    pmf = get_pmf()
    count = 0
    for especie, params in _ECUACIONES_PREDET.items():
        pmf.agregar_especie(especie)
        ec = EcuacionVolumen(a0=params['a0'], a1=params['a1'],
                              a2=params['a2'], b0=params['b0'], especie=especie)
        pmf.asignar_ecuacion(especie, ec)
        count += 1
    save_pmf(pmf)
    flash(f"{count} ecuaciones predeterminadas cargadas", "success")
    return redirect(url_for("listar_especies"))


@app.route("/crecimiento/cargar_tp_predeterminadas")
def cargar_tp_predeterminadas():
    pmf = get_pmf()
    count = pmf.cargar_tp_predeterminadas()
    save_pmf(pmf)
    flash(f"{count} ecuaciones de T.P. predeterminadas cargadas", "success")
    return redirect(url_for("listar_tp"))


@app.route("/crecimiento/cargar_edad_predeterminadas")
def cargar_edad_predeterminadas():
    pmf = get_pmf()
    count = pmf.cargar_edad_predeterminadas()
    save_pmf(pmf)
    flash(f"{count} ecuaciones de Edad predeterminadas cargadas", "success")
    return redirect(url_for("listar_tp"))


# =============== INVENTARIO POR RODAL (CLASES) ===============

_ENCABEZADO_INVENTARIO_RE = re.compile(r"^(.+?)\s*\((ARB|ALT)\)\s*$", re.IGNORECASE)


def _normalizar_nombre_especie(nombre):
    return " ".join(nombre.strip().split()).casefold()


def _numero_importado(valor, fila, columna, entero=False):
    texto = str(valor).strip()
    if not texto:
        return 0
    try:
        numero = float(texto.replace(",", "."))
    except ValueError:
        raise ValueError(f"Fila {fila}, {columna}: valor no numérico '{texto}'")
    if not math.isfinite(numero) or numero < 0:
        raise ValueError(f"Fila {fila}, {columna}: el valor debe ser mayor o igual que cero")
    if entero:
        if not numero.is_integer():
            raise ValueError(f"Fila {fila}, {columna}: el número de árboles debe ser entero")
        return int(numero)
    return numero


def _parsear_inventario_pegado(texto, pmf, censo_total=False):
    if not isinstance(texto, str) or not texto.strip():
        raise ValueError("Pegue la tabla copiada desde Excel")
    if len(texto) > 1_000_000:
        raise ValueError("La tabla pegada supera el tamaño permitido")
    lineas = [linea.rstrip("\r") for linea in texto.splitlines() if linea.strip()]
    if len(lineas) < 2:
        raise ValueError("La tabla debe incluir encabezados y al menos una fila de datos")
    if len(lineas) > 501:
        raise ValueError("La tabla no puede contener más de 500 filas de datos")
    if "\t" not in lineas[0]:
        raise ValueError("Copie y pegue las celdas directamente desde Excel")

    encabezados = [celda.strip() for celda in lineas[0].split("\t")]
    encabezados[0] = encabezados[0].lstrip("\ufeff")
    if encabezados[0].upper() not in {"CD", "DNCC"}:
        raise ValueError("La primera columna debe llamarse CD")
    if len(encabezados) < 3 or (len(encabezados) - 1) % 2 != 0:
        raise ValueError("Después de CD deben existir pares Especie (ARB) y Especie (ALT)")

    catalogo = {_normalizar_nombre_especie(especie): especie for especie in pmf.especies}
    pares = []
    desconocidas = []
    especies_encabezado = set()
    for indice in range(1, len(encabezados), 2):
        arb = _ENCABEZADO_INVENTARIO_RE.match(encabezados[indice])
        alt = _ENCABEZADO_INVENTARIO_RE.match(encabezados[indice + 1])
        if not arb or arb.group(2).upper() != "ARB":
            raise ValueError(f"La columna {indice + 1} debe terminar en (ARB)")
        if not alt or alt.group(2).upper() != "ALT":
            raise ValueError(f"La columna {indice + 2} debe terminar en (ALT)")
        nombre_arb = " ".join(arb.group(1).split())
        nombre_alt = " ".join(alt.group(1).split())
        normalizado = _normalizar_nombre_especie(nombre_arb)
        if normalizado != _normalizar_nombre_especie(nombre_alt):
            raise ValueError(f"Las columnas {indice + 1} y {indice + 2} no pertenecen a la misma especie")
        if normalizado in especies_encabezado:
            raise ValueError(f"La especie '{nombre_arb}' aparece más de una vez")
        especies_encabezado.add(normalizado)
        especie = catalogo.get(normalizado)
        if not especie:
            desconocidas.append(nombre_arb)
            especie = nombre_arb
        pares.append((indice, especie))

    clases_por_especie = {especie: [] for _, especie in pares}
    cds = set()
    advertencias = []
    for numero_fila, linea in enumerate(lineas[1:], start=2):
        celdas = linea.split("\t")
        if len(celdas) < len(encabezados):
            celdas.extend([""] * (len(encabezados) - len(celdas)))
        if len(celdas) > len(encabezados) and any(celda.strip() for celda in celdas[len(encabezados):]):
            raise ValueError(f"Fila {numero_fila}: contiene columnas adicionales")
        try:
            cd_numero = float(celdas[0].strip().replace(",", "."))
        except ValueError:
            raise ValueError(f"Fila {numero_fila}: CD no es numérico")
        if not math.isfinite(cd_numero) or cd_numero <= 0:
            raise ValueError(f"Fila {numero_fila}: CD debe ser mayor que cero")
        cd = int(cd_numero) if cd_numero.is_integer() else cd_numero
        if censo_total and cd not in CENSO_DNCC:
            raise ValueError(f"Fila {numero_fila}: CD debe ser una categoría de 10 a 100 cm")
        if not censo_total and (cd < 5 or cd > 100 or not math.isclose(cd_numero % 5, 0, abs_tol=1e-9)):
            advertencias.append(
                f"CD {cd:g} no coincide con las categorías estándar de 5 en 5; se usará como diámetro real."
            )
        if cd in cds and not censo_total:
            raise ValueError(f"Fila {numero_fila}: la clase CD {cd} está repetida")
        cds.add(cd)
        for indice, especie in pares:
            arboles = _numero_importado(celdas[indice], numero_fila,
                                        f"{especie} (ARB)", entero=True)
            altura = _numero_importado(celdas[indice + 1], numero_fila,
                                        f"{especie} (ALT)")
            if censo_total and arboles > 0 and altura not in CENSO_ALTURAS:
                raise ValueError(f"Fila {numero_fila}, {especie} (ALT): use una categoría de altura de 5 a 35 m")
            clases_por_especie[especie].append(
                {"dncc": cd, "altura_m": altura, "no_arboles": arboles}
            )
    for clases in clases_por_especie.values():
        clases.sort(key=lambda clase: clase["dncc"])
    return {"clases": clases_por_especie, "desconocidas": desconocidas,
            "filas": len(cds), "advertencias": advertencias}


def _capa_cartografia_actual():
    return get_pmf().cartografia or None


@app.route("/superficies", methods=["GET", "POST"])
def superficies():
    pmf = get_pmf()
    if request.method == "POST":
        try:
            pmf.superficies = leer_captura(request.form)
            if not save_pmf(pmf):
                raise OSError("No fue posible guardar la captura de superficies.")
            flash("Cuadro de superficies guardado.", "success")
        except (OSError, ValueError) as exc:
            flash(str(exc), "error")
    cuadro = calcular_cuadro(pmf.superficies)
    ia_contexto = None
    if any(fila.get("anterior") or fila.get("actual") for fila in cuadro.get("filas", [])):
        ia_contexto = {
            "clasificacion": [
                {
                    "clave": fila.get("clave"), "nombre": fila.get("nombre"),
                    "nivel": fila.get("nivel"),
                    "anterior_ha": fila.get("anterior"), "actual_ha": fila.get("actual"),
                    "variacion_ha": fila.get("variacion"),
                    "porcentaje_actual": fila.get("porcentaje_actual"),
                    "porcentaje_variacion": fila.get("porcentaje_variacion"),
                }
                for fila in cuadro.get("filas", [])
            ],
        }
    return render_template("superficies/index.html", cuadro=cuadro,
                           formato_superficie=formato_numero,
                           ia_tipo="superficies", ia_contexto=ia_contexto)


@app.route("/superficies/exportar-excel", methods=["POST"])
def exportar_superficies_excel():
    try:
        cuadro = calcular_cuadro(leer_captura(request.form))
    except ValueError as exc:
        flash(str(exc), "error")
        return redirect(url_for("superficies"))
    return send_file(exportar_excel(cuadro), as_attachment=True,
                     download_name="cuadro_superficies.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/superficies/reporte-word", methods=["POST"])
def reporte_superficies_word():
    try:
        cuadro = calcular_cuadro(leer_captura(request.form))
    except ValueError as exc:
        flash(str(exc), "error")
        return redirect(url_for("superficies"))
    pmf = get_pmf()
    return send_file(generar_word_superficies(pmf, cuadro), as_attachment=True,
                     download_name="reporte_superficies.docx",
                     mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")


def _datos_cartografia_por_rodal(pmf, capa):
    """Prepara para el visor resultados existentes, sin alterar el proyecto."""
    campo = capa.get("campo_rodal", "") if capa else ""
    if not campo:
        return {}, None

    rodales = {str(rodal.id): rodal for rodal in pmf.rodales}
    existencias = {}
    for fila in pmf.cuadro_existencias().get("filas", []):
        if fila.get("_type") == "subtotal":
            continue
        resumen = existencias.setdefault(str(fila["rodal"]), {
            "existencias_m3": 0.0, "volumen_ha_m3": 0.0, "area_basal_ha_m2": 0.0,
        })
        resumen["existencias_m3"] += float(fila.get("vol_umm", 0) or 0)
        resumen["volumen_ha_m3"] += float(fila.get("vol_ha", 0) or 0)
        resumen["area_basal_ha_m2"] += float(fila.get("ab", 0) or 0)

    incrementos = {}
    for fila in pmf.resumen_incrementos().get("filas", []):
        if fila.get("_type") == "subtotal":
            continue
        incrementos[str(fila["rodal"])] = incrementos.get(str(fila["rodal"]), 0.0) + float(fila.get("arb_ha", 0) or 0)

    tratamientos = {}
    for intervencion in pmf.plan_cortas.intervenciones:
        tratamientos.setdefault(str(intervencion.rodal_id), []).append(intervencion.tratamiento)

    errores = {}
    if pmf.muestreo_error:
        for resultado in pmf.muestreo_error[-1].get("resultado", {}).get("rodales", []):
            clave = str(resultado.get("clave", ""))
            estadistica = resultado.get("estadistica", {})
            if clave and estadistica:
                errores[clave] = {
                    "error_muestreo_pct": estadistica.get("error_relativo_pct"),
                    "estado_error_muestreo": estadistica.get("estado"),
                }

    identificadores_capa = []
    datos = {}
    for indice, feature in enumerate(capa.get("features", [])):
        valor = feature.get("properties", {}).get(campo)
        if valor is None:
            continue
        identificador = str(valor)
        identificadores_capa.append(identificador)
        rodal = rodales.get(identificador)
        if not rodal:
            continue
        datos_rodal = {"identificador": identificador, "superficie_ha": rodal.superficie_ha}
        datos_rodal.update(existencias.get(identificador, {}))
        if identificador in incrementos:
            datos_rodal["arboles_ha"] = incrementos[identificador]
        intensidades = pmf.intensidad_corta.get(rodal.id, {})
        if intensidades:
            datos_rodal["intensidad_corta"] = [
                {"especie": especie, "porcentaje": porcentaje}
                for especie, porcentaje in intensidades.items()
            ]
        if identificador in tratamientos:
            datos_rodal["tratamientos"] = tratamientos[identificador]
        datos_rodal.update(errores.get(identificador, {}))
        datos[indice] = datos_rodal

    ids_capa = set(identificadores_capa)
    validacion = {
        "enlazados": sorted({datos[indice]["identificador"] for indice in datos}),
        "sin_simfi": sorted(ids_capa - set(rodales)),
        "sin_capa": sorted(set(rodales) - ids_capa),
    }
    return datos, validacion


@app.route("/cartografia", methods=["GET", "POST"])
def cartografia():
    if request.method == "POST":
        archivo = request.files.get("capa")
        if not archivo or not archivo.filename:
            flash("Seleccione una capa GeoJSON, KML o ZIP-SHP.", "error")
            return redirect(url_for("cartografia"))
        try:
            capa = cargar_capa(archivo.filename, archivo.read())
            capa["campo_rodal"] = ""
            pmf = get_pmf()
            pmf.cartografia = capa
            if not save_pmf(pmf):
                raise OSError("No fue posible guardar la capa en el proyecto.")
            flash(f"Capa guardada en el proyecto: {len(capa['features'])} polígono(s).", "success")
        except (OSError, ValueError) as exc:
            flash(str(exc), "error")
        return redirect(url_for("cartografia"))
    pmf = get_pmf()
    capa = pmf.cartografia or None
    datos_rodales, validacion_enlace = _datos_cartografia_por_rodal(pmf, capa)
    return render_template("cartografia/index.html", capa=capa,
                            campos=campos_atributos(capa) if capa else [],
                            capa_geografica=geometria_geografica(capa) if capa else False,
                            datos_rodales=datos_rodales,
                            validacion_enlace=validacion_enlace)


@app.route("/cartografia/campo-rodal", methods=["POST"])
def cartografia_campo_rodal():
    pmf = get_pmf()
    capa = pmf.cartografia
    if not capa:
        flash("Cargue primero una capa de rodales.", "error")
    else:
        campo = request.form.get("campo_rodal", "")
        capa["campo_rodal"] = campo if campo in campos_atributos(capa) else ""
        if save_pmf(pmf):
            flash("Campo identificador de rodal actualizado.", "success")
        else:
            flash("No fue posible guardar el campo identificador en el proyecto.", "error")
    return redirect(url_for("cartografia"))


@app.route("/cartografia/limpiar", methods=["POST"])
def cartografia_limpiar():
    pmf = get_pmf()
    pmf.cartografia = {}
    if save_pmf(pmf):
        flash("La capa fue retirada del proyecto.", "success")
    else:
        flash("No fue posible retirar la capa del proyecto.", "error")
    return redirect(url_for("cartografia"))


@app.route("/cartografia/exportar", methods=["POST"])
def cartografia_exportar():
    from io import BytesIO
    pmf = get_pmf()
    capa = pmf.cartografia
    if not capa:
        flash("Cargue primero una capa de rodales.", "error")
        return redirect(url_for("cartografia"))
    if not capa.get("campo_rodal"):
        flash("Para exportar es necesario seleccionar primero el campo identificador de rodal.", "error")
        return redirect(url_for("cartografia"))
    formato = request.form.get("formato", "geojson")
    datos, _ = _datos_cartografia_por_rodal(pmf, capa)
    if capa.get("crs_identificado") == "No identificado" and formato == "shp":
        flash("La capa original no tiene CRS identificado: la exportación Shapefile no incluirá archivo .prj.", "warning")
    base = re.sub(r"[^A-Za-z0-9_.-]", "_", (capa.get("nombre") or "capa").rsplit(".", 1)[0]) or "capa"
    try:
        if formato == "shp":
            contenido = exportar_shp_zip(capa, datos)
            return send_file(BytesIO(contenido), as_attachment=True,
                             download_name=base + "_parametros_rodal.zip", mimetype="application/zip")
        if formato == "xlsx":
            contenido = exportar_excel_atributos(capa, datos, FIRMA_EXPORTACION)
            return send_file(BytesIO(contenido), as_attachment=True,
                             download_name=base + "_parametros_rodal.xlsx",
                             mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        contenido = exportar_geojson(capa, datos)
        return send_file(BytesIO(contenido), as_attachment=True,
                         download_name=base + "_parametros_rodal.geojson",
                         mimetype="application/geo+json")
    except (OSError, ValueError) as exc:
        flash(str(exc), "error")
        return redirect(url_for("cartografia"))


@app.route("/inventario/rodal")
def listar_tablas():
    pmf = get_pmf()
    return render_template("inventario/tablas.html", pmf=pmf)


def _leer_censo_excel(archivo):
    from openpyxl import load_workbook
    libro = load_workbook(archivo, read_only=True, data_only=True)
    try:
        hoja = libro.active
        encabezados = next(hoja.iter_rows(min_row=1, max_row=1, values_only=True), None)
        if not encabezados:
            raise ValueError("El archivo Excel está vacío")
        normalizar = lambda valor: re.sub(r"[^a-z0-9]", "", unicodedata.normalize(
            "NFD", str(valor or "")).encode("ascii", "ignore").decode("ascii").lower())
        columnas = {normalizar(nombre): indice for indice, nombre in enumerate(encabezados)}
        dap_indice = next((columnas[nombre] for nombre in ("dap", "dapcm", "diametro", "diametrocm")
                           if nombre in columnas), None)
        altura_indice = next((columnas[nombre] for nombre in ("altura", "alturam")
                               if nombre in columnas), None)
        arboles_indice = next((columnas[nombre] for nombre in ("arboles", "noarboles", "numeroarboles")
                               if nombre in columnas), None)
        if dap_indice is None or altura_indice is None or arboles_indice is None:
            raise ValueError("El Excel debe incluir las columnas DAP (cm), Altura (m) y Árboles")
        arboles = []
        for numero_fila, fila in enumerate(hoja.iter_rows(min_row=2, values_only=True), start=2):
            if not any(valor is not None and str(valor).strip() for valor in fila):
                continue
            try:
                dap = float(str(fila[dap_indice]).replace(",", "."))
                altura = float(str(fila[altura_indice]).replace(",", "."))
                cantidad_num = float(str(fila[arboles_indice]).replace(",", "."))
                if not cantidad_num.is_integer():
                    raise ValueError
                cantidad = int(cantidad_num)
            except (TypeError, ValueError, IndexError):
                raise ValueError(f"Fila {numero_fila}: DAP, altura y árboles deben ser numéricos")
            if (not math.isfinite(dap) or not math.isfinite(altura) or dap not in CENSO_DNCC or
                    altura not in CENSO_ALTURAS or cantidad <= 0):
                raise ValueError(f"Fila {numero_fila}: use clases CD 10-100, altura 5-35 y árboles mayores que cero")
            arboles.append((dap, altura, cantidad))
        if not arboles:
            raise ValueError("El Excel no contiene árboles para importar")
        return arboles
    finally:
        libro.close()


CENSO_DNCC = tuple(range(10, 101, 5))
CENSO_ALTURAS = tuple(range(5, 36, 5))


@app.route("/inventario/censo-total")
def censo_total():
    pmf = get_pmf()
    rodales = [rodal for rodal in pmf.rodales_visibles if rodal.tipo_inventario == "censo_total"]
    rid = request.args.get("rid", "").strip()
    if rid not in {rodal.id for rodal in rodales}:
        rid = rodales[0].id if rodales else ""
    esp = request.args.get("esp", "").strip()
    if esp not in pmf.especies:
        esp = pmf.especies[0] if pmf.especies else ""
    cuadricula = {}
    for arbol in pmf.arboles_censo(rid, esp):
        if arbol.dap_cm in CENSO_DNCC and arbol.altura_m in CENSO_ALTURAS:
            cuadricula[(arbol.dap_cm, arbol.altura_m)] = cuadricula.get(
                (arbol.dap_cm, arbol.altura_m), 0) + arbol.no_arboles
    ecuacion = pmf.obtener_ecuacion(esp)
    ecuacion_json = json.dumps(asdict(ecuacion)) if ecuacion else "null"
    return render_template("inventario/censo_total.html", pmf=pmf, rodales=rodales, rid=rid,
                           esp=esp, cuadricula=cuadricula, dnccs=CENSO_DNCC,
                           alturas=CENSO_ALTURAS, ecuacion_json=ecuacion_json,
                           resumen=pmf.resumen_censo_total(rid) if rid else None)


@app.route("/inventario/censo-total/guardar/<rid>/<esp>", methods=["POST"])
def guardar_censo_total(rid, esp):
    pmf = get_pmf()
    try:
        rodal = pmf.buscar_rodal(rid)
        if not rodal or rodal.oculto or rodal.tipo_inventario != "censo_total":
            raise ValueError("Seleccione un rodal activo configurado como Censo total")
        if esp not in pmf.especies:
            raise ValueError("La especie seleccionada no está registrada")
        registros = []
        for clave, valor in request.form.items():
            if not clave.startswith("censo_") or not valor.strip():
                continue
            try:
                dap, altura = (float(numero) for numero in clave.removeprefix("censo_").split("__"))
                cantidad = int(valor)
            except ValueError:
                raise ValueError("La cuadrícula contiene un valor inválido")
            if dap not in CENSO_DNCC or altura not in CENSO_ALTURAS or cantidad < 0:
                raise ValueError("La cuadrícula contiene un valor fuera de rango")
            if cantidad:
                registros.append(ArbolCenso(rid, esp, dap, altura, no_arboles=cantidad))
        pmf.censos_totales = [arbol for arbol in pmf.censos_totales
                              if not (arbol.rodal_id.casefold() == rid.casefold() and
                                      arbol.especie.casefold() == esp.casefold())]
        pmf.censos_totales.extend(registros)
        save_pmf(pmf)
        flash(f"Cuadrícula guardada: {sum(arbol.no_arboles for arbol in registros)} árboles", "success")
    except ValueError as error:
        flash(str(error), "error")
    return redirect(url_for("censo_total", rid=rid, esp=esp))


@app.route("/inventario/censo-total/agregar", methods=["POST"])
def agregar_arbol_censo():
    pmf = get_pmf()
    rid = request.form.get("rid", "").strip()
    esp = request.form.get("esp", "").strip()
    try:
        rodal = pmf.buscar_rodal(rid)
        if not rodal or rodal.oculto:
            raise ValueError("Seleccione un rodal activo")
        if esp not in pmf.especies:
            raise ValueError("Seleccione una especie registrada")
        pmf.agregar_arbol_censo(ArbolCenso(rodal_id=rid, especie=esp,
                                            dap_cm=float(request.form.get("dap_cm", 0)),
                                            altura_m=float(request.form.get("altura_m", 0))))
        save_pmf(pmf)
        flash("Árbol registrado en el censo", "success")
    except (TypeError, ValueError) as error:
        flash(str(error), "error")
    return redirect(url_for("censo_total", rid=rid, esp=esp))


@app.route("/inventario/censo-total/importar/<rid>/<esp>", methods=["POST"])
def importar_censo_total(rid, esp):
    pmf = get_pmf()
    try:
        rodal = pmf.buscar_rodal(rid)
        if not rodal or rodal.oculto or rodal.tipo_inventario != "censo_total":
            raise ValueError("Seleccione un rodal activo configurado como Censo total")
        if esp not in pmf.especies:
            raise ValueError("La especie seleccionada no está registrada")
        archivo = request.files.get("archivo")
        if not archivo or not archivo.filename:
            raise ValueError("Seleccione un archivo Excel")
        arboles = _leer_censo_excel(archivo)
        for dap, altura, cantidad in arboles:
            pmf.agregar_arbol_censo(ArbolCenso(rodal_id=rid, especie=esp, dap_cm=dap,
                                                altura_m=altura, no_arboles=cantidad))
        save_pmf(pmf)
        return jsonify({"success": True, "importados": len(arboles)})
    except (OSError, TypeError, ValueError) as error:
        return jsonify({"error": str(error)}), 400


@app.route("/inventario/censo-total/importar-datos/<rid>", methods=["POST"])
def importar_datos_censo_total(rid):
    pmf = get_pmf()
    rodal = pmf.buscar_rodal(rid)
    if not rodal or rodal.oculto or rodal.tipo_inventario != "censo_total":
        return jsonify({"error": "Seleccione un rodal activo configurado como Censo total"}), 400
    datos = request.get_json(silent=True) or {}
    try:
        resultado = _parsear_inventario_pegado(datos.get("texto", ""), pmf, censo_total=True)
    except ValueError as error:
        return jsonify({"error": str(error)}), 400
    if resultado["desconocidas"]:
        primera = resultado["desconocidas"][0]
        return jsonify({
            "error": "Hay especies que no están registradas en el catálogo",
            "especies_desconocidas": resultado["desconocidas"],
            "registrar_url": url_for("listar_especies", nueva=primera,
                                     volver=url_for("censo_total", rid=rid)),
        }), 400

    especies = []
    for especie, clases in resultado["clases"].items():
        existentes = pmf.arboles_censo(rid, especie)
        especies.append({
            "especie": especie,
            "arboles_pegados": sum(clase["no_arboles"] for clase in clases),
            "arboles_simfi": sum(arbol.no_arboles for arbol in existentes),
            "reemplaza": bool(existentes),
        })
    if not datos.get("confirmar"):
        return jsonify({"success": True, "vista_previa": True,
                        "filas": resultado["filas"], "especies": especies})

    especies_importadas = {especie.casefold() for especie in resultado["clases"]}
    pmf.censos_totales = [arbol for arbol in pmf.censos_totales
                          if not (arbol.rodal_id.casefold() == rid.casefold() and
                                  arbol.especie.casefold() in especies_importadas)]
    for especie, clases in resultado["clases"].items():
        celdas = {}
        for clase in clases:
            if clase["no_arboles"] <= 0:
                continue
            clave = (clase["dncc"], clase["altura_m"])
            celdas[clave] = celdas.get(clave, 0) + clase["no_arboles"]
        for (dap, altura), cantidad in celdas.items():
            pmf.agregar_arbol_censo(ArbolCenso(rid, especie, dap, altura, no_arboles=cantidad))
    save_pmf(pmf)
    return jsonify({"success": True, "importadas": len(especies), "especies": especies})


@app.route("/inventario/censo-total/eliminar/<arbol_id>", methods=["POST"])
def eliminar_arbol_censo(arbol_id):
    pmf = get_pmf()
    rid = request.form.get("rid", "").strip()
    esp = request.form.get("esp", "").strip()
    if pmf.eliminar_arbol_censo(arbol_id):
        save_pmf(pmf)
        flash("Árbol eliminado del censo", "success")
    else:
        flash("Registro de árbol no encontrado", "error")
    return redirect(url_for("censo_total", rid=rid, esp=esp))


@app.route("/inventario/rodal/importar_pegado/<rid>", methods=["POST"])
def importar_inventario_pegado(rid):
    pmf = get_pmf()
    rodal = pmf.buscar_rodal(rid)
    if not rodal:
        return jsonify({"error": "El rodal seleccionado no existe"}), 404
    if rodal.tipo_inventario == "existencias":
        return jsonify({"error": "El rodal es de valores de existencias: capturelos en su pantalla."}), 400
    datos = request.get_json(silent=True) or {}
    try:
        sitios = float(datos.get("sitios", ""))
        area_sitio_m2 = float(datos.get("area_sitio_m2", ""))
    except (TypeError, ValueError):
        return jsonify({"error": "Indique el número de sitios y el área por sitio."}), 400
    if sitios <= 0 or not sitios.is_integer():
        return jsonify({"error": "El número de sitios debe ser un entero mayor que cero."}), 400
    if area_sitio_m2 <= 0:
        return jsonify({"error": "El área por sitio debe ser mayor que cero."}), 400
    sitios = int(sitios)
    try:
        resultado = _parsear_inventario_pegado(datos.get("texto", ""), pmf)
    except ValueError as error:
        return jsonify({"error": str(error)}), 400
    if resultado["desconocidas"]:
        primera = resultado["desconocidas"][0]
        return jsonify({
            "error": "Hay especies que no están registradas en el catálogo",
            "especies_desconocidas": resultado["desconocidas"],
            "registrar_url": url_for("listar_especies", nueva=primera,
                                     volver=url_for("listar_tablas")),
        }), 400

    resumen = []
    for especie, clases in resultado["clases"].items():
        existentes = [tabla for tabla in pmf.tablas_inventario
                       if tabla.rodal_id.casefold() == rid.casefold() and
                       tabla.especie.casefold() == especie.casefold()]
        resumen.append({
            "especie": especie,
            "arboles_pegados": sum(clase["no_arboles"] for clase in clases),
            "arboles_simfi": sum(clase.no_arboles for tabla in existentes for clase in tabla.clases),
            "reemplaza": bool(existentes),
        })
    if not datos.get("confirmar"):
        return jsonify({"success": True, "vista_previa": True,
                        "filas": resultado["filas"], "especies": resumen,
                        "advertencias": resultado["advertencias"],
                        "sitios": sitios, "area_sitio_m2": area_sitio_m2})

    rodal.sitios = sitios
    rodal.area_sitio_m2 = area_sitio_m2
    for especie, clases in resultado["clases"].items():
        coincidencias = [tabla for tabla in pmf.tablas_inventario
                         if tabla.rodal_id.casefold() == rid.casefold() and
                         tabla.especie.casefold() == especie.casefold()]
        if coincidencias:
            tabla = coincidencias[0]
            for duplicada in coincidencias[1:]:
                pmf.tablas_inventario.remove(duplicada)
        else:
            tabla = TablaInventarioRodal(rodal_id=rid, especie=especie)
            pmf.agregar_tabla_inventario(tabla)
        tabla.clases = [ClaseDiametrica(**clase) for clase in clases]
    save_pmf(pmf)
    return jsonify({"success": True, "importadas": len(resumen),
                    "filas": resultado["filas"], "especies": resumen,
                    "advertencias": resultado["advertencias"]})


@app.route("/inventario/existencias/<rid>")
def captura_existencias(rid):
    """Pantalla de captura de valores directos (rodales tipo existencias).

    Acepta ?esp=<especie>&grupo=<existencias|incrementos> para preseleccionar.
    """
    pmf = get_pmf()
    rodal = pmf.buscar_rodal(rid)
    if not rodal or rodal.oculto:
        flash("Rodal no encontrado", "error")
        return redirect(url_for("listar_tablas"))
    if rodal.tipo_inventario != "existencias":
        return redirect(url_for("listar_tablas"))
    especies = sorted(pmf.especies)
    esp_sel = request.args.get("esp", "").strip()
    if esp_sel not in especies:
        esp_sel = especies[0] if especies else ""
    grupo = request.args.get("grupo", "").strip()
    if grupo not in ("existencias", "incrementos"):
        grupo = "existencias"
    valores_existencias = {}
    for registro in pmf.existencias_directas:
        if registro.rodal_id.casefold() == rid.casefold():
            valores_existencias[registro.especie] = registro
    valores_incrementos = {}
    for registro in pmf.incrementos_directos:
        if registro.rodal_id.casefold() == rid.casefold():
            valores_incrementos[registro.especie] = registro
    return render_template("inventario/existencias.html", pmf=pmf, rodal=rodal,
                           especies=especies, esp_sel=esp_sel, grupo=grupo,
                           valores_existencias=valores_existencias,
                           valores_incrementos=valores_incrementos,
                           con_existencias=set(valores_existencias),
                           con_incrementos=set(valores_incrementos))


@app.route("/inventario/existencias/<rid>/guardar", methods=["POST"])
def guardar_existencias(rid):
    """Guarda valores directos del grupo indicado (existencias o incrementos).

    Todo vacio elimina el registro del grupo. Los ceros explicitos se guardan.
    """
    pmf = get_pmf()
    rodal = pmf.buscar_rodal(rid)
    if not rodal or rodal.oculto or rodal.tipo_inventario != "existencias":
        flash("Rodal no encontrado o no es de valores de existencias", "error")
        return redirect(url_for("listar_tablas"))
    grupo = request.form.get("grupo", "existencias").strip()
    if grupo not in ("existencias", "incrementos"):
        grupo = "existencias"
    try:
        if grupo == "existencias":
            guardados = eliminados = 0
            for especie in pmf.especies:
                valores = {campo: request.form.get("%s_%s" % (campo, especie), "").strip()
                           if "%s_%s" % (campo, especie) in request.form else ""
                           for campo in ("arb", "ab", "vol")}
                if not any("%s_%s" % (campo, especie) in request.form
                           for campo in ("arb", "ab", "vol")):
                    continue
                if not any(valores.values()):
                    existente = pmf.buscar_existencia_directa(rid, especie)
                    if existente:
                        pmf.existencias_directas.remove(existente)
                        eliminados += 1
                    continue
                pmf.fijar_existencia_directa(rid, especie, valores["arb"] or "0",
                                             valores["ab"] or "0", valores["vol"] or "0")
                guardados += 1
            mensaje = "Valores de existencias guardados"
        else:
            guardados = eliminados = 0
            for especie in pmf.especies:
                valores = {campo: request.form.get("%s_%s" % (campo, especie), "").strip()
                           if "%s_%s" % (campo, especie) in request.form else ""
                           for campo in ("arb", "ab", "tp", "ica", "icapct", "ima",
                                         "edad", "dq", "h")}
                if not any("%s_%s" % (campo, especie) in request.form
                           for campo in ("arb", "ab", "tp", "ica", "icapct", "ima",
                                         "edad", "dq", "h")):
                    continue
                if not any(valores.values()):
                    if pmf.eliminar_incremento_directo(rid, especie):
                        eliminados += 1
                    continue
                pmf.fijar_incremento_directo(
                    rid, especie, valores["arb"] or "0", valores["ab"] or "0",
                    tp=valores["tp"], ica_ha=valores["ica"], ica_pct=valores["icapct"],
                    ima_ha=valores["ima"], edad=valores["edad"],
                    dq_cm=valores["dq"], h_m=valores["h"])
                guardados += 1
            mensaje = "Valores de incrementos guardados"
    except ValueError as error:
        flash(str(error), "error")
        return redirect(url_for("captura_existencias", rid=rid, grupo=grupo,
                               esp=request.form.get("especie_sel", "")))
    if not save_pmf(pmf):
        flash("No se pudo guardar el proyecto", "error")
    else:
        if eliminados and not guardados:
            mensaje = "Valores eliminados"
        flash(mensaje, "success")
    return redirect(url_for("captura_existencias", rid=rid, grupo=grupo,
                            esp=request.form.get("especie_sel", "")))


@app.route("/inventario/existencias/<rid>/eliminar/<grupo>/<esp>")
def eliminar_valores_directos(rid, grupo, esp):
    """Elimina los valores directos del grupo indicado, con confirmacion en UI."""
    pmf = get_pmf()
    rodal = pmf.buscar_rodal(rid)
    if not rodal or rodal.oculto or rodal.tipo_inventario != "existencias":
        flash("Rodal no encontrado o no es de valores de existencias", "error")
        return redirect(url_for("listar_tablas"))
    if grupo == "existencias":
        existente = pmf.buscar_existencia_directa(rid, esp)
        if existente:
            pmf.existencias_directas.remove(existente)
    elif grupo == "incrementos":
        pmf.eliminar_incremento_directo(rid, esp)
    else:
        flash("Grupo no reconocido", "error")
        return redirect(url_for("captura_existencias", rid=rid))
    if not save_pmf(pmf):
        flash("No se pudo guardar el proyecto", "error")
    else:
        flash("Valores eliminados", "success")
    return redirect(url_for("captura_existencias", rid=rid, grupo=grupo
                            if grupo in ("existencias", "incrementos") else "existencias"))


@app.route("/inventario/rodal/editar/<rid>/<esp>")
def editar_tabla(rid, esp):
    pmf = get_pmf()
    rodal = pmf.buscar_rodal(rid)
    if rodal and rodal.tipo_inventario == "censo_total":
        return redirect(url_for("censo_total", rid=rid, esp=esp))
    if rodal and rodal.tipo_inventario == "existencias":
        return redirect(url_for("captura_existencias", rid=rid))
    tabla = pmf.buscar_tabla_inventario(rid, esp)
    if not tabla:
        tabla = TablaInventarioRodal(rodal_id=rid, especie=esp)
        pmf.agregar_tabla_inventario(tabla)
        save_pmf(pmf)
    num_sitios = rodal.sitios if rodal else 1
    factor_exp = pmf.obtener_factor_expansion(rodal)
    arbha_map = {}
    abha_map = {}
    erha_map = {}
    ert_map = {}
    total_arboles = 0
    total_arb_ha = 0.0
    total_ab = 0.0
    total_er = 0.0
    total_ert = 0.0
    suma_h2n = 0.0
    suma_n = 0
    for c in tabla.clases:
        if c.no_arboles > 0:
            total_arboles += c.no_arboles
            if c.altura_m > 0:
                suma_h2n += c.altura_m * c.altura_m * c.no_arboles
                suma_n += c.no_arboles
            if num_sitios > 0:
                nah = (c.no_arboles / num_sitios) * factor_exp
                arbha_map[c.dncc] = nah
                total_arb_ha += nah
                ab = tabla.area_basal_ha(c, nah)
                abha_map[c.dncc] = ab
                total_ab += ab
                vu = tabla.volumen_unitario(c, pmf)
                er = vu * nah
                erha_map[c.dncc] = er
                total_er += er
                if rodal:
                    ert_total = er * rodal.superficie_ha
                    ert_map[c.dncc] = ert_total
                    total_ert += ert_total
    altura_cuadratica = (suma_h2n / suma_n) ** 0.5 if suma_n > 0 else 0
    ec = pmf.obtener_ecuacion(esp)
    ecuacion_json = json.dumps({"a0": ec.a0, "a1": ec.a1, "a2": ec.a2, "b0": ec.b0}) if ec else "null"
    sup_rodal = rodal.superficie_ha if rodal else 0
    especies_ordenadas = sorted(pmf.especies, key=_orden_especies)
    return render_template("inventario/editar_tabla.html", pmf=pmf, tabla=tabla, rid=rid, esp=esp,
                           num_sitios=num_sitios, factor_exp=factor_exp,
                           arbha_map=arbha_map, abha_map=abha_map, erha_map=erha_map, ert_map=ert_map,
                           total_arboles=total_arboles, total_arb_ha=total_arb_ha,
                           total_ab=total_ab, total_er=total_er, total_ert=total_ert,
                           altura_cuadratica=round(altura_cuadratica, 2),
                           ecuacion_json=ecuacion_json, sup_rodal=sup_rodal,
                           especies_ordenadas=especies_ordenadas)


@app.route("/inventario/rodal/importar_excel/<rid>/<esp>", methods=["POST"])
def importar_excel_tabla(rid, esp):
    try:
        from openpyxl import load_workbook
        file = request.files.get("file")
        if not file:
            return jsonify({"error": "No se recibio archivo"})
        wb = load_workbook(file, data_only=True)
        ws = wb.active
        filas = []
        for row in ws.iter_rows(min_row=2, values_only=True):
            dncc = int(row[0]) if row[0] else None
            altura = float(row[1]) if len(row) > 1 and row[1] else None
            arboles = int(row[2]) if len(row) > 2 and row[2] else None
            if dncc:
                filas.append({"dncc": dncc, "altura": altura, "arboles": arboles})
        return jsonify({"filas": filas, "total": len(filas)})
    except Exception as e:
        return jsonify({"error": str(e)})


@app.route("/inventario/rodal/guardar_clases/<rid>/<esp>", methods=["POST"])
def guardar_clases(rid, esp):
    pmf = get_pmf()
    tabla = pmf.buscar_tabla_inventario(rid, esp)
    if not tabla:
        tabla = TablaInventarioRodal(rodal_id=rid, especie=esp)
        pmf.agregar_tabla_inventario(tabla)
    clases_actuales = {c.dncc: c for c in tabla.clases}
    dnccs = set()
    eliminadas = 0
    for clave in request.form:
        if clave.startswith("alt_") or clave.startswith("arb_"):
            try:
                valor = float(clave.split("_", 1)[1])
                dnccs.add(int(valor) if valor.is_integer() else valor)
            except ValueError:
                continue
    for dn in sorted(dnccs):
        alt_key = f"alt_{dn}"
        arb_key = f"arb_{dn}"
        alt_str = request.form.get(alt_key, "").strip()
        arb_str = request.form.get(arb_key, "").strip()
        if not alt_str and not arb_str:
            # Fila vaciada: elimina la clase si existía. Sin esto, vaciar una
            # fila no tenia efecto y los valores anteriores reaparecian.
            if dn in clases_actuales:
                tabla.clases = [c for c in tabla.clases if c.dncc != dn]
                del clases_actuales[dn]
                eliminadas += 1
            continue
        alt = float(alt_str) if alt_str else 0
        arb = int(arb_str) if arb_str else 0
        if alt < 0 or arb < 0:
            flash("Altura y número de árboles deben ser mayores o iguales que cero", "error")
            return redirect(url_for("editar_tabla", rid=rid, esp=esp))
        if dn in clases_actuales:
            clases_actuales[dn].altura_m = alt
            clases_actuales[dn].no_arboles = arb
        else:
            tabla.agregar_clase(ClaseDiametrica(dncc=dn, altura_m=alt, no_arboles=arb))
    if "menores_activo" in request.form:
        # Sección "Diámetros menores de 5 cm": un solo juego de campos
        # (diámetro, altura, número de árboles). Si se deja vacío, no hay
        # clase menor registrada.
        dia_str = request.form.get("men_dia", "").strip()
        alt_men_str = request.form.get("men_alt", "").strip()
        arb_men_str = request.form.get("men_arb", "").strip()
        menores = []
        if dia_str or alt_men_str or arb_men_str:
            try:
                diametro = float(dia_str)
            except ValueError:
                flash("El diámetro debe ser un número mayor que 0 y menor que 5 cm", "error")
                return redirect(url_for("editar_tabla", rid=rid, esp=esp))
            if not dia_str or not (diametro > 0 and diametro < 5):
                flash("El diámetro debe ser mayor que 0 y menor que 5 cm", "error")
                return redirect(url_for("editar_tabla", rid=rid, esp=esp))
            dn = int(diametro) if float(diametro).is_integer() else round(float(diametro), 2)
            try:
                alt = float(alt_men_str) if alt_men_str else 0
                arb = int(arb_men_str) if arb_men_str else 0
            except ValueError:
                flash("Altura y número de árboles deben ser mayores o iguales que cero", "error")
                return redirect(url_for("editar_tabla", rid=rid, esp=esp))
            if alt < 0 or arb < 0:
                flash("Altura y número de árboles deben ser mayores o iguales que cero", "error")
                return redirect(url_for("editar_tabla", rid=rid, esp=esp))
            menores.append(ClaseDiametrica(dncc=dn, altura_m=alt, no_arboles=arb))
        tabla.clases = [c for c in tabla.clases if c.dncc >= 5]
        tabla.clases.extend(menores)
    tabla.clases.sort(key=lambda clase: clase.dncc)
    save_pmf(pmf)
    detalle_eliminadas = ""
    if eliminadas:
        detalle_eliminadas = (f" ({eliminadas} clase eliminada)" if eliminadas == 1
                              else f" ({eliminadas} clases eliminadas)")

    sig_esp = request.form.get("siguiente_esp", "").strip()
    if sig_esp:
        flash("Tabla guardada" + detalle_eliminadas, "success")
        return redirect(url_for("editar_tabla", rid=rid, esp=sig_esp))
    elif "finalizar" in request.form:
        rodal = pmf.buscar_rodal(rid)
        if rodal:
            rodal.finalizado = True
            save_pmf(pmf)
        flash(f"Rodal {rid} finalizado", "success")
        return redirect(url_for("listar_tablas"))

    flash("Tabla guardada" + detalle_eliminadas, "success")
    return redirect(url_for("listar_tablas"))


@app.route("/inventario/rodal/eliminar/<rid>/<esp>")
def eliminar_tabla(rid, esp):
    pmf = get_pmf()
    pmf.eliminar_tabla_inventario(rid, esp)
    save_pmf(pmf)
    flash("Tabla eliminada", "success")
    return redirect(url_for("listar_tablas"))


@app.route("/inventario/rodal/limpiar_tablas", methods=["POST"])
def limpiar_tablas_inventario():
    pmf = get_pmf()
    total = pmf.limpiar_tablas_inventario()
    save_pmf(pmf)
    flash(f"Se eliminaron {total} tablas de inventario", "success")
    return redirect(url_for("listar_tablas"))


@app.route("/inventario/dashboard/todos")
def dashboard_todos():
    pmf = get_pmf()
    rows = []
    total_arb = total_arb_ha = total_ab = total_er = total_ert = 0
    suma_dncc2_nah = suma_h_nah = 0.0
    for t in pmf.tablas_inventario:
        rodal = pmf.buscar_rodal(t.rodal_id)
        if rodal and rodal.tipo_inventario == "existencias":
            continue
        num_sitios = rodal.sitios if rodal else 1
        factor_exp = pmf.obtener_factor_expansion(rodal)
        sup_rodal = rodal.superficie_ha if rodal else 0
        for c in t.clases:
            if c.no_arboles == 0:
                continue
            nah = t.no_arb_ha(c, factor_exp, num_sitios, pmf.usar_factor_ajuste)
            ab = t.area_basal_ha(c, nah)
            vu = t.volumen_unitario(c, pmf)
            er = vu * nah
            ert = er * sup_rodal
            total_arb += c.no_arboles; total_arb_ha += nah; total_ab += ab
            total_er += er; total_ert += ert
            suma_dncc2_nah += c.dncc ** 2 * nah
            suma_h_nah += c.altura_m * nah
            rows.append({"rodal": t.rodal_id, "especie": t.especie, "dncc": c.dncc,
                         "altura": c.altura_m, "vol_unitario": vu, "no_arboles": c.no_arboles,
                         "arb_ha": nah, "ab": ab, "er": er, "ert": ert})
    dg = (suma_dncc2_nah / total_arb_ha) ** 0.5 if total_arb_ha > 0 else 0
    h_prom = suma_h_nah / total_arb_ha if total_arb_ha > 0 else 0
    for registro in pmf.existencias_directas:
        rodal_directo = pmf.buscar_rodal(registro.rodal_id)
        if not rodal_directo or rodal_directo.oculto:
            continue
        sup_dir = rodal_directo.superficie_ha or 0
        ert_dir = registro.vol_ha * sup_dir
        total_arb_ha += registro.arboles_ha; total_ab += registro.ab_ha
        total_er += registro.vol_ha; total_ert += ert_dir
        rows.append({"rodal": registro.rodal_id, "especie": registro.especie, "dncc": None,
                     "altura": None, "vol_unitario": None, "no_arboles": None,
                     "arb_ha": registro.arboles_ha, "ab": registro.ab_ha,
                     "er": registro.vol_ha, "ert": ert_dir})
    return render_template("inventario/dashboard_rodal.html", pmf=pmf, rid="TODOS", esp=None,
                           rows=rows, total_arb=total_arb, total_arb_ha=total_arb_ha,
                           total_ab=total_ab, total_er=total_er, total_ert=total_ert,
                           dg=dg, h_prom=h_prom, num_sitios=0, factor_exp=0)


@app.route("/inventario/dashboard/rodal/<rid>")
def dashboard_rodal(rid):
    pmf = get_pmf()
    rodal = pmf.buscar_rodal(rid)
    tablas = [t for t in pmf.tablas_inventario
              if t.rodal_id == rid and not (
                  rodal and rodal.tipo_inventario == "existencias")]
    num_sitios = rodal.sitios if rodal else 1
    factor_exp = pmf.obtener_factor_expansion(rodal)
    sup_rodal = rodal.superficie_ha if rodal else 0
    rows = []
    total_arb = total_arb_ha = total_ab = total_er = total_ert = 0
    suma_dncc2_nah = suma_h_nah = 0.0
    por_especie = {}
    for t in tablas:
        esp = t.especie
        if esp not in por_especie:
            por_especie[esp] = {"arb": 0, "arb_ha": 0.0, "ab": 0.0, "er": 0.0, "ert": 0.0}
        for c in t.clases:
            if c.no_arboles == 0:
                continue
            nah = t.no_arb_ha(c, factor_exp, num_sitios, pmf.usar_factor_ajuste)
            ab = t.area_basal_ha(c, nah)
            vu = t.volumen_unitario(c, pmf)
            er = vu * nah
            ert = er * sup_rodal
            total_arb += c.no_arboles; total_arb_ha += nah; total_ab += ab
            total_er += er; total_ert += ert
            suma_dncc2_nah += c.dncc ** 2 * nah
            suma_h_nah += c.altura_m * nah
            por_especie[esp]["arb"] += c.no_arboles
            por_especie[esp]["arb_ha"] += nah
            por_especie[esp]["ab"] += ab
            por_especie[esp]["er"] += er
            por_especie[esp]["ert"] += ert
            rows.append({"especie": t.especie, "dncc": c.dncc, "altura": c.altura_m,
                         "vol_unitario": vu, "no_arboles": c.no_arboles,
                         "arb_ha": nah, "ab": ab, "er": er, "ert": ert})
    dg = (suma_dncc2_nah / total_arb_ha) ** 0.5 if total_arb_ha > 0 else 0
    h_prom = suma_h_nah / total_arb_ha if total_arb_ha > 0 else 0
    for registro in pmf.existencias_directas:
        if registro.rodal_id.casefold() != rid.casefold():
            continue
        rodal_directo = pmf.buscar_rodal(registro.rodal_id)
        if not rodal_directo or rodal_directo.oculto:
            continue
        sup_dir = rodal_directo.superficie_ha or 0
        ert_dir = registro.vol_ha * sup_dir
        total_arb_ha += registro.arboles_ha; total_ab += registro.ab_ha
        total_er += registro.vol_ha; total_ert += ert_dir
        if registro.especie not in por_especie:
            por_especie[registro.especie] = {"arb": 0, "arb_ha": 0.0, "ab": 0.0,
                                              "er": 0.0, "ert": 0.0}
        por_especie[registro.especie]["arb_ha"] += registro.arboles_ha
        por_especie[registro.especie]["ab"] += registro.ab_ha
        por_especie[registro.especie]["er"] += registro.vol_ha
        por_especie[registro.especie]["ert"] += ert_dir
        rows.append({"especie": registro.especie, "dncc": None, "altura": None,
                     "vol_unitario": None, "no_arboles": None,
                     "arb_ha": registro.arboles_ha, "ab": registro.ab_ha,
                     "er": registro.vol_ha, "ert": ert_dir})
    ia_contexto = None
    if rows:
        ia_contexto = {
            "rodal": rodal.id if rodal else rid,
            "superficie_ha": sup_rodal, "sitios": num_sitios,
            "factor_expansion": factor_exp,
            "por_especie": [
                {
                    "especie": especie, "arboles": datos["arb"], "arboles_ha": datos["arb_ha"],
                    "area_basal_ha_m2": datos["ab"], "volumen_ha_m3": datos["er"],
                    "existencias_m3": datos["ert"],
                }
                for especie, datos in por_especie.items()
            ],
            "totales": {
                "arboles": total_arb, "arboles_ha": total_arb_ha,
                "area_basal_ha_m2": total_ab, "volumen_ha_m3": total_er,
                "existencias_m3": total_ert,
            },
            "diametro_medio_cm": dg, "altura_media_m": h_prom,
        }
    return render_template("inventario/dashboard_rodal.html", pmf=pmf, tabla=None, rodal=rodal,
                           rid=rid, esp=None, rows=rows, num_sitios=num_sitios, factor_exp=factor_exp,
                           total_arb=total_arb, total_arb_ha=total_arb_ha, total_ab=total_ab,
                           total_er=total_er, total_ert=total_ert, dg=dg, h_prom=h_prom,
                           por_especie=por_especie, ia_tipo="dashboard_rodal", ia_contexto=ia_contexto)


@app.route("/inventario/dashboard/rodal/<rid>/<esp>")
def dashboard_rodal_especie(rid, esp):
    pmf = get_pmf()
    tabla = pmf.buscar_tabla_inventario(rid, esp)
    rodal = pmf.buscar_rodal(rid)
    num_sitios = rodal.sitios if rodal else 1
    factor_exp = pmf.obtener_factor_expansion(rodal)
    sup_rodal = rodal.superficie_ha if rodal else 0
    rows = []
    total_arb = total_arb_ha = total_ab = total_er = total_ert = 0
    suma_dncc2_nah = suma_h_nah = 0.0
    for c in (tabla.clases if tabla and not (
            rodal and rodal.tipo_inventario == "existencias") else []):
        if c.no_arboles == 0:
            continue
        nah = tabla.no_arb_ha(c, factor_exp, num_sitios, pmf.usar_factor_ajuste)
        ab = tabla.area_basal_ha(c, nah)
        vu = tabla.volumen_unitario(c, pmf)
        er = vu * nah
        ert = er * sup_rodal
        total_arb += c.no_arboles; total_arb_ha += nah; total_ab += ab
        total_er += er; total_ert += ert
        suma_dncc2_nah += c.dncc ** 2 * nah
        suma_h_nah += c.altura_m * nah
        rows.append({"dncc": c.dncc, "altura": c.altura_m, "vol_unitario": vu,
                     "no_arboles": c.no_arboles, "arb_ha": nah, "ab": ab, "er": er, "ert": ert})
    directo = pmf.buscar_existencia_directa(rid, esp)
    if directo and rodal and rodal.tipo_inventario == "existencias":
        ert_dir = directo.vol_ha * (rodal.superficie_ha or 0)
        total_arb_ha += directo.arboles_ha; total_ab += directo.ab_ha
        total_er += directo.vol_ha; total_ert += ert_dir
        rows.append({"dncc": None, "altura": None, "vol_unitario": None, "no_arboles": None,
                     "arb_ha": directo.arboles_ha, "ab": directo.ab_ha,
                     "er": directo.vol_ha, "ert": ert_dir})
    dg = (suma_dncc2_nah / total_arb_ha) ** 0.5 if total_arb_ha > 0 else 0
    h_prom = suma_h_nah / total_arb_ha if total_arb_ha > 0 else 0
    ia_contexto = None
    if rows:
        ia_contexto = {
            "rodal": rid, "especie": esp,
            "superficie_ha": sup_rodal, "sitios": num_sitios,
            "factor_expansion": factor_exp,
            "clases": [
                {
                    "dncc_cm": fila["dncc"], "altura_m": fila["altura"],
                    "volumen_unitario_m3": fila["vol_unitario"],
                    "arboles": fila["no_arboles"], "arboles_ha": fila["arb_ha"],
                    "area_basal_ha_m2": fila["ab"], "volumen_ha_m3": fila["er"],
                    "existencias_m3": fila["ert"],
                }
                for fila in rows
            ],
            "totales": {
                "arboles": total_arb, "arboles_ha": total_arb_ha,
                "area_basal_ha_m2": total_ab, "volumen_ha_m3": total_er,
                "existencias_m3": total_ert,
            },
            "diametro_medio_cm": dg, "altura_media_m": h_prom,
        }
    return render_template("inventario/dashboard_rodal.html", pmf=pmf, tabla=tabla, rodal=rodal,
                           rid=rid, esp=esp, rows=rows, num_sitios=num_sitios, factor_exp=factor_exp,
                           total_arb=total_arb, total_arb_ha=total_arb_ha, total_ab=total_ab,
                           total_er=total_er, total_ert=total_ert, dg=dg, h_prom=h_prom,
                           ia_tipo="dashboard_rodal", ia_contexto=ia_contexto)


@app.route("/inventario/rodal/reporte/<rid>/<esp>")
def reporte_tabla(rid, esp):
    pmf = get_pmf()
    tabla = pmf.buscar_tabla_inventario(rid, esp)
    rodal = pmf.buscar_rodal(rid)
    directo = pmf.buscar_existencia_directa(rid, esp)
    if not tabla and not (directo and rodal and rodal.tipo_inventario == "existencias"):
        flash("Tabla no encontrada", "error")
        return redirect(url_for("listar_tablas"))
    num_sitios = rodal.sitios if rodal else 1
    factor_exp = pmf.obtener_factor_expansion(rodal)
    sup_rodal = rodal.superficie_ha if rodal else 0
    rows = []
    total_arb = total_arb_ha = total_ab = total_er = total_ert = 0
    suma_dncc2_nah = 0.0
    suma_h_nah = 0.0
    es_directo = bool(directo and rodal and rodal.tipo_inventario == "existencias")
    if es_directo:
        ert_dir = directo.vol_ha * sup_rodal
        total_arb_ha = directo.arboles_ha
        total_ab = directo.ab_ha
        total_er = directo.vol_ha
        total_ert = ert_dir
        rows.append({"dncc": None, "altura": None, "vol_unitario": None, "no_arboles": None,
                     "arb_ha": directo.arboles_ha, "ab": directo.ab_ha,
                     "er": directo.vol_ha, "ert": ert_dir})
    for c in (tabla.clases if tabla and not es_directo else []):
        if c.no_arboles == 0:
            continue
        nah = tabla.no_arb_ha(c, factor_exp, num_sitios, pmf.usar_factor_ajuste)
        ab = tabla.area_basal_ha(c, nah)
        vu = tabla.volumen_unitario(c, pmf)
        er = vu * nah
        ert = er * sup_rodal
        total_arb += c.no_arboles
        total_arb_ha += nah
        total_ab += ab
        total_er += er
        total_ert += ert
        suma_dncc2_nah += c.dncc ** 2 * nah
        suma_h_nah += c.altura_m * nah
        rows.append({"dncc": c.dncc, "altura": c.altura_m, "vol_unitario": vu,
                     "no_arboles": c.no_arboles, "arb_ha": nah, "ab": ab, "er": er, "ert": ert})
    dg = (suma_dncc2_nah / total_arb_ha) ** 0.5 if total_arb_ha > 0 else 0
    h_prom = suma_h_nah / total_arb_ha if total_arb_ha > 0 else 0
    ia_contexto = {
        "rodal": rodal.id if rodal else rid,
        "especie": esp,
        "superficie_ha": (rodal.superficie_ha if rodal else 0) or 0,
        "sitios": (rodal.sitios if rodal else 1) or 1,
        "factor_expansion": factor_exp,
        "clases": [
            {
                "dncc_cm": fila["dncc"], "altura_m": fila["altura"],
                "volumen_unitario_m3": fila["vol_unitario"],
                "arboles": fila["no_arboles"], "arboles_ha": fila["arb_ha"],
                "area_basal_ha_m2": fila["ab"], "volumen_ha_m3": fila["er"],
                "existencias_m3": fila["ert"],
            }
            for fila in rows
        ],
        "totales": {
            "arboles": total_arb, "arboles_ha": total_arb_ha,
            "area_basal_ha_m2": total_ab, "volumen_ha_m3": total_er,
            "existencias_m3": total_ert,
        },
        "diametro_medio_cm": dg, "altura_media_m": h_prom,
    }
    return render_template("inventario/reporte_tabla.html",
                           pmf=pmf, rodal=rodal, especie=esp, rows=rows,
                           total_arb=total_arb, total_arb_ha=total_arb_ha,
                           total_ab=total_ab, total_er=total_er, total_ert=total_ert,
                           dg=dg, h_prom=h_prom, factor_exp=factor_exp,
                           ia_tipo="reporte_tabla", ia_contexto=ia_contexto)


# =============== CRECIMIENTO ===============

@app.route("/crecimiento")
def ver_crecimiento():
    pmf = get_pmf()
    return render_template("crecimiento/index.html", pmf=pmf)


@app.route("/crecimiento/guardar", methods=["POST"])
def guardar_crecimiento():
    pmf = get_pmf()
    c = pmf.crecimiento
    try:
        vol = request.form.get("volumen_actual_m3ha", "").strip()
        edad = request.form.get("edad_actual_anios", "").strip()
        sitio = request.form.get("calidad_sitio", "").strip()
        ima_e = request.form.get("ima_esperado", "").strip()
        if vol:
            c.volumen_actual_m3ha = float(vol)
        if edad:
            c.edad_actual_anios = float(edad)
        if sitio:
            c.calidad_sitio = sitio
        c.ima_esperado = float(ima_e) if ima_e else None
        save_pmf(pmf)
        flash("Datos de crecimiento actualizados", "success")
    except Exception as e:
        flash(f"Error: {e}", "error")
    return redirect(url_for("ver_crecimiento"))


@app.route("/crecimiento/proyectar", methods=["POST"])
def proyectar_crecimiento():
    pmf = get_pmf()
    c = pmf.crecimiento
    try:
        anos = float(request.form.get("anos", 0))
        vol_fut, ima = c.proyectar(anos)
        flash(f"Vol. futuro ({anos:.0f} anos): {vol_fut:.2f} m3/ha | IMA: {ima:.2f} m3/ha/ano", "info")
    except Exception as e:
        flash(f"Error: {e}", "error")
    return redirect(url_for("ver_crecimiento"))


# =============== TIEMPO DE PASO (KLEPAC) ===============

@app.route("/crecimiento/tp")
def listar_tp():
    pmf = get_pmf()
    return render_template("crecimiento/tp.html", pmf=pmf)


@app.route("/crecimiento/tp/guardar", methods=["POST"])
def guardar_tp():
    pmf = get_pmf()
    esp = request.form.get("especie", "").strip()
    if not esp:
        flash("Seleccione una especie", "error")
        return redirect(url_for("listar_tp"))
    valores = {}
    for key, val in request.form.items():
        if key.startswith("tp_"):
            try:
                dncc = int(key.split("_")[1])
                tp = float(val)
                if dncc > 0 and tp > 0:
                    valores[dncc] = tp
            except:
                pass
    if valores:
        pmf.tiempo_paso[esp] = valores
        save_pmf(pmf)
        flash(f"T.P. guardado para '{esp}' ({len(valores)} registros)", "success")
    else:
        flash("No se ingresaron datos validos", "error")
    return redirect(url_for("listar_tp"))


@app.route("/crecimiento/tp_ecuacion", methods=["POST"])
def guardar_tp_ecuacion():
    pmf = get_pmf()
    esp = request.form.get("especie", "").strip()
    try:
        a = request.form.get("a", "").strip()
        b = request.form.get("b", "").strip()
        c = request.form.get("c", "").strip()
        if a and b and c:
            pmf.tp_ecuaciones[esp] = {"a": float(a), "b": float(b), "c": float(c)}
            if esp in pmf.tiempo_paso:
                del pmf.tiempo_paso[esp]
            flash(f"Ecuacion T.P. guardada para '{esp}'", "success")
        elif esp in pmf.tp_ecuaciones:
            del pmf.tp_ecuaciones[esp]
            flash(f"Ecuacion eliminada para '{esp}'", "info")
        save_pmf(pmf)
    except Exception as e:
        flash(f"Error: {e}", "error")
    return redirect(url_for("listar_tp"))


@app.route("/crecimiento/edad_ecuacion", methods=["POST"])
def guardar_edad_ecuacion():
    pmf = get_pmf()
    esp = request.form.get("especie", "").strip()
    try:
        a = request.form.get("a", "").strip()
        b = request.form.get("b", "").strip()
        c = request.form.get("c", "").strip()
        d = request.form.get("d", "").strip()
        if a and b and c and d:
            pmf.edad_ecuaciones[esp] = {"a": float(a), "b": float(b), "c": float(c), "d": float(d)}
            flash(f"Ecuacion de Edad guardada para '{esp}'", "success")
        elif esp in pmf.edad_ecuaciones:
            del pmf.edad_ecuaciones[esp]
            flash("Ecuacion eliminada", "info")
        save_pmf(pmf)
    except Exception as e:
        flash(f"Error: {e}", "error")
    return redirect(url_for("listar_tp"))


@app.route("/crecimiento/reporte_klepac/<rid>/<esp>")
def reporte_klepac(rid, esp):
    pmf = get_pmf()
    tabla = pmf.buscar_tabla_inventario(rid, esp)
    if not tabla:
        flash("Tabla de inventario no encontrada", "error")
        return redirect(url_for("listar_tablas"))
    tiene_ec = esp in pmf.tp_ecuaciones
    tp_vals = pmf.tiempo_paso.get(esp, {})
    if not tiene_ec and not tp_vals:
        flash(f"No hay datos de T.P. para '{esp}'", "error")
        return redirect(url_for("listar_tablas"))
    rodal = pmf.buscar_rodal(rid)
    num_sitios = rodal.sitios if rodal else 1
    factor_exp = pmf.obtener_factor_expansion(rodal)
    rows = []
    total_arb_ha = total_vol_ha = suma_ica = 0.0
    for c in tabla.clases:
        if c.no_arboles == 0:
            continue
        tp = pmf.calcular_tp(esp, c.dncc)
        if tp is None:
            continue
        nah = tabla.no_arb_ha(c, factor_exp, num_sitios, pmf.usar_factor_ajuste)
        vu = tabla.volumen_unitario(c, pmf)
        vol_ha = vu * nah
        col6 = 1000.0 / (c.dncc * tp)
        col7 = vol_ha / (c.dncc * tp) * 10.0
        total_arb_ha += nah
        total_vol_ha += vol_ha
        suma_ica += col7
        rows.append({"dncc": c.dncc, "vol_tipo": vu, "arb_ha": nah,
                     "vol_ha": vol_ha, "tp": tp, "col6": col6, "col7": col7})
    ica_pct = suma_ica / total_arb_ha * 100 if total_arb_ha > 0 else 0
    ia_contexto = {
        "rodal": rodal.id if rodal else rid,
        "especie": esp,
        "clases": [
            {
                "dncc_cm": fila["dncc"], "volumen_unitario_m3": fila["vol_tipo"],
                "arboles_ha": fila["arb_ha"], "volumen_ha_m3": fila["vol_ha"],
                "tiempo_paso_anios": fila["tp"],
                "tasa_decremento_arb_ha_por_cm": fila["col6"],
                "ica_m3_ha_anio": fila["col7"],
            }
            for fila in rows
        ],
        "totales": {
            "arboles_ha": total_arb_ha, "volumen_ha_m3": total_vol_ha,
            "ica_m3_ha_anio": suma_ica, "ica_porcentaje": ica_pct,
        },
    }
    return render_template("crecimiento/reporte_klepac.html",
                           pmf=pmf, rodal=rodal, especie=esp, rows=rows,
                           total_arb_ha=total_arb_ha, total_vol_ha=total_vol_ha,
                           suma_ica=suma_ica, ica_pct=ica_pct,
                           ia_tipo="klepac", ia_contexto=ia_contexto)


# =============== PLAN DE CORTAS ===============

_TRATAMIENTOS_SILVICOLAS = [
    "CR Árboles padre",
    "Corta de liberación",
    "Corta de Selección",
    "Corta preparatoria",
    "Corta diseminatoria",
    "Corta de extracción",
    "Cortas de aclareo",
    "Corta de Rescate",
]


def _resumen_plan_cortas(pmf, datos_intervenciones=None):
    if datos_intervenciones is None:
        cache = {}
        datos_intervenciones = [pmf.datos_intervencion_corta(i, cache)
                                for i in pmf.plan_cortas.intervenciones
                                if (pmf.buscar_rodal(i.rodal_id) and
                                    not pmf.buscar_rodal(i.rodal_id).oculto)]
    acumulados = {}
    for dato in datos_intervenciones:
        numero = dato["intervencion"].anualidad
        por_especie = acumulados.setdefault(numero, {})
        for fila in dato["filas"]:
            valores = por_especie.setdefault(
                fila["especie"], {"posibilidad": 0.0, "infraestructura": 0.0, "total": 0.0}
            )
            valores["posibilidad"] += fila["posibilidad"]
            valores["infraestructura"] += fila["infraestructura"]
            valores["total"] += fila["total"]

    anios = {a.numero: a.anio for a in pmf.plan_cortas.anualidades}
    grupos = []
    total_general = {"posibilidad": 0.0, "infraestructura": 0.0, "total": 0.0}
    for numero in sorted(acumulados):
        filas = []
        subtotal = {"posibilidad": 0.0, "infraestructura": 0.0, "total": 0.0}
        for especie in sorted(
                acumulados[numero],
                key=lambda especie: _orden_especie_volumen(
                    especie, acumulados[numero][especie]["total"])):
            valores = acumulados[numero][especie]
            filas.append({"especie": especie, **valores})
            for clave in subtotal:
                subtotal[clave] += valores[clave]
        for clave in total_general:
            total_general[clave] += subtotal[clave]
        grupos.append({"numero": numero, "anio": anios.get(numero),
                       "filas": filas, "subtotal": subtotal})
    return grupos, total_general


def _conciliacion_plan_cortas(pmf, resumen_plan):
    posibilidad_existencias = {}
    for fila in pmf.cuadro_existencias().get("filas", []):
        if fila.get("_type") == "subtotal":
            continue
        especie = fila.get("especie", "")
        posibilidad_existencias[especie] = (
            posibilidad_existencias.get(especie, 0) + float(fila.get("pos_umm", 0) or 0)
        )

    volumen_plan = {}
    for grupo in resumen_plan:
        for fila in grupo["filas"]:
            especie = fila["especie"]
            volumen_plan[especie] = volumen_plan.get(especie, 0) + fila["total"]

    filas = []
    especies_con_volumen = set(posibilidad_existencias) | set(volumen_plan)
    for especie in sorted(
            especies_con_volumen,
            key=lambda especie: _orden_especie_volumen(
                especie, volumen_plan.get(especie, posibilidad_existencias.get(especie, 0)))):
        esperado = posibilidad_existencias.get(especie, 0)
        programado = volumen_plan.get(especie, 0)
        diferencia = programado - esperado
        filas.append({"especie": especie, "existencias": esperado,
                      "plan": programado, "diferencia": diferencia,
                      "coincide": abs(diferencia) < 0.001})
    total_existencias = sum(posibilidad_existencias.values())
    total_plan = sum(volumen_plan.values())
    diferencia_total = total_plan - total_existencias
    return {"filas": filas, "total_existencias": total_existencias,
            "total_plan": total_plan, "diferencia": diferencia_total,
            "coincide": abs(diferencia_total) < 0.001 and all(f["coincide"] for f in filas)}

@app.route("/cortas")
def ver_cortas():
    pmf = get_pmf()
    contexto = _contexto_plan_cortas(pmf)
    superficies_asignadas = {}
    for intervencion in contexto["intervenciones_visibles"]:
        if not intervencion.intervencion_origen_id:
            superficies_asignadas[intervencion.rodal_id] = (
                superficies_asignadas.get(intervencion.rodal_id, 0) + intervencion.superficie_ha
            )
    conteo_intervenciones = {}
    for intervencion in contexto["intervenciones_visibles"]:
        conteo_intervenciones[intervencion.rodal_id] = (
            conteo_intervenciones.get(intervencion.rodal_id, 0) + 1
        )
    return render_template("cortas/index.html", pmf=pmf,
                           datos_intervenciones=contexto["datos_intervenciones"],
                           superficies_asignadas=superficies_asignadas,
                           conteo_intervenciones=conteo_intervenciones,
                           totales_anualidad=contexto["totales_anualidad"],
                           totales_generales=contexto["totales_generales"],
                           resumen_plan=contexto["resumen_plan"],
                           total_resumen_plan=contexto["total_resumen_plan"],
                           conciliacion_plan=contexto["conciliacion_plan"],
                           tratamientos=_TRATAMIENTOS_SILVICOLAS)


def _intervenciones_ordenadas_tabla8(pmf):
    """Intervenciones visibles en el orden de la Tabla 8.

    Agrupadas por área de corta (anualidad ascendente); dentro de cada
    área manda el orden manual y, en su defecto, el orden de registro.
    """
    visibles = [i for i in pmf.plan_cortas.intervenciones
                if (pmf.buscar_rodal(i.rodal_id) and
                    not pmf.buscar_rodal(i.rodal_id).oculto)]
    posicion_registro = {id(i): n for n, i in enumerate(pmf.plan_cortas.intervenciones)}
    base_manuales = len(posicion_registro) + 1

    def _clave(intervencion):
        orden = intervencion.orden
        if orden is None:
            orden = base_manuales + posicion_registro.get(id(intervencion), 0)
        return (intervencion.anualidad, orden,
                posicion_registro.get(id(intervencion), 0))

    return sorted(visibles, key=_clave)


def _mover_intervencion_tabla8(pmf, intervencion_id, direccion):
    """Mueve la intervención dentro de su área de corta. Retorna error o None."""
    objetivo = pmf.buscar_intervencion_corta(intervencion_id)
    if not objetivo:
        return "Intervención no encontrada"
    grupo = [i for i in _intervenciones_ordenadas_tabla8(pmf)
             if i.anualidad == objetivo.anualidad]
    indice = next((n for n, i in enumerate(grupo) if i.id == intervencion_id), None)
    if indice is None:
        return "Intervención no encontrada"
    destino = indice + direccion
    if destino < 0 or destino >= len(grupo):
        return "Ya está en el extremo del área"
    for posicion, item in enumerate(grupo):
        item.orden = posicion
    grupo[indice].orden, grupo[destino].orden = grupo[destino].orden, grupo[indice].orden
    return None


def _contexto_plan_cortas(pmf):
    cache = {}
    intervenciones_visibles = [i for i in pmf.plan_cortas.intervenciones
                               if (pmf.buscar_rodal(i.rodal_id) and
                                   not pmf.buscar_rodal(i.rodal_id).oculto)]
    # Tabla 8: agrupada por área de corta (anualidad ascendente); dentro de
    # cada área manda el orden manual y, en su defecto, el orden de registro.
    datos_intervenciones = [pmf.datos_intervencion_corta(i, cache)
                            for i in _intervenciones_ordenadas_tabla8(pmf)]
    numeros_anualidad = {a.numero for a in pmf.plan_cortas.anualidades}
    for dato in datos_intervenciones:
        intervencion = dato["intervencion"]
        errores = []
        if intervencion.anualidad not in numeros_anualidad:
            errores.append("La anualidad no existe en el calendario actual")
        if not dato["rodal"]:
            errores.append("La UMM ya no existe")
        if intervencion.superficie_ha <= 0:
            errores.append("La superficie debe ser mayor que cero")
        if intervencion.intervencion_origen_id:
            origen = pmf.buscar_intervencion_corta(intervencion.intervencion_origen_id)
            if not origen:
                errores.append("No existe la intervención anterior vinculada")
            elif origen.anualidad >= intervencion.anualidad:
                errores.append("La intervención vinculada debe estar en una anualidad posterior a su origen")
        dato["errores"] = errores
    totales_anualidad = {}
    for dato in datos_intervenciones:
        numero = dato["intervencion"].anualidad
        totales = totales_anualidad.setdefault(
            numero, {"superficie": 0.0, "posibilidad": 0.0,
                     "infraestructura": 0.0, "total": 0.0}
        )
        totales["superficie"] += dato["intervencion"].superficie_ha
        for fila in dato["filas"]:
            totales["posibilidad"] += fila["posibilidad"]
            totales["infraestructura"] += fila["infraestructura"]
            totales["total"] += fila["total"]
    totales_generales = {
        clave: sum(totales[clave] for totales in totales_anualidad.values())
        for clave in ("superficie", "posibilidad", "infraestructura", "total")
    }
    resumen_plan, total_resumen_plan = _resumen_plan_cortas(pmf, datos_intervenciones)
    conciliacion_plan = _conciliacion_plan_cortas(pmf, resumen_plan)
    return {
        "intervenciones_visibles": intervenciones_visibles,
        "datos_intervenciones": datos_intervenciones,
        "totales_anualidad": totales_anualidad,
        "totales_generales": totales_generales,
        "resumen_plan": resumen_plan,
        "total_resumen_plan": total_resumen_plan,
        "conciliacion_plan": conciliacion_plan,
    }


@app.route("/cortas/exportar/word")
def exportar_plan_cortas_word():
    pmf = get_pmf()
    contexto = _contexto_plan_cortas(pmf)
    salida = generar_word_plan_cortas(
        pmf, contexto["datos_intervenciones"], contexto["totales_anualidad"],
        contexto["totales_generales"], contexto["resumen_plan"],
        contexto["total_resumen_plan"], contexto["conciliacion_plan"])
    return send_file(salida, as_attachment=True,
                     download_name="SIMFI_Plan_Cortas.docx",
                     mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")


@app.route("/cortas/guardar", methods=["POST"])
def guardar_cortas():
    pmf = get_pmf()
    pc = pmf.plan_cortas
    try:
        anio_inicio = int(request.form.get("anio_inicio", "0"))
        tipo = request.form.get("tipo_programacion", "anual")
        cantidad = int(request.form.get("cantidad_personalizada", "10") or 10)
        if anio_inicio < 1900 or anio_inicio > 9999:
            raise ValueError("El año de inicio debe tener cuatro dígitos")
        if tipo not in {"anual", "bianual", "trianual", "personalizado"}:
            raise ValueError("Tipo de programación no válido")
        if cantidad < 1 or cantidad > 50:
            raise ValueError("La cantidad personalizada debe estar entre 1 y 50")

        configuracion_cambio = (tipo != pc.tipo_programacion or
                                anio_inicio != pc.anio_inicio or
                                cantidad != pc.cantidad_personalizada)
        pc.anio_inicio = anio_inicio
        pc.tipo_programacion = tipo
        pc.cantidad_personalizada = cantidad
        if configuracion_cambio:
            pc.generar_anualidades()
        for anualidad in pc.anualidades:
            valor = request.form.get(f"anio_{anualidad.numero}", "").strip()
            if valor:
                anualidad.anio = int(valor)
                if anualidad.anio < 1900 or anualidad.anio > 9999:
                    raise ValueError("Los años de las anualidades deben tener cuatro dígitos")

        numeros = {a.numero for a in pc.anualidades}
        fuera_del_calendario = [i for i in pc.intervenciones if i.anualidad not in numeros]
        if fuera_del_calendario:
            raise ValueError("La nueva programación dejaría intervenciones fuera del calendario")
        if len({a.anio for a in pc.anualidades}) != len(pc.anualidades):
            raise ValueError("Los años de las anualidades no pueden repetirse")
        save_pmf(pmf)
        flash("Calendario del plan de cortas actualizado", "success")
    except Exception as e:
        flash(f"Error: {e}", "error")
    return redirect(url_for("ver_cortas"))


@app.route("/cortas/intervenciones/agregar", methods=["POST"])
def agregar_intervencion_corta():
    pmf = get_pmf()
    pc = pmf.plan_cortas
    try:
        anualidad = int(request.form.get("anualidad", "0"))
        tratamiento = request.form.get("tratamiento", "").strip()
        modo = request.form.get("modo_intervencion", "nueva")
        if anualidad not in {a.numero for a in pc.anualidades}:
            raise ValueError("Seleccione una anualidad válida")
        if tratamiento not in _TRATAMIENTOS_SILVICOLAS:
            raise ValueError("Seleccione un tratamiento silvícola")

        origen_id = ""
        superficie_completa = False
        if modo == "vinculada":
            origen_id = request.form.get("intervencion_origen_id", "").strip()
            origen = pmf.buscar_intervencion_corta(origen_id)
            if not origen:
                raise ValueError("Seleccione una intervención anterior")
            if origen.anualidad >= anualidad:
                raise ValueError("La intervención vinculada debe corresponder a una anualidad anterior")
            rodal_id = origen.rodal_id
            superficie = origen.superficie_ha
            superficie_completa = origen.superficie_completa
        else:
            rodal_id = request.form.get("rodal_id", "").strip()
            rodal = pmf.buscar_rodal(rodal_id)
            if not rodal or rodal.oculto:
                raise ValueError("Seleccione una UMM con inventario")
            if not pmf.especies_inventario_rodal(rodal_id):
                raise ValueError("La UMM seleccionada no tiene inventario")
            superficie_completa = request.form.get("tipo_superficie") == "completa"
            superficie = rodal.superficie_ha if superficie_completa else float(
                request.form.get("superficie_ha", "0") or 0
            )
            if superficie <= 0:
                raise ValueError("La superficie asignada debe ser mayor que cero")
            asignada = sum(i.superficie_ha for i in pc.intervenciones
                           if i.rodal_id == rodal_id and not i.intervencion_origen_id)
            if asignada + superficie > rodal.superficie_ha:
                if request.form.get("confirmar_exceso") != "1":
                    raise ValueError(
                        f"La superficie acumulada ({asignada + superficie:.3f} ha) supera "
                        f"la superficie de la UMM ({rodal.superficie_ha:.3f} ha). Confirme el excedente."
                    )

        intervencion_id = secrets.token_hex(5)
        while pmf.buscar_intervencion_corta(intervencion_id):
            intervencion_id = secrets.token_hex(5)
        if modo != "vinculada":
            registradas = sum(1 for i in pc.intervenciones if i.rodal_id == rodal_id)
            if registradas and request.form.get("confirmar_duplicada") != "1":
                raise ValueError(
                    f"La UMM {rodal_id} ya tiene {registradas} intervención(es) "
                    "registrada(s) en el plan. Confirme para agregar otra.")
        pc.intervenciones.append(IntervencionCorta(
            id=intervencion_id, anualidad=anualidad, rodal_id=rodal_id,
            superficie_ha=superficie, tratamiento=tratamiento,
            superficie_completa=superficie_completa,
            intervencion_origen_id=origen_id,
        ))
        session["ultima_anualidad_corta"] = anualidad
        save_pmf(pmf)
        flash("Intervención agregada al plan", "success")
    except Exception as e:
        flash(f"Error: {e}", "error")
    return redirect(url_for("ver_cortas"))


@app.route("/cortas/intervenciones/<intervencion_id>/volumenes", methods=["POST"])
def guardar_volumenes_intervencion(intervencion_id):
    pmf = get_pmf()
    intervencion = pmf.buscar_intervencion_corta(intervencion_id)
    if not intervencion:
        flash("Intervención no encontrada", "error")
        return redirect(url_for("ver_cortas"))
    try:
        infraestructura = {}
        posibilidad_editada = dict(intervencion.posibilidad_editada)
        cantidad = int(request.form.get("cantidad_especies", "0") or 0)
        for indice in range(cantidad):
            especie = request.form.get(f"especie_{indice}", "").strip()
            if not especie:
                continue
            valor_infra = float(request.form.get(f"infraestructura_{indice}", "0") or 0)
            if valor_infra < 0:
                raise ValueError("El volumen por infraestructura no puede ser negativo")
            if valor_infra > 0:
                infraestructura[especie] = valor_infra
            valor_pos = float(request.form.get(f"posibilidad_{indice}", "0") or 0)
            if valor_pos < 0:
                raise ValueError("La posibilidad no puede ser negativa")
            posibilidad_editada[especie] = valor_pos
        intervencion.infraestructura = infraestructura
        intervencion.posibilidad_editada = posibilidad_editada
        save_pmf(pmf)
        flash("Volúmenes de la intervención actualizados", "success")
    except Exception as e:
        flash(f"Error: {e}", "error")
    return redirect(url_for("ver_cortas"))


@app.route("/cortas/intervenciones/<intervencion_id>/editar", methods=["POST"])
def editar_intervencion_corta(intervencion_id):
    pmf = get_pmf()
    intervencion = pmf.buscar_intervencion_corta(intervencion_id)
    if not intervencion:
        flash("Intervención no encontrada", "error")
        return redirect(url_for("ver_cortas"))
    try:
        anualidad = int(request.form.get("anualidad", "0"))
        tratamiento = request.form.get("tratamiento", "").strip()
        if anualidad not in {a.numero for a in pmf.plan_cortas.anualidades}:
            raise ValueError("Seleccione una anualidad válida")
        if tratamiento not in _TRATAMIENTOS_SILVICOLAS:
            raise ValueError("Seleccione un tratamiento silvícola")
        origen = pmf.buscar_intervencion_corta(intervencion.intervencion_origen_id)
        if origen and origen.anualidad >= anualidad:
            raise ValueError("La intervención debe ser posterior a la anualidad de origen")
        dependientes = [i for i in pmf.plan_cortas.intervenciones
                        if i.intervencion_origen_id == intervencion.id]
        if any(i.anualidad <= anualidad for i in dependientes):
            raise ValueError("Existen intervenciones vinculadas que deben permanecer en anualidades posteriores")

        intervencion.anualidad = anualidad
        intervencion.tratamiento = tratamiento
        if not intervencion.intervencion_origen_id:
            rodal = pmf.buscar_rodal(intervencion.rodal_id)
            if not rodal:
                raise ValueError("La UMM ya no existe")
            superficie_completa = request.form.get("tipo_superficie") == "completa"
            superficie = rodal.superficie_ha if superficie_completa else float(
                request.form.get("superficie_ha", "0") or 0
            )
            if superficie <= 0:
                raise ValueError("La superficie debe ser mayor que cero")
            otras_superficies = sum(i.superficie_ha for i in pmf.plan_cortas.intervenciones
                                    if i.id != intervencion.id and
                                    i.rodal_id == intervencion.rodal_id and
                                    not i.intervencion_origen_id)
            if otras_superficies + superficie > rodal.superficie_ha:
                if request.form.get("confirmar_exceso") != "1":
                    raise ValueError("La superficie acumulada supera la superficie de la UMM")
            intervencion.superficie_ha = superficie
            intervencion.superficie_completa = superficie_completa

            pendientes = [intervencion]
            while pendientes:
                padre = pendientes.pop()
                for hija in pmf.plan_cortas.intervenciones:
                    if hija.intervencion_origen_id == padre.id:
                        hija.rodal_id = padre.rodal_id
                        hija.superficie_ha = padre.superficie_ha
                        hija.superficie_completa = padre.superficie_completa
                        pendientes.append(hija)
        save_pmf(pmf)
        flash("Registro del plan actualizado", "success")
    except Exception as e:
        flash(f"Error: {e}", "error")
    return redirect(url_for("ver_cortas"))


@app.route("/cortas/intervenciones/<intervencion_id>/eliminar", methods=["POST"])
def eliminar_intervencion_corta(intervencion_id):
    pmf = get_pmf()
    dependientes = [i for i in pmf.plan_cortas.intervenciones
                    if i.intervencion_origen_id == intervencion_id]
    if dependientes:
        flash("No se puede eliminar: existen intervenciones posteriores vinculadas", "error")
    else:
        original = len(pmf.plan_cortas.intervenciones)
        pmf.plan_cortas.intervenciones = [i for i in pmf.plan_cortas.intervenciones
                                          if i.id != intervencion_id]
        if len(pmf.plan_cortas.intervenciones) < original:
            save_pmf(pmf)
            flash("Intervención eliminada", "success")
        else:
            flash("Intervención no encontrada", "error")
    return redirect(url_for("ver_cortas"))


@app.route("/cortas/intervenciones/<intervencion_id>/subir", methods=["POST"])
def subir_intervencion_corta(intervencion_id):
    pmf = get_pmf()
    error = _mover_intervencion_tabla8(pmf, intervencion_id, -1)
    if error:
        flash(error, "error")
    else:
        save_pmf(pmf)
    return redirect(url_for("ver_cortas"))


@app.route("/cortas/intervenciones/<intervencion_id>/bajar", methods=["POST"])
def bajar_intervencion_corta(intervencion_id):
    pmf = get_pmf()
    error = _mover_intervencion_tabla8(pmf, intervencion_id, 1)
    if error:
        flash(error, "error")
    else:
        save_pmf(pmf)
    return redirect(url_for("ver_cortas"))


@app.route("/cortas/orden-manual/activar", methods=["POST"])
def activar_orden_manual_corta():
    session["orden_manual_cortas"] = True
    return redirect(url_for("ver_cortas"))


@app.route("/cortas/orden-manual/terminar", methods=["POST"])
def terminar_orden_manual_corta():
    session.pop("orden_manual_cortas", None)
    return redirect(url_for("ver_cortas"))


@app.route("/cortas/orden-manual/guardar", methods=["POST"])
def guardar_orden_manual_corta():
    pmf = get_pmf()
    datos = request.get_json(silent=True) or {}
    try:
        anualidad = int(datos.get("anualidad", -1))
    except (TypeError, ValueError):
        return {"ok": False, "error": "Área no válida"}, 400
    ids = [str(ident) for ident in (datos.get("orden") or [])]
    grupo = [i for i in _intervenciones_ordenadas_tabla8(pmf)
             if i.anualidad == anualidad]
    if not grupo or {i.id for i in grupo} != set(ids):
        return {"ok": False, "error": "Orden no válido para el área"}, 400
    por_id = {i.id: i for i in grupo}
    for posicion, ident in enumerate(ids):
        por_id[ident].orden = posicion
    save_pmf(pmf)
    return {"ok": True}


@app.route("/cortas/intervenciones/limpiar", methods=["POST"])
def limpiar_intervenciones_corta():
    pmf = get_pmf()
    pmf.plan_cortas.intervenciones = []
    save_pmf(pmf)
    flash("Se limpiaron todos los registros del plan de cortas", "success")
    return redirect(url_for("ver_cortas"))


@app.route("/cortas/exportar/excel")
def exportar_plan_cortas_excel():
    pmf = get_pmf()
    cache = {}
    datos = [pmf.datos_intervencion_corta(i, cache)
             for i in _intervenciones_ordenadas_tabla8(pmf)]

    from io import BytesIO
    from flask import Response
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = "Plan de Cortas"
    wb.properties.creator = FIRMA_EXPORTACION
    ws.oddFooter.center.text = FIRMA_EXPORTACION
    ws.merge_cells("A1:H1")
    ws["A1"] = "Tabla 8 - Posibilidad anual y plan de cortas, por unidad mínima de manejo"
    ws["A1"].font = Font(bold=True, size=13, color="FFFFFF")
    ws["A1"].fill = PatternFill("solid", fgColor="0F3D23")
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 26

    ws["A2"] = "Área de Corta"
    ws.merge_cells("B2:C2")
    ws["B2"] = "Unidad Mínima de Manejo (UMM)"
    ws.merge_cells("D2:D3")
    ws["D2"] = "Tratamiento Silvícola"
    ws.merge_cells("E2:F2")
    ws["E2"] = "Posibilidad"
    ws.merge_cells("G2:G3")
    ws["G2"] = "Volumen por infraestructura (m3 VTA)"
    ws.merge_cells("H2:H3")
    ws["H2"] = "Posibilidad + volumen por infraestructura (m3 VTA)"
    ws["A3"] = "No."
    ws["B3"] = "No."
    ws["C3"] = "Superficie (ha)"
    ws["E3"] = "Género"
    ws["F3"] = "m3 VTA"

    borde_fino = Side(style="thin", color="AAB7AA")
    borde = Border(left=borde_fino, right=borde_fino, top=borde_fino, bottom=borde_fino)
    for fila in ws.iter_rows(min_row=2, max_row=3, min_col=1, max_col=8):
        for celda in fila:
            celda.font = Font(bold=True, color="FFFFFF")
            celda.fill = PatternFill("solid", fgColor="1A5632")
            celda.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            celda.border = borde

    fila_actual = 4
    totales_generales = {"superficie": 0.0, "posibilidad": 0.0,
                         "infraestructura": 0.0, "total": 0.0}
    for anualidad in pmf.plan_cortas.anualidades:
        grupo = [dato for dato in datos if dato["intervencion"].anualidad == anualidad.numero]
        if not grupo:
            continue
        subtotal = {"superficie": 0.0, "posibilidad": 0.0,
                    "infraestructura": 0.0, "total": 0.0}
        inicio_grupo = fila_actual
        for dato in grupo:
            intervencion = dato["intervencion"]
            filas = dato["filas"] or [{"especie": "", "posibilidad": 0.0,
                                        "infraestructura": 0.0, "total": 0.0}]
            inicio_intervencion = fila_actual
            subtotal["superficie"] += intervencion.superficie_ha
            for fila in filas:
                ws.append([intervencion.anualidad, intervencion.rodal_id,
                           intervencion.superficie_ha, intervencion.tratamiento,
                           fila["especie"], fila["posibilidad"],
                           fila["infraestructura"], fila["total"]])
                subtotal["posibilidad"] += fila["posibilidad"]
                subtotal["infraestructura"] += fila["infraestructura"]
                subtotal["total"] += fila["total"]
                fila_actual += 1
            if len(filas) > 1:
                for columna in ("B", "C", "D"):
                    ws.merge_cells(f"{columna}{inicio_intervencion}:{columna}{fila_actual - 1}")
        if fila_actual - 1 > inicio_grupo:
            ws.merge_cells(start_row=inicio_grupo, start_column=1,
                           end_row=fila_actual - 1, end_column=1)
            ws.cell(inicio_grupo, 1).alignment = Alignment(
                horizontal="center", vertical="center")

        ws.append([f"Subtotal Anualidad {anualidad.numero}", "", subtotal["superficie"],
                   "Subtotal", "", subtotal["posibilidad"],
                   subtotal["infraestructura"], subtotal["total"]])
        ws.merge_cells(start_row=fila_actual, start_column=1, end_row=fila_actual, end_column=2)
        ws.merge_cells(start_row=fila_actual, start_column=4, end_row=fila_actual, end_column=5)
        for celda in ws[fila_actual]:
            celda.font = Font(bold=True, color="0F3D23")
            celda.fill = PatternFill("solid", fgColor="E7EFE7")
        for clave in totales_generales:
            totales_generales[clave] += subtotal[clave]
        fila_actual += 1

    ws.append(["TOTAL GENERAL", "", totales_generales["superficie"], "TOTAL", "",
               totales_generales["posibilidad"], totales_generales["infraestructura"],
               totales_generales["total"]])
    ws.merge_cells(start_row=fila_actual, start_column=1, end_row=fila_actual, end_column=2)
    ws.merge_cells(start_row=fila_actual, start_column=4, end_row=fila_actual, end_column=5)
    for celda in ws[fila_actual]:
        celda.font = Font(bold=True, color="FFFFFF")
        celda.fill = PatternFill("solid", fgColor="0F3D23")

    for fila in ws.iter_rows(min_row=4, max_row=fila_actual, min_col=1, max_col=8):
        for celda in fila:
            celda.border = borde
            celda.alignment = Alignment(vertical="center", wrap_text=True)
        for indice in (3, 6, 7, 8):
            fila[indice - 1].number_format = "#,##0.000"
    anchos = {"A": 18, "B": 16, "C": 17, "D": 28, "E": 24, "F": 16, "G": 24, "H": 28}
    for columna, ancho in anchos.items():
        ws.column_dimensions[columna].width = ancho
    ws.freeze_panes = "A4"

    salida = BytesIO()
    wb.save(salida)
    return Response(salida.getvalue(),
                    mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": "attachment;filename=plan_de_cortas.xlsx"})


def _etiqueta_area_corta(numero, anio):
    """Etiqueta del área de corta con año de ejecución (1-2027)."""
    return f"{numero}-{anio}" if anio else str(numero)


@app.route("/cortas/resumen/exportar/excel")
def exportar_resumen_plan_cortas_excel():
    pmf = get_pmf()
    grupos, total_general = _resumen_plan_cortas(pmf)

    from io import BytesIO
    from flask import Response
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

    wb = Workbook()
    ws = wb.active
    ws.title = "Resumen Plan de Cortas"
    wb.properties.creator = FIRMA_EXPORTACION
    ws.oddFooter.center.text = FIRMA_EXPORTACION
    ws.merge_cells("A1:F1")
    ws["A1"] = "Tabla 9 - Posibilidad anual y plan de cortas (resumen)ᵇ"
    ws["A1"].font = Font(bold=True, size=13, color="FFFFFF")
    ws["A1"].fill = PatternFill("solid", fgColor="0F3D23")
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 26

    ws.merge_cells("A2:A3")
    ws["A2"] = "Área de Corta No."
    ws.merge_cells("B2:C2")
    ws["B2"] = "Posibilidad"
    ws.merge_cells("D2:D3")
    ws["D2"] = "Volumen por infraestructura (m3 VTA)"
    ws.merge_cells("E2:E3")
    ws["E2"] = "Posibilidad + volumen por infraestructura (m3 VTA)"
    ws.merge_cells("F2:F3")
    ws["F2"] = "Especies por aprovechar"
    ws["B3"] = "Especie"
    ws["C3"] = "m3 VTA"

    lado = Side(style="thin", color="AAB7AA")
    borde = Border(left=lado, right=lado, top=lado, bottom=lado)
    for fila in ws.iter_rows(min_row=2, max_row=3, min_col=1, max_col=6):
        for celda in fila:
            celda.font = Font(bold=True, color="FFFFFF")
            celda.fill = PatternFill("solid", fgColor="1A5632")
            celda.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            celda.border = borde

    fila_actual = 4
    for grupo in grupos:
        inicio_grupo = fila_actual
        etiqueta = _etiqueta_area_corta(grupo["numero"], grupo.get("anio"))
        for fila in grupo["filas"]:
            ws.append([etiqueta, fila["especie"], fila["posibilidad"],
                       fila["infraestructura"], fila["total"], fila["especie"]])
            fila_actual += 1
        if len(grupo["filas"]) > 1:
            ws.merge_cells(start_row=inicio_grupo, start_column=1,
                           end_row=fila_actual - 1, end_column=1)
        subtotal = grupo["subtotal"]
        ws.append([f"Subtotalᵃ Área de Corta {etiqueta}", "",
                   subtotal["posibilidad"], subtotal["infraestructura"],
                   subtotal["total"], ""])
        ws.merge_cells(start_row=fila_actual, start_column=1,
                       end_row=fila_actual, end_column=2)
        for celda in ws[fila_actual]:
            celda.font = Font(bold=True, color="0F3D23")
            celda.fill = PatternFill("solid", fgColor="E7EFE7")
        fila_actual += 1

    ws.append(["Totalᵃ", "", total_general["posibilidad"],
               total_general["infraestructura"], total_general["total"], ""])
    ws.merge_cells(start_row=fila_actual, start_column=1,
                   end_row=fila_actual, end_column=2)
    for celda in ws[fila_actual]:
        celda.font = Font(bold=True, color="FFFFFF")
        celda.fill = PatternFill("solid", fgColor="0F3D23")
    ultima_fila_datos = fila_actual
    fila_actual += 2
    ws.merge_cells(start_row=fila_actual, start_column=1, end_row=fila_actual, end_column=6)
    ws.cell(fila_actual, 1, "a Incluir subtotales por área de corta y totales para el predio.")
    fila_actual += 1
    ws.merge_cells(start_row=fila_actual, start_column=1, end_row=fila_actual, end_column=6)
    ws.cell(fila_actual, 1, "b Esta tabla debe incluirse en el cuerpo del Programa de Manejo Forestal.")

    for fila in ws.iter_rows(min_row=4, max_row=ultima_fila_datos, min_col=1, max_col=6):
        for celda in fila:
            celda.border = borde
            celda.alignment = Alignment(vertical="center", wrap_text=True)
        for indice in (3, 4, 5):
            fila[indice - 1].number_format = "#,##0.000"
    for fila in range(ultima_fila_datos + 2, fila_actual + 1):
        ws.cell(fila, 1).font = Font(italic=True, size=9)
    anchos = {"A": 20, "B": 26, "C": 16, "D": 26, "E": 30, "F": 26}
    for columna, ancho in anchos.items():
        ws.column_dimensions[columna].width = ancho
    ws.freeze_panes = "A4"

    salida = BytesIO()
    wb.save(salida)
    return Response(salida.getvalue(),
                    mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": "attachment;filename=resumen_plan_de_cortas.xlsx"})


# =============== INTENSIDAD DE CORTA ===============

@app.route("/cortas/intensidades")
def editar_intensidades():
    pmf = get_pmf()
    return render_template("cortas/intensidades.html", pmf=pmf)


@app.route("/cortas/intensidades/guardar", methods=["POST"])
def guardar_intensidades():
    pmf = get_pmf()
    for key, val in request.form.items():
        if key.startswith("int_"):
            parts = key.split("_")
            rid = parts[1]
            esp = "_".join(parts[2:])
            try:
                pct = float(val)
                if pct < 0 or pct > 100:
                    continue
                pmf.intensidad_corta.setdefault(rid, {})[esp] = pct
            except:
                pass
    save_pmf(pmf)
    flash("Intensidades guardadas", "success")
    return redirect(url_for("editar_intensidades"))


# =============== REPORTES ===============

_ESTADISTICA_MUESTREO_VACIA = {"n": 0, "media_m3_ha": None, "varianza": None,
                               "desviacion_estandar": None, "cv_pct": None, "error_estandar": None,
                               "t_critico": None, "error_absoluto_m3_ha": None, "error_relativo_pct": None,
                               "error_relativo_final_pct": None, "li_m3_ha": None, "ls_m3_ha": None,
                               "li_practico_m3_ha": None, "estado": "Sin información",
                               "poblacion_N": None, "superficie_sitio_ha": None, "superficie_sitio_m2": None,
                               "intensidad_muestreo_pct": None, "fpc_factor": 1.0, "grados_libertad": None,
                               "advertencia_fpc": None,
                               "mensaje": "No es posible calcular el error de muestreo con menos de 2 sitios válidos."}

AVISO_VERSION_MOTOR_MUESTREO_ANTERIOR = ("Resultado calculado con la versión anterior del motor. "
                                         "Recalcule para actualizar el estado de cumplimiento y la "
                                         "inclusión de sitios en cero.")


def _version_motor_muestreo_anterior(version_str):
    """True si el registro fue calculado con un motor anterior a la versión 3.0."""
    try:
        partes = [int(parte) for parte in str(version_str).split(".")[:2]]
    except (TypeError, ValueError):
        return True
    while len(partes) < 2:
        partes.append(0)
    return tuple(partes[:2]) < (3, 0)


def _error_reportado(estadistica):
    """Error de muestreo a mostrar: siempre el estadístico (error_relativo_pct).

    Ignora cualquier error_relativo_final_pct almacenado: en registros calculados
    con el motor anterior a la versión 3.0 ese campo contiene el valor dividido
    entre 10. Esta función solo lee; nunca reescribe el registro guardado.
    """
    estadistica = estadistica or {}
    valor = estadistica.get("error_relativo_pct")
    return valor if isinstance(valor, (int, float)) and not isinstance(valor, bool) else None


def _aplicar_exclusion_rodales(datos, excluidos):
    """Filtra rodales excluidos por el usuario y renormaliza los agregados.

    El cálculo (media, error, volumen, sitios requeridos) se refiere solo al
    conjunto incluido: la superficie del predio pasa a ser la suma de los
    rodales incluidos. Devuelve (ids_excluidos, datos_excluidos). Solo se usa
    en Error de muestreo; no toca el resto de los procedimientos.
    """
    ids = {str(i) for i in (excluidos or []) if str(i)}
    presentes = {str(r.get("id")) for r in datos.get("rodales", [])}
    ids = {i for i in ids if i in presentes}
    if not ids:
        return [], []
    excluidos_datos = copy.deepcopy([r for r in datos.get("rodales", []) if str(r.get("id")) in ids])
    datos["rodales"] = [r for r in datos.get("rodales", []) if str(r.get("id")) not in ids]
    if not datos["rodales"]:
        raise ErrorMuestreoValidacion("Seleccione al menos un rodal para el cálculo.")
    superficie = sum(float(r.get("superficie_ha") or 0) for r in datos["rodales"])
    muestreada = sum(float(s.get("tamano_m2") or 0) for r in datos["rodales"] for s in r.get("sitios", [])) / 10000
    datos["superficie_predio_ha"] = superficie
    datos["superficie_representada_ha"] = superficie
    datos["superficie_no_representada_ha"] = 0.0
    datos["superficie_muestreada_ha"] = muestreada
    datos["intensidad_total_pct"] = (muestreada / superficie * 100) if superficie else 0
    datos["sitios_validos"] = sum(len(r.get("sitios", [])) for r in datos["rodales"])
    datos["sitios_cero"] = sum(1 for r in datos["rodales"] for s in r.get("sitios", []) if s.get("estado") == "completado_cero")
    return sorted(ids), excluidos_datos


def _normalizar_registro_muestreo(registro):
    """Garantiza la forma mínima para vista/exportación sin recalcular nada.

    Los registros degradados (sin 'estadistica' u otras claves) mostraban
    500 Internal Server Error al renderizar; se rellenan con valores nulos
    que las plantillas ya representan como '—'.
    """
    resultado = registro.get("resultado", {}) or {}
    registro["resultado"] = resultado
    predio = resultado.setdefault("predio", {})
    predio.setdefault("nombre", "No registrado")
    configuracion = resultado.setdefault("configuracion", {})
    configuracion.setdefault("diseno_muestreo", "No registrado")
    configuracion.setdefault("nivel_confianza", "No registrado")
    validacion = resultado.setdefault("validacion", {})
    for clave in ("sitios_validos", "sitios_cero", "superficie_predio_ha",
                  "superficie_representada_ha", "superficie_muestreada_ha",
                  "superficie_no_representada_ha"):
        validacion.setdefault(clave, 0)
    rodales = resultado.get("rodales")
    if not isinstance(rodales, list):
        resultado["rodales"] = []
        rodales = []
    validos = []
    for rodal in rodales:
        if not isinstance(rodal, dict):
            continue
        validos.append(rodal)
        rodal.setdefault("clave", "sin clave")
        rodal.setdefault("superficie_ha", 0)
        rodal.setdefault("intensidad_pct", 0)
        rodal.setdefault("volumen_estimado_m3", 0)
        rodal.setdefault("error_total_m3", None)
        rodal.setdefault("li_total_m3", None)
        rodal.setdefault("ls_total_m3", None)
        if not isinstance(rodal.get("sitios"), list):
            rodal["sitios"] = []
        rodal["sitios"] = [s for s in rodal["sitios"] if isinstance(s, dict)]
        if not isinstance(rodal.get("estadistica"), dict):
            rodal["estadistica"] = dict(_ESTADISTICA_MUESTREO_VACIA)
        else:
            base = dict(_ESTADISTICA_MUESTREO_VACIA)
            base.update(rodal["estadistica"])
            rodal["estadistica"] = base
        for sitio in rodal["sitios"]:
            sitio.setdefault("numero", None)
            sitio.setdefault("estado", "No registrado")
            sitio.setdefault("tamano_m2", None)
            sitio.setdefault("volumen_sitio_m3", None)
            sitio.setdefault("volumen_ha_m3", None)
    resultado["rodales"] = validos
    general = resultado.get("resultado_general")
    if not isinstance(general, dict):
        resultado["resultado_general"] = {"estado": "No evaluable", "clasificacion": "No evaluable",
                                          "error_relativo_pct": None, "error_relativo_final_pct": None}
    if not isinstance(resultado.get("limitaciones"), list):
        resultado["limitaciones"] = []
    resultado.setdefault("fpc_estado", "No registrado")
    if not isinstance(resultado.get("diagnostico_conjunto"), dict):
        resultado["diagnostico_conjunto"] = {}
    if not isinstance(resultado.get("comprobacion"), dict):
        resultado["comprobacion"] = {}
    if not isinstance(resultado.get("diagnostico"), dict):
        resultado["diagnostico"] = None
    resultado["aviso_version_motor"] = (AVISO_VERSION_MOTOR_MUESTREO_ANTERIOR
                                        if _version_motor_muestreo_anterior(resultado.get("version_motor"))
                                        else None)
    return registro

@app.route("/error-muestreo")
def error_muestreo():
    pmf = get_pmf()
    # Proyectos creados antes de la matriz no contienen estos campos.
    if not hasattr(pmf, "muestreo_borradores"):
        pmf.muestreo_borradores = []
    if not hasattr(pmf, "muestreo_error"):
        pmf.muestreo_error = []
    for registro in pmf.muestreo_error:
        if not isinstance(registro, dict):
            continue
        _normalizar_registro_muestreo(registro)
        resultado = registro.get("resultado", {})
        validacion = resultado.setdefault("validacion", {})
        validacion.setdefault("intensidad_total_pct", None)
        resultado.setdefault("fpc_estado", "No registrado")
        resultado.setdefault("limitaciones", [])
        resultado.setdefault("resultado_general", {"clasificacion": "No evaluable"})
    historial = list(reversed(pmf.muestreo_error))
    actual = historial[0] if historial else None
    return render_template("error_muestreo/index.html", pmf=pmf, actual=actual,
                           historial=historial, version_motor_muestreo=VERSION_MOTOR_MUESTREO)


@app.route("/error-muestreo/importar", methods=["POST"])
def importar_error_muestreo():
    archivo = request.files.get("archivo")
    if not archivo or not archivo.filename:
        flash("Seleccione el JSON exportado por MOREDIF.", "danger")
        return redirect(url_for("error_muestreo"))
    try:
        contenido = archivo.read()
        documento = json.loads(contenido.decode("utf-8"))
        datos = normalizar_documento(documento)
        # La copia de trabajo conserva los valores fuente y los editables por separado.
        for rodal in datos["rodales"]:
            rodal["origen"] = "importado_moredif"
            for sitio in rodal["sitios"]:
                sitio.update({
                    "volumen_sitio_original_m3": sitio["volumen_sitio_m3"],
                    "volumen_ha_original_m3": sitio["volumen_ha_m3"],
                    "volumen_sitio_trabajo_m3": sitio["volumen_sitio_m3"],
                    "volumen_ha_trabajo_m3": sitio["volumen_ha_m3"],
                    "superficie_original_m2": sitio["tamano_m2"],
                    "superficie_trabajo_m2": sitio["tamano_m2"],
                    "estado_original": sitio["estado"], "estado_trabajo": sitio["estado"],
                    "origen": "importado_moredif", "fue_modificado": False,
                })
    except UnicodeDecodeError:
        flash("El archivo debe estar codificado como UTF-8.", "danger")
        return redirect(url_for("error_muestreo"))
    except (json.JSONDecodeError, ErrorMuestreoValidacion) as error:
        flash(f"No se importó el archivo: {error}", "danger")
        return redirect(url_for("error_muestreo"))

    pmf = get_pmf()
    trazabilidad = documento.get("trazabilidad", {})
    borrador = {
        "id": secrets.token_hex(12),
        "fecha_importacion": datetime.datetime.now().isoformat(),
        "usuario": session.get("usuario", ""),
        "archivo_nombre": os.path.basename(archivo.filename),
        "sha256_archivo": hash_archivo(contenido),
        "hash_fuente_moredif": trazabilidad.get("hash_fuente"),
        "schema": documento.get("schema"), "version_schema": documento.get("version"),
        "version_motor": VERSION_MOTOR_MUESTREO, "datos": datos,
        # Se conserva el byte original para recalcular y auditar sin depender de MOREDIF.
        "archivo_original_base64": base64.b64encode(contenido).decode("ascii"),
        "configuracion_original": documento.get("configuracion", {}),
    }
    # Solo se conserva el borrador en trabajo: cada importación sustituye al anterior.
    pmf.muestreo_borradores = [borrador]
    if save_pmf(pmf):
        flash("Archivo validado. Revise y confirme la matriz antes de calcular.", "success")
        return redirect(url_for("matriz_error_muestreo", borrador_id=borrador["id"]))
    else:
        flash("El archivo fue validado, pero no fue posible guardar el borrador.", "danger")
    return redirect(url_for("error_muestreo"))


def _buscar_borrador_muestreo(pmf, borrador_id):
    return next((item for item in pmf.muestreo_borradores if item.get("id") == borrador_id), None)


@app.route("/error-muestreo/matriz/<borrador_id>")
def matriz_error_muestreo(borrador_id):
    pmf = get_pmf()
    borrador = _buscar_borrador_muestreo(pmf, borrador_id)
    if not borrador:
        flash("El borrador de muestreo no existe.", "danger")
        return redirect(url_for("error_muestreo"))
    rodales = borrador["datos"]["rodales"]
    try:
        numeros = sorted({int(sitio["numero"]) for rodal in rodales for sitio in rodal["sitios"]})
    except (TypeError, ValueError):
        flash("El borrador contiene un número de sitio inválido; vuelva a importar el archivo.", "danger")
        return redirect(url_for("error_muestreo"))
    por_rodal = {str(rodal["id"]): {sitio["numero"]: sitio for sitio in rodal["sitios"]} for rodal in rodales}
    n_total_rodales = len(rodales)
    try:
        datos_ini = copy.deepcopy(borrador.get("datos") or {})
        excluidos_ini, _ = _aplicar_exclusion_rodales(datos_ini, borrador.get("excluidos") or [])
        n_incluidos = len(datos_ini.get("rodales", []))
        calculo_inicial = calcular_error_muestreo(
            datos_normalizados=datos_ini,
            continuar_sin_fpc=True)
    except (ErrorMuestreoValidacion, ValueError, KeyError, TypeError):
        calculo_inicial = {"rodales": []}
        excluidos_ini = []
        n_incluidos = None
    previa_rodal = {}
    for item in calculo_inicial.get("rodales") or []:
        est = item.get("estadistica") or {}
        final = _error_reportado(est)
        previa_rodal[str(item.get("id"))] = {"n": est.get("n"), "N": est.get("poblacion_N"), "E": final}
    general_inicial = calculo_inicial.get("resultado_general") or {}
    _info_inicial = general_inicial.get("error_relativo_informativo_pct")
    previa_general = {"E": _error_reportado(general_inicial),
                      "I": (_info_inicial if isinstance(_info_inicial, (int, float))
                            and not isinstance(_info_inicial, bool) else None),
                      "estado": general_inicial.get("estado")}
    if previa_general["E"] is not None:
        previa_general["texto"] = f"{previa_general['E']:.2f} %"
        previa_general["insignia"] = previa_general["estado"] or "Sin calcular"
        previa_general["clave"] = previa_general["estado"] or ""
    elif previa_general["I"] is not None:
        previa_general["texto"] = f"{previa_general['I']:.2f} %"
        previa_general["insignia"] = "Informativo"
        previa_general["clave"] = "Informativo"
    else:
        previa_general["texto"] = "—"
        previa_general["insignia"] = previa_general["estado"] or "Sin calcular"
        previa_general["clave"] = previa_general["estado"] or ""
    return render_template("error_muestreo/matriz.html", borrador=borrador, rodales=rodales,
                           numeros=numeros, por_rodal=por_rodal, previa_rodal=previa_rodal,
                           previa_general=previa_general, excluidos=excluidos_ini,
                           n_total_rodales=n_total_rodales, n_incluidos=n_incluidos)


@app.route("/error-muestreo/matriz/<borrador_id>/previa", methods=["POST"])
def previa_matriz_error_muestreo(borrador_id):
    pmf = get_pmf()
    borrador = _buscar_borrador_muestreo(pmf, borrador_id)
    if not borrador:
        return jsonify({"ok": False, "mensaje": "El borrador de muestreo no existe."}), 404
    previa = request.get_json(force=True, silent=True) or {}
    datos = copy.deepcopy(borrador.get("datos", {}) or {})
    if not isinstance(datos.get("rodales"), list) or not isinstance(datos.get("configuracion"), dict):
        return jsonify({"ok": False, "mensaje": "El borrador no contiene datos válidos."}), 400
    unidad = str(previa.get("unidad", "sitio"))
    celdas = previa.get("celdas", {}) or {}
    try:
        for rodal in datos.get("rodales", []) or []:
            conservados = []
            for sitio in rodal.get("sitios", []) or []:
                clave = f"volumen_{sitio.get('id')}"
                if clave not in celdas:
                    conservados.append(sitio)
                    continue
                texto = str(celdas.get(clave, "")).strip().replace(",", ".")
                if texto == "":
                    continue
                valor = float(texto)
                if not math.isfinite(valor) or valor < 0:
                    raise ErrorMuestreoValidacion("La vista previa omite valores no numéricos o negativos.")
                area = float(sitio.get("tamano_m2") or 400)
                valor_sitio = valor if unidad != "ha" else valor * area / 10000
                sitio["volumen_sitio_m3"] = valor_sitio
                sitio["volumen_ha_m3"] = valor_sitio * 10000 / area
                sitio["volumen_sitio_trabajo_m3"] = valor_sitio
                sitio["volumen_ha_trabajo_m3"] = sitio["volumen_ha_m3"]
                conservados.append(sitio)
            existentes = {s.get("numero") for s in conservados}
            for clave, texto in celdas.items():
                prefijo = f"nuevo_{rodal.get('id')}_"
                if not clave.startswith(prefijo):
                    continue
                texto = str(texto or "").strip().replace(",", ".")
                if texto == "":
                    continue
                numero = int(clave[len(prefijo):])
                if numero in existentes:
                    continue
                valor = float(texto)
                if not math.isfinite(valor) or valor < 0:
                    raise ErrorMuestreoValidacion("La vista previa omite valores no numéricos o negativos.")
                area = float(rodal.get("tamano_predeterminado_m2") or 400)
                valor_sitio = valor if unidad != "ha" else valor * area / 10000
                conservados.append({"id": "previa-" + secrets.token_hex(6), "numero": numero, "tamano_m2": area,
                                    "volumen_sitio_m3": valor_sitio, "volumen_ha_m3": valor_sitio * 10000 / area,
                                    "estado": "agregado_manual_simfi"})
                existentes.add(numero)
            rodal["sitios"] = sorted(conservados, key=lambda s: s.get("numero"))
        for nuevo in previa.get("rodales_nuevos", []) or []:
            datos.setdefault("rodales", []).append({"id": str(nuevo.get("id")), "clave": str(nuevo.get("clave", "")),
                                                    "superficie_ha": float(nuevo.get("superficie_ha") or 0),
                                                    "sitios": [], "origen": "agregado_manual_simfi"})
        excluidos, _ = _aplicar_exclusion_rodales(datos, previa.get("excluidos", []) or [])
        nh = {}
        for parte in str(previa.get("nh_texto", "")).split(","):
            if "=" in parte:
                clave, valor = parte.split("=", 1)
                try:
                    numero = int(valor.strip())
                except (TypeError, ValueError):
                    continue
                if numero > 0:
                    nh[clave.strip()] = numero
        resultado = calcular_error_muestreo(fpc_nh=nh, datos_normalizados=datos,
                                            continuar_sin_fpc=str(previa.get("opcion_fpc", "")) == "sin_fpc")
    except (ValueError, ErrorMuestreoValidacion) as error:
        return jsonify({"ok": False, "mensaje": str(error)}), 400
    def _final(est):
        return _error_reportado(est)
    return jsonify({"ok": True, "unidad": unidad,
                    "rodales": [{"id": r.get("id"), "clave": r.get("clave"), "n": (r.get("estadistica") or {}).get("n"),
                                 "poblacion_N": (r.get("estadistica") or {}).get("poblacion_N"),
                                 "intensidad_muestreo_pct": (r.get("estadistica") or {}).get("intensidad_muestreo_pct"),
                                 "error_relativo_pct": _final(r.get("estadistica")),
                                 "estado": (r.get("estadistica") or {}).get("estado")}
                                for r in resultado.get("rodales", [])],
                    "general": {"error_relativo_pct": _final(resultado.get("resultado_general")),
                                "error_relativo_informativo_pct": (resultado.get("resultado_general") or {}).get("error_relativo_informativo_pct"),
                                "estado": (resultado.get("resultado_general") or {}).get("estado")},
                    "excluidos": excluidos})


@app.route("/error-muestreo/volumenes/editar")
def editar_volumenes_error_muestreo():
    pmf = get_pmf()
    if not pmf.muestreo_error:
        flash("Confirme y calcule una matriz antes de editar volúmenes.", "danger")
        return redirect(url_for("error_muestreo"))
    actual = pmf.muestreo_error[-1]
    resultado = actual.get("resultado", {}) or {}
    rodales_resultado = resultado.get("rodales", []) or []
    if not rodales_resultado:
        flash("El cálculo confirmado no contiene rodales editables.", "danger")
        return redirect(url_for("error_muestreo"))
    datos = {"predio": copy.deepcopy(resultado.get("predio", {})),
             "configuracion": copy.deepcopy(resultado.get("configuracion", {})), "rodales": [],
             "advertencias": [], "resumen_muestreo": copy.deepcopy(resultado.get("resumen_muestreo", {}))}
    for rodal in rodales_resultado:
        sitios = []
        for sitio in rodal.get("sitios", []) or []:
            area = sitio.get("tamano_m2") or 400
            volumen = sitio.get("volumen_sitio_m3")
            volumen_ha = sitio.get("volumen_ha_m3")
            sitios.append({"id": sitio.get("id") or ("simfi-" + secrets.token_hex(6)),
                           "numero": sitio.get("numero"), "tamano_m2": area,
                           "volumen_sitio_m3": volumen, "volumen_ha_m3": volumen_ha,
                           "estado": sitio.get("estado") or "completado_datos",
                           "volumen_sitio_original_m3": sitio.get("volumen_sitio_original_m3", volumen),
                           "volumen_ha_original_m3": sitio.get("volumen_ha_original_m3", volumen_ha),
                           "volumen_sitio_trabajo_m3": volumen, "volumen_ha_trabajo_m3": volumen_ha,
                           "superficie_original_m2": sitio.get("superficie_original_m2", area),
                           "superficie_trabajo_m2": sitio.get("superficie_trabajo_m2", area),
                           "estado_original": sitio.get("estado_original", sitio.get("estado") or "completado_datos"),
                           "estado_trabajo": sitio.get("estado_trabajo", sitio.get("estado") or "completado_datos"),
                           "origen": "reapertura_calculo", "fue_modificado": False})
        area_pred = next((s["tamano_m2"] for s in sitios if s["tamano_m2"]), 400)
        datos["rodales"].append({"id": rodal.get("id"), "clave": rodal.get("clave") or str(rodal.get("id")),
                                 "superficie_ha": rodal.get("superficie_ha"), "sitios": sitios,
                                 "origen": "reapertura_calculo", "tamano_predeterminado_m2": area_pred})
    excluidos_restaurados = []
    for rodal_ex in copy.deepcopy(actual.get("rodales_excluidos") or []):
        if str(rodal_ex.get("id")) not in {str(r.get("id")) for r in datos["rodales"]}:
            datos["rodales"].append(rodal_ex)
            excluidos_restaurados.append(str(rodal_ex.get("id")))
    superficie_representada = sum(float(r.get("superficie_ha") or 0) for r in datos["rodales"])
    superficie_muestreada = sum(float(s.get("tamano_m2") or 0) for r in datos["rodales"] for s in r.get("sitios", [])) / 10000
    superficie_predio = float((datos.get("predio") or {}).get("superficie_total_ha") or superficie_representada or 0)
    datos.update({"sitios_validos": sum(len(r.get("sitios", [])) for r in datos["rodales"]),
                  "sitios_cero": sum(1 for r in datos["rodales"] for s in r.get("sitios", []) if s.get("estado") == "completado_cero"),
                  "superficie_predio_ha": superficie_predio, "superficie_representada_ha": superficie_representada,
                  "superficie_muestreada_ha": superficie_muestreada,
                  "intensidad_total_pct": (superficie_muestreada / superficie_predio * 100) if superficie_predio else 0,
                  "superficie_no_representada_ha": superficie_predio - superficie_representada})
    borrador = {"id": secrets.token_hex(12), "fecha_importacion": datetime.datetime.now().isoformat(),
                "usuario": session.get("usuario", ""), "archivo_nombre": re.sub(r"( \(reedición\))+$", "", actual.get("archivo_nombre", "matriz confirmada")),
                "sha256_archivo": actual.get("sha256_archivo", ""), "hash_fuente_moredif": actual.get("hash_fuente_moredif", ""),
                "schema": actual.get("schema", "simfi.muestreo"), "version_schema": actual.get("version_schema", "1.0"),
                "version_motor": VERSION_MOTOR_MUESTREO, "datos": datos,
                "archivo_original_base64": actual.get("archivo_original_base64", ""),
                "configuracion_original": actual.get("configuracion_original", datos["configuracion"]),
                "origen": "reapertura_calculo", "reapertura_de": actual.get("id"),
                "excluidos": excluidos_restaurados}
    # Solo se conserva el borrador en trabajo: la reedición sustituye al anterior.
    pmf.muestreo_borradores = [borrador]
    if save_pmf(pmf):
        flash("Se abrió la matriz de volúmenes del cálculo confirmado. Al confirmar se generará un nuevo cálculo.", "success")
        return redirect(url_for("matriz_error_muestreo", borrador_id=borrador["id"]))
    flash("No fue posible abrir la matriz para edición.", "danger")
    return redirect(url_for("error_muestreo"))


@app.route("/error-muestreo/matriz/<borrador_id>/confirmar", methods=["POST"])
def confirmar_matriz_error_muestreo(borrador_id):
    pmf = get_pmf()
    borrador = _buscar_borrador_muestreo(pmf, borrador_id)
    if not borrador:
        flash("El borrador de muestreo no existe.", "danger")
        return redirect(url_for("error_muestreo"))
    datos = copy.deepcopy(borrador["datos"])
    correcciones = []
    try:
        nuevos_rodales = json.loads(request.form.get("rodales_nuevos_json", "[]"))
        for nuevo in nuevos_rodales:
            clave = str(nuevo.get("clave", "")).strip()
            superficie = float(nuevo.get("superficie_ha"))
            area = float(nuevo.get("tamano_m2", 400))
            if not clave or superficie <= 0 or area <= 0:
                raise ErrorMuestreoValidacion("Los rodales nuevos requieren clave, superficie y tamaño de sitio válidos.")
            if any(str(rodal["clave"]).casefold() == clave.casefold() for rodal in datos["rodales"]):
                raise ErrorMuestreoValidacion(f"La clave de rodal {clave} ya existe.")
            datos["rodales"].append({"id": str(nuevo["id"]), "clave": clave, "superficie_ha": superficie,
                                     "sitios": [], "origen": "agregado_manual_simfi", "tamano_predeterminado_m2": area})
        for rodal in datos["rodales"]:
            for sitio in rodal["sitios"]:
                campo = f"volumen_{sitio['id']}"
                texto = request.form.get(campo, "").strip()
                if not texto:
                    raise ErrorMuestreoValidacion("Las celdas de sitios existentes requieren un volumen.")
                valor = float(texto)
                if not math.isfinite(valor) or valor < 0:
                    raise ErrorMuestreoValidacion("Los volúmenes editados deben ser números finitos no negativos.")
                anterior = sitio["volumen_sitio_m3"]
                if not math.isclose(valor, anterior, rel_tol=1e-9, abs_tol=1e-9):
                    correcciones.append({"rodal_id": rodal["id"], "rodal": rodal["clave"], "sitio_id": sitio["id"],
                                        "numero": sitio["numero"], "anterior_m3": anterior, "nuevo_m3": valor})
                    sitio["volumen_sitio_m3"] = valor
                    sitio["volumen_ha_m3"] = valor * 10000 / sitio["tamano_m2"]
                    sitio["volumen_sitio_trabajo_m3"] = valor
                    sitio["volumen_ha_trabajo_m3"] = sitio["volumen_ha_m3"]
                    sitio["fue_modificado"] = True
            # Una celda previamente vacía con dato crea un sitio sólo en la copia de trabajo.
            existentes = {sitio["numero"] for sitio in rodal["sitios"]}
            for clave, texto in request.form.items():
                prefijo = f"nuevo_{rodal['id']}_"
                if not clave.startswith(prefijo) or not texto.strip():
                    continue
                numero = int(clave[len(prefijo):])
                if numero in existentes:
                    continue
                valor = float(texto.replace(",", "."))
                area = float(rodal.get("tamano_predeterminado_m2") or 400)
                if numero <= 0 or valor < 0 or not math.isfinite(valor):
                    raise ErrorMuestreoValidacion("Los sitios nuevos requieren número positivo y volumen no negativo.")
                rodal["sitios"].append({"id": "simfi-" + secrets.token_hex(10), "numero": numero, "tamano_m2": area,
                                        "volumen_sitio_m3": valor, "volumen_ha_m3": valor * 10000 / area,
                                        "estado": "agregado_manual_simfi", "estado_trabajo": "agregado_manual_simfi",
                                        "origen": "agregado_manual_simfi", "fue_modificado": True})
                correcciones.append({"rodal_id": rodal["id"], "rodal": rodal["clave"], "numero": numero,
                                    "tipo": "sitio_agregado", "nuevo_m3": valor})
            rodal["sitios"].sort(key=lambda sitio: sitio["numero"])
        try:
            excluidos_pedidos = json.loads(request.form.get("excluidos_json", "[]") or "[]")
        except (TypeError, ValueError):
            excluidos_pedidos = []
        excluidos, excluidos_datos = _aplicar_exclusion_rodales(datos, excluidos_pedidos)
        nh = {}
        for parte in request.form.get("nh_texto", "").split(","):
            if "=" in parte:
                clave, valor = parte.split("=", 1)
                nh[clave.strip()] = int(valor.strip())
        resultado = calcular_error_muestreo(fpc_nh=nh, datos_normalizados=datos,
                                            continuar_sin_fpc=request.form.get("opcion_fpc") == "sin_fpc")
    except (ValueError, ErrorMuestreoValidacion) as error:
        flash(f"No se confirmó la matriz: {error}", "danger")
        return redirect(url_for("matriz_error_muestreo", borrador_id=borrador_id))
    try:
        resultado["diagnostico"] = diagnosticar_muestreo(resultado)
    except Exception:
        resultado["diagnostico"] = None
    if excluidos:
        claves_exc = ", ".join(str(r.get("clave", r.get("id"))) for r in excluidos_datos)
        resultado.setdefault("limitaciones", []).append(
            f"Cálculo limitado por el usuario a {len(resultado.get('rodales', []))} de "
            f"{len(resultado.get('rodales', [])) + len(excluidos_datos)} rodales (excluidos: {claves_exc}).")
    registro = {key: borrador[key] for key in ("id", "fecha_importacion", "usuario", "archivo_nombre", "sha256_archivo",
                                               "hash_fuente_moredif", "schema", "version_schema", "version_motor",
                                               "archivo_original_base64", "configuracion_original")}
    registro.update({"fecha_calculo": datetime.datetime.now().isoformat(), "configuracion_utilizada": datos["configuracion"],
                     "correcciones_matriz": correcciones, "resultado": resultado,
                     "rodales_excluidos": excluidos_datos})
    pmf.muestreo_error.append(registro)
    pmf.muestreo_borradores = [item for item in pmf.muestreo_borradores if item.get("id") != borrador_id]
    if save_pmf(pmf):
        flash("Matriz confirmada y cálculo generado con trazabilidad.", "success")
    else:
        flash("La matriz se confirmó, pero no fue posible guardar el cálculo.", "danger")
    return redirect(url_for("error_muestreo"))


@app.route("/error-muestreo/exportar/excel")
def exportar_error_muestreo_excel():
    pmf = get_pmf()
    if not pmf.muestreo_error:
        return "No hay análisis para exportar", 404
    from io import BytesIO
    from openpyxl import Workbook
    from flask import Response
    registro = pmf.muestreo_error[-1]
    if not isinstance(registro, dict) or not isinstance(registro.get("resultado"), dict):
        return "No hay análisis para exportar", 404
    _normalizar_registro_muestreo(registro)
    resultado = registro["resultado"]
    libro = Workbook()
    sitios = libro.active
    sitios.title = "Datos por sitio"
    sitios.append(["Rodal", "Sitio", "Estado", "Superficie m2", "Volumen sitio m3", "Volumen ha m3"])
    for rodal in resultado["rodales"]:
        for sitio in rodal.get("sitios") or []:
            sitios.append([rodal.get("clave"), sitio.get("numero"), sitio.get("estado"), sitio.get("tamano_m2"),
                           sitio.get("volumen_sitio_m3"), sitio.get("volumen_ha_m3")])
    resumen = libro.create_sheet("Resultados por rodal")
    resumen.append(["Rodal", "Superficie ha", "n", "N", "Media m3/ha", "Var", "s", "CV %", "SE", "t", "gl", "Error de muestreo %", "LI", "LS", "Intensidad %", "Estado"])
    for rodal in resultado["rodales"]:
        e = rodal.get("estadistica") or {}
        final = _error_reportado(e)
        resumen.append([rodal.get("clave"), rodal.get("superficie_ha"), e.get("n"), e.get("poblacion_N"),
                        e.get("media_m3_ha"), e.get("varianza"), e.get("desviacion_estandar"), e.get("cv_pct"),
                        e.get("error_estandar"), e.get("t_critico"), e.get("grados_libertad"), final,
                        e.get("li_m3_ha"), e.get("ls_m3_ha"),
                        e.get("intensidad_muestreo_pct", rodal.get("intensidad_pct")), e.get("estado")])
    general = libro.create_sheet("Resultado general")
    general.append(["Indicador", "Valor"])
    for clave, valor in resultado["resultado_general"].items():
        if clave == "distribucion_sugerida_por_rodal":
            continue
        general.append([clave, valor])
    general.append([])
    general.append(["Distribución sugerida por rodal (mínimo 2 por rodal, proporcional a la superficie)"])
    general.append(["Rodal", "n_h sugerido"])
    for item in (resultado["resultado_general"].get("distribucion_sugerida_por_rodal") or []):
        general.append([item.get("clave"), item.get("n_h")])
    advertencias = libro.create_sheet("Advertencias")
    advertencias.append(["Mensaje"])
    for aviso in resultado["limitaciones"]:
        advertencias.append([aviso])
    hoja_diagnostico = libro.create_sheet("Diagnóstico")
    diagnostico = resultado.get("diagnostico")
    try:
        motor_anterior_diag = tuple(int(p) for p in str(resultado.get("version_motor")).split(".")[:2]) < (3, 0)
    except (TypeError, ValueError):
        motor_anterior_diag = True
    if not diagnostico or not diagnostico.get("disponible"):
        hoja_diagnostico.append(["Diagnóstico disponible al recalcular." if motor_anterior_diag
                                 else (diagnostico or {}).get("mensaje", "Diagnóstico no disponible.")])
    else:
        hoja_diagnostico.append(["Resumen"])
        hoja_diagnostico.append([diagnostico.get("resumen", "")])
        hoja_diagnostico.append([])
        hoja_diagnostico.append(["Aporte de cada rodal al error del predio (informativo)"])
        hoja_diagnostico.append(["Rodal", "Aporte %", "Acumulado %", "Clasificación"])
        for a in diagnostico.get("aporte_por_rodal", []):
            hoja_diagnostico.append([a["clave"], a["aporte_pct"], a["aporte_acumulado_pct"], a["clasificacion"]])
        hoja_diagnostico.append([])
        sitios_adic = diagnostico.get("sitios_adicionales", {})
        hoja_diagnostico.append(["Sitios adicionales recomendados"])
        hoja_diagnostico.append([sitios_adic.get("mensaje", "")])
        distribucion = sitios_adic.get("distribucion_por_rodal") or []
        if distribucion:
            hoja_diagnostico.append(["Rodal", "Sitios adicionales sugeridos"])
            for d in distribucion:
                hoja_diagnostico.append([d["clave"], d["sitios_adicionales"]])
        hoja_diagnostico.append([])
        hoja_diagnostico.append(["Sitios con volumen atípico - Revisar"])
        hoja_diagnostico.append(["Rodal", "Sitio", "Volumen m3", "Razón", "z", "Error sin el sitio %"])
        for a in diagnostico.get("sitios_atipicos_revisar", []):
            hoja_diagnostico.append([a["clave"], a["numero_sitio"], a["volumen_m3"], a["razon"], a["z"],
                                     a["error_general_sin_el_sitio_pct"]])
        hoja_diagnostico.append([])
        hoja_diagnostico.append(["Sitios con volumen atípico - Verificar (baja prioridad)"])
        hoja_diagnostico.append(["Rodal", "Sitio", "Volumen m3"])
        for a in diagnostico.get("sitios_atipicos_verificar", []):
            hoja_diagnostico.append([a["clave"], a["numero_sitio"], a["volumen_m3"]])
    analisis = interpretar_muestreo(resultado, registro.get("correcciones_matriz", []))
    interpretacion = libro.create_sheet("Interpretación")
    interpretacion.append(["Sección", "Texto"])
    interpretacion.append(["Título", analisis["titulo"]])
    interpretacion.append(["Estado", analisis["estado_datos"]])
    for titulo, textos in analisis["secciones"]:
        for texto in textos:
            interpretacion.append([titulo, texto])
    cuadros = libro.create_sheet("Cuadros")
    cuadros.append(list(analisis["encabezados"]))
    for fila in analisis["tabla"]:
        cuadros.append(list(fila))
    salida = BytesIO()
    libro.save(salida)
    return Response(salida.getvalue(), mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": "attachment;filename=error_muestreo.xlsx"})


@app.route("/error-muestreo/exportar/pdf")
def exportar_error_muestreo_pdf():
    pmf = get_pmf()
    if not pmf.muestreo_error:
        return "No hay análisis para exportar", 404
    registro = pmf.muestreo_error[-1]
    if not isinstance(registro, dict) or not isinstance(registro.get("resultado"), dict):
        return "No hay análisis para exportar", 404
    _normalizar_registro_muestreo(registro)
    resultado = registro["resultado"]
    analisis = interpretar_muestreo(resultado, registro.get("correcciones_matriz", []))
    return send_file(generar_pdf(pmf, analisis), as_attachment=True,
                     download_name="SIMFI_ANALISIS_ERROR_MUESTREO.pdf", mimetype="application/pdf")


@app.route("/error-muestreo/interpretacion")
def interpretar_error_muestreo():
    pmf = get_pmf()
    if not pmf.muestreo_error:
        flash("Confirme y calcule una matriz antes de generar la interpretación.", "danger")
        return redirect(url_for("error_muestreo"))
    registro = pmf.muestreo_error[-1]
    if not isinstance(registro, dict) or not isinstance(registro.get("resultado"), dict):
        flash("No hay análisis confirmado para interpretar.", "danger")
        return redirect(url_for("error_muestreo"))
    _normalizar_registro_muestreo(registro)
    analisis = interpretar_muestreo(registro["resultado"], registro.get("correcciones_matriz", []))
    resultado = registro["resultado"]
    configuracion = resultado.get("configuracion") or {}
    general = resultado.get("resultado_general") or {}
    ia_contexto = {
        "predio": (resultado.get("predio") or {}).get("nombre", "No registrado"),
        "configuracion": {
            "nivel_confianza_porcentaje": configuracion.get("nivel_confianza"),
            "error_objetivo_porcentaje": configuracion.get("error_objetivo_pct"),
            "fpc": resultado.get("fpc_estado"),
        },
        "rodales": [
            {
                "rodal": rodal.get("clave"), "superficie_ha": rodal.get("superficie_ha"),
                "volumen_estimado_m3": rodal.get("volumen_estimado_m3"),
                "n_sitios": (rodal.get("estadistica") or {}).get("n"),
                "media_m3_ha": (rodal.get("estadistica") or {}).get("media_m3_ha"),
                "error_relativo_porcentaje": (rodal.get("estadistica") or {}).get("error_relativo_pct"),
                "error_relativo_final_porcentaje": _error_reportado(rodal.get("estadistica")),
                "limite_inferior_m3_ha": (rodal.get("estadistica") or {}).get("li_m3_ha"),
                "limite_superior_m3_ha": (rodal.get("estadistica") or {}).get("ls_m3_ha"),
                "estado": (rodal.get("estadistica") or {}).get("estado"),
            }
            for rodal in resultado.get("rodales", []) if isinstance(rodal, dict)
        ],
        "resultado_general": {
            "estado": general.get("estado"),
            "clasificacion": general.get("clasificacion"),
            "media_m3_ha": general.get("media_m3_ha"),
            "error_relativo_porcentaje": general.get("error_relativo_pct"),
            "error_relativo_final_porcentaje": _error_reportado(general),
            "volumen_estimado_m3": general.get("volumen_estimado_m3"),
            "limites": (general.get("li_m3_ha"), general.get("ls_m3_ha")) if general.get("li_m3_ha") is not None else None,
        },
        "limitaciones": resultado.get("limitaciones", []),
    }
    return render_template("error_muestreo/interpretacion.html", analisis=analisis,
                           resultado=resultado, ia_tipo="muestreo", ia_contexto=ia_contexto)


@app.route("/error-muestreo/interpretacion/word")
def exportar_interpretacion_error_muestreo_word():
    pmf = get_pmf()
    if not pmf.muestreo_error:
        return "No hay análisis confirmado para exportar", 404
    registro = pmf.muestreo_error[-1]
    if not isinstance(registro, dict) or not isinstance(registro.get("resultado"), dict):
        return "No hay análisis confirmado para exportar", 404
    _normalizar_registro_muestreo(registro)
    analisis = interpretar_muestreo(registro["resultado"], registro.get("correcciones_matriz", []))
    from io import BytesIO
    salida = BytesIO()
    generar_word_error_muestreo(pmf, analisis, registro["resultado"]).save(salida)
    contenido = salida.getvalue()
    salida.seek(0)
    pmf.reportes_error_muestreo.append({"id": secrets.token_hex(10), "fecha": datetime.datetime.now().isoformat(),
                                        "usuario": session.get("usuario", ""), "analisis_id": registro.get("id"),
                                        "version_plantilla": VERSION_PLANTILLA_MUESTREO,
                                        "estado_comprobacion": "Pendiente de verificador independiente",
                                        "reglas": analisis["reglas"], "sha256_documento": hash_archivo(contenido)})
    save_pmf(pmf)
    nombre = re.sub(r"[^A-Za-z0-9_-]+", "_", str(registro["resultado"]["predio"].get("nombre", "PREDIO"))).strip("_") or "PREDIO"
    fecha = datetime.datetime.now().strftime("%Y%m%d")
    return send_file(salida, as_attachment=True,
                     download_name=f"SIMFI_ANALISIS_ERROR_MUESTREO_{nombre}_{fecha}_{VERSION_PLANTILLA_MUESTREO}.docx",
                     mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")

@app.route("/reportes")
def reportes():
    pmf = get_pmf()
    return render_template("reportes/index.html", pmf=pmf)


@app.route("/reportes/interpretacion")
def reporte_interpretacion_integral():
    pmf = get_pmf()
    nivel = request.args.get("nivel", "tecnico").strip().lower()
    nivel = nivel if nivel in NIVELES else "tecnico"
    contexto = construir_contexto(pmf)
    ia_contexto = None
    if contexto.get("rodales"):
        ia_contexto = {
            "predio": pmf.predio or pmf.nombre,
            "nivel": nivel,
            "rodales": [
                {
                    "rodal": r.get("id"),
                    "arboles_ha": r.get("n"),
                    "area_basal_ha_m2": r.get("g"),
                    "volumen_umm_m3": r.get("volumen"),
                    "posibilidad_umm_m3": r.get("posibilidad"),
                    "especie_principal": r.get("principal"),
                }
                for r in contexto.get("rodales", []) if isinstance(r, dict)
            ],
            "existencias_totales_m3": (contexto.get("existencias") or {}).get("total_vol_umm"),
            "posibilidad_total_m3": (contexto.get("existencias") or {}).get("total_pos_umm"),
            "alertas": contexto.get("alertas", []),
        }
    return render_template("reportes/interpretacion_integral.html", pmf=pmf, nivel=nivel,
                           contexto=contexto, ia_tipo="integral", ia_contexto=ia_contexto)


@app.route("/reportes/interpretacion/guardar", methods=["POST"])
def guardar_interpretacion_integral():
    pmf = get_pmf()
    nivel = request.form.get("nivel", "tecnico").strip().lower()
    nivel = nivel if nivel in NIVELES else "tecnico"
    reporte = pmf.registrar_reporte(construir_contexto(pmf), nivel, session.get("usuario", ""),
                                    request.form.get("observaciones", ""))
    if save_pmf(pmf):
        flash(f"Reporte técnico guardado con trazabilidad ({reporte['id'][:8]}).", "success")
    else:
        flash("No fue posible guardar la instantánea del reporte.", "danger")
    return redirect(url_for("reporte_interpretacion_integral", nivel=nivel))


@app.route("/reportes/interpretacion/exportar/<formato>")
def exportar_interpretacion_integral(formato):
    pmf = get_pmf()
    nivel = request.args.get("nivel", "tecnico").strip().lower()
    nivel = nivel if nivel in NIVELES else "tecnico"
    if formato == "word":
        return send_file(generar_word_integral(pmf, nivel), as_attachment=True,
                         download_name=f"SIMFI_Interpretacion_Integral_{nivel}.docx",
                         mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    if formato == "pdf":
        return send_file(generar_pdf_integral(pmf, nivel), as_attachment=True,
                         download_name=f"SIMFI_Interpretacion_Integral_{nivel}.pdf",
                         mimetype="application/pdf")
    return "Formato no válido", 404


@app.route("/reportes/concentrado")
def reporte_concentrado():
    pmf = get_pmf()
    data = pmf.concentrado_datos()
    ia_contexto = None
    if data and data.get("valores"):
        filas = []
        for (rid, esp), valores in data["valores"].items():
            if not isinstance(valores, dict):
                continue
            filas.append({
                "rodal": rid, "especie": esp,
                "arboles_ha": valores.get("Arb/ha"), "area_basal_ha_m2": valores.get("AB m2/ha"),
                "volumen_emm_m3": valores.get("ER m3/ha"), "volumen_ert_m3": valores.get("ERT VTA"),
                "ica_m3_ha_anio": valores.get("ICA m3"), "ica_porcentaje": valores.get("ICA %"),
                "diametro_medio_cm": valores.get("Dg cm"), "altura_media_m": valores.get("H prom m"),
            })
        ia_contexto = {"especies": data.get("especies", []), "rodales": data.get("rodales", []),
                       "variables": data.get("variables", []), "combinaciones": filas}
    return render_template("reportes/concentrado.html", pmf=pmf, data=data,
                           ia_tipo="concentrado", ia_contexto=ia_contexto)


@app.route("/reportes/cuadro_existencias")
def reporte_cuadro_existencias():
    pmf = get_pmf()
    data = pmf.cuadro_existencias()
    resumen = pmf.resumen_existencias_predio()
    contexto = construir_contexto(pmf)
    reporte = construir_datos_reporte_existencias(pmf, session.get("usuario", ""), SISTEMA_VERSION)
    ia_contexto = None
    if data.get("filas"):
        tratamientos = {}
        for intervencion in pmf.plan_cortas.intervenciones:
            tratamientos.setdefault(str(intervencion.rodal_id), []).append(
                intervencion.tratamiento)
        ia_contexto = contexto_semantico_existencias(
            data, resumen, contexto.get("alertas", []), tratamientos)
    return render_template("reportes/cuadro_existencias.html", pmf=pmf, data=data,
                           resumen=resumen, interpretacion=analisis_existencias(data, resumen, contexto),
                           reporte_existencias=reporte,
                            reglas_existencias=interpretar_reporte_existencias(reporte),
                             graficas_existencias=datos_graficas_existencias(reporte),
                             ocultar_botones_exportacion=True,
                             ia_tipo="cuadro_existencias", ia_contexto=ia_contexto)


@app.route("/reportes/cuadro_existencias/ordenar_rodales", methods=["POST"])
def ordenar_rodales_cuadro_existencias():
    pmf = get_pmf()
    try:
        orden = json.loads(request.form.get("orden_rodales", "[]"))
        visibles = [rodal for rodal in pmf.rodales if not rodal.oculto]
        ids_visibles = [rodal.id for rodal in visibles]
        if not isinstance(orden, list) or orden != list(dict.fromkeys(orden)):
            raise ValueError("El orden recibido no es válido.")
        if set(orden) != set(ids_visibles):
            raise ValueError("El orden debe contener todos los rodales visibles una sola vez.")
        por_id = {rodal.id: rodal for rodal in visibles}
        siguiente = iter(orden)
        pmf.rodales = [por_id[next(siguiente)] if not rodal.oculto else rodal
                       for rodal in pmf.rodales]
        save_pmf(pmf)
        flash("Orden de rodales actualizado para todo SIMFI.", "success")
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        flash(str(exc), "error")
    return redirect(url_for("reporte_cuadro_existencias"))


@app.route("/reportes/existencias/exportar/<formato>")
def exportar_existencias_tecnico(formato):
    pmf = get_pmf()
    reporte = construir_datos_reporte_existencias(pmf, session.get("usuario", ""), SISTEMA_VERSION)
    if reporte["balance"] == "revisar":
        return "No se puede emitir el reporte definitivo: revise las inconsistencias del balance volumétrico.", 409
    analisis = analisis_detallado_existencias(reporte, interpretar_reporte_existencias(reporte))
    predio = re.sub(r"[^A-Za-z0-9_-]+", "_", unicodedata.normalize("NFKD", pmf.predio or pmf.nombre).encode("ascii", "ignore").decode()).strip("_") or "Sin_predio"
    nombre = f"SIMFI_EXISTENCIAS_E_INTERPRETACION_{predio}_{datetime.date.today().isoformat()}_{SISTEMA_VERSION}"
    if formato == "excel":
        return exportar_cuadro_excel()
    if formato == "word":
        return send_file(generar_word_cuadro_existencias(
            pmf, reporte["cuadro"], analisis, pmf.resumen_existencias_predio()), as_attachment=True,
                         download_name=nombre + ".docx",
                         mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    if formato == "pdf":
        return send_file(generar_pdf_cuadro_existencias(
            pmf, reporte["cuadro"], analisis, pmf.resumen_existencias_predio()), as_attachment=True,
                         download_name=nombre + ".pdf", mimetype="application/pdf")
    return "Formato no válido", 404


@app.route("/reportes/cuadro_existencias/exportar/word")
def exportar_cuadro_existencias_word():
    pmf = get_pmf()
    reporte = construir_datos_reporte_existencias(pmf, session.get("usuario", ""), SISTEMA_VERSION)
    if reporte["balance"] == "revisar":
        return "No se puede emitir el reporte definitivo: revise las inconsistencias del balance volumétrico.", 409
    data = reporte["cuadro"]
    analisis = analisis_detallado_existencias(reporte, interpretar_reporte_existencias(reporte))
    predio = re.sub(r"[^A-Za-z0-9_-]+", "_", unicodedata.normalize("NFKD", pmf.predio or pmf.nombre).encode("ascii", "ignore").decode()).strip("_") or "Sin_predio"
    return send_file(generar_word_cuadro_existencias(
        pmf, data, analisis, pmf.resumen_existencias_predio()), as_attachment=True,
                     download_name=f"SIMFI_EXISTENCIAS_E_INTERPRETACION_{predio}_{datetime.date.today().isoformat()}_{SISTEMA_VERSION}.docx",
                     mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")


@app.route("/reportes/cuadro_existencias/exportar/excel")
def exportar_cuadro_excel():
    pmf = get_pmf()
    data = pmf.cuadro_existencias()
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    wb = Workbook()
    ws = wb.active
    ws.title = "Cuadro Existencias"
    wb.properties.creator = FIRMA_EXPORTACION
    ws.oddFooter.center.text = FIRMA_EXPORTACION
    encabezado_superior = ["Unidad Minima de Manejo (UMM)", "", "Especie",
                           "Existencias Reales", "", "", "Intensidad de Corta (%) Por UMM",
                           "Residuales", "Posibilidad", "", ""]
    encabezado_inferior = ["No.", "Superficie (ha)", "", "m³ VTA por Ha",
                           "m³ VTA por UMM", "Area basal m2/ha", "",
                           "m³ VTA por UMM", "Area basal m2/ha", "m³ VTA/ha", "m³ VTA/UMM"]
    verde = "1A5632"
    letras = "FFFFFF"
    verde_oscuro = "0F3D23"
    azul_claro = "D9D9D9"
    borde = Side(style="thin", color="CCCCCC")
    borde_celda = Border(left=borde, right=borde, top=borde, bottom=borde)
    enc_font = Font(bold=True, color="000000", size=11)
    enc_fill = PatternFill(start_color=verde, end_color=verde, fill_type="solid")
    ws.append(encabezado_superior)
    ws.append(encabezado_inferior)
    for fila_encabezado in (1, 2):
        for col_idx in range(1, 12):
            celda = ws.cell(row=fila_encabezado, column=col_idx)
            celda.font = enc_font
            celda.fill = PatternFill(start_color="D9D9D9", end_color="D9D9D9", fill_type="solid")
            celda.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            celda.border = borde_celda
    ws.merge_cells("A1:B1")
    ws.merge_cells("C1:C2")
    ws.merge_cells("D1:F1")
    ws.merge_cells("G1:G2")
    ws.merge_cells("H1:H2")
    ws.merge_cells("I1:K1")
    for referencia in ("A1", "C1", "D1", "G1", "H1", "I1"):
        ws[referencia].alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[1].height = 32
    ws.row_dimensions[2].height = 30
    fila_idx = 3
    rangos_rodal = []
    inicio_rodal = None
    rodal_actual = None
    for f in data.get("filas", []):
        if f.get("_type") == "subtotal":
            if inicio_rodal is not None:
                rangos_rodal.append((inicio_rodal, fila_idx - 1))
                inicio_rodal = None
                rodal_actual = None
            vals = [f"{f.get('rodal', '')} — Subtotal", "", "",
                    f.get("vol_ha", 0), f.get("vol_umm", 0), f.get("ab", 0),
                    "", f.get("res_vol", 0), f.get("res_ab", 0),
                    f.get("pos_ha", 0), f.get("pos_umm", 0)]
            ws.append(vals)
            for col_idx in range(1, len(vals) + 1):
                celda = ws.cell(row=fila_idx, column=col_idx)
                celda.font = Font(bold=True)
                celda.fill = PatternFill(start_color=azul_claro, end_color=azul_claro, fill_type="solid")
                celda.border = borde_celda
                if col_idx >= 4:
                    celda.alignment = Alignment(horizontal="right")
                    celda.number_format = "#,##0.00" if col_idx == 7 else "#,##0.000"
                else:
                    celda.alignment = Alignment(horizontal="center", vertical="center")
            ws.merge_cells(start_row=fila_idx, start_column=1, end_row=fila_idx, end_column=3)
            ws.cell(row=fila_idx, column=1).alignment = Alignment(horizontal="left", vertical="center")
        else:
            if inicio_rodal is None:
                inicio_rodal = fila_idx
                rodal_actual = f.get("rodal")
            elif f.get("rodal") != rodal_actual:
                rangos_rodal.append((inicio_rodal, fila_idx - 1))
                inicio_rodal = fila_idx
                rodal_actual = f.get("rodal")
            vals = [f.get("rodal", ""), f.get("superficie", 0), f.get("especie", ""),
                    f.get("vol_ha", 0), f.get("vol_umm", 0), f.get("ab", 0),
                    f.get("intensidad", ""), f.get("res_vol", 0), f.get("res_ab", 0),
                    f.get("pos_ha", 0), f.get("pos_umm", 0)]
            ws.append(vals)
            for col_idx in range(1, len(vals) + 1):
                celda = ws.cell(row=fila_idx, column=col_idx)
                celda.border = borde_celda
                if col_idx >= 4:
                    celda.alignment = Alignment(horizontal="right")
                    celda.number_format = "#,##0.00" if col_idx == 7 else "#,##0.000"
                else:
                    celda.alignment = Alignment(horizontal="center", vertical="center")
        ws.cell(row=fila_idx, column=2).number_format = "#,##0.000"
        fila_idx += 1

    if inicio_rodal is not None:
        rangos_rodal.append((inicio_rodal, fila_idx - 1))
    for inicio, fin in rangos_rodal:
        if fin > inicio:
            for columna in (1, 2):
                ws.merge_cells(start_row=inicio, start_column=columna,
                               end_row=fin, end_column=columna)
                ws.cell(row=inicio, column=columna).alignment = Alignment(
                    horizontal="center", vertical="center")
    ws.append([])
    fila_idx += 1
    total_vals = ["TOTAL", "", "", data.get("total_vol_ha", 0), data.get("total_vol_umm", 0),
                  data.get("total_ab", 0), data.get("total_intensidad", ""), data.get("total_res_vol", 0),
                  data.get("total_res_ab", 0), data.get("total_pos_ha", 0),
                  data.get("total_pos_umm", 0)]
    ws.append(total_vals)
    for col_idx in range(1, len(total_vals) + 1):
        celda = ws.cell(row=fila_idx, column=col_idx)
        celda.font = Font(bold=True, color=letras, size=11)
        celda.fill = PatternFill(start_color=verde, end_color=verde, fill_type="solid")
        celda.border = borde_celda
        if col_idx >= 4:
            celda.alignment = Alignment(horizontal="right")
            celda.number_format = "#,##0.00" if col_idx == 7 else "#,##0.000"
        else:
            celda.alignment = Alignment(horizontal="center", vertical="center")
    for col_idx in range(1, ws.max_column + 1):
        max_len = max((len(str(ws.cell(row=fila, column=col_idx).value or ""))
                       for fila in range(1, ws.max_row + 1)), default=8) + 2
        ws.column_dimensions[get_column_letter(col_idx)].width = max(max_len, 12)

    resumen = pmf.resumen_existencias_predio()
    ws_resumen = wb.create_sheet("Resumen Existencias")
    ws_resumen.merge_cells("A1:E1")
    ws_resumen["A1"] = "Tabla 6 - Resumen de existencias a nivel de predio o conjunto predial"
    ws_resumen["A1"].font = Font(bold=True, size=13, color="000000")
    ws_resumen["A1"].fill = PatternFill("solid", fgColor="D9D9D9")
    ws_resumen["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws_resumen.append(["Especie", "Existencias reales (m3 VTA)",
                       "Posibilidad (m3 VTA)", "Residuales (m3 VTA)", "Intensidad (%)"])
    for celda in ws_resumen[2]:
        celda.font = enc_font
        celda.fill = PatternFill("solid", fgColor="D9D9D9")
        celda.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        celda.border = borde_celda
    for fila in resumen["filas"]:
        ws_resumen.append([fila["especie"], fila["existencias"],
                           fila["posibilidad"], fila["residuales"],
                           fila["posibilidad"] * 100 / fila["existencias"]
                           if fila["existencias"] else None])
    totales = resumen["totales"]
    ws_resumen.append(["Total", totales["existencias"], totales["posibilidad"],
                       totales["residuales"],
                       totales["posibilidad"] * 100 / totales["existencias"]
                       if totales["existencias"] else None])
    for fila in ws_resumen.iter_rows(min_row=3, max_row=ws_resumen.max_row,
                                     min_col=1, max_col=5):
        for celda in fila:
            celda.border = borde_celda
            celda.alignment = Alignment(vertical="center")
        for indice in (2, 3, 4):
            fila[indice - 1].number_format = "#,##0.000"
        fila[4].number_format = "#,##0.00"
    for celda in ws_resumen[ws_resumen.max_row]:
        celda.font = Font(bold=True, color="000000")
        celda.fill = PatternFill("solid", fgColor="D9D9D9")
    for columna, ancho in (("A", 30), ("B", 26), ("C", 24), ("D", 24), ("E", 16)):
        ws_resumen.column_dimensions[columna].width = ancho
    ws_resumen.freeze_panes = "A3"
    import tempfile
    tmp = tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False)
    wb.save(tmp.name)
    tmp.close()
    with open(tmp.name, "rb") as f:
        bytes_data = f.read()
    os.unlink(tmp.name)
    from flask import Response
    return Response(bytes_data, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": "attachment;filename=cuadro_existencias.xlsx"})


@app.route("/reportes/resumen_existencias/exportar/excel")
def exportar_resumen_existencias_excel():
    pmf = get_pmf()
    resumen = pmf.resumen_existencias_predio()

    from io import BytesIO
    from flask import Response
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

    wb = Workbook()
    ws = wb.active
    ws.title = "Resumen Existencias"
    wb.properties.creator = FIRMA_EXPORTACION
    ws.oddFooter.center.text = FIRMA_EXPORTACION
    ws.merge_cells("A1:D1")
    ws["A1"] = "Tabla 6 - Resumen de existencias a nivel de predio o conjunto predial"
    ws["A1"].font = Font(bold=True, size=13, color="FFFFFF")
    ws["A1"].fill = PatternFill("solid", fgColor="0F3D23")
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 26

    encabezados = ["Especie", "Existencias reales (m3 VTA)",
                   "Posibilidad (m3 VTA)", "Residuales (m3 VTA)"]
    ws.append(encabezados)
    lado = Side(style="thin", color="AAB7AA")
    borde = Border(left=lado, right=lado, top=lado, bottom=lado)
    for celda in ws[2]:
        celda.font = Font(bold=True, color="FFFFFF")
        celda.fill = PatternFill("solid", fgColor="1A5632")
        celda.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        celda.border = borde

    for fila in resumen["filas"]:
        ws.append([fila["especie"], fila["existencias"],
                   fila["posibilidad"], fila["residuales"]])
    totales = resumen["totales"]
    ws.append(["Total", totales["existencias"], totales["posibilidad"], totales["residuales"]])
    fila_total = ws.max_row
    for fila in ws.iter_rows(min_row=3, max_row=fila_total, min_col=1, max_col=4):
        for celda in fila:
            celda.border = borde
            celda.alignment = Alignment(vertical="center")
        for indice in (2, 3, 4):
            fila[indice - 1].number_format = "#,##0.000"
    for celda in ws[fila_total]:
        celda.font = Font(bold=True, color="FFFFFF")
        celda.fill = PatternFill("solid", fgColor="0F3D23")

    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 26
    ws.column_dimensions["C"].width = 24
    ws.column_dimensions["D"].width = 24
    ws.freeze_panes = "A3"
    salida = BytesIO()
    wb.save(salida)
    return Response(salida.getvalue(),
                    mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": "attachment;filename=resumen_existencias.xlsx"})


@app.route("/reportes/cuadro_existencias/guardar_intensidad", methods=["POST"])
def guardar_intensidad():
    pmf = get_pmf()
    data = request.get_json()
    if not data or "intensidades" not in data:
        return jsonify({"error": "sin datos"}), 400
    for item in data["intensidades"]:
        rid = item.get("rodal")
        esp = item.get("especie")
        val = item.get("intensidad")
        if rid and esp and val is not None:
            intensidad = float(val)
            if intensidad < 0 or intensidad > 100:
                return jsonify({"error": "La intensidad debe estar entre 0 y 100"}), 400
            pmf.intensidad_corta.setdefault(rid, {})[esp] = intensidad
            # La celda se edito a mano: ya no refleja un criterio de aclareos.
            if rid in pmf.origen_intensidad and esp in pmf.origen_intensidad[rid]:
                del pmf.origen_intensidad[rid][esp]
                if not pmf.origen_intensidad[rid]:
                    del pmf.origen_intensidad[rid]
    save_pmf(pmf)
    return jsonify({"success": True})


@app.route("/reportes/cuadro_existencias/formatear_intensidades", methods=["POST"])
def formatear_intensidades():
    pmf = get_pmf()
    pmf.intensidad_corta = {}
    pmf.origen_intensidad = {}
    save_pmf(pmf)
    return jsonify({"success": True})


@app.route("/reportes/resumen_incrementos/guardar_parametros", methods=["POST"])
def guardar_parametros_incrementos():
    """Guarda TP y Edad aprobados por el usuario en el cuadro de incrementos.

    Recibe JSON {"ajustes": [{"rodal":, "especie":, "tp":, "edad":}]}.
    Un valor vacio restablece el calculado. Solo acepta numeros > 0.
    La categoria del TP se toma del servidor para garantizar que el aprobado
    coincida con la categoria evaluada en esa fila.
    """
    pmf = get_pmf()
    datos = request.get_json(silent=True) or {}
    ajustes = datos.get("ajustes")
    if not isinstance(ajustes, list) or not ajustes:
        return jsonify({"error": "Sin ajustes para guardar"}), 400
    vigentes = {}
    for fila in pmf.resumen_incrementos().get("filas", []):
        if not fila.get("_type"):
            rodal_fila = pmf.buscar_rodal(fila.get("rodal"))
            vigentes[(fila.get("rodal"), fila.get("especie"))] = {
                "categoria": fila.get("tp_categoria", ""),
                "directo": bool(rodal_fila and rodal_fila.tipo_inventario == "existencias"),
            }
    actualizados = 0
    restablecidos = 0
    try:
        for item in ajustes:
            if not isinstance(item, dict):
                continue
            rid = str(item.get("rodal", "") or "").strip()
            esp = str(item.get("especie", "") or "").strip()
            if (rid, esp) not in vigentes:
                continue
            if vigentes[(rid, esp)]["directo"]:
                # Renglon directo: TP y Edad se guardan en el registro de
                # incrementos (fuente unica para estos renglones).
                directo = pmf.buscar_incremento_directo(rid, esp)
                if not directo:
                    continue
                for campo, clave in (("tp", "tp"), ("edad", "edad")):
                    if clave not in item:
                        continue
                    valor = item.get(clave)
                    if valor is None or (isinstance(valor, str) and not valor.strip()):
                        setattr(directo, campo, None)
                        restablecidos += 1
                        continue
                    try:
                        numero = float(valor)
                    except (TypeError, ValueError):
                        return jsonify({"error": f"{campo} debe ser un numero mayor que cero"}), 400
                    if not math.isfinite(numero) or numero <= 0:
                        return jsonify({"error": f"{campo} debe ser un numero mayor que cero"}), 400
                    setattr(directo, campo, numero)
                    actualizados += 1
                continue
            if "tp" in item:
                categoria = vigentes[(rid, esp)]["categoria"]
                if item.get("tp") not in (None, "") and not categoria:
                    return jsonify({"error": f"Sin categoria evaluada para {rid} / {esp}"}), 400
                resultado = pmf.fijar_tp_aprobado(esp, categoria, item.get("tp"))
                if resultado is None:
                    restablecidos += 1
                else:
                    actualizados += 1
            if "edad" in item:
                resultado = pmf.fijar_edad_aprobada(rid, esp, item.get("edad"))
                if resultado is None:
                    restablecidos += 1
                else:
                    actualizados += 1
    except ValueError as error:
        return jsonify({"error": str(error)}), 400
    if not save_pmf(pmf):
        return jsonify({"error": "No se pudo guardar el proyecto"}), 500
    return jsonify({"success": True, "actualizados": actualizados,
                    "restablecidos": restablecidos})


@app.route("/reportes/resumen_incrementos")
def reporte_resumen_incrementos():
    pmf = get_pmf()
    data = pmf.resumen_incrementos()
    contexto = construir_contexto(pmf)
    ia_contexto = None
    if data.get("filas"):
        ia_contexto = contexto_semantico_incrementos(data, contexto.get("alertas", []))
    return render_template("reportes/resumen_incrementos.html", pmf=pmf, data=data,
                            interpretacion=analisis_incrementos(data, contexto),
                            ocultar_botones_exportacion=True,
                            ia_tipo="incrementos", ia_contexto=ia_contexto)


@app.route("/reportes/incrementos/exportar/<formato>")
def exportar_incrementos_tecnico(formato):
    pmf = get_pmf()
    data = pmf.resumen_incrementos()
    analisis = analisis_incrementos(data, construir_contexto(pmf))
    if formato == "excel":
        return exportar_incrementos_excel()
    if formato == "word":
        return send_file(generar_word_cuadro_incrementos(pmf, data, analisis), as_attachment=True,
                         download_name="SIMFI_Interpretacion_Incrementos.docx",
                         mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    if formato == "pdf":
        return send_file(generar_pdf_cuadro_incrementos(pmf, data, analisis), as_attachment=True,
                         download_name="SIMFI_Interpretacion_Incrementos.pdf", mimetype="application/pdf")
    return "Formato no válido", 404


def exportar_incrementos_excel():
    pmf = get_pmf()
    data = pmf.resumen_incrementos()
    from io import BytesIO
    from flask import Response
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = "Resumen Incrementos"
    wb.properties.creator = FIRMA_EXPORTACION
    ws.oddFooter.center.text = FIRMA_EXPORTACION
    ws.merge_cells("A1:J1")
    ws["A1"] = "Resumen de incrementos"
    ws["A1"].font = Font(bold=True, size=13, color="000000")
    ws["A1"].fill = PatternFill("solid", fgColor="D9D9D9")
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    encabezados = ["UMM", "Especie", "Sup (ha)", "Arb/ha", "AB (m2/ha)", "TP",
                   "ICA (m3/ha/a)", "ICA%", "IMA (m3/ha/a)", "Edad"]
    ws.append(encabezados)
    borde = Border(*(Side(style="thin", color="CCCCCC") for _ in range(4)))
    for celda in ws[2]:
        celda.font = Font(bold=True, color="000000")
        celda.fill = PatternFill("solid", fgColor="D9D9D9")
        celda.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        celda.border = borde
    fila_idx = 3
    rangos_rodal = []
    inicio = None
    rodal_actual = None

    def valor(valor, decimales):
        return None if valor in (None, "") else float(valor)

    for fila in data.get("filas", []):
        if fila.get("_type") == "subtotal":
            if inicio is not None:
                rangos_rodal.append((inicio, fila_idx - 1))
                inicio = None
                rodal_actual = None
            vals = ["Subtotal", "", "", valor(fila.get("arb_ha"), 2),
                    valor(fila.get("ab"), 3), "", valor(fila.get("ica"), 4),
                    "", valor(fila.get("ima"), 4), ""]
            ws.append(vals)
            for celda in ws[fila_idx]:
                celda.font = Font(bold=True, color="000000")
                celda.fill = PatternFill("solid", fgColor="D9D9D9")
                celda.border = borde
                celda.alignment = Alignment(horizontal="center", vertical="center")
        else:
            if inicio is None:
                inicio = fila_idx
                rodal_actual = fila.get("rodal")
            elif fila.get("rodal") != rodal_actual:
                rangos_rodal.append((inicio, fila_idx - 1))
                inicio = fila_idx
                rodal_actual = fila.get("rodal")
            ws.append([fila.get("rodal", ""), fila.get("especie", ""),
                       valor(fila.get("superficie"), 3), valor(fila.get("arb_ha"), 2),
                       valor(fila.get("ab"), 3), valor(fila.get("tp"), 1),
                       valor(fila.get("ica"), 4), valor(fila.get("ica_pct"), 2),
                       valor(fila.get("ima"), 4), valor(fila.get("edad"), 1)])
            for celda in ws[fila_idx]:
                celda.border = borde
                celda.alignment = Alignment(vertical="center")
        for columna in (3, 4, 5, 6, 7, 8, 9, 10):
            ws.cell(fila_idx, columna).number_format = {
                3: "0.000", 4: "0.00", 5: "0.000", 6: "0.0", 7: "0.0000",
                8: "0.00", 9: "0.0000", 10: "0.0"
            }[columna]
        fila_idx += 1
    if inicio is not None:
        rangos_rodal.append((inicio, fila_idx - 1))
    for inicio, fin in rangos_rodal:
        if fin > inicio:
            for columna in (1, 3):
                ws.merge_cells(start_row=inicio, start_column=columna,
                               end_row=fin, end_column=columna)
                ws.cell(inicio, columna).alignment = Alignment(
                    horizontal="center", vertical="center")
    total = ["TOTAL", "", valor(data.get("total_superficie"), 3),
             valor(data.get("total_arb_ha"), 2), valor(data.get("total_ab"), 3),
             valor(data.get("total_tp"), 1), valor(data.get("total_ica"), 4),
             valor(data.get("total_ica_pct"), 2), valor(data.get("total_ima"), 4),
             valor(data.get("total_edad"), 1)]
    ws.append(total)
    for celda in ws[ws.max_row]:
        celda.font = Font(bold=True, color="000000")
        celda.fill = PatternFill("solid", fgColor="D9D9D9")
        celda.border = borde
    for columna, ancho in enumerate((16, 24, 12, 12, 14, 10, 16, 10, 16, 10), 1):
        ws.column_dimensions[get_column_letter(columna)].width = ancho
    ws.freeze_panes = "A3"
    salida = BytesIO()
    wb.save(salida)
    return Response(salida.getvalue(),
                    mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": "attachment;filename=resumen_incrementos.xlsx"})


# ------------------------------------------------------------------ #
# Reforestación                                                       #
# ------------------------------------------------------------------ #

_CONIFERAS_REFORESTACION = ("Pinus", "Abies", "Cupressus", "Juniperus")

_SUBTITULO_REFORESTACION = ("Solo se reforestan coníferas (Pinus, Abies, Cupressus y "
                            "Juniperus); las latifoliadas se regeneran por rebrotes.")


@app.route("/reportes/reforestacion")
def reporte_reforestacion():
    """Cuadro de reforestación derivado del plan de cortas + capturas manuales."""
    pmf = get_pmf()
    disponibles = pmf.agregados_reforestacion()
    seleccion = {}
    if isinstance(pmf.reforestacion, dict):
        for registro in pmf.reforestacion.get("selecciones", []):
            if isinstance(registro, dict):
                try:
                    seleccion[int(registro.get("anualidad", 0))] = list(
                        registro.get("especies", []))
                except (TypeError, ValueError):
                    continue
    for disponible in disponibles:
        disponible["seleccionadas"] = seleccion.get(disponible["numero"], [])
        disponible["coniferas"] = [(especie, valor) for especie, valor
                                   in disponible["especies"] if es_conifera(especie)]
        disponible["rebrote"] = [(especie, valor) for especie, valor
                                 in disponible["especies"] if not es_conifera(especie)]
    coniferas_proyecto = sorted({e for e in pmf.especies if es_conifera(e)})
    return render_template("reportes/reforestacion.html", pmf=pmf,
                           datos=pmf.datos_reforestacion(),
                           disponibles=disponibles,
                           areas_manuales=pmf.reforestacion.get("manuales", [])
                           if isinstance(pmf.reforestacion, dict) else [],
                           coniferas=coniferas_proyecto,
                           es_conifera=es_conifera,
                           densidad=pmf.reforestacion.get("densidad")
                           if isinstance(pmf.reforestacion, dict) else None,
                           aviso_coniferas=_SUBTITULO_REFORESTACION)


@app.route("/reportes/reforestacion/guardar", methods=["POST"])
def guardar_reforestacion():
    """Guarda la densidad y las coníferas seleccionadas por área."""
    pmf = get_pmf()
    carga = request.get_json(silent=True) or {}
    densidad = carga.get("densidad")
    if densidad in (None, ""):
        densidad = None
    else:
        try:
            densidad = float(densidad)
        except (TypeError, ValueError):
            return jsonify({"success": False, "error": "La densidad debe ser un número"}), 400
        if densidad <= 0:
            return jsonify({"success": False,
                            "error": "La densidad debe ser mayor a cero"}), 400
    selecciones = []
    for registro in carga.get("selecciones", []):
        if not isinstance(registro, dict):
            continue
        try:
            anualidad = int(registro.get("anualidad", 0))
        except (TypeError, ValueError):
            continue
        especies = [esp for esp in registro.get("especies", [])
                    if isinstance(esp, str) and esp.strip()]
        conicidad = [esp for esp in especies if es_conifera(esp)]
        if any(e not in conicidad for e in especies):
            return jsonify({"success": False,
                            "error": "Solo pueden reforestarse coníferas"}), 400
        if anualidad > 0 and conicidad:
            selecciones.append({"anualidad": anualidad,
                                "especies": conicidad})
    estado = dict(pmf.reforestacion) if isinstance(pmf.reforestacion, dict) else {}
    superficies = estado.get("superficies") if isinstance(estado.get("superficies"), dict) else {}
    anios = estado.get("anios") if isinstance(estado.get("anios"), dict) else {}
    manuales = estado.get("manuales") if isinstance(estado.get("manuales"), list) else []
    pmf.reforestacion = {"densidad": densidad, "selecciones": selecciones,
                         "superficies": superficies, "anios": anios,
                         "manuales": manuales}
    if not pmf.guardar(pmf.ruta_archivo):
        return jsonify({"success": False,
                        "error": "No se pudo guardar el proyecto"}), 500
    return jsonify({"success": True})


@app.route("/reportes/reforestacion/anio", methods=["POST"])
def guardar_anio_reforestacion():
    """Guarda el año de ejecución editado por el usuario para un área.

    Sin edición, el cuadro calcula el año del plan de cortas + 1.
    """
    pmf = get_pmf()
    carga = request.get_json(silent=True) or {}
    try:
        anualidad = int(carga.get("anualidad", 0))
    except (TypeError, ValueError):
        return jsonify({"success": False, "error": "Área no válida"}), 400
    if anualidad <= 0:
        return jsonify({"success": False, "error": "Área no válida"}), 400
    try:
        pmf.establecer_anio_reforestacion(anualidad, carga.get("anio"))
    except ValueError as error:
        return jsonify({"success": False, "error": str(error)}), 400
    if not pmf.guardar(pmf.ruta_archivo):
        return jsonify({"success": False,
                        "error": "No se pudo guardar el proyecto"}), 500
    return jsonify({"success": True})


@app.route("/reportes/reforestacion/superficie", methods=["POST"])
def guardar_superficie_reforestacion():
    """Guarda la superficie editada por el usuario para un área del plan."""
    pmf = get_pmf()
    carga = request.get_json(silent=True) or {}
    try:
        anualidad = int(carga.get("anualidad", 0))
    except (TypeError, ValueError):
        return jsonify({"success": False, "error": "Área no válida"}), 400
    if anualidad <= 0:
        return jsonify({"success": False, "error": "Área no válida"}), 400
    try:
        pmf.establecer_superficie_reforestacion(
            anualidad, carga.get("superficie"))
    except ValueError as error:
        return jsonify({"success": False, "error": str(error)}), 400
    if not pmf.guardar(pmf.ruta_archivo):
        return jsonify({"success": False,
                        "error": "No se pudo guardar el proyecto"}), 500
    return jsonify({"success": True})


@app.route("/reportes/reforestacion/area_manual/agregar", methods=["POST"])
def agregar_area_manual_reforestacion():
    """Registra un área de regeneración capturada manualmente."""
    pmf = get_pmf()
    carga = request.get_json(silent=True) or {}
    try:
        pmf.agregar_area_manual_reforestacion(
            carga.get("nombre"), carga.get("anio"), carga.get("superficie"),
            carga.get("filas", []))
    except ValueError as error:
        return jsonify({"success": False, "error": str(error)}), 400
    if not pmf.guardar(pmf.ruta_archivo):
        return jsonify({"success": False,
                        "error": "No se pudo guardar el proyecto"}), 500
    return jsonify({"success": True})


@app.route("/reportes/reforestacion/area_manual/eliminar", methods=["POST"])
def eliminar_area_manual_reforestacion():
    """Elimina un área manual del cuadro de reforestación."""
    pmf = get_pmf()
    carga = request.get_json(silent=True) or {}
    if not pmf.eliminar_area_manual_reforestacion(carga.get("id", "")):
        return jsonify({"success": False, "error": "Área no encontrada"}), 404
    if not pmf.guardar(pmf.ruta_archivo):
        return jsonify({"success": False,
                        "error": "No se pudo guardar el proyecto"}), 500
    return jsonify({"success": True})


@app.route("/reportes/reforestacion/exportar/<formato>")
def exportar_reforestacion(formato):
    pmf = get_pmf()
    datos = pmf.datos_reforestacion()
    if not datos.get("areas"):
        flash("No hay especies seleccionadas para reforestar", "error")
        return redirect(url_for("reporte_reforestacion"))
    disponibles = pmf.agregados_reforestacion()
    if formato == "excel":
        return exportar_reforestacion_excel(datos)
    if formato == "word":
        return send_file(generar_word_cuadro_reforestacion(pmf, datos, disponibles),
                         as_attachment=True,
                         download_name="SIMFI_Cuadro_Reforestacion.docx",
                         mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    if formato == "pdf":
        return send_file(generar_pdf_cuadro_reforestacion(pmf, datos, disponibles),
                         as_attachment=True,
                         download_name="SIMFI_Cuadro_Reforestacion.pdf",
                         mimetype="application/pdf")
    return "Formato no válido", 404


def exportar_reforestacion_excel(datos):
    from io import BytesIO
    from flask import Response
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = "Reforestación"
    wb.properties.creator = FIRMA_EXPORTACION
    ws.oddFooter.center.text = FIRMA_EXPORTACION
    ws.merge_cells("A1:F1")
    ws["A1"] = "Cuadro de reforestación"
    ws["A1"].font = Font(bold=True, size=13, color="000000")
    ws["A1"].fill = PatternFill("solid", fgColor="D9D9D9")
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    if datos.get("densidad"):
        ws.merge_cells("A2:F2")
        ws["A2"] = f"Densidad de plantación: {datos['densidad']:,.0f} plantas/ha"
        ws["A2"].font = Font(italic=True, color="555555")
        ws.append([])
    encabezados = ["Área de regeneración", "Superficie (ha)", "Especie",
                   "Proporción (%)", "Número de plantas", "Año de ejecución"]
    ws.append(encabezados)
    borde = Border(*(Side(style="thin", color="CCCCCC") for _ in range(4)))
    fila_encabezado = ws.max_row
    for celda in ws[fila_encabezado]:
        celda.font = Font(bold=True, color="000000")
        celda.fill = PatternFill("solid", fgColor="D9D9D9")
        celda.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        celda.border = borde
    fila_idx = fila_encabezado + 1
    for area in datos.get("areas", []):
        inicio = fila_idx
        for fila in area.get("filas", []):
            ws.append([area.get("numero") if area.get("numero") is not None else area["etiqueta"], float(area["superficie"]),
                       fila["especie"], round(float(fila["proporcion"]), 2),
                       float(round(fila["plantas"])) if fila.get("plantas") is not None else None,
                       area["anio"]])
            for celda in ws[fila_idx]:
                celda.border = borde
                celda.alignment = Alignment(horizontal="center", vertical="center")
            ws.cell(fila_idx, 2).number_format = "#,##0.000"
            ws.cell(fila_idx, 4).number_format = "0.00"
            ws.cell(fila_idx, 5).number_format = "#,##0"
            fila_idx += 1
        if fila_idx - 1 > inicio:
            ws.merge_cells(start_row=inicio, start_column=1,
                           end_row=fila_idx - 1, end_column=1)
            ws.merge_cells(start_row=inicio, start_column=2,
                           end_row=fila_idx - 1, end_column=2)
            ws.merge_cells(start_row=inicio, start_column=6,
                           end_row=fila_idx - 1, end_column=6)
        subtotal = ["Subtotal {}".format(area["etiqueta"]), float(area["superficie"]),
                    "", round(float(area.get("subtotal_proporcion", 0.0)), 2),
                    float(round(area["subtotal_plantas"])) if datos.get("densidad") else None,
                    area["anio"]]
        ws.append(subtotal)
        for celda in ws[fila_idx]:
            celda.font = Font(bold=True, color="000000")
            celda.fill = PatternFill("solid", fgColor="D9D9D9")
            celda.border = borde
            celda.alignment = Alignment(horizontal="center", vertical="center")
        ws.cell(fila_idx, 2).number_format = "#,##0.000"
        ws.cell(fila_idx, 5).number_format = "#,##0"
        fila_idx += 1
    ws.append([])
    fila_idx += 1
    ws.append(["Total general", "", "", "", float(round(datos.get("total_general", 0.0))) if datos.get("densidad") else None, ""])
    for celda in ws[fila_idx]:
        celda.font = Font(bold=True, color="000000")
        celda.fill = PatternFill("solid", fgColor="E2EFDA")
        celda.border = borde
        celda.alignment = Alignment(horizontal="center", vertical="center")
    ws.cell(fila_idx, 5).number_format = "#,##0"
    fila_idx += 1
    ws.append([])
    fila_idx += 1
    ws.append(["Totales por especie"])
    ws.cell(fila_idx, 1).font = Font(bold=True, color="000000")
    ws.cell(fila_idx, 1).fill = PatternFill("solid", fgColor="D9D9D9")
    fila_idx += 1
    for especie, plantas in sorted(datos.get("totales_especie", {}).items()):
        ws.append(["", especie, float(round(plantas)), "", "", ""])
        ws.cell(fila_idx, 2).alignment = Alignment(horizontal="left")
        ws.cell(fila_idx, 3).number_format = "#,##0"
        for celda in ws[fila_idx]:
            celda.border = borde
        fila_idx += 1
    for columna, ancho in enumerate((22, 16, 28, 14, 18, 16), 1):
        ws.column_dimensions[get_column_letter(columna)].width = ancho
    ws.freeze_panes = ws.cell(fila_encabezado + 1, 1).coordinate
    salida = BytesIO()
    wb.save(salida)
    return Response(salida.getvalue(),
                    mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": "attachment;filename=reforestacion.xlsx"})


@app.route("/aclareos")
def aclareos():
    return render_template("aclareos/index.html")


def _contexto_turnos(pmf, calculo=None, formulario=None, error=None, extension=None):
    catalogo = cargar_catalogo_turnos()
    ia_tipo = "turnos"
    ia_contexto = None
    if calculo:
        ia_contexto = {
            "especie": calculo.get("especie"),
            "nombre_cientifico": calculo.get("nombre_cientifico"),
            "calidad_estacion": calculo.get("calidad_estacion"),
            "diametro_objetivo_cm": calculo.get("diametro_objetivo"),
            "edad_calculada_anios": calculo.get("edad_calculada"),
            "edad_redondeada_anios": calculo.get("edad_redondeada"),
            "diametro_verificacion_cm": calculo.get("diametro_verificacion"),
            "modelo": calculo.get("modelo"),
            "tipo_ecuacion": calculo.get("tipo_ecuacion"),
            "condicion_tabular": calculo.get("condicion_tabular"),
            "extrapolacion": bool(calculo.get("extrapolacion")),
            "rango_ordinario_anios": calculo.get("rango_ordinario"),
            "turno_referencia_publicado_anios": calculo.get("turno_referencia_publicado"),
            "diametro_referencia_publicado_cm": calculo.get("diametro_referencia_publicado"),
            "advertencias": calculo.get("advertencias", []),
        }
    return {
        "pmf": pmf, "catalogo": catalogo, "calculo": calculo,
        "calidades_por_especie": {
            especie: list(datos.get("calidades", {}))
            for especie, datos in catalogo.get("especies", {}).items()
        },
        "grafica": generar_datos_grafica_turno(calculo, catalogo) if calculo else None,
        "formulario": formulario or {}, "error": error, "extension": extension,
        "historial": list(reversed(pmf.calculos_turno)),
        "ia_tipo": ia_tipo, "ia_contexto": ia_contexto,
    }


@app.route("/turnos", methods=["GET", "POST"])
def turnos():
    pmf = get_pmf()
    if request.method == "POST":
        formulario = {
            "especie": request.form.get("especie", "").strip(),
            "calidad_estacion": request.form.get("calidad_estacion", "").strip(),
            "diametro_objetivo": request.form.get("diametro_objetivo", "").strip(),
        }
        ampliar = request.form.get("accion") == "ampliar_200"
        try:
            calculo = calcular_turno_tecnico(
                formulario["especie"], formulario["calidad_estacion"],
                formulario["diametro_objetivo"], ampliar_hasta_200=ampliar)
            calculo.update({
                "id": secrets.token_hex(8),
                "proyecto_id": pmf.ruta_archivo or pmf.nombre,
                "fecha_calculo": datetime.datetime.now().isoformat(timespec="seconds"),
                "usuario": session.get("usuario"),
            })
            pmf.calculos_turno.append(calculo)
            save_pmf(pmf)
            flash("Turno técnico calculado y guardado en el proyecto activo.", "success")
            return redirect(url_for("turnos", calculo=calculo["id"]))
        except ErrorTurno as exc:
            contexto = _contexto_turnos(
                pmf, formulario=formulario, error=str(exc),
                extension=exc.detalles if exc.codigo == "requiere_extension" else None)
            return render_template("turnos/index.html", **contexto), 400

    calculo_id = request.args.get("calculo", "").strip()
    calculo = next((item for item in pmf.calculos_turno if item.get("id") == calculo_id), None)
    formulario = ({"especie": calculo["especie"],
                   "calidad_estacion": calculo["calidad_estacion"],
                   "diametro_objetivo": calculo["diametro_objetivo"]}
                  if calculo else {})
    return render_template("turnos/index.html", **_contexto_turnos(
        pmf, calculo=calculo, formulario=formulario))


@app.route("/turnos/reporte", methods=["POST"])
def reporte_turno():
    pmf = get_pmf()
    calculo_id = request.form.get("calculo_id", "").strip()
    calculo = next((item for item in pmf.calculos_turno if item.get("id") == calculo_id), None)
    if not calculo:
        return "No existe el cálculo de turno solicitado en el proyecto activo.", 404
    try:
        grafica_png = decodificar_png(request.form.get("grafica_png", ""))
        salida = generar_reporte_turno(
            pmf, calculo, grafica_png, os.path.join(IMG_DIR, "SIMFI GDE.png"))
    except (ValueError, OSError, KeyError) as exc:
        return str(exc), 400
    return send_file(
        salida, as_attachment=True,
        download_name=nombre_archivo_turno(
            calculo["especie"], pmf.predio or pmf.nombre),
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    )


def _evaluacion_aclareo_guardable(evaluacion):
    guardable = json.loads(json.dumps(evaluacion))
    guardable.pop("modelo", None)
    guardable.pop("grafica", None)
    guardable.get("actual", {}).pop("clases", None)
    resultado_actual = guardable.get("guia_actual", {}).get("resultado")
    if resultado_actual:
        resultado_actual.pop("trazabilidad", None)
    for escenario in guardable.get("escenarios", {}).values():
        escenario.pop("clases_residuales", None)
        escenario.pop("clases_extraidas", None)
        resultado = escenario.get("guia", {}).get("resultado")
        if resultado:
            resultado.pop("trazabilidad", None)
    return guardable


def _filas_especies_aclareos(pmf, con_subtotales=False):
    """Devuelve la misma tabla dasométrica mostrada en Intensidad de corta.

    Con con_subtotales=True agrega una fila de subtotal por rodal (solo para
    la vista en pantalla; la exportación usa las filas de datos).
    """
    filas_especies = []
    for rid in pmf.rodales_aclareo:
        inicio_rodal = len(filas_especies)
        for tabla in sorted((t for t in pmf.tablas_inventario if t.rodal_id == rid),
                            key=lambda tabla: _orden_especies(tabla.especie)):
            resumen = resumen_rodal_especie(pmf, rid, tabla.especie)
            if resumen:
                filas_especies.append(resumen)
        for registro in sorted((r for r in pmf.existencias_directas if r.rodal_id == rid),
                               key=lambda registro: _orden_especies(registro.especie)):
            resumen = resumen_rodal_especie(pmf, rid, registro.especie)
            if resumen:
                filas_especies.append(resumen)
        cantidad_especies = len(filas_especies) - inicio_rodal
        for indice in range(inicio_rodal, len(filas_especies)):
            filas_especies[indice]["_rowspan"] = cantidad_especies if indice == inicio_rodal else 0
        if con_subtotales and cantidad_especies:
            filas_especies.append({
                "_type": "subtotal", "rodal": rid,
                "n": sum(f["n"] for f in filas_especies[inicio_rodal:]),
                "g": sum(f["g"] for f in filas_especies[inicio_rodal:]),
                "v": sum(f["v"] for f in filas_especies[inicio_rodal:]),
            })
    return filas_especies


@app.route("/aclareos/intensidad-corta", methods=["GET", "POST"])
def intensidad_corta_aclareos():
    pmf = get_pmf()
    cuadro = pmf.cuadro_existencias()
    areas_por_rodal = {}
    for fila in cuadro.get("filas", []):
        if fila.get("_type") == "subtotal":
            continue
        rid = fila.get("rodal")
        area = areas_por_rodal.setdefault(rid, {"rodal": rid, "superficie": fila.get("superficie", 0),
                                                "especies": [], "vol_ha": 0, "vol_umm": 0, "ab": 0})
        area["especies"].append(fila.get("especie", ""))
        for clave in ("vol_ha", "vol_umm", "ab"):
            area[clave] += float(fila.get(clave, 0) or 0)
    areas = list(areas_por_rodal.values())
    ids_validos = {area["rodal"] for area in areas}
    pmf.rodales_aclareo = [rid for rid in pmf.rodales_aclareo if rid in ids_validos]
    accion = request.form.get("accion", "seleccionar_areas") if request.method == "POST" else ""
    if request.method == "POST" and accion == "seleccionar_areas":
        seleccionados = request.form.getlist("rodales_aclareo")
        pmf.rodales_aclareo = [area["rodal"] for area in areas
                               if area["rodal"] in seleccionados]
        save_pmf(pmf)
        cantidad = len(pmf.rodales_aclareo)
        flash(f"Se guardaron {cantidad} área(s) para el cálculo de aclareos.", "success")
        return redirect(url_for("intensidad_corta_aclareos", importar="1"))

    modelos = cargar_modelos_densidad()
    if request.method == "POST" and accion in {"generar_escenarios", "proponer_usuario", "adoptar", "calcular_veiga", "aplicar_cuadro", "aplicar_manual"}:
        rid = request.form.get("rodal", "").strip()
        especie = request.form.get("especie", "").strip()
        rodal = pmf.buscar_rodal(rid)
        if (not rodal or rodal.oculto or rid not in pmf.rodales_aclareo or
                (not pmf.buscar_tabla_inventario(rid, especie)
                 and not (rodal.tipo_inventario == "existencias"
                          and pmf.buscar_existencia_directa(rid, especie)))):
            flash("El rodal y especie no pertenecen a las áreas seleccionadas.", "error")
            return redirect(url_for("intensidad_corta_aclareos", importar="1"))
        clave = clave_analisis(rid, especie)
        try:
            if accion == "generar_escenarios":
                ciclo = float(request.form.get("ciclo_corta", 0))
                if ciclo <= 0 or ciclo > 100:
                    raise ValueError("El ciclo de corta debe ser mayor que 0 y no exceder 100 años.")
                pmf.plan_cortas.ciclo_corta_anios = ciclo
                evaluacion = construir_evaluacion(pmf, rid, especie, ciclo, modelos)
                registrar_trazabilidad(evaluacion, session.get("usuario"))
            elif accion == "calcular_veiga":
                guardada = pmf.escenarios_aclareo.get(clave)
                if not guardada:
                    raise ValueError("Primero genere los escenarios técnicos para esta especie.")
                evaluacion = json.loads(json.dumps(guardada))
                evaluacion["modelo"] = seleccionar_modelo(especie, modelos=modelos)
                actual_estructurado = resumen_rodal_especie(pmf, rid, especie)
                if not actual_estructurado or any(
                        not math.isclose(actual_estructurado[variable], evaluacion["actual"][variable], rel_tol=1e-7)
                        for variable in ("n", "g", "v")):
                    raise ValueError("El inventario cambió; regenere los escenarios antes de calcular Veiga.")
                parametros = {
                    "diametro_deseado": request.form.get("diametro_deseado", "").strip(),
                    "densidad_objetivo": request.form.get("densidad_objetivo", "").strip(),
                }
                edad_retro_raw = request.form.get("edad_retroproyeccion", "").strip()
                if edad_retro_raw:
                    parametros["edad_retroproyeccion"] = edad_retro_raw
                veiga = escenario_veiga(actual_estructurado, parametros=parametros, modelo=evaluacion["modelo"])
                evaluacion["escenarios"]["veiga"] = veiga
                evaluacion["adoptado"] = None
                registrar_trazabilidad(evaluacion, session.get("usuario"))
            elif accion in {"aplicar_cuadro", "aplicar_manual"}:
                guardada = pmf.escenarios_aclareo.get(clave)
                if not guardada:
                    raise ValueError("Primero genere los escenarios técnicos para esta especie.")
                evaluacion = json.loads(json.dumps(guardada))
                evaluacion["modelo"] = seleccionar_modelo(especie, modelos=modelos)
                actual_estructurado = resumen_rodal_especie(pmf, rid, especie)
                if not actual_estructurado or any(
                        not math.isclose(actual_estructurado[variable], evaluacion["actual"][variable], rel_tol=1e-7)
                        for variable in ("n", "g", "v")):
                    raise ValueError("El inventario cambió; regenere los escenarios antes de aplicar.")
                if accion == "aplicar_cuadro":
                    adoptado = evaluacion.get("adoptado") or {}
                    escenario_id = adoptado.get("escenario_id", "")
                    escenario = evaluacion.get("escenarios", {}).get(escenario_id)
                    if not escenario_id or not escenario:
                        raise ValueError("Adopte primero un escenario para aplicarlo al cuadro.")
                    porcentaje, motivo = intensidad_volumetrica_equivalente(escenario)
                    if porcentaje is None:
                        raise ValueError(motivo or "El escenario no se puede aplicar al cuadro.")
                    criterio = escenario.get("nombre", escenario_id)
                else:
                    try:
                        porcentaje = float(request.form.get("intensidad_manual", ""))
                    except (TypeError, ValueError):
                        raise ValueError("Indique una intensidad manual entre 0 y 100 %.")
                    if not math.isfinite(porcentaje) or porcentaje < 0 or porcentaje > 100:
                        raise ValueError("Indique una intensidad manual entre 0 y 100 %.")
                    escenario_id = "manual"
                    criterio = "Manual"
                anterior = float(pmf.intensidad_corta.get(rid, {}).get(especie, 0) or 0)
                pmf.intensidad_corta.setdefault(rid, {})[especie] = round(porcentaje, 2)
                pmf.origen_intensidad.setdefault(rid, {})[especie] = {
                    "criterio": criterio, "escenario_id": escenario_id,
                    "intensidad": round(porcentaje, 2),
                    "fecha": datetime.datetime.now().isoformat(timespec="seconds"),
                    "usuario": session.get("usuario", ""),
                }
                registrar_trazabilidad(evaluacion, session.get("usuario"))
                flash(f"Intensidad {porcentaje:.2f} % ({criterio}) aplicada al cuadro "
                      f"para {rid} / {especie} (anterior: {anterior:.2f} %).", "success")
            else:
                guardada = pmf.escenarios_aclareo.get(clave)
                if not guardada:
                    raise ValueError("Primero genere los escenarios técnicos para esta especie.")
                evaluacion = json.loads(json.dumps(guardada))
                evaluacion["modelo"] = seleccionar_modelo(especie, modelos=modelos)
                if accion == "proponer_usuario":
                    actual_estructurado = resumen_rodal_especie(pmf, rid, especie)
                    if not actual_estructurado or any(
                            not math.isclose(actual_estructurado[variable], evaluacion["actual"][variable], rel_tol=1e-7)
                            for variable in ("n", "g", "v")):
                        raise ValueError("El inventario cambió; regenere los escenarios antes de evaluar la propuesta.")
                    propuesta = escenario_usuario(
                        actual_estructurado, request.form.get("intensidad_usuario", ""),
                        request.form.get("unidad_usuario", ""), evaluacion["modelo"])
                    evaluacion["escenarios"]["usuario"] = propuesta
                    evaluacion["adoptado"] = None
                    registrar_trazabilidad(evaluacion, session.get("usuario"))
                else:
                    escenario_id = request.form.get("escenario_id", "")
                    escenario = evaluacion["escenarios"].get(escenario_id)
                    if not escenario or escenario.get("estado") != "disponible":
                        raise ValueError("El escenario seleccionado no está disponible para adopción.")
                    evaluacion["adoptado"] = {
                        "escenario_id": escenario_id,
                        "criterio": escenario["nombre"],
                        "intensidad": escenario["intensidad_original"],
                        "unidad": escenario["unidad_original"],
                        "residual": escenario["residual"],
                        "fecha": datetime.datetime.now().isoformat(timespec="seconds"),
                        "usuario": session.get("usuario"),
                    }
            pmf.escenarios_aclareo[clave] = _evaluacion_aclareo_guardable(evaluacion)
            save_pmf(pmf)
            flash("Evaluación de aclareo actualizada.", "success")
            destino = url_for("intensidad_corta_aclareos", importar="1", rid=rid, especie=especie)
            if accion in {"aplicar_cuadro", "aplicar_manual"}:
                return redirect(destino + "#intensidades-aplicadas")
            return redirect(destino + "#evaluacion-aclareo")
        except (ValueError, TypeError) as exc:
            flash(str(exc), "error")
            return redirect(url_for("intensidad_corta_aclareos", importar="1", rid=rid, especie=especie))

    filas_especies = _filas_especies_aclareos(pmf, con_subtotales=True)
    rid_activo = request.args.get("rid", "").strip()
    especie_activa = request.args.get("especie", "").strip()
    evaluacion = None
    if rid_activo and especie_activa:
        guardada = pmf.escenarios_aclareo.get(clave_analisis(rid_activo, especie_activa))
        if guardada:
            evaluacion = json.loads(json.dumps(guardada))
            modelo = seleccionar_modelo(especie_activa, modelos=modelos)
            evaluacion["modelo"] = modelo
            evaluacion["grafica"] = datos_grafica_aclareo(
                evaluacion["actual"], modelo,
                evaluacion.get("guia_actual", {}).get("resultado"))
    ia_contexto = None
    pct_aplicar = None
    if evaluacion:
        adoptado_vista = evaluacion.get("adoptado") or {}
        escenario_vista = (evaluacion.get("escenarios") or {}).get(
            adoptado_vista.get("escenario_id", ""), {})
        pct_aplicar, _motivo = intensidad_volumetrica_equivalente(escenario_vista)
    if evaluacion:
        actual = evaluacion.get("actual") or {}
        guia = evaluacion.get("guia_actual") or {}
        escenarios = []
        for esc in (evaluacion.get("escenarios") or {}).values():
            if not isinstance(esc, dict):
                continue
            entrada = {"id": esc.get("id"), "nombre": esc.get("nombre"),
                       "estado": esc.get("estado"), "unidad": esc.get("unidad_original")}
            if esc.get("mensaje"):
                entrada["mensaje"] = esc["mensaje"]
            if esc.get("intensidad_original") is not None:
                entrada["intensidad_original_porcentaje"] = esc["intensidad_original"]
            residual = esc.get("residual")
            if isinstance(residual, dict):
                entrada["residual"] = {
                    "arboles_ha": residual.get("n"), "area_basal_ha_m2": residual.get("g"),
                    "volumen_ha_m3": residual.get("v"), "diametro_medio_cm": residual.get("dq"),
                }
            resultado_guia = (esc.get("guia") or {}).get("resultado")
            if resultado_guia is not None:
                entrada["condicion_residual_guia"] = resultado_guia
            escenarios.append(entrada)
        adoptado = evaluacion.get("adoptado")
        ia_contexto = {
            "rodal": actual.get("rodal"), "especie": actual.get("especie"),
            "superficie_ha": actual.get("superficie"),
            "ciclo_corta_anios": evaluacion.get("ciclo_corta"),
            "estado_actual": {
                "arboles_ha": actual.get("n"), "area_basal_ha_m2": actual.get("g"),
                "volumen_ha_m3": actual.get("v"), "diametro_medio_cm": actual.get("dq"),
                "tiempo_paso_anios": actual.get("tp"), "ica_m3_ha_anio": actual.get("ica"),
                "ima_m3_ha_anio": actual.get("ima"),
                "tasa_incremento_volumetrico_porcentaje": actual.get("tasa_incremento_volumetrico_pct"),
            },
            "guia_actual": {
                "estado": guia.get("estado"), "modelo": guia.get("modelo_id"),
                "resultado": guia.get("resultado"), "alerta": bool(guia.get("alerta")),
            },
            "escenarios": escenarios,
            "adoptado": (adoptado and {
                "escenario_id": adoptado.get("escenario_id"), "criterio": adoptado.get("criterio"),
                "intensidad_porcentaje": adoptado.get("intensidad"), "unidad": adoptado.get("unidad"),
                "residual": adoptado.get("residual"),
            }) or None,
        }
    return render_template(
        "aclareos/intensidad_corta.html", pmf=pmf, areas=areas,
        seleccionados=set(pmf.rodales_aclareo),
        mostrar_areas=request.args.get("importar") == "1" or bool(pmf.rodales_aclareo),
        filas_especies=filas_especies, evaluacion=evaluacion,
        rid_activo=rid_activo, especie_activa=especie_activa,
        aplicadas=tabla_intensidades_aplicadas(pmf),
        intensidad_cuadro_actual=(
            float(pmf.intensidad_corta.get(rid_activo, {}).get(especie_activa, 0) or 0)
            if rid_activo and especie_activa else None),
        pct_aplicar=pct_aplicar,
        ia_tipo="aclareos", ia_contexto=ia_contexto,
    )


@app.route("/aclareos/intensidad-corta/reporte", methods=["POST"])
def reporte_intensidad_aclareos():
    pmf = get_pmf()
    if request.form.get("accion") == "exportar_todos":
        filas = _filas_especies_aclareos(pmf)
        if not filas:
            flash("No hay rodales ni especies seleccionados para exportar.", "error")
            return redirect(url_for("intensidad_corta_aclareos", importar="1"))
        evaluaciones = {
            clave_analisis(fila["rodal"], fila["especie"]): pmf.escenarios_aclareo.get(
                clave_analisis(fila["rodal"], fila["especie"]))
            for fila in filas
        }
        try:
            documento = generar_reporte_aclareos_multirodal(
                pmf, filas, evaluaciones, os.path.join(IMG_DIR, "SIMFI GDE.png"))
        except (ValueError, KeyError, TypeError, OSError) as exc:
            flash(str(exc), "error")
            return redirect(url_for("intensidad_corta_aclareos", importar="1"))
        return send_file(
            documento,
            mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            as_attachment=True,
            download_name=nombre_archivo_aclareos_multirodal(),
        )
    rid = request.form.get("rodal", "").strip()
    especie = request.form.get("especie", "").strip()
    evaluacion = pmf.escenarios_aclareo.get(clave_analisis(rid, especie))
    if not evaluacion:
        flash("No existe una evaluación guardada para generar el reporte.", "error")
        return redirect(url_for("intensidad_corta_aclareos", importar="1", rid=rid, especie=especie))
    try:
        grafica_png = decodificar_png(request.form.get("grafica_png", ""))
        evaluacion = json.loads(json.dumps(evaluacion))
        evaluacion["modelo"] = seleccionar_modelo(especie, modelos=cargar_modelos_densidad())
        documento = generar_reporte_aclareos(
            pmf, evaluacion, grafica_png, os.path.join(IMG_DIR, "SIMFI GDE.png"))
    except (ValueError, KeyError, TypeError) as exc:
        flash(str(exc), "error")
        return redirect(url_for("intensidad_corta_aclareos", importar="1", rid=rid, especie=especie))
    return send_file(
        documento,
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        as_attachment=True,
        download_name=nombre_archivo_aclareos(especie, rid),
    )


@app.route("/aclareos/intensidades-aplicadas/exportar/<formato>")
def exportar_intensidades_aplicadas(formato):
    """Exporta el cuadro de intensidades aplicadas a Excel, Word o PDF."""
    pmf = get_pmf()
    try:
        if formato == "excel":
            salida = generar_excel_intensidades_aplicadas(pmf)
            return send_file(salida, as_attachment=True,
                             download_name="SIMFI_Intensidades_Aplicadas.xlsx",
                             mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        if formato == "word":
            salida = generar_word_intensidades_aplicadas(
                pmf, os.path.join(IMG_DIR, "SIMFI GDE.png"))
            return send_file(salida, as_attachment=True,
                             download_name="SIMFI_Intensidades_Aplicadas.docx",
                             mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
        if formato == "pdf":
            salida = generar_pdf_intensidades_aplicadas(pmf)
            return send_file(salida, as_attachment=True,
                             download_name="SIMFI_Intensidades_Aplicadas.pdf",
                             mimetype="application/pdf")
    except ValueError as exc:
        flash(str(exc), "error")
        return redirect(url_for("intensidad_corta_aclareos", importar="1"))
    return "Formato no válido", 404


@app.route("/aclareos/reporte-rodales/exportar/<formato>")
def exportar_reporte_rodales(formato):
    """Exporta el reporte de rodales seleccionados a Excel, Word o PDF.

    Incluye todos los renglones con base dasométrica, con la intensidad del
    cuadro (0 % si no hay aplicada).
    """
    pmf = get_pmf()
    titulo = "RODALES SELECCIONADOS PARA ACLAREOS"
    try:
        filas = tabla_reporte_rodales(pmf)
        if not filas:
            raise ValueError("No hay rodales seleccionados con datos para exportar.")
        if formato == "excel":
            salida = generar_excel_intensidades_aplicadas(
                pmf, filas=filas, titulo=titulo,
                hoja_titulo="Rodales seleccionados",
                columnas=_COLUMNAS_REPORTE_RODALES, horizontal=True)
            return send_file(salida, as_attachment=True,
                             download_name="SIMFI_Rodales_Aclareos.xlsx",
                             mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        if formato == "word":
            salida = generar_word_intensidades_aplicadas(
                pmf, os.path.join(IMG_DIR, "SIMFI GDE.png"), filas=filas,
                titulo=titulo, titulo_tabla="Rodales seleccionados",
                columnas=_COLUMNAS_REPORTE_RODALES, horizontal=True)
            return send_file(salida, as_attachment=True,
                             download_name="SIMFI_Rodales_Aclareos.docx",
                             mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
        if formato == "pdf":
            salida = generar_pdf_intensidades_aplicadas(
                pmf, filas=filas, titulo=titulo,
                columnas=_COLUMNAS_REPORTE_RODALES)
            return send_file(salida, as_attachment=True,
                             download_name="SIMFI_Rodales_Aclareos.pdf",
                             mimetype="application/pdf")
    except ValueError as exc:
        flash(str(exc), "error")
        return redirect(url_for("intensidad_corta_aclareos", importar="1"))
    return "Formato no válido", 404


@app.route("/aclareos/guias-densidad")
def guias_densidad():
    pmf = get_pmf()
    rid = request.args.get("rid", "").strip()
    modelo_id = request.args.get("modelo_id", "").strip()
    especie = request.args.get("especie", "").strip()
    vista_id = request.args.get("vista", "").strip()
    especies_incluidas = request.args.getlist("incluida")
    modelos = cargar_modelos_densidad()
    rodales_con_datos = {
        t.rodal_id.casefold() for t in pmf.tablas_inventario if t.clases
    }
    rodales = [r for r in pmf.rodales_visibles if r.id.casefold() in rodales_con_datos]
    especies_por_rodal = {
        rodal.id: sorted({tabla.especie for tabla in pmf.tablas_inventario
                          if tabla.rodal_id.casefold() == rodal.id.casefold() and tabla.clases},
                         key=_orden_especies)
        for rodal in rodales
    }
    dashboard = obtener_datos_rodal(pmf, rid) if rid else None
    distribucion_diametrica = _rows_graficas(pmf, rid) if rid else []
    analisis = construir_analisis_densidad(
        pmf, rid, modelo_id or None,
        request.args.get("n_residual", "").strip(),
        request.args.get("g_residual", "").strip(),
        request.args.get("grado_objetivo", "").strip(),
        vista_id or None, modelos, especie or None,
        especies_incluidas=especies_incluidas,
    )

    return render_template(
        "aclareos/guias_densidad.html", pmf=pmf, rodales=rodales, rid=rid,
        especie=(analisis.get("datos_rodal") or {}).get("especie_seleccionada") or especie,
        especies_por_rodal=especies_por_rodal, modelos=modelos,
        dashboard=dashboard, distribucion_diametrica=distribucion_diametrica,
        **analisis,
    )


@app.route("/aclareos/guias-densidad/reporte-word", methods=["POST"])
def reporte_word_guia_densidad():
    pmf = get_pmf()
    analisis = construir_analisis_densidad(
        pmf,
        request.form.get("rid", "").strip(),
        request.form.get("modelo_id", "").strip() or None,
        request.form.get("n_residual", "").strip(),
        request.form.get("g_residual", "").strip(),
        request.form.get("grado_objetivo", "").strip(),
        request.form.get("vista", "").strip() or None,
        especie=request.form.get("especie", "").strip() or None,
    )
    if analisis["error"] or not analisis["modelo"] or not analisis["condicion"]:
        return analisis["error"] or "No existe un análisis válido para generar el reporte.", 400
    try:
        grafica_png = decodificar_png(request.form.get("grafica_png", ""))
        salida = generar_reporte_densidad(
            pmf, analisis, grafica_png, os.path.join(IMG_DIR, "SIMFI GDE.png"))
    except (ValueError, OSError) as exc:
        return str(exc), 400
    nombre = nombre_archivo_reporte(
        analisis["modelo"]["especie"]["nombre_canonico"],
        analisis["datos_rodal"]["rodal_id"],
    )
    return send_file(
        salida,
        as_attachment=True,
        download_name=nombre,
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    )


def _incremento_anual(pmf, rodal_id, especie, vol_ha):
    """Retorna el incremento anual m³/ha/año para la especie."""
    cf = pmf.factor_carbono(especie)
    if cf < 0.48:  # coníferas
        v = pmf._calc_valores_rodal_especie(rodal_id, especie)
        if not v: return None
        ica = v.get('ICA m3')
        return ica if (ica is not None and ica > 0) else None
    else:  # latifoliadas
        return vol_ha * 0.02


def _asignar_rowspan_rodal(filas):
    grupos = {}
    for fila in filas:
        if fila.get("_type") == "subtotal":
            continue
        grupos.setdefault(fila.get("rodal"), []).append(fila)
    for grupo in grupos.values():
        for indice, fila in enumerate(grupo):
            fila["_rowspan"] = len(grupo) if indice == 0 else 0
    return filas

def _calc_captura(pmf):
    filas = []; g_vol = g_cc = g_co2 = 0.0
    prom_vol_ha = []; prom_tcc = []; prom_tco2 = []
    for rodal in pmf.rodales_visibles:
        rrid = rodal.id
        especies = pmf.especies_inventario_rodal(rrid)
        s_vol = s_cc = s_co2 = 0.0
        valores_especies = [(e, pmf._calc_valores_rodal_especie(rrid, e)) for e in especies]
        valores_especies = [(e, v) for e, v in valores_especies if v]
        valores_especies.sort(key=lambda item: _orden_especie_volumen(
            item[0], item[1].get('ER m3/ha', 0)))
        for e, v in valores_especies:
            vol_ha = v.get('ER m3/ha', 0) or 0
            cf = pmf.factor_carbono(e)
            inc = _incremento_anual(pmf, rrid, e, vol_ha)
            if inc is None or inc <= 0: continue
            s_vol += vol_ha
            captura_c = inc * _FACTOR_MS * cf * _FACTOR_RAICES
            captura_co2 = captura_c * _FACTOR_CO2
            s_cc += captura_c; s_co2 += captura_co2
            filas.append({"rodal": rrid, "especie": e, "ica": inc, "vol_ha": vol_ha,
                          "cf": cf, "captura_c": captura_c, "captura_co2": captura_co2})
            prom_vol_ha.append(vol_ha)
            prom_tcc.append(captura_c)
            prom_tco2.append(captura_co2)
        if s_vol > 0:
            filas.append({"_type": "subtotal", "rodal": rrid, "vol_ha": s_vol,
                          "captura_c": s_cc, "captura_co2": s_co2})
            g_vol += s_vol; g_cc += s_cc; g_co2 += s_co2
    return {"filas": _asignar_rowspan_rodal(filas), "total_vol": g_vol, "total_captura_c": g_cc, "total_captura_co2": g_co2,
            "prom_vol_ha": _promedio_simple(prom_vol_ha),
            "prom_captura_c": _promedio_simple(prom_tcc),
            "prom_captura_co2": _promedio_simple(prom_tco2)}

def _calc_oxigeno(pmf):
    _FO2 = 2.67; filas = []; g_cc = g_o2 = 0.0
    prom_tcc = []; prom_to2 = []
    for rodal in pmf.rodales_visibles:
        rrid = rodal.id
        especies = pmf.especies_inventario_rodal(rrid)
        s_cc = s_o2 = 0.0
        valores_especies = [(e, pmf._calc_valores_rodal_especie(rrid, e)) for e in especies]
        valores_especies = [(e, v) for e, v in valores_especies if v]
        valores_especies.sort(key=lambda item: _orden_especie_volumen(
            item[0], item[1].get('ER m3/ha', 0)))
        for e, v in valores_especies:
            vol_ha = v.get('ER m3/ha', 0) or 0
            cf = pmf.factor_carbono(e)
            inc = _incremento_anual(pmf, rrid, e, vol_ha)
            if inc is None or inc <= 0: continue
            captura_c = inc * _FACTOR_MS * cf * _FACTOR_RAICES
            oxigeno = captura_c * _FO2
            s_cc += captura_c; s_o2 += oxigeno
            filas.append({"rodal": rrid, "especie": e, "ica": inc,
                          "cf": cf, "captura_c": captura_c, "oxigeno": oxigeno})
            prom_tcc.append(captura_c)
            prom_to2.append(oxigeno)
        if s_cc > 0:
            filas.append({"_type": "subtotal", "rodal": rrid, "captura_c": s_cc, "oxigeno": s_o2})
            g_cc += s_cc; g_o2 += s_o2
    return {"filas": _asignar_rowspan_rodal(filas), "total_captura_c": g_cc, "total_oxigeno": g_o2,
            "prom_captura_c": _promedio_simple(prom_tcc),
            "prom_oxigeno": _promedio_simple(prom_to2)}


def _superficie_rodal_carbono(pmf, rid):
    """Superficie del rodal para los cuadros de carbono/oxígeno."""
    rodal = pmf.buscar_rodal(rid)
    return rodal.superficie_ha if rodal else 0


def _carbono_exportacion(pmf, tab, con_superficie=False):
    """Prepara filas y encabezados de la pestaña activa sin recalcular.

    Con con_superficie=True, captura y oxígeno incluyen la columna
    "Sup (ha)" después de Especie (contenido ya la trae de origen).
    """
    data = pmf.reporte_carbono()
    captura = _calc_captura(pmf)
    oxigeno = _calc_oxigeno(pmf)
    if tab == "captura":
        fuente = captura
        titulo = "Resumen de captura de CO₂"
        encabezados = ["Rodal", "Especie", "ICA (m³/ha/año)", "Vol (m³/ha)", "CF",
                       "Captura C (t/ha/año)", "Captura CO₂ (t/ha/año)"]
        if con_superficie:
            encabezados = ["Rodal", "Especie", "Sup (ha)"] + encabezados[2:]
        filas = []
        for f in fuente.get("filas", []):
            if f.get("_type") == "subtotal":
                valores = ["Subtotal", "", "",
                           f.get("vol_ha", 0), "", f.get("captura_c", 0),
                           f.get("captura_co2", 0)]
                if con_superficie:
                    valores.insert(2, _superficie_rodal_carbono(pmf, f.get("rodal", "")))
                filas.append({"valores_fisicos": valores, "negrita": True,
                              "sombra": "D9D9D9"})
            else:
                valores = [f.get("rodal", ""), f.get("especie", ""), f.get("ica", 0),
                           f.get("vol_ha", 0), f.get("cf", 0), f.get("captura_c", 0),
                           f.get("captura_co2", 0)]
                if con_superficie:
                    valores.insert(2, _superficie_rodal_carbono(pmf, f.get("rodal", "")))
                filas.append(valores)
        return titulo, encabezados, filas, fuente
    if tab == "oxigeno":
        fuente = oxigeno
        titulo = "Resumen de producción de oxígeno"
        encabezados = ["Rodal", "Especie", "ICA (m³/ha/año)", "CF",
                       "Captura C (t/ha/año)", "O₂ (t/ha/año)"]
        if con_superficie:
            encabezados = ["Rodal", "Especie", "Sup (ha)"] + encabezados[2:]
        filas = []
        for f in fuente.get("filas", []):
            if f.get("_type") == "subtotal":
                valores = ["Subtotal", "", "", "",
                           f.get("captura_c", 0), f.get("oxigeno", 0)]
                if con_superficie:
                    valores.insert(2, _superficie_rodal_carbono(pmf, f.get("rodal", "")))
                filas.append({"valores_fisicos": valores, "negrita": True,
                              "sombra": "D9D9D9"})
            else:
                valores = [f.get("rodal", ""), f.get("especie", ""), f.get("ica", 0),
                           f.get("cf", 0), f.get("captura_c", 0), f.get("oxigeno", 0)]
                if con_superficie:
                    valores.insert(2, _superficie_rodal_carbono(pmf, f.get("rodal", "")))
                filas.append(valores)
        return titulo, encabezados, filas, fuente
    fuente = data
    titulo = "Resumen de contenido de carbono y CO₂"
    encabezados = ["Rodal", "Especie", "Sup (ha)", "Vol (m³/ha)", "CF",
                   "MS (t/ha)", "MS total (t)", "C (t/ha)", "C total (t)",
                   "CO₂eq (t/ha)", "CO₂eq total (t)"]
    filas = []
    for f in fuente.get("filas", []):
        if f.get("_type") == "subtotal":
            filas.append({"valores_fisicos": ["Subtotal", "", f.get("superficie", 0),
                          f.get("vol_ha", 0), "", f.get("ms_ha", 0), "", f.get("carbono_ha", 0),
                          "", f.get("co2_ha", 0), ""], "negrita": True,
                          "sombra": "D9D9D9"})
        else:
            filas.append([f.get("rodal", ""), f.get("especie", ""), f.get("superficie", 0),
                          f.get("vol_ha", 0), f.get("cf", 0), f.get("ms_ha", 0),
                          f.get("ms_total", 0), f.get("carbono_ha", 0), f.get("carbono_total", 0),
                          f.get("co2_ha", 0), f.get("co2_total", 0)])
    return titulo, encabezados, filas, fuente

@app.route("/reportes/carbono")
def reporte_carbono():
    pmf = get_pmf()
    rid = request.args.get("rid", "").strip()
    esp = request.args.get("esp", "").strip()
    tab = request.args.get("tab", "contenido")
    detalle = None
    if rid and esp:
        tabla = pmf.buscar_tabla_inventario(rid, esp)
        rodal = pmf.buscar_rodal(rid)
        if tabla and rodal and not rodal.oculto:
            num_sitios = rodal.sitios if rodal else 1
            factor_exp = pmf.obtener_factor_expansion(rodal)
            sup_rodal = rodal.superficie_ha
            cf = pmf.factor_carbono(esp)
            detalle = []
            for c in tabla.clases:
                if c.no_arboles == 0:
                    continue
                nah = tabla.no_arb_ha(c, factor_exp, num_sitios, pmf.usar_factor_ajuste)
                vu = tabla.volumen_unitario(c, pmf)
                vol_ha = vu * nah
                ms_ha = vol_ha * _FACTOR_MS
                c_ha = ms_ha * cf * _FACTOR_RAICES
                co2_ha = c_ha * _FACTOR_CO2
                detalle.append({"dncc": c.dncc, "altura": c.altura_m, "no_arboles": c.no_arboles,
                                "arb_ha": nah, "vol_unitario": vu, "vol_ha": vol_ha,
                                "ms_ha": ms_ha, "carbono_ha": c_ha, "co2_ha": co2_ha})
    data = pmf.reporte_carbono()
    captura_data = _calc_captura(pmf)
    oxigeno_data = _calc_oxigeno(pmf)
    contexto_pmf = construir_contexto(pmf)
    alertas_pmf = contexto_pmf.get("alertas", [])
    especies_rodal = []
    if rid and (not pmf.buscar_rodal(rid) or not pmf.buscar_rodal(rid).oculto):
        especies_rodal = sorted({t.especie for t in pmf.tablas_inventario if t.rodal_id == rid}, key=_orden_especies)
    # El contexto de IA refleja la pestana analizada y no mezcla variables de otros modulos.
    if tab == "captura":
        contexto_semantico = contexto_carbono_captura(captura_data, alertas_pmf)
        fuente_filas = captura_data.get("filas")
    elif tab == "oxigeno":
        contexto_semantico = contexto_carbono_oxigeno(oxigeno_data, alertas_pmf)
        fuente_filas = oxigeno_data.get("filas")
    else:
        contexto_semantico = contexto_carbono_contenido(data, alertas_pmf)
        fuente_filas = data.get("filas")
    ia_contexto = contexto_semantico if fuente_filas else None
    return render_template("reportes/carbono.html", pmf=pmf, data=data,
                           rid=rid, esp=esp, detalle=detalle,
                           especies_rodal=especies_rodal,
                           captura_data=captura_data, oxigeno_data=oxigeno_data,
                              tab_active=tab,
                               interpretacion=analisis_carbono(data, captura_data, oxigeno_data, contexto_pmf, tab=tab),
                               ocultar_botones_exportacion=True,
                               ia_tipo="carbono", ia_contexto=ia_contexto)


_SUFIJO_ARCHIVO_CARBONO = {"contenido": "Contenido_Carbono", "captura": "Captura_CO2",
                          "oxigeno": "Produccion_Oxigeno"}


@app.route("/reportes/carbono/exportar/<formato>")
def exportar_carbono_tecnico(formato):
    pmf = get_pmf()
    tab = request.args.get("tab", "contenido").strip() or "contenido"
    titulo, encabezados, filas, fuente = _carbono_exportacion(pmf, tab)
    analisis = analisis_carbono(pmf.reporte_carbono(), _calc_captura(pmf), _calc_oxigeno(pmf), construir_contexto(pmf), tab=tab)
    sufijo = _SUFIJO_ARCHIVO_CARBONO.get(tab, "Contenido_Carbono")
    if formato == "excel":
        hojas = []
        for clave, nombre_hoja in _HOJAS_CARBONO:
            titulo_hoja, encabezados_hoja, filas_hoja, _ = _carbono_exportacion(
                pmf, clave, con_superficie=True)
            hojas.append((nombre_hoja, titulo_hoja, encabezados_hoja, filas_hoja))
        hoja_activa = next((indice for indice, (clave, _) in enumerate(_HOJAS_CARBONO)
                            if clave == tab), 0)
        return exportar_carbono_excel_libro(pmf, hojas, sufijo, hoja_activa)
    if formato == "word":
        return send_file(generar_word_cuadro_carbono(pmf, titulo, encabezados, filas, fuente, analisis), as_attachment=True,
                         download_name=f"SIMFI_{sufijo}.docx",
                         mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    if formato == "pdf":
        return send_file(generar_pdf_cuadro_carbono(pmf, titulo, encabezados, filas, fuente, analisis), as_attachment=True,
                         download_name=f"SIMFI_{sufijo}.pdf", mimetype="application/pdf")
    return "Formato no válido", 404


_HOJAS_CARBONO = (("contenido", "Contenido"), ("captura", "Captura"),
                   ("oxigeno", "Oxigeno"))


def _escribir_hoja_carbono_excel(ws, titulo, encabezados, filas):
    """Escribe el cuadro de una pestaña y fusiona Rodal y Sup (ha) por rodal."""
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    ws.page_setup.orientation = ws.ORIENTATION_PORTRAIT
    ws.page_setup.paperSize = ws.PAPERSIZE_LETTER
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(encabezados))
    ws.cell(1, 1, titulo)
    ws.cell(1, 1).font = Font(bold=True, size=13, color="000000")
    ws.cell(1, 1).fill = PatternFill("solid", fgColor="D9D9D9")
    ws.cell(1, 1).alignment = Alignment(horizontal="center", vertical="center")
    ws.append(encabezados)
    borde = Border(*(Side(style="thin", color="CCCCCC") for _ in range(4)))
    for celda in ws[2]:
        celda.font = Font(bold=True, color="000000")
        celda.fill = PatternFill("solid", fgColor="D9D9D9")
        celda.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        celda.border = borde
    columnas_fusion = [1]
    if "Sup (ha)" in encabezados:
        columnas_fusion.append(encabezados.index("Sup (ha)") + 1)
    fila_excel = 3
    rangos = []
    inicio = None
    rodal_actual = None
    for fila in filas:
        valores = fila.get("valores_fisicos", fila) if isinstance(fila, dict) else fila
        if isinstance(fila, dict):
            if inicio is not None:
                rangos.append((inicio, fila_excel - 1))
                inicio = None
                rodal_actual = None
        else:
            rodal = valores[0] if valores else ""
            if inicio is None:
                inicio = fila_excel
                rodal_actual = rodal
            elif rodal != rodal_actual:
                rangos.append((inicio, fila_excel - 1))
                inicio = fila_excel
                rodal_actual = rodal
        ws.append(list(valores))
        for celda in ws[fila_excel]:
            celda.border = borde
            celda.alignment = Alignment(vertical="center")
        if isinstance(fila, dict):
            for celda in ws[fila_excel]:
                celda.font = Font(bold=True, color="000000")
                celda.fill = PatternFill("solid", fgColor="D9D9D9")
        fila_excel += 1
    if inicio is not None:
        rangos.append((inicio, fila_excel - 1))
    for inicio, fin in rangos:
        if fin > inicio:
            for columna in columnas_fusion:
                ws.merge_cells(start_row=inicio, start_column=columna,
                               end_row=fin, end_column=columna)
                ws.cell(inicio, columna).alignment = Alignment(
                    horizontal="center", vertical="center")
    for col in range(1, ws.max_column + 1):
        for row in range(3, ws.max_row + 1):
            if isinstance(ws.cell(row, col).value, (int, float)):
                ws.cell(row, col).number_format = "0.000"
        ancho_calculado = max(len(str(ws.cell(row, col).value or ""))
                              for row in range(1, ws.max_row + 1)) + 2
        ws.column_dimensions[get_column_letter(col)].width = (
            14 if col == 1 else 28 if col == 2 else max(12, ancho_calculado))
    ws.freeze_panes = "A3"


def exportar_carbono_excel_libro(pmf, hojas, sufijo="Contenido_Carbono", hoja_activa=0):
    """Genera un libro con las tres pestañas de carbono/oxígeno."""
    from io import BytesIO
    from flask import Response
    from openpyxl import Workbook
    wb = Workbook()
    wb.properties.creator = FIRMA_EXPORTACION
    for indice, (nombre_hoja, titulo, encabezados, filas) in enumerate(hojas):
        ws = wb.active if indice == 0 else wb.create_sheet(title=nombre_hoja)
        if indice == 0:
            ws.title = nombre_hoja
        _escribir_hoja_carbono_excel(ws, titulo, encabezados, filas)
    wb.active = hoja_activa
    salida = BytesIO()
    wb.save(salida)
    return Response(salida.getvalue(),
                    mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f"attachment;filename=SIMFI_{sufijo}.xlsx"})


def exportar_carbono_excel(pmf, titulo, encabezados, filas, fuente, sufijo="Contenido_Carbono"):
    return exportar_carbono_excel_libro(pmf, [("Resumen", titulo, encabezados, filas)], sufijo)


def _rows_graficas(pmf, rid):
    rows = []
    rodal = pmf.buscar_rodal(rid)
    if not rodal or rodal.oculto:
        return rows
    factor_exp = pmf.obtener_factor_expansion(rodal)
    for t in pmf.tablas_inventario:
        if t.rodal_id != rid:
            continue
        for c in t.clases:
            if c.no_arboles == 0:
                continue
            nah = (c.no_arboles / rodal.sitios) * factor_exp
            rows.append({"dncc": c.dncc, "especie": t.especie, "arb_ha": nah})
    return rows


@app.route("/reportes/graficas")
def graficas():
    pmf = get_pmf()
    rid = request.args.get("rid", "").strip()
    rows = _rows_graficas(pmf, rid) if rid else []
    return render_template("reportes/graficas.html", pmf=pmf, rid=rid, rows=rows)


@app.route("/calculo/captura_co2")
def captura_co2():
    pmf = get_pmf()
    rid = request.args.get("rid", "").strip()
    esp = request.args.get("esp", "").strip()
    detalle = None
    data = {"filas": [], "total_vol": 0, "total_captura_c": 0, "total_captura_co2": 0}
    g_vol = g_cc = g_co2 = 0.0
    prom_vol_ha = []; prom_tcc = []; prom_tco2 = []
    for rodal in pmf.rodales_visibles:
        rrid = rodal.id
        especies = pmf.especies_inventario_rodal(rrid)
        s_vol = s_cc = s_co2 = 0.0
        for e in especies:
            v = pmf._calc_valores_rodal_especie(rrid, e)
            if not v:
                continue
            ica = v.get('ICA m3')
            if ica is None or ica <= 0:
                continue
            cf = pmf.factor_carbono(e)
            vol_ha = v.get('ER m3/ha', 0) or 0
            captura_c = ica * _FACTOR_MS * cf * _FACTOR_RAICES
            captura_co2 = captura_c * _FACTOR_CO2
            s_vol += vol_ha; s_cc += captura_c; s_co2 += captura_co2
            data["filas"].append({"rodal": rrid, "especie": e, "ica": ica,
                                  "vol_ha": vol_ha, "cf": cf,
                                  "captura_c": captura_c, "captura_co2": captura_co2})
            prom_vol_ha.append(vol_ha)
            prom_tcc.append(captura_c)
            prom_tco2.append(captura_co2)
        if s_vol > 0:
            data["filas"].append({"_type": "subtotal", "rodal": rrid,
                                  "vol_ha": s_vol, "captura_c": s_cc, "captura_co2": s_co2})
            g_vol += s_vol; g_cc += s_cc; g_co2 += s_co2
    data["total_vol"] = g_vol; data["total_captura_c"] = g_cc; data["total_captura_co2"] = g_co2
    data["prom_vol_ha"] = _promedio_simple(prom_vol_ha)
    data["prom_captura_c"] = _promedio_simple(prom_tcc)
    data["prom_captura_co2"] = _promedio_simple(prom_tco2)
    return render_template("calculo/captura_co2.html", pmf=pmf, data=data,
                           rid=rid, esp=esp, detalle=detalle)


@app.route("/calculo/produccion_oxigeno")
def produccion_oxigeno():
    pmf = get_pmf()
    _FACTOR_O2 = 2.67
    rid = request.args.get("rid", "").strip()
    esp = request.args.get("esp", "").strip()
    data = {"filas": [], "total_captura_c": 0, "total_oxigeno": 0}
    g_cc = g_o2 = 0.0
    prom_tcc = []; prom_to2 = []
    for rodal in pmf.rodales_visibles:
        rrid = rodal.id
        especies = pmf.especies_inventario_rodal(rrid)
        s_cc = s_o2 = 0.0
        for e in especies:
            v = pmf._calc_valores_rodal_especie(rrid, e)
            if not v:
                continue
            ica = v.get('ICA m3')
            if ica is None or ica <= 0:
                continue
            cf = pmf.factor_carbono(e)
            captura_c = ica * _FACTOR_MS * cf * _FACTOR_RAICES
            oxigeno = captura_c * _FACTOR_O2
            s_cc += captura_c; s_o2 += oxigeno
            data["filas"].append({"rodal": rrid, "especie": e, "ica": ica,
                                  "cf": cf, "captura_c": captura_c, "oxigeno": oxigeno})
            prom_tcc.append(captura_c)
            prom_to2.append(oxigeno)
        if s_cc > 0:
            data["filas"].append({"_type": "subtotal", "rodal": rrid,
                                  "captura_c": s_cc, "oxigeno": s_o2})
            g_cc += s_cc; g_o2 += s_o2
    data["total_captura_c"] = g_cc; data["total_oxigeno"] = g_o2
    data["prom_captura_c"] = _promedio_simple(prom_tcc)
    data["prom_oxigeno"] = _promedio_simple(prom_to2)
    return render_template("calculo/produccion_oxigeno.html", pmf=pmf, data=data,
                           rid=rid, esp=esp)


# =============== API / AJAX ===============

@app.route("/api/pmf/data")
def api_pmf_data():
    pmf = get_pmf()
    return jsonify(pmf_to_dict(pmf))


@app.route("/api/rodales")
def api_rodales():
    pmf = get_pmf()
    return jsonify([asdict(r) for r in pmf.rodales_visibles])


@app.route("/api/graficas/datos/<rid>")
def api_graficas_datos(rid):
    pmf = get_pmf()
    return jsonify(_rows_graficas(pmf, rid))


@app.route("/api/estados")
def api_estados():
    return jsonify(sorted(MUNICIPIOS.keys()))


@app.route("/api/municipios/<estado>")
def api_municipios(estado):
    return jsonify(MUNICIPIOS.get(estado, []))


@app.route("/api/seleccionar_directorio")
def api_seleccionar_directorio():
    try:
        return jsonify({"ruta": _seleccionar_directorio()})
    except Exception as e:
        return jsonify({"error": str(e)})


@app.route("/api/especies")
def api_especies():
    pmf = get_pmf()
    return jsonify(pmf.especies)


@app.route("/api/calcular_volumen", methods=["POST"])
def api_calcular_volumen():
    pmf = get_pmf()
    dap = float(request.form.get("dap", 0))
    h = float(request.form.get("altura", 0))
    esp = request.form.get("especie", "")
    vol = pmf.volumen_arbol(esp, dap, h)
    return jsonify({"volumen": round(vol, 4), "especie": esp, "dap": dap, "altura": h})


@app.route("/volumen_individual")
def volumen_individual():
    pmf = get_pmf()
    return render_template("reportes/volumen_individual.html", pmf=pmf)


# =============== DUSSAN (asistente flotante) ===============
# Dussan consulta resultados que SIMFI ya calculo. No recalcula, no escribe en
# el proyecto, no accede a la base de datos y no expone credenciales: la IA se
# invoca a traves del servicio existente, que ya lee la API key del entorno.


def _dussan_no_disponible():
    return jsonify({
        "ok": False,
        "mensaje": "El asistente Dussan no esta disponible en esta instalacion.",
    }), 503


@app.route("/api/dussan/contexto")
def dussan_contexto():
    """Contexto vigente para Dussan: predio, UMM/rodal, modulo y reporte."""
    if not _MODULO_DUSSAN_DISPONIBLE or not _dussan_habilitado():
        return _dussan_no_disponible()
    estado = _dussan_estado(get_pmf())
    if not estado:
        return _dussan_no_disponible()
    return jsonify({
        "ok": True,
        "estado": estado["estado"],
        "rodales": estado["rodales"],
        "herramientas": dussan_backend.herramientas_disponibles(),
        "contrato": dussan_backend.CONTRATO,
        "no_disponibles": dussan_backend.NO_DISPONIBLES,
        "nota_umm": dussan_backend.NOTA_UMM,
    })


@app.route("/api/dussan/herramienta", methods=["POST"])
def dussan_herramienta():
    """Ejecuta una herramienta de lectura de Dussan sobre datos de SIMFI."""
    if not _MODULO_DUSSAN_DISPONIBLE or not _dussan_habilitado():
        return _dussan_no_disponible()
    cuerpo = request.get_json(silent=True) or {}
    argumentos = cuerpo.get("argumentos")
    argumentos = argumentos if isinstance(argumentos, dict) else {}
    estado = _dussan_estado(get_pmf())
    if not estado:
        return _dussan_no_disponible()
    resultado = dussan_backend.ejecutar_herramienta(
        str(cuerpo.get("herramienta", "") or ""), argumentos,
        dussan_backend.contexto_plano(estado))
    datos = resultado.get("datos")
    if isinstance(datos, dict) and datos.get("destino"):
        # El destino es un endpoint de Flask: se resuelve la URL real aqui.
        try:
            datos["url"] = url_for(datos["destino"])
        except Exception:
            datos["url"] = ""
    return jsonify(resultado)


@app.route("/api/dussan/chat", methods=["POST"])
def dussan_chat():
    """Dussan consulta lo necesario en SIMFI y responde con el motor de IA."""
    if not _MODULO_DUSSAN_DISPONIBLE or not _dussan_habilitado():
        return _dussan_no_disponible()
    cuerpo = request.get_json(silent=True) or {}
    pregunta = str(cuerpo.get("pregunta", "") or "").strip()
    if not pregunta:
        return jsonify({"ok": False, "mensaje": "Escribe o dicta una pregunta."})
    if len(pregunta) > 1200:
        return jsonify({"ok": False, "mensaje": "La pregunta es demasiado extensa."})
    herramientas = cuerpo.get("herramientas")
    herramientas = herramientas if isinstance(herramientas, list) else None
    estado = _dussan_estado(get_pmf())
    if not estado:
        return _dussan_no_disponible()
    resultado = dussan_backend.consultar_y_responder(
        pregunta, dussan_backend.contexto_plano(estado), herramientas,
        {"rodal": str(cuerpo.get("rodal", "") or "")})
    return jsonify(resultado)


# =============== AJUSTES ===============

@app.route("/ajustes", methods=["GET", "POST"])
def ajustes():
    pmf = get_pmf()
    if request.method == "POST":
        try:
            area_sitio = request.form.get("area_sitio_m2", "").strip()
            if area_sitio:
                pmf.area_sitio_m2 = float(area_sitio)
            save_pmf(pmf)
            flash("Ajustes guardados", "success")
        except Exception as e:
            flash(f"Error: {e}", "error")
        return redirect(url_for("ajustes"))
    return render_template("ajustes.html", pmf=pmf)


@app.route("/ajustes/ia", methods=["GET", "POST"])
def ajustes_ia():
    if not _MODULO_IA_DISPONIBLE:
        flash("El modulo de interpretacion IA no esta disponible.", "error")
        return redirect(url_for("ajustes"))
    config = cargar_config_ia()
    if request.method == "POST":
        try:
            modo = request.form.get("modo", "automatico")
            if modo not in {"automatico", "local", "en_linea"}:
                raise ValueError("Seleccione un motor de interpretacion valido")
            local = config["local"]
            online = config["en_linea"]
            local["servidor"] = request.form.get("local_servidor", "").strip().rstrip("/")
            local["modelo"] = request.form.get("local_modelo", "").strip()
            online["habilitada"] = request.form.get("online_habilitada") == "1"
            online["proveedor"] = request.form.get("online_proveedor", "groq").strip()
            if online["proveedor"] not in {"groq", "openrouter", "openai_compatible"}:
                raise ValueError("Seleccione un proveedor de IA en linea valido")
            online["servidor"] = request.form.get("online_servidor", "").strip().rstrip("/")
            online["modelo"] = request.form.get("online_modelo", "").strip()
            online["api_key_env"] = request.form.get("online_api_key_env", "").strip()
            if not local["servidor"].startswith(("http://localhost", "http://127.0.0.1")):
                raise ValueError("El servidor local debe apuntar a localhost")
            if online["habilitada"] and not online["servidor"].startswith("https://"):
                raise ValueError("El servicio de IA en linea debe usar HTTPS")
            if online["api_key_env"] and not re.fullmatch(r"[A-Z_][A-Z0-9_]*", online["api_key_env"]):
                raise ValueError("El nombre de la variable de API no es valido")
            config["modo"] = modo
            guardar_config_ia(config)
            flash("Configuracion de IA guardada. La API key no se almacena en SIMFI.", "success")
        except Exception as error:
            flash(f"Error: {error}", "error")
        return redirect(url_for("ajustes_ia"))
    return render_template("ia/configuracion.html", config=config,
                           estado=_SERVICIO_INTERPRETACION_IA.estado(config))


@app.route("/ajustes/dussan", methods=["POST"])
def ajustes_dussan():
    """Guarda solo las preferencias de Dussan, sin tocar el motor de IA."""
    if not _MODULO_DUSSAN_DISPONIBLE:
        flash("El asistente Dussan no esta disponible en esta instalacion.", "error")
        return redirect(url_for("ajustes_ia"))
    try:
        config = cargar_config_ia()
        dussan = config.setdefault("dussan", {})
        dussan["habilitado"] = request.form.get("dussan_habilitado") == "1"
        dussan["voz"] = request.form.get("dussan_voz") == "1"
        guardar_config_ia(config)
        flash("Configuracion de Dussan guardada.", "success")
    except Exception as error:
        flash("Error al guardar la configuracion de Dussan: %s" % error, "error")
    return redirect(url_for("ajustes_ia"))


# =============== ARCHIVOS ===============

@app.route("/admin/usuarios")
def admin_usuarios():
    if session.get("rol") != "admin":
        flash("Acceso denegado", "danger")
        return redirect(url_for("index"))
    usuarios = _cargar_usuarios()
    return render_template("admin_usuarios.html", usuarios=usuarios)


@app.route("/admin/usuarios/agregar", methods=["POST"])
def admin_agregar_usuario():
    if session.get("rol") != "admin":
        return jsonify({"error": "no_auth"}), 403
    username = request.form.get("usuario", "").strip()
    password = request.form.get("password", "").strip()
    rol = request.form.get("rol", "consulta").strip()
    if not username or not password:
        flash("Usuario y contraseña requeridos", "danger")
        return redirect(url_for("admin_usuarios"))
    usuarios = _cargar_usuarios()
    if username in usuarios:
        flash("El usuario ya existe", "danger")
        return redirect(url_for("admin_usuarios"))
    usuarios[username] = {"password": generate_password_hash(password), "rol": rol}
    _guardar_usuarios(usuarios)
    flash(f"Usuario {username} creado", "success")
    return redirect(url_for("admin_usuarios"))


@app.route("/admin/usuarios/eliminar/<username>")
def admin_eliminar_usuario(username):
    if session.get("rol") != "admin":
        flash("Acceso denegado", "danger")
        return redirect(url_for("index"))
    if username == "DR.PIFL":
        flash("No se puede eliminar el administrador principal", "danger")
        return redirect(url_for("admin_usuarios"))
    usuarios = _cargar_usuarios()
    if username in usuarios:
        del usuarios[username]
        _guardar_usuarios(usuarios)
        flash(f"Usuario {username} eliminado", "success")
    return redirect(url_for("admin_usuarios"))


@app.route("/admin/usuarios/cambiar_password", methods=["POST"])
def admin_cambiar_password():
    if session.get("rol") != "admin":
        return jsonify({"error": "no_auth"}), 403
    username = request.form.get("usuario", "")
    password = request.form.get("password", "").strip()
    if not username or not password:
        flash("Usuario y contraseña requeridos", "danger")
        return redirect(url_for("admin_usuarios"))
    usuarios = _cargar_usuarios()
    if username in usuarios:
        usuarios[username]["password"] = generate_password_hash(password)
        _guardar_usuarios(usuarios)
        flash(f"Contraseña actualizada para {username}", "success")
    return redirect(url_for("admin_usuarios"))


@app.route("/archivos")
def listar_archivos():
    archivos = [os.path.basename(ruta) for ruta in _rutas_proyectos_guardados()
                if os.path.dirname(ruta) == PROJECTS_DIR]
    respaldos_proyecto = []
    pmf = get_pmf()
    if pmf and pmf.ruta_archivo:
        respaldos_proyecto = listar_respaldos_actuales(pmf)
    return render_template("archivos.html", archivos=sorted(archivos),
                           respaldos_proyecto=respaldos_proyecto,
                           proyecto_actual=pmf.nombre if pmf else "")


def listar_respaldos_actuales(pmf):
    try:
        return respaldos.listar_respaldos(pmf.ruta_archivo, DATA_DIR)[:20]
    except Exception:
        return []


@app.route("/respaldos/restaurar", methods=["POST"])
def restaurar_respaldo():
    pmf = get_pmf()
    nombre = request.form.get("archivo", "")
    destino = request.form.get("origen", "archivos")
    punto = url_for("listar_archivos") if destino != "respaldos" else url_for("panel_respaldos")
    if not pmf or not pmf.ruta_archivo:
        flash("No hay un proyecto guardado activo", "error")
        return redirect(punto)
    try:
        realizado = respaldos.restaurar(pmf.ruta_archivo, nombre, DATA_DIR)
    except Exception:
        realizado = False
    if realizado:
        flash("Proyecto restaurado desde el respaldo; la copia previa se "
              "conserva como pre_restauracion", "success")
    else:
        flash("No se pudo restaurar el respaldo", "error")
    return redirect(punto)


@app.route("/respaldos/descargar")
def descargar_respaldo():
    pmf = get_pmf()
    nombre = request.args.get("archivo", "")
    if not pmf or not pmf.ruta_archivo:
        flash("No hay un proyecto guardado activo", "error")
        return redirect(url_for("listar_archivos"))
    from io import BytesIO
    contenido = respaldos.descargar_bytes(pmf.ruta_archivo, nombre, DATA_DIR)
    if contenido is None:
        flash("El respaldo solicitado no existe", "error")
        return redirect(url_for("listar_archivos"))
    return send_file(BytesIO(contenido), as_attachment=True,
                     download_name=nombre, mimetype="application/json")


@app.route("/respaldos")
def panel_respaldos():
    pmf = get_pmf()
    lista = listar_respaldos_actuales(pmf) if pmf else []
    return render_template("respaldos.html", pmf=pmf, respaldos=lista,
                           proyecto_guardado=bool(pmf and pmf.ruta_archivo))


@app.route("/proyectos/<archivo>/eliminar", methods=["POST"])
def eliminar_proyecto(archivo):
    origen = request.form.get("origen", "index")
    destino = "listar_archivos" if origen == "archivos" else "index"
    ruta = os.path.realpath(os.path.join(PROJECTS_DIR, archivo))
    if (archivo != os.path.basename(archivo) or
            not archivo.lower().endswith(".json") or
            os.path.dirname(ruta) != os.path.realpath(PROJECTS_DIR)):
        flash("No se puede eliminar el archivo seleccionado", "error")
        return redirect(url_for(destino))
    if not os.path.isfile(ruta):
        flash("El proyecto ya no existe", "error")
        return redirect(url_for(destino))
    try:
        os.remove(ruta)
        ruta_actual = session.get("ruta_actual", "")
        if ruta_actual and os.path.normcase(os.path.realpath(ruta_actual)) == os.path.normcase(ruta):
            session.pop("ruta_actual", None)
            session.pop("pmf_data", None)
            session.modified = True
        try:
            with open(LAST_PROJECT_FILE, "r", encoding="utf-8") as estado:
                ultima_ruta = json.load(estado).get("ruta", "")
            if ultima_ruta and os.path.normcase(os.path.realpath(ultima_ruta)) == os.path.normcase(ruta):
                os.remove(LAST_PROJECT_FILE)
        except (OSError, ValueError, AttributeError):
            pass
        flash(f"Proyecto '{archivo}' eliminado", "success")
    except OSError as error:
        flash(f"No se pudo eliminar el proyecto: {error}", "error")
    return redirect(url_for(destino))


# =============== INTEGRACION IA LOCAL (PRUEBA AISLADA) ===============

@app.route("/ia/test", methods=["GET", "POST"])
def prueba_ia():
    """Prueba aislada de conexion con Ollama y con la IA en linea. No altera ningun resultado."""
    if not _MODULO_IA_DISPONIBLE:
        flash("El modulo de IA local no esta disponible en esta instalacion.", "error")
        return redirect(url_for("index"))
    config = cargar_config_ia()
    servicio = estado_servicio_ia(config)
    interpretacion = None
    error_interpretacion = None
    prueba_online = None
    prueba_online_ok = None
    if request.method == "POST":
        objetivo = request.form.get("objetivo", "local")
        if objetivo == "en_linea":
            prueba_online = _SERVICIO_INTERPRETACION_IA.online.probar_conexion(config)
            prueba_online_ok = prueba_online.get("ok", False)
            error_interpretacion = None if prueba_online_ok else prueba_online.get("mensaje")
        elif not servicio["disponible"]:
            error_interpretacion = servicio["mensaje"]
        else:
            ok, texto, mensaje, _metadatos = interpretar_resultados_ia(DATOS_PRUEBA_IA, config)
            if ok:
                interpretacion = texto
            else:
                error_interpretacion = mensaje
    return render_template(
        "ia/test.html",
        servicio=servicio,
        modelo_configurado=config.get("modelo", ""),
        config_online=config.get("en_linea", {}),
        habilitada=bool(config.get("habilitada", True)),
        interpretacion=interpretacion,
        error_interpretacion=error_interpretacion,
        prueba_online=prueba_online,
        prueba_online_ok=bool(prueba_online_ok),
    )


# =============== IA AMPLIADA EN REPORTES EN PANTALLA ===============
# Genera interpretacion tecnica ampliada (prosa) desde datos ya calculados por
# SIMFI. No modifica calculos, resultados ni las exportaciones Word/PDF, que
# conservan su interpretacion determinista. Degrada de forma elegante.

@app.route("/ia/reportes/interpretar", methods=["POST"])
def interpretar_reporte_ia():
    cuerpo = request.get_json(silent=True) or {}
    tipo = str(cuerpo.get("tipo", "")).strip()
    datos = cuerpo.get("contexto")
    if not (_MODULO_IA_DISPONIBLE and _MODULO_IA_REPORTES_DISPONIBLE):
        return jsonify({"ok": False, "texto": None,
                        "mensaje": "La interpretacion ampliada con IA local no esta disponible en esta instalacion."})
    if tipo not in _TIPOS_IA_REPORTES:
        return jsonify({"ok": False, "texto": None,
                        "mensaje": "Tipo de reporte no reconocido para la interpretacion ampliada."})
    if not isinstance(datos, dict) or not datos:
        return jsonify({"ok": False, "texto": None,
                        "mensaje": "No hay datos calculados disponibles para interpretar."})
    ok, texto, mensaje, metadatos = interpretar_ia_reporte_engine(tipo, datos)
    return jsonify({"ok": ok, "texto": texto, "mensaje": mensaje or "No se pudo generar la interpretacion.",
                    "metadatos": metadatos})


# =============== MAIN ===============

if __name__ == "__main__":
    print("=" * 50)
    print("  Sistema para el manejo forestal intensivo V 1.0")
    print("=" * 50)
    print(f"  Directorio de datos: {DATA_DIR}")
    print(f"  Abrir en: http://127.0.0.1:5000")
    print("=" * 50)
    app.run(debug=False, threaded=True)
