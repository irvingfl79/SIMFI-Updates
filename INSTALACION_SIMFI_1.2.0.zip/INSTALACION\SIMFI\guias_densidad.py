import json
import functools
import math
import os
import re
import unicodedata
import datetime


DIRECTORIO_MODELOS = os.path.join(os.path.dirname(__file__), "modelos_densidad")
DIAMETROS_ISOLINEAS = (10, 15, 20, 25, 30, 35, 40, 45, 50)


def _normalizar_especie(nombre):
    texto = unicodedata.normalize("NFKD", nombre or "")
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", texto).strip().casefold()


def calcular_diametro_cuadratico(n, g):
    if n <= 0 or g <= 0:
        return None
    return math.sqrt(40000.0 * g / (math.pi * n))


def cargar_modelos_densidad():
    modelos = _cargar_modelos_densidad_cacheados()
    return [dict(modelo) for modelo in modelos]


@functools.lru_cache(maxsize=1)
def _cargar_modelos_densidad_cacheados():
    modelos = []
    if not os.path.isdir(DIRECTORIO_MODELOS):
        return tuple()
    for archivo in sorted(os.listdir(DIRECTORIO_MODELOS)):
        if not archivo.lower().endswith(".json"):
            continue
        ruta = os.path.join(DIRECTORIO_MODELOS, archivo)
        try:
            with open(ruta, "r", encoding="utf-8") as entrada:
                modelo = json.load(entrada)
            if modelo.get("modelo_id") and modelo.get("especie", {}).get("nombre_canonico"):
                modelo["_archivo"] = archivo
                modelos.append(modelo)
        except (OSError, ValueError, TypeError):
            continue
    return tuple(modelos)


def modelos_para_especie(especie, modelos=None):
    buscada = _normalizar_especie(especie)
    disponibles = modelos if modelos is not None else cargar_modelos_densidad()
    coincidencias = []
    for modelo in disponibles:
        datos_especie = modelo.get("especie", {})
        nombres = [datos_especie.get("nombre_canonico", "")]
        nombres.extend(datos_especie.get("alias", []))
        if buscada and buscada in {_normalizar_especie(n) for n in nombres}:
            coincidencias.append(modelo)
    return coincidencias


def seleccionar_modelo(especie, modelo_id=None, modelos=None):
    coincidencias = modelos_para_especie(especie, modelos)
    if modelo_id:
        return next((m for m in coincidencias if m.get("modelo_id") == modelo_id), None)
    return coincidencias[0] if len(coincidencias) == 1 else None


def obtener_datos_rodal(pmf, rodal_id, especie=None):
    rodal = pmf.buscar_rodal(rodal_id)
    if not rodal:
        return None
    por_especie = []
    for nombre_especie in sorted({t.especie for t in pmf.tablas_inventario
                                   if t.rodal_id.casefold() == rodal.id.casefold()}):
        valores = pmf._calc_valores_rodal_especie(rodal.id, nombre_especie)
        if not valores:
            continue
        por_especie.append({
            "especie": nombre_especie,
            "n": float(valores.get("Arb/ha", 0) or 0),
            "g": float(valores.get("AB m2/ha", 0) or 0),
        })
    validas = [fila for fila in por_especie if fila["n"] > 0 and fila["g"] > 0]
    especie_dominante = max(validas, key=lambda fila: (fila["g"], fila["n"]), default=None)
    n = sum(fila["n"] for fila in validas)
    g = sum(fila["g"] for fila in validas)
    especie_seleccionada = None
    if especie:
        especie_seleccionada = next(
            (fila for fila in por_especie
             if _normalizar_especie(fila["especie"]) == _normalizar_especie(especie)), None)
        if especie_seleccionada:
            n = especie_seleccionada["n"]
            g = especie_seleccionada["g"]
    dq = calcular_diametro_cuadratico(n, g)
    return {
        "rodal_id": rodal.id,
        "n": n,
        "g": g,
        "dq": dq,
        "especie_dominante": especie_dominante["especie"] if especie_dominante else None,
        "especie_seleccionada": (especie_seleccionada["especie"]
                                  if especie_seleccionada else None),
        "composicion": por_especie,
        "n_total": sum(fila["n"] for fila in validas),
        "g_total": sum(fila["g"] for fila in validas),
        "es_mixto": len(validas) > 1,
    }


def _frontera_por_id(modelo, frontera_id):
    return next((f for f in modelo.get("fronteras", [])
                 if f.get("id") == frontera_id), None)


def _valor_fcc_en_dq(frontera, dq):
    parametros = frontera.get("parametros", {})
    amc = parametros.get("area_maxima_copa", {})
    c0 = amc.get("c0")
    c1 = amc.get("c1")
    c2 = amc.get("c2")
    if None in (c0, c1, c2):
        return None
    porcentaje_hectarea = float(c0) + float(c1) * dq + float(c2) * dq ** 2
    return 100.0 / porcentaje_hectarea if porcentaje_hectarea > 0 else None


def _valor_fcc_modelo_copa(frontera, dq):
    parametros = frontera.get("parametros", {})
    copa = parametros.get("modelo_copa", {})
    intercepto = copa.get("intercepto")
    pendiente = copa.get("pendiente")
    if intercepto is None or pendiente is None:
        return None
    diametro_copa = float(intercepto) + float(pendiente) * dq
    area_copa = math.pi / 4.0 * diametro_copa ** 2
    area_maxima_porcentaje = area_copa / 100.0
    return 100.0 / area_maxima_porcentaje if area_maxima_porcentaje > 0 else None


def _valor_frontera_en_dq(frontera, dq):
    if not frontera or frontera.get("estado") != "disponible" or dq <= 0:
        return None
    tipo = frontera.get("tipo_ecuacion")
    if tipo == "n_dq_potencia":
        parametros = frontera.get("parametros", {})
        a = parametros.get("a")
        b = parametros.get("b")
        if a is not None and b is not None:
            return float(a) * dq ** float(b)
    if tipo == "n_dq_log_lineal":
        parametros = frontera.get("parametros", {})
        alpha = parametros.get("alpha")
        beta = parametros.get("beta")
        if alpha is not None and beta is not None:
            return math.exp(float(alpha)) * dq ** float(beta)
    if tipo == "fcc_area_maxima_copa_polinomial":
        return _valor_fcc_en_dq(frontera, dq)
    if tipo == "fcc_modelo_copa_lineal":
        return _valor_fcc_modelo_copa(frontera, dq)
    if tipo in ("idr_potencial_zona", "idr_exponencial_zona"):
        parametros = frontera.get("parametros", {})
        idr_maximo = parametros.get("idr_maximo")
        porcentaje = parametros.get("porcentaje")
        dq_referencia = parametros.get("dq_referencia_cm")
        if None in (idr_maximo, porcentaje, dq_referencia):
            return None
        if tipo == "idr_potencial_zona":
            exponente = parametros.get("exponente")
            if exponente is None:
                return None
            return float(idr_maximo) * float(porcentaje) / 100.0 * (dq / float(dq_referencia)) ** float(exponente)
        coeficiente = parametros.get("coeficiente")
        if coeficiente is None:
            return None
        return float(idr_maximo) * float(porcentaje) / 100.0 * math.exp(float(coeficiente) * (dq - float(dq_referencia)))
    return None


def calcular_n_fcc(dq, modelo):
    frontera = next((f for f in modelo.get("fronteras", [])
                     if f.get("tipo_ecuacion") in
                     ("fcc_area_maxima_copa_polinomial", "fcc_modelo_copa_lineal")), None)
    return _valor_frontera_en_dq(frontera, dq)


def calcular_n_frontera(dq, modelo, frontera_id):
    return _valor_frontera_en_dq(_frontera_por_id(modelo, frontera_id), dq)


def calcular_idr(n, dq, modelo):
    metodo = modelo.get("indice_densidad", {})
    if metodo.get("estado") != "disponible" or n <= 0 or dq <= 0:
        return None
    if metodo.get("tipo") == "reineke_dq_referencia":
        dq_referencia = metodo.get("dq_referencia_cm")
        beta = metodo.get("beta")
        if dq_referencia and beta is not None:
            return n * (dq / float(dq_referencia)) ** (-float(beta))
    if metodo.get("tipo") == "idr_potencial_referencia":
        dq_referencia = metodo.get("dq_referencia_cm")
        exponente = metodo.get("exponente")
        if dq_referencia and exponente is not None:
            return n * (dq / float(dq_referencia)) ** float(exponente)
    if metodo.get("tipo") == "idr_exponencial_referencia":
        dq_referencia = metodo.get("dq_referencia_cm")
        coeficiente = metodo.get("coeficiente")
        if dq_referencia and coeficiente is not None:
            return n * math.exp(float(coeficiente) * (dq - float(dq_referencia)))
    return None


def obtener_idr_maximo_modelo(modelo):
    metodo = modelo.get("indice_densidad", {})
    if metodo.get("maximo_calculo") is not None:
        return float(metodo["maximo_calculo"])
    dq_referencia = metodo.get("dq_referencia_cm")
    frontera_id = metodo.get("frontera_maxima")
    if dq_referencia and frontera_id:
        return calcular_n_frontera(float(dq_referencia), modelo, frontera_id)
    return None


def _zona_por_grado(grado, modelo):
    if grado is None:
        return None
    for zona in modelo.get("zonas_densidad", []):
        minimo = zona.get("min")
        maximo = zona.get("max")
        if minimo is not None and math.isclose(grado, minimo, rel_tol=1e-12, abs_tol=1e-9):
            grado_comparado = minimo
        elif maximo is not None and math.isclose(grado, maximo, rel_tol=1e-12, abs_tol=1e-9):
            grado_comparado = maximo
        else:
            grado_comparado = grado
        supera_minimo = (minimo is None or grado_comparado > minimo or
                          (zona.get("min_inclusivo", True) and grado_comparado == minimo))
        bajo_maximo = (maximo is None or grado_comparado < maximo or
                       (zona.get("max_inclusivo", False) and grado_comparado == maximo))
        if supera_minimo and bajo_maximo:
            return zona
    return None


def _interpretacion_secundaria(grado, modelo):
    if grado is None or not modelo.get("interpretaciones_grado"):
        return None
    zona = _zona_por_grado(grado, {"zonas_densidad": modelo["interpretaciones_grado"]})
    return zona.get("nombre") if zona else None


def clasificar_densidad(n, g, modelo):
    if n <= 0 or g <= 0:
        return None
    if modelo.get("metodo_clasificacion") == "zonas_grado_densidad":
        zona = _zona_por_grado(calcular_grado_densidad(n, g, modelo), modelo)
        return zona.get("nombre") if zona else None
    dq = calcular_diametro_cuadratico(n, g)
    umbrales = {
        frontera.get("id"): _valor_frontera_en_dq(frontera, dq)
        for frontera in modelo.get("fronteras", [])
    }
    for regla in modelo.get("reglas_clasificacion", []):
        tipo = regla.get("tipo")
        if tipo == "sobre":
            limite = umbrales.get(regla.get("frontera"))
            coincide = limite is not None and n > limite
        elif tipo == "entre":
            superior = umbrales.get(regla.get("superior"))
            inferior = umbrales.get(regla.get("inferior"))
            coincide = superior is not None and inferior is not None and inferior <= n <= superior
        elif tipo == "debajo":
            limite = umbrales.get(regla.get("frontera"))
            coincide = limite is not None and n < limite
        else:
            coincide = False
        if coincide:
            return regla.get("nombre")
    return None


def calcular_grado_densidad(n, g, modelo):
    metodo = modelo.get("metodo_grado_densidad", {})
    if metodo.get("estado") != "disponible" or n <= 0 or g <= 0:
        return None
    if metodo.get("tipo") == "idr_relativo_maximo_modelo":
        dq = calcular_diametro_cuadratico(n, g)
        idr = calcular_idr(n, dq, modelo)
        idr_maximo = obtener_idr_maximo_modelo(modelo)
        return idr / float(idr_maximo) * 100.0 if idr is not None and idr_maximo else None
    if metodo.get("tipo") == "reineke_relativo_linea_a":
        dq = calcular_diametro_cuadratico(n, g)
        referencia = _frontera_por_id(modelo, metodo.get("frontera_referencia", "A"))
        n_referencia = _valor_frontera_en_dq(referencia, dq)
        return n / n_referencia * 100.0 if n_referencia else None
    return None


def evaluar_condicion(n, g, modelo):
    if n <= 0 or g <= 0:
        raise ValueError("N y G deben ser mayores que cero.")
    dq = calcular_diametro_cuadratico(n, g)
    grado = calcular_grado_densidad(n, g, modelo)
    zona = _zona_por_grado(grado, modelo)
    indice = calcular_idr(n, dq, modelo)
    fronteras = {}
    for frontera in modelo.get("fronteras", []):
        n_frontera = _valor_frontera_en_dq(frontera, dq)
        fronteras[frontera.get("id")] = {
            "n": n_frontera,
            "g": n_frontera * math.pi * dq ** 2 / 40000.0 if n_frontera else None,
        }
    return {
        "n": n,
        "g": g,
        "dq": dq,
        "indice_densidad": indice,
        "indice_nombre": modelo.get("indice_densidad", {}).get("nombre"),
        "grado_densidad": grado,
        "clasificacion": clasificar_densidad(n, g, modelo),
        "condicion_competencia": _interpretacion_secundaria(grado, modelo),
        "interpretacion": zona.get("interpretacion") if zona else None,
        "advertencia_clasificacion": zona.get("advertencia") if zona else None,
        "fronteras": fronteras,
        "trazabilidad": {
            "modelo_id": modelo.get("modelo_id"),
            "modelo_version": modelo.get("version_modelo"),
            "especie": modelo.get("especie", {}).get("nombre_cientifico"),
            "region": modelo.get("region_aplicacion"),
            "version_modelo": modelo.get("version_modelo"),
            "fecha_modelo": modelo.get("fecha_modelo"),
            "fecha_registro": modelo.get("fecha_registro"),
            "fecha_calculo": datetime.datetime.now().isoformat(timespec="seconds"),
            "coeficientes": modelo.get("fronteras"),
            "metodo": modelo.get("indice_densidad") or modelo.get("metodologia"),
            "fuente": modelo.get("fuente"),
        },
    }


def construir_interpretacion(condicion, modelo):
    clave = condicion.get("clasificacion") or "pendiente"
    regla = modelo.get("interpretaciones", {}).get(clave)
    if not regla:
        return None
    grado = condicion.get("grado_densidad")
    if grado is not None:
        resumen = (f"El rodal presenta un grado de densidad de {grado:.1f} % con respecto "
                   f"a la referencia de la guía para {modelo['especie']['nombre_canonico']}. ")
    else:
        resumen = (f"La condición del rodal fue evaluada con la guía registrada para "
                   f"{modelo['especie']['nombre_canonico']}. ")
    texto = resumen + regla.get("descripcion", "")
    competencia = condicion.get("condicion_competencia")
    if competencia:
        texto += f" La guía identifica adicionalmente la condición: {competencia.lower()}."
    return {
        "titulo": regla.get("titulo", clave),
        "texto": texto.strip(),
        "consideracion": regla.get("consideracion", ""),
        "semaforo": regla.get("semaforo", {"etiqueta": "Resultado técnico", "tono": "neutral"}),
        "condicion": competencia or regla.get("titulo", clave),
    }


def construir_comparacion(actual, escenario, modelo):
    grado_actual = actual.get("grado_densidad")
    grado_residual = escenario.get("grado_densidad")
    frases = []
    if grado_actual is not None and grado_residual is not None:
        if grado_residual < grado_actual:
            verbo = "reduce"
        elif grado_residual > grado_actual:
            verbo = "incrementa"
        else:
            verbo = "mantiene"
        frases.append(f"El escenario {verbo} el grado de densidad de {grado_actual:.1f} % "
                      f"a {grado_residual:.1f} %.")
    categoria_actual = actual.get("clasificacion")
    categoria_residual = escenario.get("clasificacion")
    if categoria_actual and categoria_residual:
        if categoria_actual == categoria_residual:
            frases.append(f"La condición residual permanece en la categoría "
                          f"«{categoria_residual}» definida por la guía.")
        else:
            frases.append(f"La condición propuesta desplaza al rodal desde «{categoria_actual}» "
                          f"hacia «{categoria_residual}».")
    return " ".join(frases)


def construir_analisis_densidad(pmf, rodal_id, modelo_id=None, n_residual=None,
                                 g_residual=None, grado_objetivo=None, vista_id=None,
                                 modelos=None, especie=None, especies_incluidas=None):
    resultado = {
        "datos_rodal": None, "modelos_especie": [], "modelo": None,
        "condicion": None, "interpretacion": None, "residual": None,
        "interpretacion_residual": None, "remocion": None, "escenarios": [],
        "comparacion": None, "grafica": None, "grado_objetivo": None,
        "mensaje": None, "error": None, "especies_incluidas": [],
    }
    if not rodal_id:
        return resultado
    disponibles = modelos if modelos is not None else cargar_modelos_densidad()
    datos_generales = obtener_datos_rodal(pmf, rodal_id)
    especie_evaluada = especie or (datos_generales or {}).get("especie_dominante")
    modelos_preseleccion = modelos_para_especie(especie_evaluada, disponibles)
    modelo_preseleccionado = next(
        (modelo for modelo in disponibles
         if modelo.get("modelo_id") == modelo_id), None)
    guia_mixta = bool(modelo_preseleccionado and
                      modelo_preseleccionado.get("aplicacion_mixta"))
    datos_rodal = obtener_datos_rodal(
        pmf, rodal_id, None if guia_mixta else especie_evaluada)
    if guia_mixta and datos_rodal:
        datos_rodal = dict(datos_rodal)
        datos_rodal["especie_seleccionada"] = especie_evaluada
    resultado["datos_rodal"] = datos_rodal
    if not datos_rodal:
        resultado["error"] = "No se encontró el rodal seleccionado."
        return resultado
    if not datos_rodal["especie_dominante"]:
        resultado["error"] = "El rodal no tiene valores válidos de N y área basal."
        return resultado
    if not guia_mixta and not datos_rodal["especie_seleccionada"]:
        resultado["error"] = "La especie seleccionada no tiene inventario en este rodal."
        return resultado
    if datos_rodal["n"] <= 0 or datos_rodal["g"] <= 0:
        resultado["error"] = "La especie seleccionada no tiene valores válidos de N y área basal."
        return resultado

    incluidas = [str(nombre).strip() for nombre in (especies_incluidas or []) if str(nombre).strip()]
    if incluidas:
        composicion_disponible = {fila["especie"]: fila for fila in datos_generales.get("composicion", [])}
        faltantes = [nombre for nombre in incluidas if nombre not in composicion_disponible]
        if faltantes:
            resultado["error"] = "Hay especies seleccionadas que no pertenecen al rodal: " + ", ".join(faltantes)
            return resultado
        n_conjunto = sum(composicion_disponible[nombre]["n"] for nombre in incluidas)
        g_conjunto = sum(composicion_disponible[nombre]["g"] for nombre in incluidas)
        if n_conjunto <= 0 or g_conjunto <= 0:
            resultado["error"] = "Las especies seleccionadas no tienen valores válidos de N y G."
            return resultado
        datos_rodal = dict(datos_rodal)
        datos_rodal.update({
            "n": n_conjunto,
            "g": g_conjunto,
            "dq": calcular_diametro_cuadratico(n_conjunto, g_conjunto),
            "especies_incluidas": incluidas,
            "especie_seleccionada": especie_evaluada,
            "es_mixto": len(incluidas) > 1,
        })

    resultado["condicion"] = {
        "n": datos_rodal["n"], "g": datos_rodal["g"], "dq": datos_rodal["dq"],
        "indice_densidad": None, "indice_nombre": None,
        "grado_densidad": None, "clasificacion": None,
    }
    resultado["especies_incluidas"] = incluidas or [especie_evaluada]

    modelos_especie = modelos_para_especie(especie_evaluada, disponibles)
    modelo = seleccionar_modelo(especie_evaluada, modelo_id, disponibles)
    if modelo_id and not modelo:
        # La guía puede utilizarse como referencia para una composición mixta
        # aunque su especie de referencia sea distinta a la especie principal.
        modelo = next((opcion for opcion in disponibles
                       if opcion.get("modelo_id") == modelo_id), None)
    resultado["modelos_especie"] = modelos_especie
    resultado["modelo"] = modelo
    if modelo_id and not modelo:
        resultado["error"] = "La guía seleccionada no corresponde a las guías disponibles."
        return resultado
    if not modelos_especie and not modelo:
        resultado["mensaje"] = ("No existe una guía de densidad registrada para "
                                 f"{datos_rodal['especie_seleccionada']}.")
        return resultado
    if len(modelos_especie) > 1 and not modelo_id:
        resultado["mensaje"] = "Seleccione la guía regional que se aplicará a este rodal."
        return resultado
    if not modelo:
        return resultado

    try:
        condicion = evaluar_condicion(datos_rodal["n"], datos_rodal["g"], modelo)
        resultado["condicion"] = condicion
        resultado["interpretacion"] = construir_interpretacion(condicion, modelo)
        if grado_objetivo not in (None, ""):
            objetivo = float(grado_objetivo)
            limites = modelo.get("simulacion_objetivo", {})
            minimo = float(limites.get("min_porcentaje", 0.01))
            maximo = float(limites.get("max_porcentaje", 1000))
            if not minimo <= objetivo <= maximo:
                raise ValueError(f"El grado objetivo debe estar entre {minimo:g} y {maximo:g} %.")
            resultado["grado_objetivo"] = objetivo

        if n_residual not in (None, "") or g_residual not in (None, ""):
            if n_residual in (None, "") or g_residual in (None, ""):
                raise ValueError("Capture N y G para la condición residual.")
            residual = evaluar_condicion(float(n_residual), float(g_residual), modelo)
            if residual["n"] > condicion["n"] or residual["g"] > condicion["g"]:
                raise ValueError("La condición residual no puede superar los valores actuales.")
            objetivo = resultado["grado_objetivo"]
            remocion_n = condicion["n"] - residual["n"]
            remocion_g = condicion["g"] - residual["g"]
            remocion = {
                "n": remocion_n,
                "g": remocion_g,
                "reduccion_n_pct": remocion_n / condicion["n"] * 100.0,
                "reduccion_g_pct": remocion_g / condicion["g"] * 100.0,
                "grado_objetivo": objetivo,
                "diferencia_objetivo": (residual["grado_densidad"] - objetivo
                                        if objetivo is not None and
                                        residual["grado_densidad"] is not None else None),
            }
            interpretacion_residual = construir_interpretacion(residual, modelo)
            comparacion = construir_comparacion(condicion, residual, modelo)
            escenario = {
                "id": "escenario_1", "nombre": "Escenario 1",
                "condicion": residual, "interpretacion": interpretacion_residual,
                "remocion": remocion, "comparacion": comparacion,
            }
            resultado.update({
                "residual": residual, "interpretacion_residual": interpretacion_residual,
                "remocion": remocion, "comparacion": comparacion,
                "escenarios": [escenario],
            })
        resultado["grafica"] = generar_datos_grafica(
            modelo, condicion, resultado["residual"], vista_id)
    except (ValueError, TypeError) as exc:
        resultado["error"] = str(exc)
        if resultado["condicion"]:
            resultado["grafica"] = generar_datos_grafica(
                modelo, resultado["condicion"], vista_id=vista_id)
        resultado.update({"residual": None, "remocion": None, "escenarios": [],
                          "comparacion": None, "interpretacion_residual": None})
    return resultado


def _rango_vista(modelo, dq_rodal, vista_id=None):
    rango = modelo.get("rango_diametrico", {})
    vistas = rango.get("vistas", [])
    vista = next((v for v in vistas if v.get("id") == vista_id), None)
    if not vista and vistas:
        vista = next((v for v in vistas if
                      v.get("min_cm", 0) <= dq_rodal <= v.get("max_cm", float("inf"))), None)
    return vista or {
        "id": "completa",
        "etiqueta": "Completa",
        "min_cm": rango.get("min_cm", 10),
        "max_cm": rango.get("max_cm", 50),
    }


def generar_datos_grafica(modelo, condicion_actual, condicion_residual=None, vista_id=None):
    vista = _rango_vista(modelo, condicion_actual["dq"], vista_id)
    dq_min = int(vista["min_cm"])
    dq_max = int(vista["max_cm"])
    curvas = []
    max_n_datos = max(condicion_actual["n"], condicion_residual["n"] if condicion_residual else 0)
    for frontera in modelo.get("fronteras", []):
        puntos = []
        if frontera.get("estado") == "disponible":
            for dq in range(dq_min, dq_max + 1):
                n = _valor_frontera_en_dq(frontera, dq)
                if n is not None:
                    g = n * math.pi * dq ** 2 / 40000.0
                    puntos.append({"x": n, "y": g})
            puntos.sort(key=lambda punto: punto["x"])
        curvas.append({
            "nombre": frontera.get("id"),
            "etiqueta": frontera.get("etiqueta", "Línea " + str(frontera.get("id"))),
            "significado": frontera.get("significado", ""),
            "estado": frontera.get("estado", "pendiente"),
            "puntos": puntos,
        })

    curvas_grado = []
    metodo_grado = modelo.get("metodo_grado_densidad", {})
    referencia = _frontera_por_id(modelo, metodo_grado.get("frontera_referencia", "A"))
    if metodo_grado.get("estado") == "disponible" and referencia:
        fundamentales = metodo_grado.get("porcentajes_fundamentales", [])
        for porcentaje in metodo_grado.get("porcentajes_grafica", []):
            if porcentaje == 100:
                continue
            puntos = []
            for dq in range(dq_min, dq_max + 1):
                n_referencia = _valor_frontera_en_dq(referencia, dq)
                if n_referencia is not None:
                    n = n_referencia * porcentaje / 100.0
                    puntos.append({"x": n, "y": n * math.pi * dq ** 2 / 40000.0})
            puntos.sort(key=lambda punto: punto["x"])
            curvas_grado.append({
                "porcentaje": porcentaje,
                "fundamental": porcentaje in fundamentales,
                "puntos": puntos,
            })

    # El rango de la vista se centra en las condiciones calculadas, no en toda
    # la extensión matemática de las curvas o isolíneas.
    max_n = max(max_n_datos * 1.15, 100.0)
    valores_g = [condicion_actual["g"]]
    if condicion_residual:
        valores_g.append(condicion_residual["g"])
    for curva in curvas + curvas_grado:
        puntos_relevantes = [punto for punto in curva.get("puntos", [])
                             if punto["x"] <= max_n]
        valores_g.extend(punto["y"] for punto in puntos_relevantes)
    max_g = max(max(valores_g, default=0.0) * 1.15, 1.0)
    isolineas = []
    diametros = modelo.get("diametros_isolineas", DIAMETROS_ISOLINEAS)
    for dq in (d for d in diametros if dq_min <= d <= dq_max):
        puntos = []
        for fraccion in (0.08, 0.25, 0.5, 0.75, 1.0):
            n = max_n * fraccion
            puntos.append({"x": n, "y": n * math.pi * dq ** 2 / 40000.0})
        isolineas.append({"dq": dq, "puntos": puntos})
    return {
        "curvas": curvas,
        "curvas_grado": curvas_grado,
        "isolineas": isolineas,
        "max_n": max_n,
        "max_g": max_g,
        "vista": vista,
        "vistas": modelo.get("rango_diametrico", {}).get("vistas", []),
        "zonas": modelo.get("zonas_densidad") or modelo.get("reglas_clasificacion", []),
    }
