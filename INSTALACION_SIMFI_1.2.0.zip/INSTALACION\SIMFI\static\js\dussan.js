/* Dussan — asistente virtual de SIMFI (API visual y conversacion).
   Expone window.Dussan. No calcula, no escribe y no altera resultados.
   SIMFI CALCULA Y VALIDA; Dussan consulta, interpreta y orienta. */
(function (global) {
  'use strict';

  var ESTADOS = ['idle', 'listening', 'thinking', 'speaking', 'success', 'warning'];
  var MENSAJES = {
    idle: 'Listo para ayudarte.',
    listening: 'Te escucho...',
    thinking: 'Estoy consultando los datos de SIMFI...',
    speaking: 'Dussan esta respondiendo...',
    success: 'Proceso completado.',
    warning: 'Atencion: revisa esta informacion.'
  };

  function DussanAPI(opciones) {
    var ajustes = opciones || {};
    this.habilitado = ajustes.habilitado !== false;
    this.voz = new global.DussanVoice();
    this.estado = 'idle';
    this.contexto = {
      predio: '', umm: '', rodal: '', modulo: '', reporte: '',
      proyecto: '', usuario: '', rol: '', version: ''
    };
    this.rodales = [];
    this.ultimo_analisis = null;
    this.listeners = {};
    this.ocupado = false;
    this.elementos = {};
  }

  DussanAPI.prototype.on = function (evento, funcion) {
    if (!this.listeners[evento]) { this.listeners[evento] = []; }
    this.listeners[evento].push(funcion);
    return this;
  };

  DussanAPI.prototype.emit = function (evento, datos) {
    var lista = this.listeners[evento] || [];
    for (var i = 0; i < lista.length; i += 1) {
      try { lista[i](datos || {}); } catch (error) { /* un oyente no rompe Dussan */ }
    }
  };

  DussanAPI.prototype.setContext = function (contexto) {
    var previo = this.contexto;
    this.contexto = Object.assign({}, this.contexto, contexto || {});
    this.emit('context_changed', this.contexto);
    if (this.contexto.rodal !== previo.rodal) { this.emit('simfi_event', {tipo: 'rodal_cambio'}); }
  };

  DussanAPI.prototype.setState = function (estado, mensaje) {
    if (ESTADOS.indexOf(estado) < 0) { return; }
    this.estado = estado;
    this.emit('state_changed', {estado: estado, mensaje: mensaje || ''});
  };

  DussanAPI.prototype.speak = function (texto, opciones) {
    var mensaje = String(texto || '');
    if (!mensaje) { return; }
    this.setState('speaking', MENSAJES.speaking);
    this.emit('speak', {texto: mensaje});
    if (!opciones || opciones.voz !== false) { this.voz.hablar(mensaje); }
  };

  DussanAPI.prototype.notify = function (tipo, texto) {
    this.setState(ESTADOS.indexOf(tipo) >= 0 ? tipo : 'warning', texto);
    this.emit('notification', {tipo: tipo, texto: texto});
  };

  DussanAPI.prototype.handleSimfiEvent = function (evento) {
    this.emit('simfi_event', evento || {});
  };

  DussanAPI.prototype.request = function (accion, carga) {
    this.emit('tool_request', {accion: accion, payload: carga || {}});
  };

  /* Sincroniza el contexto con el que publica el backend de SIMFI. */
  DussanAPI.prototype.sincronizar = function (datos) {
    if (!datos) { return Promise.resolve(null); }
    var estado = datos.estado || {};
    this.rodales = datos.rodales || [];
    this.setContext({
      predio: estado.proyecto ? (estado.proyecto.predio || '') : '',
      proyecto: estado.proyecto ? (estado.proyecto.proyecto || '') : '',
      umm: estado.rodal_actual || '',
      rodal: estado.rodal_actual || '',
      modulo: estado.modulo_etiqueta || '',
      reporte: estado.reporte_etiqueta || '',
      usuario: estado.usuario || '',
      rol: estado.rol || '',
      version: estado.version_sistema || ''
    });
    this.emit('contexto_cargado', datos);
    return datos;
  };

  DussanAPI.prototype.establecerRodal = function (idRodal) {
    var existe = this.rodales.some(function (rodal) {
      return String(rodal.id).toLowerCase() === String(idRodal || '').toLowerCase();
    });
    this.setContext({rodal: existe ? idRodal : ''});
    return existe;
  };

  /* Consulta una herramienta de lectura de SIMFI. */
  DussanAPI.prototype.consultar = function (herramienta, argumentos) {
    var self = this;
    return global.DussanTools.consultar(herramienta, argumentos).then(function (r) {
      if (r.herramienta === 'abrir_modulo' && r.ok && r.destino) {
        self.emit('tool_request', {accion: 'abrir_modulo', payload: r});
      }
      return r;
    });
  };

  /* Pregunta abierta: consulta lo necesario en SIMFI y responde. */
  DussanAPI.prototype.preguntar = function (pregunta, opciones) {
    var self = this;
    var texto = String(pregunta || '').trim();
    if (!texto) { return Promise.resolve(null); }
    if (this.ocupado) { return Promise.resolve(null); }
    this.ocupado = true;
    this.setState('thinking', MENSAJES.thinking);
    this.emit('pregunta', {texto: texto});
    var ajustes = opciones || {};
    if (ajustes.herramientas === undefined && this.contexto.rodal) {
      ajustes = Object.assign({}, ajustes, {rodal: this.contexto.rodal});
    }
    return global.DussanTools.preguntar(texto, ajustes).then(function (r) {
      self.ocupado = false;
      if (r.ok && r.texto) {
        if (r.herramientas) { self.ultimo_analisis = r.herramientas; }
        if (r.aviso) {
          self.setState('warning', 'Respuesta con datos de SIMFI (sin IA).');
          self.emit('speak', {texto: r.texto});
          self.emit('notification', {tipo: 'warning', texto: r.aviso});
        } else {
          self.speak(r.texto);
        }
      } else {
        var mensaje = (r && r.mensaje) || 'No se pudo obtener una respuesta de SIMFI.';
        self.setState('warning', 'Sin informacion disponible.');
        self.emit('speak', {texto: mensaje});
      }
      self.emit('respuesta', r || {});
      return r;
    });
  };

  DussanAPI.prototype.alternarVoz = function () {
    if (this.voz.habilitada) {
      var apagado = this.voz.deshabilitar();
      this.notify('idle', apagado.mensaje);
      this.emit('voz', {habilitada: false});
      return apagado;
    }
    var encendido = this.voz.habilitar();
    this.notify(encendido.ok ? 'success' : 'warning', encendido.mensaje);
    this.emit('voz', {habilitada: encendido.ok});
    return encendido;
  };

  global.DussanAPI = DussanAPI;

  /* ===================== Interfaz ===================== */

  function crear(documento, etiqueta, clase, texto) {
    var elemento = documento.createElement(etiqueta);
    if (clase) { elemento.className = clase; }
    if (texto !== undefined && texto !== null) { elemento.textContent = texto; }
    return elemento;
  }

  function construirPanel(documento, dussan) {
    var raiz = crear(documento, 'aside', 'dussan-root');
    raiz.id = 'dussan-panel';
    raiz.setAttribute('aria-label', 'Dussan, asistente de SIMFI');

    var encabezado = crear(documento, 'div', 'dussan-header');
    var textos = crear(documento, 'div');
    textos.appendChild(crear(documento, 'strong', null, 'Dussan'));
    textos.appendChild(crear(documento, 'small', null, 'Asistente de SIMFI'));
    textos.appendChild(crear(documento, 'div', 'dussan-contexto', ''));
    encabezado.appendChild(textos);
    var botones = crear(documento, 'div', 'dussan-acciones');

    var btnVoz = crear(documento, 'button', null, '🎤 Voz');
    btnVoz.id = 'dussan-voz';
    btnVoz.type = 'button';
    btnVoz.title = 'Activar o desactivar la voz de Dussan';
    btnVoz.setAttribute('aria-pressed', 'false');
    var btnMin = crear(documento, 'button', null, '✕');
    btnMin.id = 'dussan-minimizar';
    btnMin.type = 'button';
    btnMin.title = 'Minimizar Dussan';
    btnMin.setAttribute('aria-label', 'Minimizar Dussan');
    botones.appendChild(btnVoz);
    botones.appendChild(btnMin);
    encabezado.appendChild(botones);
    raiz.appendChild(encabezado);

    /* Escena: el pastor alemán aprobado como personaje central, con su globo. */
    var escena = crear(documento, 'div', 'dussan-escena estado-idle');
    escena.id = 'dussan-escena';
    var marco = crear(documento, 'div', 'dussan-marco');
    var avatar = crear(documento, 'img');
    avatar.id = 'dussan-avatar';
    avatar.setAttribute('alt', 'Dussan, pastor alemán asistente de SIMFI');
    var urlAvatar = (global.SIMFI_DUSSAN && global.SIMFI_DUSSAN.avatar) || '';
    if (urlAvatar) { avatar.src = urlAvatar; }
    avatar.onerror = function () {
      /* Si un asset futuro falta, se vuelve al idle sin romper el panel. */
      var repliegue = (global.SIMFI_DUSSAN &&
        ((global.SIMFI_DUSSAN.estados || {}).idle || global.SIMFI_DUSSAN.avatar)) || '';
      if (repliegue && avatar.getAttribute('src') !== repliegue) { avatar.src = repliegue; }
      else { avatar.style.display = 'none'; }
    };
    marco.appendChild(avatar);
    escena.appendChild(marco);
    raiz.appendChild(escena);

    var estado = crear(documento, 'div', 'dussan-state', 'Listo para ayudarte.');
    estado.id = 'dussan-estado';
    raiz.appendChild(estado);

    /* Globo único: el intercambio vigente, sin burbujas de conversación. */
    var globo = crear(documento, 'div', 'dussan-globo');
    globo.id = 'dussan-globo';
    globo.setAttribute('aria-live', 'polite');
    var pregunta = crear(documento, 'div', 'dussan-pregunta', '');
    pregunta.id = 'dussan-pregunta';
    var respuesta = crear(documento, 'div', 'dussan-respuesta',
      '¡Hola! Soy Dussan 🐾 Tu asistente virtual de SIMFI. ¿En qué puedo ayudarte hoy? 🍃');
    respuesta.id = 'dussan-respuesta';
    globo.appendChild(pregunta);
    globo.appendChild(respuesta);
    escena.appendChild(globo);

    var rapidas = crear(documento, 'div', 'dussan-quick');
    [
      ['🌲 Existencias', 'consultar_existencias'],
      ['📊 Muestreo', 'consultar_muestreo'],
      ['📈 Incrementos', 'consultar_incremento'],
      ['🗺 UMM', 'consultar_rodales']
    ].forEach(function (item) {
      var boton = crear(documento, 'button', null, item[0]);
      boton.type = 'button';
      boton.setAttribute('data-herramienta', item[1]);
      rapidas.appendChild(boton);
    });
    raiz.appendChild(rapidas);

    var compositor = crear(documento, 'div', 'dussan-composer');
    var entrada = crear(documento, 'input');
    entrada.id = 'dussan-entrada';
    entrada.type = 'text';
    entrada.placeholder = 'Escribe o habla con Dussan...';
    entrada.autocomplete = 'off';
    var mic = crear(documento, 'button', null, '🎙');
    mic.id = 'dussan-microfono';
    mic.type = 'button';
    mic.title = 'Dictar con voz';
    var enviar = crear(documento, 'button', null, '➤');
    enviar.id = 'dussan-enviar';
    enviar.type = 'button';
    enviar.title = 'Enviar';
    compositor.appendChild(entrada);
    compositor.appendChild(mic);
    compositor.appendChild(enviar);
    raiz.appendChild(compositor);

    /* Píldora flotante al minimizar: el avatar queda visible y reabre el panel.
       La miniatura y cada estado son URLs sustituibles por assets finales. */
    var mapaEstados = (global.SIMFI_DUSSAN && global.SIMFI_DUSSAN.estados) || {};
    var urlMini = (global.SIMFI_DUSSAN && global.SIMFI_DUSSAN.mini) || urlAvatar;
    var flotante = crear(documento, 'button', null, '');
    flotante.id = 'dussan-flotante';
    flotante.type = 'button';
    flotante.title = 'Abrir Dussan';
    flotante.setAttribute('aria-label', 'Abrir Dussan');
    flotante.hidden = true;
    var miniMarco = crear(documento, 'span', 'dussan-mini-marco');
    var mini = crear(documento, 'img');
    mini.setAttribute('alt', 'Dussan');
    if (urlMini) { mini.src = urlMini; }
    mini.onerror = function () { mini.style.display = 'none'; };
    miniMarco.appendChild(mini);
    var punto = crear(documento, 'span', 'dussan-punto punto-idle');
    punto.setAttribute('aria-hidden', 'true');
    miniMarco.appendChild(punto);
    flotante.appendChild(miniMarco);
    flotante.appendChild(crear(documento, 'span', 'dussan-nombre', 'Dussan'));

    dussan.elementos = {
      raiz: raiz, flotante: flotante, escena: escena, avatar: avatar,
      estado: estado, globo: globo, pregunta: pregunta, respuesta: respuesta,
      punto: punto, mapaEstados: mapaEstados,
      contexto: textos.querySelector('.dussan-contexto'),
      entrada: entrada, mic: mic, enviar: enviar, btnVoz: btnVoz, btnMin: btnMin
    };
    return {panel: raiz, flotante: flotante};
  }

  function describirContexto(contexto) {    var partes = [];
    if (contexto.predio) { partes.push('Predio: ' + contexto.predio); }
    if (contexto.rodal) { partes.push('UMM/rodal: ' + contexto.rodal); }
    if (contexto.modulo) { partes.push('Módulo: ' + contexto.modulo); }
    return partes.join(' · ');
  }

  function iniciar() {
    var ajustes = global.SIMFI_DUSSAN || {};
    if (ajustes.habilitado === false) { return; }
    if (!global.DussanTools || !global.DussanVoice) { return; }

    var dussan = new DussanAPI({habilitado: true});
    global.Dussan = dussan;
    /* La conversación se conserva en memoria: el globo muestra el intercambio
       vigente y el historial completo sobrevive al minimizado. */
    dussan.historial = [];
    dussan.pendiente = '';
    var documento = global.document;
    var piezas = construirPanel(documento, dussan);
    var cuerpo = documento.body || documento.documentElement;
    cuerpo.appendChild(piezas.panel);
    cuerpo.appendChild(piezas.flotante);

    /* Globo único: la pregunta vigente y la respuesta vigente de Dussan. */
    function fijarPregunta(texto) {
      dussan.elementos.pregunta.textContent = String(texto || '');
      dussan.pendiente = String(texto || '');
    }
    function fijarRespuesta(texto, clase) {
      var globo = dussan.elementos.globo;
      globo.className = 'dussan-globo' + (clase ? ' ' + clase : '');
      dussan.elementos.respuesta.textContent = String(texto || '');
      globo.scrollTop = 0;
    }
    function registrarIntercambio(ok) {
      if (!dussan.pendiente && !dussan.elementos.respuesta.textContent) { return; }
      dussan.historial.push({pregunta: dussan.pendiente,
        respuesta: dussan.elementos.respuesta.textContent, ok: ok !== false});
      dussan.pendiente = '';
    }

    dussan.on('state_changed', function (cambio) {
      dussan.elementos.escena.className = 'dussan-escena estado-' + cambio.estado;
      dussan.elementos.estado.textContent = cambio.mensaje || MENSAJES[cambio.estado] || '';
      /* La escena muestra el asset oficial del estado; el punto de la píldora
         conserva el último estado aunque el panel esté minimizado. */
      var mapa = dussan.elementos.mapaEstados || {};
      var url = mapa[cambio.estado] || mapa.idle || '';
      var imagen = dussan.elementos.avatar;
      if (url && imagen.getAttribute('src') !== url) { imagen.src = url; }
      dussan.elementos.punto.className = 'dussan-punto punto-' + cambio.estado;
    });
    dussan.on('pregunta', function (evento) {
      fijarPregunta(evento.texto);
      fijarRespuesta('Estoy revisando la información en SIMFI…');
    });
    dussan.on('speak', function (evento) {
      fijarRespuesta(evento.texto);
      registrarIntercambio(true);
    });
    dussan.on('notification', function (evento) {
      fijarRespuesta(evento.texto, evento.tipo === 'warning' ? 'aviso' : '');
      registrarIntercambio(evento.tipo !== 'warning');
    });
    dussan.on('context_changed', function () {
      dussan.elementos.contexto.textContent = describirContexto(dussan.contexto);
    });
    dussan.on('voz', function (evento) {
      dussan.elementos.btnVoz.setAttribute('aria-pressed', evento.habilitada ? 'true' : 'false');
    });
    dussan.on('tool_request', function (evento) {
      var carga = evento.payload || {};
      if (evento.accion !== 'abrir_modulo' || !carga.url) { return; }
      global.setTimeout(function () { global.location.href = carga.url; }, 400);
    });

    function enviar(texto) {
      var pregunta = String(texto || '').trim();
      if (!pregunta) { return; }
      dussan.elementos.entrada.value = '';
      dussan.preguntar(pregunta);
    }

    function minimizar() {
      dussan.elementos.raiz.style.display = 'none';
      dussan.elementos.flotante.hidden = false;
      dussan.emit('minimizado', {minimizado: true});
    }
    function restaurar() {
      dussan.elementos.flotante.hidden = true;
      dussan.elementos.raiz.style.display = '';
      dussan.emit('minimizado', {minimizado: false});
    }

    dussan.elementos.enviar.addEventListener('click', function () {
      enviar(dussan.elementos.entrada.value);
    });
    dussan.elementos.entrada.addEventListener('keydown', function (evento) {
      if (evento.key === 'Enter') { enviar(dussan.elementos.entrada.value); }
    });
    dussan.elementos.btnMin.addEventListener('click', minimizar);
    dussan.elementos.flotante.addEventListener('click', restaurar);
    dussan.elementos.btnVoz.addEventListener('click', function () {
      dussan.alternarVoz();
    });
    dussan.elementos.mic.addEventListener('click', function () {
      if (!dussan.voz.habilitada) {
        var encendido = dussan.voz.habilitar();
        dussan.elementos.btnVoz.setAttribute('aria-pressed', encendido.ok ? 'true' : 'false');
        if (!encendido.ok) {
          dussan.setState('warning', 'Voz no disponible.');
          fijarRespuesta(encendido.mensaje, 'aviso');
          return;
        }
      }
      dussan.setState('listening', 'Te escucho...');
      dussan.voz.esperar().then(function (transcripcion) {
        dussan.setState('idle', 'Listo para ayudarte.');
        enviar(transcripcion);
      }).catch(function (error) {
        dussan.setState('warning', 'Voz no disponible.');
        fijarRespuesta(error.message || 'No se pudo usar el micrófono.', 'aviso');
      });
    });

    var rapidas = dussan.elementos.raiz.querySelectorAll('.dussan-quick button');
    Array.prototype.forEach.call(rapidas, function (boton) {
      boton.addEventListener('click', function () {
        var herramienta = boton.getAttribute('data-herramienta');
        var etiqueta = boton.textContent;
        dussan.setState('thinking', 'Consultando ' + etiqueta.toLowerCase() + '...');
        fijarPregunta(etiqueta);
        fijarRespuesta('Estoy revisando la información en SIMFI…');
        dussan.consultar(herramienta, {rodal: dussan.contexto.rodal}).then(function (r) {
          if (r.ok) {
            dussan.setState('success', 'Dato consultado en SIMFI.');
            fijarRespuesta('SIMFI tiene disponible la información de ' +
              etiqueta.toLowerCase() + ' para el predio activo. ' +
              'Escríbeme qué quieres saber para darte el detalle o la interpretación.');
            registrarIntercambio(true);
          } else {
            dussan.setState('warning', 'Sin información disponible.');
            fijarRespuesta(r.mensaje || 'No hay información disponible.', 'aviso');
            registrarIntercambio(false);
          }
        });
      });
    });

    if (ajustes.voz) { dussan.voz.habilitar(); }

    dussan.sincronizar(global.SIMFI_DUSSAN.contexto || null);
    if (!global.SIMFI_DUSSAN.contexto) {
      global.DussanTools.contexto().then(function (r) {
        if (r && r.estado) { dussan.sincronizar(r); }
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', iniciar);
  } else {
    iniciar();
  }
}(window));

