"""Componente general para cuadros tecnicos de SIMFI en reportes Word.

Genera cuadros documentales listos para un Programa de Manejo Forestal:
encabezados jerarquicos (fusiones horizontales y verticales), filas compactas,
numeros formateados, filas de total, encabezados repetidos en varias paginas,
titulo tipo "Tabla N. Nombre", anchos proporcionales y orientacion de pagina.

Esta capa solo organiza y presenta datos ya calculados por los modulos de SIMFI;
no ejecuta calculos forestales.
"""

import re

from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.section import WD_ORIENT, WD_SECTION
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt


GRIS_ENCABEZADO = "D9D9D9"
GRIS_TOTAL = "EDEDED"
FUENTE = "Aptos"
TAMANO_BASE = 9

# Regla general de distribución de columnas (solo presentación; los datos,
# el orden y la estructura del cuadro no se alteran).
UNIDAD_CARACTER_CM = 0.21  # ancho medio por carácter al tamaño base
RELLENO_CELDA_CM = 0.45  # márgenes internos de celda + holgura
ANCHO_MINIMO_COLUMNA_CM = 1.5  # piso de legibilidad: ninguna columna queda comprimida
TOPE_CARACTERES_TEXTO = 26  # las columnas de texto largo se topan para no acaparar la tabla
_PATRON_TEXTO_LARGO = re.compile(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]{4,}")


def _sombrear(celda, color):
    propiedades = celda._tc.get_or_add_tcPr()
    sombreado = propiedades.find(qn("w:shd"))
    if sombreado is None:
        sombreado = OxmlElement("w:shd")
        propiedades.append(sombreado)
    sombreado.set(qn("w:fill"), color)


def _margenes_celda(celda, superior=20, inicio=60, inferior=20, fin=60):
    propiedades = celda._tc.get_or_add_tcPr()
    margenes = propiedades.find(qn("w:tcMar"))
    if margenes is None:
        margenes = OxmlElement("w:tcMar")
        propiedades.append(margenes)
    for nombre, valor in (("top", superior), ("start", inicio),
                          ("bottom", inferior), ("end", fin)):
        nodo = margenes.find(qn(f"w:{nombre}"))
        if nodo is None:
            nodo = OxmlElement(f"w:{nombre}")
            margenes.append(nodo)
        nodo.set(qn("w:w"), str(valor))
        nodo.set(qn("w:type"), "dxa")


def ancho_texto_cm(seccion):
    """Ancho util de la pagina en centimetros (pagina menos margenes)."""
    emu = (seccion.page_width - seccion.left_margin - seccion.right_margin)
    return float(emu) / 360000.0


def agregar_caption(documento, titulo, numero_tabla=None):
    """Coloca el titulo del cuadro con formato 'Tabla N. Nombre'."""
    parrafo = documento.add_paragraph()
    if "Caption" in documento.styles:
        parrafo.style = documento.styles["Caption"]
    formato = parrafo.paragraph_format
    formato.space_before = Pt(6)
    formato.space_after = Pt(3)
    formato.line_spacing = 1.0
    formato.keep_with_next = True
    numero = f"{numero_tabla}. " if numero_tabla is not None else ". "
    run = parrafo.add_run(f"Tabla {numero}{titulo}")
    run.font.name = FUENTE
    run.font.size = Pt(9)
    return parrafo


def _bordes_tabla(tabla):
    tbl_prop = tabla._tbl.tblPr
    bordes = tbl_prop.find(qn("w:tblBorders"))
    if bordes is None:
        bordes = OxmlElement("w:tblBorders")
        tbl_prop.append(bordes)
    for nombre in ("top", "left", "bottom", "right", "insideH", "insideV"):
        nodo = bordes.find(qn(f"w:{nombre}"))
        if nodo is None:
            nodo = OxmlElement(f"w:{nombre}")
            bordes.append(nodo)
        nodo.set(qn("w:val"), "single")
        nodo.set(qn("w:sz"), "4")
        nodo.set(qn("w:space"), "0")
        nodo.set(qn("w:color"), "000000")


def _layout_fijo(tabla, anchos_twips):
    """Ancho total de pagina (100%) y columnas de ancho fijo."""
    tbl_prop = tabla._tbl.tblPr
    ancho = tbl_prop.find(qn("w:tblW"))
    if ancho is None:
        ancho = OxmlElement("w:tblW")
        tbl_prop.append(ancho)
    ancho.set(qn("w:w"), "5000")
    ancho.set(qn("w:type"), "pct")
    layout = tbl_prop.find(qn("w:tblLayout"))
    if layout is None:
        layout = OxmlElement("w:tblLayout")
        tbl_prop.append(layout)
    layout.set(qn("w:type"), "fixed")
    grid = tabla._tbl.find(qn("w:tblGrid"))
    if grid is not None:
        tabla._tbl.remove(grid)
    grid = OxmlElement("w:tblGrid")
    for ancho_col in anchos_twips:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(ancho_col))
        grid.append(col)
    tabla._tbl.insert(list(tabla._tbl).index(tbl_prop) + 1, grid)


def _estilo_celda(celda, tamano=TAMANO_BASE, negrita=False, cursiva=False,
                  alineacion=WD_ALIGN_PARAGRAPH.CENTER, sombra=None,
                  repetir=False):
    celda.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    _margenes_celda(celda, superior=20, inicio=60, inferior=20, fin=60)
    for parrafo in celda.paragraphs:
        formato = parrafo.paragraph_format
        formato.space_before = Pt(0)
        formato.space_after = Pt(0)
        formato.line_spacing = 1.0
        if repetir:
            formato.keep_with_next = True
        parrafo.alignment = alineacion
        for run in parrafo.runs:
            run.font.name = FUENTE
            run.font.size = Pt(tamano)
            run.font.bold = negrita
            run.font.italic = cursiva
    if sombra:
        _sombrear(celda, sombra)


def _texto_celda(celda, texto):
    celda.text = ""
    run = celda.paragraphs[0].add_run(texto)
    return run


def _formato_celda_tabla(valor, decimal=None):
    if valor is None:
        return ""
    if isinstance(valor, float) and decimal is not None:
        return f"{valor:,.{decimal}f}"
    return str(valor)


def _marcar_encabezado_repeticion(fila):
    tr_prop = fila._tr.get_or_add_trPr()
    if tr_prop.find(qn("w:tblHeader")) is None:
        encabezado = OxmlElement("w:tblHeader")
        encabezado.set(qn("w:val"), "true")
        tr_prop.append(encabezado)


def _fusion_vertical(celda_superior, celda_inferior):
    for celda, valor in ((celda_superior, "restart"), (celda_inferior, "continue")):
        propiedades = celda._tc.get_or_add_tcPr()
        nodo = propiedades.find(qn("w:vMerge"))
        if nodo is None:
            nodo = OxmlElement("w:vMerge")
            propiedades.append(nodo)
        nodo.set(qn("w:val"), valor)


def _fusion_horizontal(celda_origen, celda_final, n_hojas):
    if celda_origen is not celda_final:
        celda_origen.merge(celda_final)
    propiedades = celda_origen._tc.get_or_add_tcPr()
    nodo = propiedades.find(qn("w:gridSpan"))
    if nodo is None:
        nodo = OxmlElement("w:gridSpan")
        propiedades.append(nodo)
    nodo.set(qn("w:val"), str(n_hojas))


def _especificaciones_encabezados(niveles):
    """Convierte niveles de encabezado en (texto, inicio, span) por hoja."""
    niveles_hoja = []
    for nivel in niveles:
        hoja = []
        indice = 0
        for celda in nivel:
            texto = celda["texto"] if isinstance(celda, dict) else str(celda)
            span = celda.get("span", 1) if isinstance(celda, dict) else 1
            hoja.append({"texto": texto, "inicio": indice, "span": span})
            indice += span
        niveles_hoja.append(hoja)
    return niveles_hoja


def _longitud_encabezados_por_columna(niveles):
    """Longitud máxima de encabezado por columna hoja (reparte longitud/span)."""
    medidas = {}
    for nivel in niveles:
        for espec in nivel:
            inicio, span = espec["inicio"], espec["span"]
            por_columna = len(espec["texto"]) / max(span, 1)
            for indice in range(inicio, inicio + span):
                medidas[indice] = max(medidas.get(indice, 0.0), por_columna)
    return medidas


def _distribuir_anchos(columnas, niveles, filas, decimales, anchos_relativos,
                       texto_cm, tamano_fuente):
    """Reparte el ancho útil entre columnas según su contenido real.

    Solo presentación: no altera datos, orden, nombres ni estructura. Cada
    columna recibe espacio proporcional a su necesidad (encabezados con tope
    de dos líneas y contenido impreso tal como sale en la celda), con un piso
    mínimo que conserva la legibilidad (p. ej. "No calculable" no se parte).
    Los pesos explícitos del llamador (anchos_relativos) modulan la
    proporción sin romper el mínimo. La suma final siempre es el ancho útil.
    """
    unidad = UNIDAD_CARACTER_CM * (tamano_fuente / TAMANO_BASE)
    encabezado = _longitud_encabezados_por_columna(niveles)
    contenido_max = [0.0] * columnas
    es_texto = [False] * columnas
    for fila in filas:
        if isinstance(fila, dict):
            valores = fila.get("valores_fisicos", fila.get("valores", []))
            tramos = {inicio: n for inicio, n in (fila.get("fusiones") or [])}
        else:
            valores = list(fila)
            tramos = {}
        for indice, valor in enumerate(valores):
            if indice >= columnas or valor is None:
                continue
            decimal = decimales.get(indice) if decimales else None
            texto = _formato_celda_tabla(valor, decimal=decimal)
            longitud = len(texto) / max(tramos.get(indice, 1), 1)
            contenido_max[indice] = max(contenido_max[indice], longitud)
            if _PATRON_TEXTO_LARGO.search(texto):
                es_texto[indice] = True
    necesidades = []
    for indice in range(columnas):
        encabezado_col = encabezado.get(indice, 0.0)
        contenido_col = contenido_max[indice]
        if es_texto[indice]:
            caracteres = max(encabezado_col / 2.0, min(contenido_col, TOPE_CARACTERES_TEXTO), 9.0)
        else:
            caracteres = max(contenido_col, encabezado_col / 2.0, 7.0)
        necesidades.append(caracteres * unidad + RELLENO_CELDA_CM)
    if anchos_relativos:
        pesos = list(anchos_relativos[:columnas]) + [1.0] * max(0, columnas - len(anchos_relativos))
        media = sum(pesos) / len(pesos) if pesos else 1.0
        if media:
            for indice, peso in enumerate(pesos):
                necesidades[indice] *= min(max(peso / media, 0.5), 2.0)
    total = sum(necesidades) or 1.0
    anchos = [necesidad * texto_cm / total for necesidad in necesidades]
    for _ in range(columnas):
        deficit = sum(max(0.0, ANCHO_MINIMO_COLUMNA_CM - ancho) for ancho in anchos)
        if deficit <= 0:
            break
        holgura = sum(max(0.0, ancho - ANCHO_MINIMO_COLUMNA_CM) for ancho in anchos)
        if holgura <= 0:
            break
        for indice, ancho in enumerate(anchos):
            if ancho <= ANCHO_MINIMO_COLUMNA_CM:
                anchos[indice] = ANCHO_MINIMO_COLUMNA_CM
            else:
                exceso = ancho - ANCHO_MINIMO_COLUMNA_CM
                anchos[indice] = ANCHO_MINIMO_COLUMNA_CM + exceso * (1.0 - deficit / holgura)
    return anchos


def crear_cuadro(documento, *, encabezados, filas, titulo=None,
                 numero_tabla=None, anchos_relativos=None, alineaciones=None,
                 decimales=None, orientacion="portrait",
                 tamano_fuente=TAMANO_BASE, repetir_encabezado=True,
                 columnas_verticales=()):
    """Crea un cuadro estandar en el documento.

    encabezados: niveles (filas) con celdas str o dict {texto, span}.
    filas: listas de valores o dicts {"valores"/"valores_fisicos", "negrita",
           "cursiva", "sombra", "fusiones"}. "valores_fisicos" va alineado
           1:1 con las columnas de la hoja (None en celdas absorbidas).
           "fusiones": pares (columna_inicio, n_columnas) de celdas combinadas.
     anchos_relativos: proporciones por columna hoja (por defecto: primera mas ancha).
            Actúan como moduladores de la distribución por contenido, que mide
            encabezados y celdas y garantiza un ancho mínimo legible.
    alineaciones: dict indice_columna -> "left"|"center"|"right".
    decimales: dict indice_columna -> numero de decimales para numericos.
    columnas_verticales: indices de columna cuyo encabezado se fusiona en
                         vertical (para encabezados jerarquicos).
    """
    seccion = documento.sections[-1]
    if orientacion == "landscape":
        seccion = documento.add_section(WD_SECTION.NEW_PAGE)
        seccion.orientation = WD_ORIENT.LANDSCAPE
        seccion.page_width, seccion.page_height = Cm(27.94), Cm(21.59)
        seccion.left_margin, seccion.right_margin = Cm(1.2), Cm(1.2)
        seccion.top_margin, seccion.bottom_margin = Cm(1.5), Cm(1.5)

    niveles = _especificaciones_encabezados(encabezados)
    columnas = len(encabezados[-1]) if encabezados else 0
    niveles_hoja = niveles

    if titulo:
        agregar_caption(documento, titulo, numero_tabla)

    tabla = documento.add_table(rows=len(niveles_hoja), cols=columnas)
    tabla.alignment = WD_TABLE_ALIGNMENT.CENTER

    for fila_nivel, especificaciones in enumerate(niveles_hoja):
        fila = tabla.rows[fila_nivel]
        for celda in fila.cells:
            _texto_celda(celda, "")
        for espec in especificaciones:
            inicio, span, texto = espec["inicio"], espec["span"], espec["texto"]
            if span > 1:
                objetivo = min(inicio + span - 1, columnas - 1)
                _fusion_horizontal(fila.cells[inicio], fila.cells[objetivo], span)
                celda = fila.cells[inicio]
            else:
                celda = fila.cells[inicio]
            vertical = fila_nivel > 0 and inicio in columnas_verticales
            if vertical:
                _fusion_vertical(tabla.rows[0].cells[inicio], celda)
                texto = ""
            run = _texto_celda(celda, texto)
            run.font.name = FUENTE
            run.font.size = Pt(tamano_fuente)
            run.font.bold = True
            _estilo_celda(celda, tamano=tamano_fuente, negrita=True,
                          alineacion=WD_ALIGN_PARAGRAPH.CENTER,
                          sombra=GRIS_ENCABEZADO, repetir=repetir_encabezado)
        if repetir_encabezado:
            _marcar_encabezado_repeticion(fila)

    alineacion_por_columna = {}
    for indice in range(columnas):
        alineacion_por_columna[indice] = "left" if indice == 0 else "center"
    if alineaciones:
        alineacion_por_columna.update(alineaciones)
    mapeo_alineacion = {"left": WD_ALIGN_PARAGRAPH.LEFT,
                        "center": WD_ALIGN_PARAGRAPH.CENTER,
                        "right": WD_ALIGN_PARAGRAPH.RIGHT}

    for numero_fila, fila in enumerate(filas):
        if isinstance(fila, dict):
            valores = fila.get("valores_fisicos", fila.get("valores", []))
            negrita = bool(fila.get("negrita", False))
            cursiva = bool(fila.get("cursiva", False))
            sombra = fila.get("sombra")
            fusiones = fila.get("fusiones") or []
        else:
            valores = list(fila)
            negrita = cursiva = False
            sombra = None
            fusiones = []
        celdas = tabla.add_row().cells
        for inicio, n_hojas in fusiones:
            if n_hojas > 1:
                objetivo = min(inicio + n_hojas - 1, len(celdas) - 1)
                for indice in range(inicio + 1, objetivo + 1):
                    _texto_celda(celdas[indice], "")
                _fusion_horizontal(celdas[inicio], celdas[objetivo], n_hojas)
        for indice, valor in enumerate(valores):
            if indice >= len(celdas) or valor is None:
                continue
            texto = _formato_celda_tabla(valor, decimal=decimales.get(indice) if decimales else None)
            _texto_celda(celdas[indice], texto)
            alineacion = mapeo_alineacion.get(alineacion_por_columna.get(indice, "center"),
                                              WD_ALIGN_PARAGRAPH.CENTER)
            _estilo_celda(celdas[indice], tamano=tamano_fuente, negrita=negrita,
                          cursiva=cursiva, alineacion=alineacion, sombra=sombra,
                          repetir=(numero_fila == 0 and repetir_encabezado))

    texto_cm = ancho_texto_cm(seccion)
    anchos_cm = _distribuir_anchos(columnas, niveles, filas, decimales,
                                   anchos_relativos, texto_cm, tamano_fuente)
    anchos_twips = [max(1, int(cm * 566.93)) for cm in anchos_cm]
    _layout_fijo(tabla, anchos_twips)
    _bordes_tabla(tabla)

    for fila in tabla.rows:
        ocupadas = set()
        for indice, celda in enumerate(fila.cells):
            if indice in ocupadas:
                continue
            propiedades = celda._tc.get_or_add_tcPr()
            nodo = propiedades.find(qn("w:gridSpan"))
            span = int(nodo.get(qn("w:val"))) if nodo is not None else 1
            ancho = sum(anchos_cm[indice:indice + span])
            celda.width = Cm(ancho)
            ocupadas.update(range(indice, indice + span))

    return tabla, seccion