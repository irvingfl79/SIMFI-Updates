import os, sys, urllib.request, zipfile, subprocess, platform, shutil, site

BASE = os.path.dirname(os.path.abspath(__file__))
PY_DIR = os.path.join(BASE, "python")
PYTHON_EXE = os.path.join(PY_DIR, "python.exe")
PYTHON_EMBED_URL = "https://www.python.org/ftp/python/3.14.6/python-3.14.6-embed-amd64.zip"
GET_PIP_URL = "https://bootstrap.pypa.io/get-pip.py"

def _log(msg):
    print(f"  [{msg}]")

def find_python():
    try:
        r = subprocess.run(["python", "--version"], capture_output=True, text=True, timeout=5)
        if r.returncode == 0:
            return "python", r.stdout.strip()
    except: pass
    try:
        r = subprocess.run(["python3", "--version"], capture_output=True, text=True, timeout=5)
        if r.returncode == 0:
            return "python3", r.stdout.strip()
    except: pass
    if os.path.isfile(PYTHON_EXE):
        try:
            r = subprocess.run([PYTHON_EXE, "--version"], capture_output=True, text=True, timeout=5)
            if r.returncode == 0:
                return PYTHON_EXE, r.stdout.strip()
        except: pass
    return None, None

def download_python():
    if os.path.isfile(PYTHON_EXE):
        _log(f"Python local ya existe en {PY_DIR}")
        return True
    os.makedirs(PY_DIR, exist_ok=True)
    zip_path = os.path.join(BASE, "python-embed.zip")
    try:
        _log(f"Descargando Python embeddable...")
        urllib.request.urlretrieve(PYTHON_EMBED_URL, zip_path)
        _log(f"Extrayendo...")
        with zipfile.ZipFile(zip_path, 'r') as zf:
            zf.extractall(PY_DIR)
        os.remove(zip_path)
        _log(f"Python extraido en {PY_DIR}")
        _habilitar_pip()
        return True
    except Exception as e:
        _log(f"Error: {e}")
        return False

def _habilitar_pip():
    pth_file = os.path.join(PY_DIR, "python._pth")
    if os.path.isfile(pth_file):
        with open(pth_file, "r") as f:
            content = f.read()
        if "import site" not in content:
            with open(pth_file, "a") as f:
                f.write("\nimport site\n")
            _log("Python._pth modificado para habilitar pip")

def download_get_pip():
    pip_path = os.path.join(BASE, "get-pip.py")
    if not os.path.isfile(pip_path):
        _log("Descargando get-pip.py...")
        urllib.request.urlretrieve(GET_PIP_URL, pip_path)
    return pip_path

def instalar_dependencias(python_exe):
    pip_script = os.path.join(os.path.dirname(python_exe), "Scripts", "pip.exe")
    if os.path.isfile(pip_script):
        pip_cmd = pip_script
    else:
        get_pip = download_get_pip()
        _log("Instalando pip...")
        subprocess.run([python_exe, get_pip, "--quiet"], check=True)
        pip_cmd = os.path.join(os.path.dirname(python_exe), "Scripts", "pip.exe")
    req = os.path.join(BASE, "requirements.txt")
    if os.path.isfile(req):
        _log("Instalando dependencias...")
        subprocess.run([python_exe, "-m", "pip", "install", "-r", req, "--quiet"], check=True)
    else:
        _log("Instalando flask y openpyxl...")
        subprocess.run([python_exe, "-m", "pip", "install", "flask", "openpyxl", "--quiet"], check=True)

def main():
    print("=" * 50)
    print("  SIMFI V 1.0 - Configuracion Portable")
    print("=" * 50)
    exe, ver = find_python()
    if exe:
        print(f"  Python encontrado: {ver}")
        print(f"  Ruta: {exe}")
        usar = exe
    else:
        print("  Python no encontrado.")
        r = input("  Descargar Python portable a la carpeta 'python/'? (s/n): ")
        if r.lower() != "s":
            print("  Cancelado.")
            return
        if not download_python():
            print("  Error al descargar Python.")
            return
        usar = PYTHON_EXE
    print()
    instalar_dependencias(usar)
    print()
    r = subprocess.run([usar, "-c", "import flask; print('Flask', flask.__version__)"], capture_output=True, text=True)
    print(f"  {r.stdout.strip()}")
    r = subprocess.run([usar, "-c", "import openpyxl; print('openpyxl', openpyxl.__version__)"], capture_output=True, text=True)
    print(f"  {r.stdout.strip()}")
    print()
    print("  Instalacion completada.")
    print(f"  Para iniciar: {usar} run.py")
    print("=" * 50)

if __name__ == "__main__":
    main()
