param(
    [string]$UrlCatalogo = "",
    [string]$Destination = ""
)

# ============================================================
# Consulta de actualizaciones SIMFI (canal en linea, lectura).
#
# NO instala nada por si solo: descarga el transporte del paquete y
# delega TODA la verificacion criptografica, el respaldo autonomico,
# la proteccion de datos y la instalacion al actualizador local
# CONFIABLE (la copia dentro de la instalacion), invocado con
# -PackageRoot hacia la carpeta descargada. El verificador Ed25519,
# las claves confiables integradas y el fail-closed permanecen
# intactos: un catalogo alterado solo produce paquetes RECHAZADOS,
# nunca paquetes aceptados.
#
# Credenciales: NINGUN token va incrustado. Si el operador exporta
# GITHUB_TOKEN en el entorno de la sesion, se usa para leer el
# repositorio privado mientras el repositorio sea privado; las PC
# finales funcionan sin tokens (repositorio publico de avisos o
# canal manual).
# ============================================================

$ErrorActionPreference = "Stop"
$EsPrueba = [bool]$env:SIMFI_UPDATE_TEST_DEST
$TempRoot = Join-Path $env:TEMP ("SIMFI_Consulta_" + [guid]::NewGuid().ToString("N"))
# Canal por defecto (opcion A): repositorio publico de avisos y
# paquetes firmados. Si el repositorio de codigo sigue privado, las
# PC finales consultan ESTE espejo sin cadenas ni tokens.
$UrlDefecto = "https://raw.githubusercontent.com/irvingfl79/SIMFI-Updates/master/actualizaciones_catalogo.json"

function Set-Tls12 {
    try {
        $Actual = [Net.ServicePointManager]::SecurityProtocol
        if (-not ([int]$Actual -band [int][Net.SecurityProtocolType]::Tls12)) {
            [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        }
    } catch {
        throw "No se pudo habilitar TLS 1.2 para la consulta en linea."
    }
}

function Get-Encabezados {
    $Encabezados = @{ "Cache-Control" = "no-cache" }
    # Token SOLO si el operador lo exporta en el entorno; jamas va
    # incrustado en el codigo ni en el paquete.
    if ($env:GITHUB_TOKEN) {
        $Encabezados["Authorization"] = ("Bearer " + $env:GITHUB_TOKEN)
    }
    return $Encabezados
}

# Localizar la instalacion existente (mismas pistas que el
# actualizador: acceso directo del Escritorio/Menu y rutas conocidas).
function Get-InstalacionSimfi {
    param([string]$Solicitada)
    if ($Solicitada) {
        return [IO.Path]::GetFullPath($Solicitada)
    }
    $CandidatosAccesos = @()
    try {
        $Shell = New-Object -ComObject WScript.Shell
        foreach ($RutaAcceso in @(
            (Join-Path ([Environment]::GetFolderPath("Desktop")) "SIMFI.lnk"),
            (Join-Path ([Environment]::GetFolderPath("Programs")) "SIMFI\SIMFI.lnk"))) {
            if (-not (Test-Path -LiteralPath $RutaAcceso -PathType Leaf)) { continue }
            $Candidato = Split-Path (Split-Path $Shell.CreateShortcut($RutaAcceso).TargetPath -Parent) -Parent
            if ($Candidato -and (Test-Path -LiteralPath (Join-Path $Candidato "app.py"))) {
                $CandidatosAccesos += $Candidato
            }
        }
    } catch {
        # Con accesos directos ilegibles se usan solo las rutas conocidas.
    }
    $Candidatos = @($CandidatosAccesos) + @(
        (Join-Path $env:LOCALAPPDATA "SIMFI"),
        (Join-Path $env:ProgramFiles "SIMFI"),
        (Join-Path ${env:ProgramFiles(x86)} "SIMFI"),
        (Join-Path $env:SystemDrive "SISTEMAS_PIFL\SISTEMA_MANEJO_FORESTAL_PIFL"),
        (Join-Path $env:SystemDrive "SISTEMAS_PIFL\SIMFI")
    )
    foreach ($Candidato in $Candidatos) {
        if ($Candidato -and (Test-Path -LiteralPath (Join-Path $Candidato "app.py"))) {
            return $Candidato
        }
    }
    throw "No se encontro una instalacion de SIMFI. Aplique primero el paquete base."
}

function Get-VersionInstalada {
    param([string]$Instalacion)
    $RutaVersion = Join-Path $Instalacion "version.json"
    if (-not (Test-Path -LiteralPath $RutaVersion)) {
        return "1.0.0"
    }
    try {
        return (Get-Content -LiteralPath $RutaVersion -Raw | ConvertFrom-Json).version
    } catch {
        throw "El archivo version.json instalado no es valido. No se consulto nada."
    }
}

function Get-LineaVersionInstalada {
    param([string]$Instalacion)
    $RutaVersion = Join-Path $Instalacion "version.json"
    if (-not (Test-Path -LiteralPath $RutaVersion)) {
        return 1
    }
    try {
        $Datos = Get-Content -LiteralPath $RutaVersion -Raw | ConvertFrom-Json
        $Propiedad = $Datos.PSObject.Properties["linea_version"]
        $Valor = 0
        if ($Propiedad -and [int]::TryParse([string]$Propiedad.Value, [ref]$Valor) -and $Valor -ge 1) {
            return $Valor
        }
        return 1
    } catch {
        throw "El archivo version.json instalado no es valido. No se consulto nada."
    }
}

function Test-Hex64 {
    param([string]$Texto)
    return ($Texto -match '^[0-9a-f]{64}$')
}

try {
    # ------------------------------------------------------------------
    # 1. Instalacion existente y version instalada (solo lectura).
    # ------------------------------------------------------------------
    $Instalacion = Get-InstalacionSimfi $Destination
    $VersionInstalada = Get-VersionInstalada $Instalacion
    $LineaInstalada = Get-LineaVersionInstalada $Instalacion
    Write-Host "SIMFI instalado: $Instalacion (version $VersionInstalada, linea $LineaInstalada)."

    # ------------------------------------------------------------------
    # 2. Catalogo de actualizaciones.
    # ------------------------------------------------------------------
    $Url = $UrlCatalogo
    if (-not $Url) { $Url = $env:SIMFI_URL_ACTUALIZACIONES }
    if (-not $Url) { $Url = $UrlDefecto }
    Set-Tls12
    try {
        $RespuestaCatalogo = Invoke-WebRequest -Uri $Url -Headers (Get-Encabezados) -UseBasicParsing -TimeoutSec 45
    } catch {
        Write-Host "SIMFI: no se pudo consultar el catalogo de actualizaciones en linea ($($_.Exception.Message))." -ForegroundColor Yellow
        Write-Host "No se descargo ni instalo nada. Puede usar el canal manual (ACTUALIZAR.bat)." -ForegroundColor Yellow
        exit 0
    }
    if ($RespuestaCatalogo.StatusCode -ne 200) {
        throw "El catalogo respondio con codigo $($RespuestaCatalogo.StatusCode); no se continua."
    }
    # El contenido puede llegar como texto (application/json) o como
    # byte[] (octet-stream); se normaliza a texto antes de parsearlo.
    $ContenidoCatalogo = $RespuestaCatalogo.Content
    if ($ContenidoCatalogo -is [byte[]] -or $ContenidoCatalogo -is [byte[,]]) {
        $ContenidoCatalogo = [Text.Encoding]::UTF8.GetString($ContenidoCatalogo)
    }
    try {
        $Catalogo = $ContenidoCatalogo | ConvertFrom-Json
    } catch {
        throw "El catalogo de actualizaciones no es JSON valido."
    }
    if ([string]$Catalogo.sistema -ne "SIMFI") {
        throw "El catalogo no corresponde al sistema SIMFI."
    }
    $VersionCatalogo = $null
    if (-not [version]::TryParse([string]$Catalogo.version, [ref]$VersionCatalogo)) {
        throw "El catalogo no contiene una version valida."
    }
    $LineaCatalogo = 0
    if (-not [int]::TryParse([string]$Catalogo.linea_version, [ref]$LineaCatalogo) -or $LineaCatalogo -lt 1) {
        throw "El catalogo no contiene una linea de version valida."
    }
    $ShaCatalogo = ([string]$Catalogo.sha256).ToLowerInvariant()
    if (-not (Test-Hex64 $ShaCatalogo)) {
        throw "El catalogo no contiene un SHA-256 valido del paquete."
    }
    $UrlArtefacto = [string]$Catalogo.url
    try {
        $EsquemaArtefacto = ([System.Uri]$UrlArtefacto).Scheme
    } catch {
        $EsquemaArtefacto = ""
    }
    if ($EsquemaArtefacto -eq "https") {
        # El canal normal (repositorio publico, carpeta de red, etc.).
    } elseif ($EsPrueba -and ($EsquemaArtefacto -eq "http")) {
        # Solo pruebas automatizadas contra servidor local.
    } else {
        throw "La URL del paquete en el catalogo no es segura (solo HTTPS)."
    }
    $NombreEsperado = "SIMFI_Actualizacion_{0}.zip" -f $Catalogo.version
    try {
        $EncabezadosUrl = @([Uri]$UrlArtefacto).Segments
        $NombreUrl = [string]$EncabezadosUrl[-1]
    } catch {
        $NombreUrl = ""
    }
    if ($NombreUrl -and $NombreUrl -ne $NombreEsperado) {
        throw "El artefacto declarado no coincide con la version del catalogo."
    }

    # ------------------------------------------------------------------
    # 3. Comparar versiones. Sin novedad = no se descarga nada.
    # ------------------------------------------------------------------
    $HayNovedad = (($LineaCatalogo -gt $LineaInstalada) -or
                   ($LineaCatalogo -eq $LineaInstalada -and $VersionCatalogo -gt [version]$VersionInstalada))
    if (-not $HayNovedad) {
        Write-Host "SIMFI $VersionInstalada esta actualizado. No hay novedades por ahora." -ForegroundColor Green
        exit 0
    }

    # ------------------------------------------------------------------
    # 4. Aviso al usuario: Aceptar o Cancelar. La instalacion es
    #    SIEMPRE optativa: rechazar detiene todo sin descargar nada.
    # ------------------------------------------------------------------
    if ($EsPrueba) {
        $Acepta = ($env:SIMFI_UPDATE_TEST_ACEPTAR -eq "1")
        if (-not $Acepta) {
            Write-Host "Actualizacion disponible ($([string]$Catalogo.version)) y cancelada (modo de pruebas sin aceptacion)."
            exit 0
        }
    } else {
        $Mensaje = ("SIMFI: hay una nueva version disponible ({0}).`n`n" +
                    "Se descargara y verifique con la firma Ed25519 de SIMFI.`n" +
                    "Sus datos y proyectos NO se modifican (respaldo automatico incluido).`n`n" +
                    "Desea actualizar ahora?") -f [string]$Catalogo.version
        $Respuesta = (New-Object -ComObject WScript.Shell).Popup(
            $Mensaje, 0, "SIMFI - Actualizacion disponible", 4 + 48)
        if ($Respuesta -ne 6) {
            Write-Host "Cancelado por el usuario. No se descargaron ni aplicaron cambios."
            exit 0
        }
    }

    # ------------------------------------------------------------------
    # 5. Descarga del transporte y verificacion de SHA-256 contra el
    #    catalogo (primera barrera; la segunda es Ed25519 del verificador).
    # ------------------------------------------------------------------
    New-Item -ItemType Directory -Path $TempRoot -Force | Out-Null
    $ZipTransporte = Join-Path $TempRoot $NombreEsperado
    Write-Host "Descargando SIMFI $([string]$Catalogo.version)..."
    try {
        Invoke-WebRequest -Uri $UrlArtefacto -Headers (Get-Encabezados) -OutFile $ZipTransporte -UseBasicParsing -TimeoutSec 900
    } catch {
        throw "No se pudo descargar el paquete: $($_.Exception.Message)"
    }
    $ZipHash = (Get-FileHash -LiteralPath $ZipTransporte -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($ZipHash -ne $ShaCatalogo) {
        throw "El paquete descargado no coincide con el SHA-256 publicado; se descarta."
    }

    # ------------------------------------------------------------------
    # 6. Desempaquetar el transporte y aplicar con el ACTUALIZADOR LOCAL
    #    CONFIABLE. El script que se ejecuta NO es el del paquete; es la
    #    copia dentro de la instalacion (cadena confiable), que realiza
    #    la verificacion Ed25519, el respaldo y la proteccion de datos
    #    como en el canal manual.
    # ------------------------------------------------------------------
    $DirPaquete = Join-Path $TempRoot "paquete"
    Expand-Archive -LiteralPath $ZipTransporte -DestinationPath $DirPaquete -Force
    $ActualizarLocal = Join-Path $Instalacion "actualizar_simfi.ps1"
    if (-not (Test-Path -LiteralPath $ActualizarLocal -PathType Leaf)) {
        $ActualizarLocal = Join-Path $PSScriptRoot "actualizar_simfi.ps1"
    }
    if (-not (Test-Path -LiteralPath $ActualizarLocal -PathType Leaf)) {
        throw "No se encontro el actualizador local de SIMFI; no se aplica nada."
    }
    Write-Host "Verificando la firma del paquete e instalando..."
    $ArgumentosHijo = @(
        "-NoProfile", "-ExecutionPolicy", "Bypass",
        "-File", $ActualizarLocal,
        "-Destination", $Instalacion,
        "-PackageRoot", $DirPaquete
    )
    if ($EsPrueba) { $ArgumentosHijo += "-NoLaunch" }
    & powershell.exe @ArgumentosHijo
    $EstadoHijo = $LASTEXITCODE
    if ($EstadoHijo -ne 0) {
        throw "La instalacion informo un problema y no completo la actualizacion (quedan sus respaldos intactos)."
    }
    Write-Host "Consulta y actualizacion terminadas con exito." -ForegroundColor Green
    exit 0
} catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "No se aplico ninguna actualizacion. Los datos y la instalacion no cambiaron." -ForegroundColor Yellow
    exit 1
} finally {
    if (Test-Path -LiteralPath $TempRoot) {
        Remove-Item -LiteralPath $TempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
