import json
import math
import os


RUTA_CATALOGO = os.path.join(os.path.dirname(__file__), "catalogo_turnos.json")
EDAD_MINIMA = 1.0
EDAD_MAXIMA_ORDINARIA = 150.0
EDAD_MAXIMA_EXTENDIDA = 200.0
TOLERANCIA_EDAD = 0.001
TOLERANCIA_DIAMETRO = 0.01


class ErrorTurno(ValueError):
    def __init__(self, mensaje, codigo="validacion", detalles=None):
        super().__init__(mensaje)
        self.codigo = codigo
        self.detalles = detalles or {}


def cargar_catalogo_turnos(ruta=RUTA_CATALOGO):
    with open(ruta, "r", encoding="utf-8") as archivo:
        return json.load(archivo)


def obtener_modelo_turno(especie, calidad, catalogo=None):
    catalogo = catalogo or cargar_catalogo_turnos()
    datos_especie = catalogo.get("especies", {}).get(especie)
    if not datos_especie:
        raise ErrorTurno("Seleccione una especie válida para calcular el turno técnico.")
    modelo = datos_especie.get("calidades", {}).get(calidad)
    if not modelo:
        raise ErrorTurno("Seleccione una calidad de estación válida.")
    return datos_especie, modelo, catalogo


def _convertir_positivo(valor, nombre):
    if valor in (None, ""):
        raise ErrorTurno(f"{nombre} es obligatorio.")
    try:
        numero = float(valor)
    except (TypeError, ValueError) as exc:
        raise ErrorTurno(f"{nombre} debe ser numérico.") from exc
    if not math.isfinite(numero) or numero <= 0:
        raise ErrorTurno(f"{nombre} debe ser finito y mayor que cero.")
    return numero


def _evaluar_modelo(modelo, edad):
    parametros = modelo.get("parametros", modelo.get("coefficients"))
    tipo = modelo.get("tipo_ecuacion", modelo.get("diameterFunction"))
    if not parametros or not tipo:
        raise ErrorTurno("El registro del modelo no contiene función o coeficientes.", "catalogo")
    if tipo == "exponencial":
        diametro = parametros["a"] * math.exp(-parametros["b"] / edad)
    elif tipo == "orantes":
        edad_cuadrada = edad ** 2
        diametro = edad_cuadrada / (parametros["a"] + parametros["b"] * edad_cuadrada)
    elif tipo == "schumacher":
        diametro = math.exp(parametros["a"] - parametros["b"] * (1.0 / edad) ** parametros["p"])
    elif tipo == "geometrico_modificado":
        diametro = parametros["a"] * edad ** (-parametros["b"] / edad)
    else:
        raise ErrorTurno("El catálogo contiene un tipo de ecuación no compatible.", "catalogo")
    if not math.isfinite(diametro) or diametro < 0:
        raise ErrorTurno("La ecuación produjo un diámetro no válido.", "calculo")
    return diametro


def evaluar_diametro(especie, calidad, edad, catalogo=None):
    edad = _convertir_positivo(edad, "La edad")
    _, modelo, _ = obtener_modelo_turno(especie, calidad, catalogo)
    return _evaluar_modelo(modelo, edad)


def rango_diametros(especie, calidad, edad_maxima=EDAD_MAXIMA_ORDINARIA, catalogo=None):
    _, modelo, catalogo = obtener_modelo_turno(especie, calidad, catalogo)
    inicio = max(EDAD_MINIMA, float(modelo.get("edad_inicio_tecnica", EDAD_MINIMA)))
    edades = [inicio + (edad_maxima - inicio) * indice / 1000.0 for indice in range(1001)]
    diametros = [evaluar_diametro(especie, calidad, edad, catalogo) for edad in edades]
    return {"edad_minima": inicio, "edad_maxima": edad_maxima,
            "diametro_minimo": min(diametros), "diametro_maximo": max(diametros)}


def _intervalos_raiz(especie, calidad, objetivo, edad_maxima, catalogo):
    _, modelo, _ = obtener_modelo_turno(especie, calidad, catalogo)
    inicio = max(EDAD_MINIMA, float(modelo.get("edad_inicio_tecnica", EDAD_MINIMA)))
    paso = 0.25
    intervalos = []
    izquierda = inicio
    f_izquierda = evaluar_diametro(especie, calidad, izquierda, catalogo) - objetivo
    while izquierda < edad_maxima:
        derecha = min(edad_maxima, izquierda + paso)
        f_derecha = evaluar_diametro(especie, calidad, derecha, catalogo) - objetivo
        if abs(f_izquierda) <= 1e-12:
            intervalos.append((izquierda, izquierda))
        elif f_izquierda * f_derecha < 0 or abs(f_derecha) <= 1e-12:
            intervalos.append((izquierda, derecha))
        izquierda, f_izquierda = derecha, f_derecha
    return intervalos


def _biseccion(especie, calidad, objetivo, intervalo, catalogo):
    izquierda, derecha = intervalo
    if izquierda == derecha:
        return izquierda
    f_izquierda = evaluar_diametro(especie, calidad, izquierda, catalogo) - objetivo
    for _ in range(100):
        centro = (izquierda + derecha) / 2.0
        f_centro = evaluar_diametro(especie, calidad, centro, catalogo) - objetivo
        if abs(f_centro) <= TOLERANCIA_DIAMETRO / 10.0 and derecha - izquierda <= TOLERANCIA_EDAD:
            return centro
        if f_izquierda * f_centro <= 0:
            derecha = centro
        else:
            izquierda = centro
            f_izquierda = f_centro
    return (izquierda + derecha) / 2.0


def calcular_turno_tecnico(especie, calidad_estacion, diametro_objetivo,
                           ampliar_hasta_200=False, catalogo=None):
    diametro_objetivo = _convertir_positivo(diametro_objetivo, "El diámetro objetivo")
    datos_especie, modelo, catalogo = obtener_modelo_turno(
        especie, calidad_estacion, catalogo)
    rango_ordinario = rango_diametros(
        especie, calidad_estacion, EDAD_MAXIMA_ORDINARIA, catalogo)
    intervalos = _intervalos_raiz(
        especie, calidad_estacion, diametro_objetivo, EDAD_MAXIMA_ORDINARIA, catalogo)
    extrapolacion = False
    edad_maxima = EDAD_MAXIMA_ORDINARIA
    if not intervalos:
        rango_extendido = rango_diametros(
            especie, calidad_estacion, EDAD_MAXIMA_EXTENDIDA, catalogo)
        intervalos_extendidos = _intervalos_raiz(
            especie, calidad_estacion, diametro_objetivo, EDAD_MAXIMA_EXTENDIDA, catalogo)
        intervalos_extendidos = [intervalo for intervalo in intervalos_extendidos
                                 if intervalo[1] >= EDAD_MAXIMA_ORDINARIA]
        if intervalos_extendidos and not ampliar_hasta_200:
            raise ErrorTurno(
                "El diámetro objetivo requiere una edad superior a 150 años. Puede ampliar explícitamente el intervalo hasta 200 años.",
                "requiere_extension",
                {"rango_ordinario": rango_ordinario, "rango_extendido": rango_extendido},
            )
        if not intervalos_extendidos:
            raise ErrorTurno(
                "El diámetro objetivo no es alcanzable por el modelo en la rama de crecimiento válida entre 1 y 200 años.",
                "fuera_rango",
                {"rango_ordinario": rango_ordinario, "rango_extendido": rango_extendido},
            )
        intervalos = intervalos_extendidos
        extrapolacion = True
        edad_maxima = EDAD_MAXIMA_EXTENDIDA

    edad = _biseccion(
        especie, calidad_estacion, diametro_objetivo, intervalos[-1], catalogo)
    diametro_verificacion = evaluar_diametro(
        especie, calidad_estacion, edad, catalogo)
    convergencia = (math.isfinite(edad) and edad > 0 and
                    abs(diametro_verificacion - diametro_objetivo) <= TOLERANCIA_DIAMETRO)
    if not convergencia:
        raise ErrorTurno("El solucionador no alcanzó la tolerancia de verificación requerida.", "convergencia")
    advertencias = []
    for regla in modelo.get("documentWarnings", []):
        if isinstance(regla, str):
            advertencias.append(regla)
            continue
        objetivo_regla = regla.get("targetDiameter")
        if (regla.get("always") or objetivo_regla is None or
                math.isclose(diametro_objetivo, float(objetivo_regla), abs_tol=0.01)):
            advertencias.append(regla.get("text", ""))
    if modelo.get("advertencia_documental"):
        advertencias.append(modelo["advertencia_documental"])
    edad_tabla_min = modelo.get("tabulatedAgeMin")
    edad_tabla_max = modelo.get("tabulatedAgeMax")
    fuera_tabla = ((edad_tabla_min is not None and edad < float(edad_tabla_min)) or
                   (edad_tabla_max is not None and edad > float(edad_tabla_max)))
    if fuera_tabla:
        limite = []
        if edad_tabla_min is not None:
            limite.append(f"mínimo {float(edad_tabla_min):g} años")
        if edad_tabla_max is not None:
            limite.append(f"máximo {float(edad_tabla_max):g} años")
        advertencias.append(
            "La edad calculada se encuentra fuera del intervalo tabulado disponible en el estudio "
            f"({', '.join(limite)}). La curva corresponde a una extrapolación de la ecuación seleccionada.")
    if extrapolacion:
        advertencias.append(
            "La solución requiere ampliar el intervalo ordinario de 150 años. El resultado entre 150 y 200 años es una extrapolación explícita del modelo.")
    if fuera_tabla:
        condicion_tabular = "Extrapolación respecto al intervalo tabulado"
    elif edad_tabla_min is not None or edad_tabla_max is not None:
        condicion_tabular = "Dentro del intervalo tabulado disponible"
    else:
        condicion_tabular = "Intervalo tabulado no registrado"
    return {
        "especie": especie,
        "species_id": datos_especie.get("speciesId", especie.lower().replace(" ", "_")),
        "nombre_cientifico": datos_especie.get("scientificName", datos_especie["nombre_cientifico"]),
        "calidad_estacion": calidad_estacion,
        "diametro_objetivo": diametro_objetivo,
        "edad_calculada": edad,
        "edad_redondeada": int(math.floor(edad + 0.5)),
        "diametro_verificacion": diametro_verificacion,
        "convergencia": convergencia,
        "modelo": modelo.get("modelName", modelo.get("modelo")),
        "modelo_clave": modelo.get("modelId", modelo.get("clave")),
        "modelo_version": modelo.get("modelVersion", modelo.get("version")),
        "tipo_ecuacion": modelo.get("diameterFunction", modelo.get("tipo_ecuacion")),
        "parametros_modelo": dict(modelo.get("coefficients", modelo.get("parametros", {}))),
        "edad_inicio_tecnica": modelo.get("edad_inicio_tecnica", EDAD_MINIMA),
        "catalogo_version": catalogo["catalogo_version"],
        "ecuacion": modelo.get("equationDisplay", modelo.get("ecuacion")),
        "fuente": modelo.get("source", catalogo["fuente"]),
        "paginas_fuente": modelo.get("sourcePages"),
        "turno_referencia_publicado": modelo.get("publishedReferenceTurn"),
        "diametro_referencia_publicado": modelo.get("publishedTargetDiameter"),
        "edad_tabla_min": edad_tabla_min,
        "edad_tabla_max": edad_tabla_max,
        "condicion_tabular": condicion_tabular,
        "extrapolacion": extrapolacion or fuera_tabla,
        "extension_200": extrapolacion,
        "advertencias": advertencias,
        "rango_ordinario": rango_ordinario,
        "edad_maxima_calculo": edad_maxima,
    }


def generar_datos_grafica_turno(calculo, catalogo=None):
    if calculo.get("tipo_ecuacion") and calculo.get("parametros_modelo"):
        modelo = {"tipo_ecuacion": calculo["tipo_ecuacion"],
                  "parametros": calculo["parametros_modelo"]}
        inicio = max(EDAD_MINIMA, float(calculo.get("edad_inicio_tecnica", EDAD_MINIMA)))
    else:
        catalogo = catalogo or cargar_catalogo_turnos()
        _, modelo, _ = obtener_modelo_turno(
            calculo["especie"], calculo["calidad_estacion"], catalogo)
        inicio = max(EDAD_MINIMA, float(modelo.get("edad_inicio_tecnica", EDAD_MINIMA)))
    # El tramo posterior permite apreciar la curva sin extender la gráfica innecesariamente.
    edad_final = min(float(calculo.get("edad_maxima_calculo", 150.0)),
                     float(calculo["edad_calculada"]) + 20.0)
    edad_final = max(inicio, edad_final)
    puntos = []
    cantidad = max(120, int((edad_final - inicio) * 2))
    for indice in range(cantidad + 1):
        edad = inicio + (edad_final - inicio) * indice / cantidad
        puntos.append({"x": edad, "y": _evaluar_modelo(modelo, edad)})
    return {"puntos": puntos,
            "punto_turno": {"x": calculo["edad_calculada"], "y": calculo["diametro_objetivo"]},
            "edad_maxima": edad_final,
            "diametro_maximo": max(punto["y"] for punto in puntos)}
