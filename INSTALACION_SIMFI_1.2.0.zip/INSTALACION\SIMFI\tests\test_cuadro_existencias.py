import json
import re
import unittest
from io import BytesIO
from unittest.mock import patch

from app import app
from openpyxl import load_workbook
from modelos import (ArbolCenso, ClaseDiametrica, EcuacionVolumen, PMFProyecto,
                     Rodal, TablaInventarioRodal, _orden_especies,
                     _orden_especie_volumen)


class SubtotalesCuadroExistenciasTest(unittest.TestCase):
    def setUp(self):
        self.pmf = PMFProyecto("Subtotales")
        self.pmf.agregar_rodal(Rodal("R1", 10, sitios=1, area_sitio_m2=10000))
        self.pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Pinus patula", [ClaseDiametrica(20, 15, 10)]))
        self.pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Pinus montezumae", [ClaseDiametrica(30, 20, 5)]))

    def test_subtotal_suma_existencias_por_hectarea_y_totales(self):
        datos = self.pmf.cuadro_existencias()
        especies = [fila for fila in datos["filas"] if fila.get("_type") != "subtotal"]
        subtotal = next(fila for fila in datos["filas"] if fila.get("_type") == "subtotal")
        self.assertAlmostEqual(subtotal["vol_ha"], sum(fila["vol_ha"] for fila in especies), delta=1e-12)
        self.assertAlmostEqual(subtotal["vol_umm"], sum(fila["vol_umm"] for fila in especies), delta=1e-12)
        self.assertAlmostEqual(subtotal["vol_umm"], subtotal["vol_ha"] * 10, delta=1e-12)

    def test_especies_se_ordenan_por_grupo_taxonomico(self):
        especies = ["Quercus rugosa", "Alnus arguta", "Cupressus lindleyi",
                    "Pinus patula", "Abies religiosa", "Pinus teocote"]
        self.assertEqual(sorted(especies, key=_orden_especies), [
            "Abies religiosa", "Cupressus lindleyi", "Pinus patula",
            "Pinus teocote", "Quercus rugosa", "Alnus arguta",
        ])

    def test_especies_se_ordenan_por_volumen_ha_dentro_del_grupo(self):
        especies = [("Pinus patula", 12.0), ("Abies religiosa", 8.0),
                    ("Pinus teocote", 25.0), ("Quercus rugosa", 30.0),
                    ("Cupressus lindleyi", 4.0)]
        ordenadas = sorted(especies, key=lambda item: _orden_especie_volumen(*item))
        self.assertEqual([especie for especie, _ in ordenadas], [
            "Pinus teocote", "Pinus patula", "Abies religiosa",
            "Cupressus lindleyi", "Quercus rugosa",
        ])

    def test_una_umm_con_una_especie_aun_genera_subtotal(self):
        self.pmf.tablas_inventario = self.pmf.tablas_inventario[:1]
        datos = self.pmf.cuadro_existencias()
        subtotales = [fila for fila in datos["filas"] if fila.get("_type") == "subtotal"]
        self.assertEqual(len(subtotales), 1)
        self.assertEqual(subtotales[0]["rodal"], "R1")
        self.assertEqual(datos["num_rodales"], 1)

    def test_pagina_muestra_ambos_subtotales_en_sus_columnas(self):
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = self.pmf.serializar()
        respuesta = cliente.get("/reportes/cuadro_existencias")
        html = respuesta.get_data(as_text=True)
        inicio = html.index("R1 &mdash; Subtotal")
        fila_html = html[inicio:html.index("</tr>", inicio)]
        self.assertIn('colspan="3"', html[inicio - 80:inicio])
        valores = [float(valor) for valor in re.findall(r"<strong>([0-9]+\.[0-9]{3})</strong>", fila_html)]
        self.assertGreaterEqual(len(valores), 2)
        self.assertGreater(valores[0], 0)
        self.assertAlmostEqual(valores[1], valores[0] * 10, delta=0.01)
        self.assertIn('draggable="true"', html)
        self.assertIn("iniciarArrastreRodal", html)
        self.assertIn("Exportar resumen", html)
        self.assertNotIn("Exportar Word", html)
        self.assertNotIn("Exportar PDF", html)

    def test_exportacion_unificada_entrega_excel_word_y_pdf(self):
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = self.pmf.serializar()

        excel = cliente.get("/reportes/existencias/exportar/excel")
        self.assertEqual(excel.status_code, 200)
        libro = load_workbook(BytesIO(excel.data))
        self.assertEqual(libro.sheetnames, ["Cuadro Existencias", "Resumen Existencias"])
        hoja = libro["Cuadro Existencias"]
        self.assertEqual(hoja["A1"].value, "Unidad Minima de Manejo (UMM)")
        self.assertEqual(hoja["C1"].value, "Especie")
        self.assertEqual(hoja["D1"].value, "Existencias Reales")
        self.assertEqual(hoja["G1"].value, "Intensidad de Corta (%) Por UMM")
        self.assertEqual(hoja["I1"].value, "Posibilidad")
        self.assertEqual(hoja["D2"].value, "m³ VTA por Ha")
        self.assertEqual(hoja["A1"].font.color.rgb[-6:], "000000")
        self.assertEqual(hoja["A5"].fill.fgColor.rgb[-6:], "D9D9D9")
        self.assertEqual(hoja["D3"].number_format, "#,##0.000")
        self.assertEqual(hoja["G3"].number_format, "#,##0.00")
        resumen_hoja = libro["Resumen Existencias"]
        self.assertEqual(resumen_hoja["A1"].fill.fgColor.rgb[-6:], "D9D9D9")
        self.assertEqual(resumen_hoja["A2"].font.color.rgb[-6:], "000000")
        fila_total = resumen_hoja.max_row
        self.assertEqual(resumen_hoja.cell(fila_total, 1).fill.fgColor.rgb[-6:], "D9D9D9")
        self.assertEqual(resumen_hoja.cell(fila_total, 1).font.color.rgb[-6:], "000000")
        rangos = {str(rango) for rango in libro["Cuadro Existencias"].merged_cells.ranges}
        self.assertIn("A3:A4", rangos)
        self.assertIn("B3:B4", rangos)
        self.assertIn("A1:B1", rangos)
        self.assertIn("C1:C2", rangos)
        self.assertIn("D1:F1", rangos)

        word = cliente.get("/reportes/existencias/exportar/word")
        self.assertEqual(word.status_code, 200)
        self.assertTrue(word.data.startswith(b"PK"))
        pdf = cliente.get("/reportes/existencias/exportar/pdf")
        self.assertEqual(pdf.status_code, 200)
        self.assertTrue(pdf.data.startswith(b"%PDF"))

    def test_exportacion_word_carbono_y_oxigeno_con_subtotales(self):
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = self.pmf.serializar()
        for tab in ("contenido", "captura", "oxigeno"):
            respuesta = cliente.get(f"/reportes/carbono/exportar/word?tab={tab}")
            self.assertEqual(respuesta.status_code, 200, tab)
            self.assertTrue(respuesta.data.startswith(b"PK"), tab)

    def test_total_general_usa_promedios_simples_por_hectarea(self):
        pmf = PMFProyecto("TotalesPromedio")
        pmf.agregar_rodal(Rodal("A", 10, sitios=1, area_sitio_m2=10000))
        pmf.agregar_rodal(Rodal("B", 4, sitios=1, area_sitio_m2=10000))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "A", "Pinus patula", [ClaseDiametrica(20, 15, 10)]))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "B", "Pinus montezumae", [ClaseDiametrica(30, 20, 5)]))
        pmf.intensidad_corta = {"A": {"Pinus patula": 10}, "B": {"Pinus montezumae": 20}}
        datos = pmf.cuadro_existencias()
        detalle = [f for f in datos["filas"] if not f.get("_type")]
        self.assertGreaterEqual(len(detalle), 2)
        self.assertAlmostEqual(datos["total_vol_ha"],
                               sum(f["vol_ha"] for f in detalle) / len(detalle))
        self.assertAlmostEqual(datos["total_ab"],
                               sum(f["ab"] for f in detalle) / len(detalle))
        self.assertAlmostEqual(datos["total_res_ab"],
                               sum(f["res_ab"] for f in detalle) / len(detalle))
        self.assertAlmostEqual(datos["total_pos_ha"],
                               sum(f["pos_ha"] for f in detalle) / len(detalle))
        self.assertAlmostEqual(datos["total_intensidad"], 15.0)
        self.assertAlmostEqual(datos["total_vol_umm"],
                               sum(f["vol_umm"] for f in detalle))
        self.assertAlmostEqual(datos["total_res_vol"],
                               sum(f["res_vol"] for f in detalle))
        self.assertAlmostEqual(datos["total_pos_umm"],
                               sum(f["pos_umm"] for f in detalle))

    def test_censo_total_usa_sus_celdas_aun_con_tabla_tradicional_vacia(self):
        pmf = PMFProyecto("Censo")
        pmf.agregar_rodal(Rodal("CENSO", 0.5, sitios=0, area_sitio_m2=0,
                                tipo_inventario="censo_total"))
        pmf.agregar_especie("Pinus patula")
        pmf.asignar_ecuacion("Pinus patula", EcuacionVolumen(
            a0=0.001, a1=2, a2=1, especie="Pinus patula"))
        pmf.agregar_tabla_inventario(TablaInventarioRodal("CENSO", "Pinus patula"))
        pmf.agregar_arbol_censo(ArbolCenso("CENSO", "Pinus patula", 40, 20, no_arboles=3))
        pmf.agregar_arbol_censo(ArbolCenso("CENSO", "Pinus patula", 40, 25, no_arboles=5))

        datos = pmf.cuadro_existencias()
        fila = next(fila for fila in datos["filas"] if fila.get("especie") == "Pinus patula")
        esperado = (pmf.volumen_arbol("Pinus patula", 40, 20) * 3 +
                    pmf.volumen_arbol("Pinus patula", 40, 25) * 5)

        self.assertAlmostEqual(fila["vol_umm"], esperado)
        self.assertAlmostEqual(fila["vol_ha"], esperado / 0.5)
        self.assertGreater(fila["ab"], 0)


class TotalesIncrementosTest(unittest.TestCase):
    def setUp(self):
        ecu = EcuacionVolumen(a0=0.001, a1=2, a2=1, especie="Pinus patula")
        self.pmf = PMFProyecto("Incrementos")
        self.pmf.agregar_especie("Pinus patula")
        self.pmf.asignar_ecuacion("Pinus patula", ecu)
        self.pmf.tp_ecuaciones["Pinus patula"] = {"a": 9.4322, "b": -0.9294, "c": 0.02695}
        self.pmf.agregar_rodal(Rodal("A", 10, sitios=0, area_sitio_m2=0,
                                     tipo_inventario="censo_total"))
        self.pmf.agregar_rodal(Rodal("B", 4, sitios=0, area_sitio_m2=0,
                                     tipo_inventario="censo_total"))
        self.pmf.agregar_arbol_censo(ArbolCenso("A", "Pinus patula", 40, 20, no_arboles=4))
        self.pmf.agregar_arbol_censo(ArbolCenso("B", "Pinus patula", 30, 15, no_arboles=2))

    def test_total_general_usa_promedios_simples_por_hectarea(self):
        datos = self.pmf.resumen_incrementos()
        detalle = [f for f in datos["filas"] if not f.get("_type")]
        self.assertEqual(len(detalle), 2)
        self.assertAlmostEqual(datos["total_superficie"], 14.0)
        self.assertAlmostEqual(datos["total_arb_ha"],
                               sum(f["arb_ha"] for f in detalle) / len(detalle))
        self.assertAlmostEqual(datos["total_ab"],
                               sum(f["ab"] for f in detalle) / len(detalle))
        icas = [f["ica"] for f in detalle if f.get("ica") is not None]
        self.assertAlmostEqual(datos["total_ica"], sum(icas) / len(icas))
        tps = [f["tp"] for f in detalle if f.get("tp") is not None]
        self.assertAlmostEqual(datos["total_tp"], sum(tps) / len(tps))
        icas_pct = [f["ica_pct"] for f in detalle if f.get("ica_pct") is not None]
        self.assertAlmostEqual(datos["total_ica_pct"], sum(icas_pct) / len(icas_pct))


class TotalesCarbonoTest(unittest.TestCase):
    def setUp(self):
        ecu = EcuacionVolumen(a0=0.001, a1=2, a2=1, especie="Pinus patula")
        self.pmf = PMFProyecto("Carbono")
        self.pmf.agregar_especie("Pinus patula")
        self.pmf.asignar_ecuacion("Pinus patula", ecu)
        self.pmf.tp_ecuaciones["Pinus patula"] = {"a": 9.4322, "b": -0.9294, "c": 0.02695}
        self.pmf.agregar_rodal(Rodal("A", 10, sitios=0, area_sitio_m2=0,
                                     tipo_inventario="censo_total"))
        self.pmf.agregar_rodal(Rodal("B", 4, sitios=0, area_sitio_m2=0,
                                     tipo_inventario="censo_total"))
        self.pmf.agregar_arbol_censo(ArbolCenso("A", "Pinus patula", 40, 20, no_arboles=4))
        self.pmf.agregar_arbol_censo(ArbolCenso("B", "Pinus patula", 30, 15, no_arboles=2))

    def test_total_general_usa_promedios_simples_por_hectarea(self):
        datos = self.pmf.reporte_carbono()
        detalle = [f for f in datos["filas"] if not f.get("_type")]
        self.assertEqual(len(detalle), 2)
        self.assertAlmostEqual(datos["prom_vol_ha"],
                               sum(f["vol_ha"] for f in detalle) / len(detalle))
        self.assertAlmostEqual(datos["prom_ms_ha"],
                               sum(f["ms_ha"] for f in detalle) / len(detalle))
        self.assertAlmostEqual(datos["prom_carbono_ha"],
                               sum(f["carbono_ha"] for f in detalle) / len(detalle))
        self.assertAlmostEqual(datos["prom_co2_ha"],
                               sum(f["co2_ha"] for f in detalle) / len(detalle))
        self.assertAlmostEqual(datos["total_ms"],
                               sum(f["ms_total"] for f in detalle))
        self.assertAlmostEqual(datos["total_carbono"],
                               sum(f["carbono_total"] for f in detalle))
        self.assertAlmostEqual(datos["total_co2"],
                               sum(f["co2_total"] for f in detalle))
        self.assertAlmostEqual(datos["total_vol"],
                               sum(f["ms_total"] for f in detalle) / 0.5)

    def test_paginas_captura_y_oxigeno_usan_promedios_simples(self):
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = self.pmf.serializar()

        r_captura = cliente.get("/calculo/captura_co2")
        html_captura = r_captura.get_data(as_text=True)
        self.assertEqual(r_captura.status_code, 200)
        self.assertIn("TOTAL GENERAL", html_captura)

        r_oxi = cliente.get("/calculo/produccion_oxigeno")
        html_oxi = r_oxi.get_data(as_text=True)
        self.assertEqual(r_oxi.status_code, 200)
        self.assertIn("TOTAL GENERAL", html_oxi)

    def test_orden_global_de_rodales_se_guarda_y_reordena_el_cuadro(self):
        pmf = PMFProyecto("Orden global")
        pmf.agregar_rodal(Rodal("A", 10))
        pmf.agregar_rodal(Rodal("B", 8))
        pmf.agregar_rodal(Rodal("C", 6))
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()

        respuesta = cliente.post(
            "/reportes/cuadro_existencias/ordenar_rodales",
            data={"orden_rodales": json.dumps(["C", "A", "B"])},
        )

        self.assertEqual(respuesta.status_code, 302)
        with cliente.session_transaction() as sesion:
            ruta = sesion["ruta_actual"]
        guardado = PMFProyecto.cargar(ruta)
        self.assertEqual([rodal.id for rodal in guardado.rodales], ["C", "A", "B"])


class LimpiarTablasInventarioTest(unittest.TestCase):
    def test_limpia_todas_las_tablas_de_inventario(self):
        pmf = PMFProyecto("Limpieza")
        pmf.agregar_rodal(Rodal("R1", 10))
        pmf.agregar_tabla_inventario(TablaInventarioRodal("R1", "Pinus patula"))
        pmf.agregar_tabla_inventario(TablaInventarioRodal("R1", "Pinus montezumae"))
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()

        respuesta = cliente.post("/inventario/rodal/limpiar_tablas", follow_redirects=True)

        self.assertEqual(respuesta.status_code, 200)
        with cliente.session_transaction() as sesion:
            ruta_guardada = sesion["ruta_actual"]
        self.assertEqual(PMFProyecto.cargar(ruta_guardada).tablas_inventario, [])


class DiametrosMenoresTest(unittest.TestCase):
    def _pmf(self, clases=None):
        pmf = PMFProyecto("Menores")
        pmf.agregar_rodal(Rodal("R1", 10, sitios=2, area_sitio_m2=500))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Pinus patula", list(clases) if clases else []))
        return pmf

    def _post(self, pmf, datos):
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=pmf), patch("app.save_pmf", return_value=True):
            return cliente.post("/inventario/rodal/guardar_clases/R1/Pinus%20patula", data=datos)

    def _clases(self, pmf):
        return pmf.buscar_tabla_inventario("R1", "Pinus patula").clases

    def test_guarda_diametro_menor_y_calcula_volumen(self):
        pmf = self._pmf()
        respuesta = self._post(pmf, {"menores_activo": "1", "men_dia": "3",
                                     "men_alt": "4.5", "men_arb": "10",
                                     "alt_10": "12", "arb_10": "5"})
        self.assertEqual(respuesta.status_code, 302)
        self.assertEqual(sorted(c.dncc for c in self._clases(pmf)), [3, 10])
        menor = next(c for c in self._clases(pmf) if c.dncc == 3)
        self.assertAlmostEqual(menor.altura_m, 4.5)
        self.assertEqual(menor.no_arboles, 10)
        self.assertGreater(pmf.buscar_tabla_inventario(
            "R1", "Pinus patula").volumen_unitario(menor, pmf), 0)

    def test_volumen_menor_se_agrega_a_totales(self):
        pmf_base = self._pmf([ClaseDiametrica(10, 12, 5)])
        pmf_men = self._pmf([ClaseDiametrica(10, 12, 5), ClaseDiametrica(3, 4.5, 10)])
        base = pmf_base.cuadro_existencias()
        con = pmf_men.cuadro_existencias()
        vol_base = sum(f["vol_ha"] for f in base["filas"] if f.get("_type") != "subtotal")
        vol_con = sum(f["vol_ha"] for f in con["filas"] if f.get("_type") != "subtotal")
        self.assertGreater(vol_con, vol_base)

    def test_rechaza_diametro_fuera_de_rango(self):
        for malo in ("0", "-2", "5", "5.0", "12", "abc"):
            pmf = self._pmf()
            respuesta = self._post(pmf, {"menores_activo": "1", "men_dia": malo,
                                         "men_alt": "4", "men_arb": "3"})
            self.assertEqual(respuesta.status_code, 302)
            self.assertEqual(self._clases(pmf), [])

    def test_nuevo_valor_sustituye_al_anterior(self):
        pmf = self._pmf()
        respuesta = self._post(pmf, {"menores_activo": "1", "men_dia": "3",
                                     "men_alt": "4.5", "men_arb": "10"})
        self.assertEqual(respuesta.status_code, 302)
        self.assertEqual(sorted(c.dncc for c in self._clases(pmf)), [3])
        respuesta = self._post(pmf, {"menores_activo": "1", "men_dia": "2",
                                     "men_alt": "3", "men_arb": "4"})
        self.assertEqual(respuesta.status_code, 302)
        self.assertEqual(sorted(c.dncc for c in self._clases(pmf)), [2])

    def test_campos_vacios_se_ignoran(self):
        pmf = self._pmf()
        respuesta = self._post(pmf, {"menores_activo": "1", "men_dia": "",
                                     "men_alt": "", "men_arb": ""})
        self.assertEqual(respuesta.status_code, 302)
        self.assertEqual(self._clases(pmf), [])

    def test_vaciar_campos_elimina_la_clase(self):
        pmf = self._pmf([ClaseDiametrica(10, 12, 5), ClaseDiametrica(3, 4.5, 10)])
        respuesta = self._post(pmf, {"menores_activo": "1", "men_dia": "",
                                     "men_alt": "", "men_arb": "",
                                     "alt_10": "12", "arb_10": "5"})
        self.assertEqual(respuesta.status_code, 302)
        self.assertEqual(sorted(c.dncc for c in self._clases(pmf)), [10])

    def test_sin_marcador_no_toca_clases_menores(self):
        pmf = self._pmf([ClaseDiametrica(2.5, 3.0, 4)])
        respuesta = self._post(pmf, {"alt_10": "12", "arb_10": "5"})
        self.assertEqual(respuesta.status_code, 302)
        self.assertIn(2.5, [c.dncc for c in self._clases(pmf)])

    def test_pagina_muestra_seccion_menores(self):
        pmf = self._pmf([ClaseDiametrica(2.5, 3.0, 4), ClaseDiametrica(10, 12, 5)])
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
        with patch("app.get_pmf", return_value=pmf), patch("app.save_pmf", return_value=True):
            respuesta = cliente.get("/inventario/rodal/editar/R1/Pinus%20patula")
        self.assertEqual(respuesta.status_code, 200)
        html = respuesta.get_data(as_text=True)
        self.assertIn("Diámetros menores de 5 cm", html)
        self.assertIn('name="men_dia"', html)
        self.assertIn('name="men_alt"', html)
        self.assertIn('name="men_arb"', html)
        self.assertNotIn("Agregar fila", html)
        self.assertNotIn('name="alt_2.5"', html)


class FusionSuperficieCarbonoTest(unittest.TestCase):
    def setUp(self):
        self.pmf = PMFProyecto("FusionSup")
        self.pmf.agregar_rodal(Rodal("R1", 10, sitios=1, area_sitio_m2=10000))
        self.pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Quercus rugosa", [ClaseDiametrica(20, 15, 10)]))
        self.pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Alnus arguta", [ClaseDiametrica(30, 20, 5)]))

    def _cliente(self):
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = self.pmf.serializar()
        return cliente

    def test_excel_entrega_tres_hojas_con_superficie_fusionada(self):
        cliente = self._cliente()
        respuesta = cliente.get("/reportes/carbono/exportar/excel?tab=captura")
        self.assertEqual(respuesta.status_code, 200)
        libro = load_workbook(BytesIO(respuesta.data))
        self.assertEqual(libro.sheetnames, ["Contenido", "Captura", "Oxigeno"])
        self.assertEqual(libro.active.title, "Captura")
        for nombre in ("Contenido", "Captura", "Oxigeno"):
            hoja = libro[nombre]
            encabezados = [celda.value for celda in hoja[2]]
            self.assertIn("Sup (ha)", encabezados, nombre)
            rangos = {str(rango) for rango in hoja.merged_cells.ranges}
            self.assertIn("A3:A4", rangos, nombre)
            self.assertIn("C3:C4", rangos, nombre)
            self.assertEqual(hoja["C3"].value, 10, nombre)

    def test_excel_desde_contenido_abre_contenido(self):
        cliente = self._cliente()
        respuesta = cliente.get("/reportes/carbono/exportar/excel?tab=contenido")
        self.assertEqual(respuesta.status_code, 200)
        libro = load_workbook(BytesIO(respuesta.data))
        self.assertEqual(libro.active.title, "Contenido")

    def test_word_contenido_fusiona_rodal_y_superficie(self):
        import zipfile
        from lxml import etree
        cliente = self._cliente()
        respuesta = cliente.get("/reportes/carbono/exportar/word?tab=contenido")
        self.assertEqual(respuesta.status_code, 200)
        with zipfile.ZipFile(BytesIO(respuesta.data)) as comprimido:
            xml = comprimido.read("word/document.xml")
        raiz = etree.fromstring(xml)
        ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
        cuadros = [tabla for tabla in raiz.xpath("//w:tbl", namespaces=ns)
                   if any("Sup (ha)" in (celda.xpath("string(.)") or "")
                          for celda in tabla.xpath("./w:tr[1]/w:tc", namespaces=ns))]
        self.assertEqual(len(cuadros), 1)
        filas = cuadros[0].xpath("./w:tr", namespaces=ns)

        def fusion(fila, columna):
            celda = fila.xpath("./w:tc", namespaces=ns)[columna]
            nodo = celda.xpath("./w:tcPr/w:vMerge", namespaces=ns)
            return nodo[0].get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val") if nodo else None

        self.assertEqual(len(filas), 4)
        self.assertEqual(fusion(filas[1], 0), "restart")
        self.assertEqual(fusion(filas[2], 0), "continue")
        self.assertEqual(fusion(filas[1], 2), "restart")
        self.assertEqual(fusion(filas[2], 2), "continue")

    def test_word_captura_y_oxigeno_sin_columna_superficie(self):
        from docx import Document
        cliente = self._cliente()
        for tab in ("captura", "oxigeno"):
            respuesta = cliente.get(f"/reportes/carbono/exportar/word?tab={tab}")
            self.assertEqual(respuesta.status_code, 200, tab)
            documento = Document(BytesIO(respuesta.data))
            cuadro = next(t for t in documento.tables if len(t.columns) > 2)
            encabezados = [celda.text for celda in cuadro.rows[0].cells]
            self.assertNotIn("Sup (ha)", encabezados, tab)

    def test_pdf_contenido_y_captura_ok(self):
        cliente = self._cliente()
        for tab in ("contenido", "captura", "oxigeno"):
            respuesta = cliente.get(f"/reportes/carbono/exportar/pdf?tab={tab}")
            self.assertEqual(respuesta.status_code, 200, tab)
            self.assertTrue(respuesta.data.startswith(b"%PDF"), tab)


    def test_cuadro_con_miles_en_pantalla_y_excel(self):
        pmf = PMFProyecto("Miles")
        pmf.agregar_rodal(Rodal("GDE", 1500, sitios=1, area_sitio_m2=10000))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "GDE", "Pinus patula", [ClaseDiametrica(20, 15, 10)]))
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()
        html = cliente.get("/reportes/cuadro_existencias").get_data(as_text=True)
        self.assertIn("1,500.000", html)
        respuesta = cliente.get("/reportes/cuadro_existencias/exportar/excel")
        self.assertEqual(respuesta.status_code, 200)
        libro = load_workbook(BytesIO(respuesta.data))
        hoja = libro["Cuadro Existencias"]
        formatos = {celda.number_format for fila in hoja.iter_rows(min_row=3)
                    for celda in fila if isinstance(celda.value, (int, float))}
        self.assertIn("#,##0.000", formatos)
        self.assertNotIn("0.000", formatos)
        hoja_resumen = libro["Resumen Existencias"]
        formatos_resumen = {celda.number_format for fila in hoja_resumen.iter_rows(min_row=3)
                            for celda in fila if isinstance(celda.value, (int, float))}
        self.assertIn("#,##0.000", formatos_resumen)


if __name__ == "__main__":
    unittest.main()
