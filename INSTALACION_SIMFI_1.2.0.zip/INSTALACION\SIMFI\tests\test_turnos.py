import math
import os
import unittest
import zipfile

from app import app
from modelos import PMFProyecto
from reporte_densidad import (decodificar_png, generar_reporte_turno,
                              nombre_archivo_turno)
from turnos import (ErrorTurno, calcular_turno_tecnico, cargar_catalogo_turnos,
                    evaluar_diametro, generar_datos_grafica_turno)


PNG_PRUEBA = (
    "data:image/png;base64,"
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M/wHwAF/gL+G2V0WQAAAABJRU5ErkJggg=="
)
BASE = os.path.dirname(os.path.dirname(__file__))
LOGO = os.path.join(BASE, "img", "SIMFI GDE.png")


class MotorTurnosTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.catalogo = cargar_catalogo_turnos()

    def test_catalogo_contiene_cuatro_especies_y_catorce_modelos(self):
        self.assertEqual(set(self.catalogo["especies"]), {
            "Pinus patula", "Pinus montezumae", "Pinus teocote", "Pinus rudis"})
        self.assertEqual(sum(len(e["calidades"]) for e in self.catalogo["especies"].values()), 14)
        self.assertEqual(set(self.catalogo["especies"]["Pinus teocote"]["calidades"]), {"I", "II", "III"})
        self.assertEqual(set(self.catalogo["especies"]["Pinus rudis"]["calidades"]), {"I", "II", "III"})

    def test_evaluacion_de_las_ocho_ecuaciones(self):
        casos = [
            ("Pinus patula", "I", 40, 40.17429939),
            ("Pinus patula", "II", 50, 40.37283918),
            ("Pinus patula", "III", 60, 39.25590092),
            ("Pinus patula", "IV", 90, 40.39585283),
            ("Pinus montezumae", "I", 60, 40.82623175),
            ("Pinus montezumae", "II", 70, 41.06081338),
            ("Pinus montezumae", "III", 70, 35.34446962),
            ("Pinus montezumae", "IV", 90, 34.93097221),
        ]
        for especie, calidad, edad, esperado in casos:
            with self.subTest(especie=especie, calidad=calidad):
                self.assertAlmostEqual(evaluar_diametro(especie, calidad, edad), esperado, delta=1e-7)

    def test_ocho_referencias_y_convergencia(self):
        casos = [
            ("Pinus patula", "I", 40, 39.6579, (38, 42)),
            ("Pinus patula", "II", 40, 49.2195, (48, 52)),
            ("Pinus patula", "III", 40, 62.3093, (60, 65)),
            ("Pinus patula", "IV", 40, 87.7931, (85, 92)),
            ("Pinus montezumae", "I", 40, 58.2025, (56, 62)),
            ("Pinus montezumae", "II", 40, 67.2299, (65, 70)),
            ("Pinus montezumae", "III", 35, 68.9284, (67, 72)),
            ("Pinus montezumae", "IV", 35, 90.2208, (88, 93)),
        ]
        for especie, calidad, diametro, edad_esperada, intervalo_publicado in casos:
            with self.subTest(especie=especie, calidad=calidad):
                resultado = calcular_turno_tecnico(especie, calidad, diametro)
                self.assertTrue(resultado["convergencia"])
                self.assertAlmostEqual(resultado["edad_calculada"], edad_esperada, delta=0.002)
                self.assertAlmostEqual(resultado["diametro_verificacion"], diametro, delta=0.01)
                self.assertGreaterEqual(resultado["edad_calculada"], intervalo_publicado[0])
                self.assertLessEqual(resultado["edad_calculada"], intervalo_publicado[1])

    def test_evaluacion_directa_de_las_seis_ecuaciones_nuevas(self):
        casos = [
            ("Pinus teocote", "I", 60, 33.95871172),
            ("Pinus teocote", "II", 75, 34.09245638),
            ("Pinus teocote", "III", 90, 34.42471802),
            ("Pinus rudis", "I", 60, 35.19650876),
            ("Pinus rudis", "II", 70, 35.11650402),
            ("Pinus rudis", "III", 90, 34.61776392),
        ]
        for especie, calidad, edad, esperado in casos:
            with self.subTest(especie=especie, calidad=calidad):
                self.assertAlmostEqual(
                    evaluar_diametro(especie, calidad, edad), esperado, delta=1e-7)

    def test_turnos_de_control_a_35_cm(self):
        casos = [
            ("Pinus teocote", "I", 62.352, 62),
            ("Pinus teocote", "II", 77.658, 78),
            ("Pinus teocote", "III", 92.357, 92),
            ("Pinus rudis", "I", 59.502, 60),
            ("Pinus rudis", "II", 69.580, 70),
            ("Pinus rudis", "III", 91.791, 92),
        ]
        for especie, calidad, edad_esperada, redondeo in casos:
            with self.subTest(especie=especie, calidad=calidad):
                resultado = calcular_turno_tecnico(especie, calidad, 35)
                self.assertAlmostEqual(resultado["edad_calculada"], edad_esperada, delta=0.002)
                self.assertEqual(resultado["edad_redondeada"], redondeo)
                self.assertAlmostEqual(resultado["diametro_verificacion"], 35, delta=0.01)

    def test_diametro_decimal(self):
        resultado = calcular_turno_tecnico("Pinus patula", "I", 37.65)
        self.assertAlmostEqual(resultado["diametro_verificacion"], 37.65, delta=0.01)
        self.assertIsInstance(resultado["edad_redondeada"], int)
        nuevo = calcular_turno_tecnico("Pinus rudis", "II", 33.75)
        self.assertAlmostEqual(nuevo["diametro_verificacion"], 33.75, delta=0.01)

    def test_valores_invalidos(self):
        for valor in (None, "", "no-numérico", 0, -3, float("inf"), float("nan")):
            with self.subTest(valor=valor), self.assertRaises(ErrorTurno):
                calcular_turno_tecnico("Pinus patula", "I", valor)
        with self.assertRaises(ErrorTurno):
            calcular_turno_tecnico("", "I", 40)
        with self.assertRaises(ErrorTurno):
            calcular_turno_tecnico("Pinus patula", "", 40)

    def test_fuera_de_rango_y_extension_explicita(self):
        with self.assertRaises(ErrorTurno) as contexto:
            calcular_turno_tecnico("Pinus patula", "I", 59)
        self.assertEqual(contexto.exception.codigo, "requiere_extension")
        extendido = calcular_turno_tecnico(
            "Pinus patula", "I", 59, ampliar_hasta_200=True)
        self.assertGreater(extendido["edad_calculada"], 150)
        self.assertLessEqual(extendido["edad_calculada"], 200)
        self.assertTrue(extendido["extrapolacion"])
        self.assertTrue(any("extrapolación" in aviso for aviso in extendido["advertencias"]))
        with self.assertRaises(ErrorTurno) as fuera:
            calcular_turno_tecnico("Pinus patula", "I", 100, ampliar_hasta_200=True)
        self.assertEqual(fuera.exception.codigo, "fuera_rango")

    def test_advertencia_documental_patula_iv(self):
        resultado = calcular_turno_tecnico("Pinus patula", "IV", 40)
        self.assertTrue(any("cuadro resumen 4.67" in aviso for aviso in resultado["advertencias"]))
        self.assertNotEqual(resultado["edad_redondeada"], 80)

    def test_especies_nuevas_no_aceptan_calidad_iv(self):
        for especie in ("Pinus teocote", "Pinus rudis"):
            with self.subTest(especie=especie), self.assertRaises(ErrorTurno):
                calcular_turno_tecnico(especie, "IV", 35)

    def test_advertencias_documentales_teocote(self):
        for calidad, texto in (("I", "63 años"), ("II", "70 años"), ("III", "93 años")):
            with self.subTest(calidad=calidad):
                resultado = calcular_turno_tecnico("Pinus teocote", calidad, 35)
                self.assertTrue(any(texto in aviso for aviso in resultado["advertencias"]))
        tercero = calcular_turno_tecnico("Pinus teocote", "III", 35)
        self.assertTrue(any("a partir de 105 años" in aviso for aviso in tercero["advertencias"]))
        self.assertTrue(any("probable error de transcripción" in aviso for aviso in tercero["advertencias"]))

    def test_extrapolacion_fuera_del_maximo_tabular(self):
        diametro_130 = evaluar_diametro("Pinus rudis", "I", 130)
        resultado = calcular_turno_tecnico("Pinus rudis", "I", diametro_130)
        self.assertAlmostEqual(resultado["edad_calculada"], 130, delta=0.002)
        self.assertTrue(resultado["extrapolacion"])
        self.assertEqual(resultado["condicion_tabular"], "Extrapolación respecto al intervalo tabulado")
        self.assertTrue(any("máximo 120 años" in aviso for aviso in resultado["advertencias"]))

    def test_diametro_fuera_de_rango_en_especie_nueva(self):
        with self.assertRaises(ErrorTurno) as contexto:
            calcular_turno_tecnico("Pinus rudis", "III", 100, ampliar_hasta_200=True)
        self.assertEqual(contexto.exception.codigo, "fuera_rango")

    def test_grafica_contiene_el_punto_calculado(self):
        resultado = calcular_turno_tecnico("Pinus montezumae", "III", 35)
        grafica = generar_datos_grafica_turno(resultado)
        self.assertAlmostEqual(grafica["punto_turno"]["x"], resultado["edad_calculada"], delta=1e-12)
        self.assertAlmostEqual(grafica["punto_turno"]["y"], 35, delta=1e-12)
        self.assertAlmostEqual(grafica["edad_maxima"], resultado["edad_calculada"] + 20.0,
                               delta=1e-12)

    def test_grafica_muestra_veinte_anios_despues_del_turno(self):
        resultado = calcular_turno_tecnico("Pinus montezumae", "III", 35)
        resultado["edad_calculada"] = 60.0
        grafica = generar_datos_grafica_turno(resultado)
        self.assertEqual(grafica["edad_maxima"], 80.0)

    def test_serializacion_y_reapertura(self):
        pmf = PMFProyecto("Programa de prueba")
        resultado = calcular_turno_tecnico("Pinus teocote", "II", 35)
        resultado.update({"id": "turno-1", "proyecto_id": pmf.nombre,
                          "fecha_calculo": "2026-08-20T10:00:00", "usuario": "prueba"})
        pmf.calculos_turno.append(resultado)
        restaurado = PMFProyecto.desde_dict(pmf.serializar())
        recuperado = restaurado.calculos_turno[0]
        self.assertEqual(recuperado["modelo_clave"], resultado["modelo_clave"])
        self.assertEqual(recuperado["parametros_modelo"], resultado["parametros_modelo"])
        self.assertAlmostEqual(recuperado["edad_calculada"], resultado["edad_calculada"], delta=1e-12)
        self.assertEqual(recuperado["fuente"], resultado["fuente"])
        self.assertEqual(recuperado["turno_referencia_publicado"], 70)


class IntegracionTurnosTest(unittest.TestCase):
    def setUp(self):
        self.cliente = app.test_client()
        pmf = PMFProyecto("Programa de prueba", predio="Predio prueba")
        with self.cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()

    def test_calculo_cambio_de_seleccion_y_reapertura(self):
        primera = self.cliente.post("/turnos", data={
            "accion": "calcular", "especie": "Pinus patula",
            "calidad_estacion": "I", "diametro_objetivo": "40",
        })
        self.assertEqual(primera.status_code, 302)
        segunda = self.cliente.post("/turnos", data={
            "accion": "calcular", "especie": "Pinus montezumae",
            "calidad_estacion": "IV", "diametro_objetivo": "35",
        })
        self.assertEqual(segunda.status_code, 302)
        pagina = self.cliente.get(segunda.headers["Location"])
        html = pagina.get_data(as_text=True)
        self.assertIn("Turno técnico estimado", html)
        self.assertIn("invalidarResultadoTurno", html)
        self.assertIn("punto_turno", html)
        with self.cliente.session_transaction() as sesion:
            self.assertNotIn("pmf_data", sesion)
            ruta = sesion["ruta_actual"]
        restaurado = PMFProyecto.cargar(ruta)
        self.assertEqual(len(restaurado.calculos_turno), 2)
        self.assertEqual(restaurado.calculos_turno[-1]["especie"], "Pinus montezumae")

    def test_selector_dinamico_y_rechazo_de_calidad_iv(self):
        respuesta = self.cliente.post("/turnos", data={
            "accion": "calcular", "especie": "Pinus teocote",
            "calidad_estacion": "IV", "diametro_objetivo": "35",
        })
        self.assertEqual(respuesta.status_code, 400)
        html = respuesta.get_data(as_text=True)
        self.assertNotIn('<option value="IV"', html)
        self.assertIn("actualizarCalidadesTurno", html)
        self.assertIn("validas.indexOf(previa)>=0?previa:''", html)

    def test_grafica_ofrece_exportar_imagen_ampliada(self):
        respuesta = self.cliente.post("/turnos", data={
            "accion": "calcular", "especie": "Pinus patula",
            "calidad_estacion": "I", "diametro_objetivo": "40",
        })
        self.assertEqual(respuesta.status_code, 302)
        html = self.cliente.get(respuesta.headers["Location"]).get_data(as_text=True)
        self.assertIn("exportarImagenTurno", html)
        self.assertIn("Exportar imagen (PNG)", html)
        self.assertIn("width=W;lienzo.height=H", html.replace(" ", ""))

    def test_calculo_y_grafica_de_especies_nuevas(self):
        for especie, calidad in (("Pinus teocote", "I"), ("Pinus rudis", "III")):
            with self.subTest(especie=especie):
                respuesta = self.cliente.post("/turnos", data={
                    "accion": "calcular", "especie": especie,
                    "calidad_estacion": calidad, "diametro_objetivo": "35",
                })
                self.assertEqual(respuesta.status_code, 302)
                html = self.cliente.get(respuesta.headers["Location"]).get_data(as_text=True)
                self.assertIn("punto_turno", html)
                self.assertIn('"y": 35.0', html)

    def test_reporte_word_turno(self):
        pmf = PMFProyecto("Programa de prueba", predio="Predio prueba")
        calculo = calcular_turno_tecnico("Pinus patula", "IV", 40)
        calculo.update({"id": "turno-1", "proyecto_id": pmf.nombre,
                        "fecha_calculo": "2026-08-20T10:00:00", "usuario": "prueba"})
        salida = generar_reporte_turno(
            pmf, calculo, decodificar_png(PNG_PRUEBA), LOGO)
        with zipfile.ZipFile(salida) as documento:
            xml = documento.read("word/document.xml").decode("utf-8")
            medios = [nombre for nombre in documento.namelist() if nombre.startswith("word/media/")]
        self.assertIn("Turno técnico estimado", xml)
        self.assertIn("Modelo de Orantes", xml)
        self.assertIn("Velarde Ramírez", xml)
        self.assertIn("cuadro resumen 4.67", xml)
        self.assertIn("w:i", xml)
        self.assertEqual(len(medios), 2)
        self.assertTrue(nombre_archivo_turno("Pinus patula", "Predio prueba").startswith("SIMFI_Turno_Tecnico_"))

    def test_reporte_especie_nueva_incluye_fuente_y_referencia(self):
        pmf = PMFProyecto("Programa de prueba", predio="Predio prueba")
        calculo = calcular_turno_tecnico("Pinus teocote", "II", 35)
        calculo.update({"id": "turno-teocote", "proyecto_id": pmf.nombre,
                        "fecha_calculo": "2026-08-20T10:00:00", "usuario": "prueba"})
        salida = generar_reporte_turno(
            pmf, calculo, decodificar_png(PNG_PRUEBA), LOGO)
        with zipfile.ZipFile(salida) as documento:
            xml = documento.read("word/document.xml").decode("utf-8")
        self.assertIn("ecuación 16", xml)
        self.assertIn("70 años para 35.00 cm", xml)
        self.assertIn("páginas impresas 68–74", xml)
        self.assertIn("no utiliza 70 años como constante", xml)


if __name__ == "__main__":
    unittest.main()
