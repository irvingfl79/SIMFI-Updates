"""Motor generico de interpretacion ampliada con IA local para reportes SIMFI.

Este modulo NO realiza calculos forestales, NO modifica resultados ni reportes
existentes y NO participa en las exportaciones Word/PDF (que conservan la
interpretacion determinista de SIMFI). Recibe una instantanea compacta de datos
ya calculados y validados por SIMFI para una vista en pantalla y devuelve prosa
tecnica ampliada. Cualquier fallo se degrada de forma elegante y el resto del
sistema sigue funcionando normalmente, incluso si Ollama no esta instalado.
"""

import json

try:
    from ai_interpretation_service import AIInterpretationService
    from ia_config import cargar_config as _cargar_config_ia
    _BASE_IA_OK = True
except ImportError:
    _BASE_IA_OK = False

_SERVICIO = AIInterpretationService() if _BASE_IA_OK else None

# Nombres descriptivos de las vistas en pantalla que exponen interpretacion.
TITULOS = {
    "proyecto": "Reporte general del proyecto",
    "integral": "Reporte integral de interpretacion forestal",
    "concentrado": "Concentrado de datos por rodal y especie",
    "cuadro_existencias": "Cuadro de existencias",
    "incrementos": "Resumen de incrementos",
    "carbono": "Carbono y oxigeno",
    "muestreo": "Interpretacion de error de muestreo",
    "reporte_tabla": "Reporte de tabla de inventario por rodal y especie",
    "dashboard_rodal": "Resumen por rodal",
    "klepac": "Reporte Klepac de crecimiento",
    "superficies": "Cuadro comparativo de superficies",
    "aclareos": "Evaluacion de intensidad de corta por aclareos",
    "turnos": "Calculo de turno tecnico",
}

# Limite de datos de la instantanea para no saturar la solicitud a Ollama.
# Es unicamente un limite de ENTRADA; SIMFI no recorta la interpretacion de salida.
_MAX_CONTEXTO_CARACTERES = 48000

# Estructura sugerida por tipo de reporte (los datos definen que tanto aplicar).
_ESTRUCTURAS_POR_TIPO = {
    "cuadro_existencias": (
        " Organiza el análisis cuando la información lo permita en este orden: "
        "1) caracterización general del predio; 2) composición, dominancia y "
        "distribución de las existencias entre especies (participaciones y "
        "acumulados); 3) variación entre UMM y contrastes; 4) área basal; "
        "5) intensidad de corta y diferencias entre especies y UMM; "
        "6) posibilidad; 7) condición residual y cambios respecto a la "
        "condición inicial; 8) situación de los tratamientos silvícolas "
        "registrados (como observación agrupada, sin repetirlos por UMM); "
        "9) síntesis técnica final. Fundamenta el análisis en los hallazgos "
        "calculados por SIMFI y usa los datos individuales solo para ilustrar "
        "patrones. No es obligatorio agotar todos los puntos si los datos no "
        "los justifican."
    ),
    "incrementos": (
        " Utiliza EXCLUSIVAMENTE las variables de crecimiento e incremento "
        "proporcionadas (arboles por hectarea, area basal, tiempo de paso, ICA, "
        "ICA porcentual, IMA y edad). No las mezcles con variables de existencias, "
        "posibilidad o residual de otros modulos."
    ),
    "carbono": (
        " Utiliza EXCLUSIVAMENTE las variables de la pestana analizada (volumen, "
        "materia seca, carbono, CO2 equivalente, captura de CO2 o produccion de "
        "oxigeno). No las mezcles con variables de otros modulos."
    ),
}

_INSTRUCCION = (
    "Genera una interpretación técnica AMPLIADA para el reporte '{titulo}' de SIMFI.\n\n"
    "SIMFI CALCULA, VALIDA Y GENERA LOS HALLAZGOS. LA IA INTERPRETA Y REDACTA.\n\n"
    "Usa EXCLUSIVAMENTE los datos, resultados, clasificaciones y hallazgos proporcionados por SIMFI. Los resultados recibidos ya fueron calculados, validados y analizados por SIMFI y constituyen la base técnica de esta interpretación.\n\n"
    "Interpreta cada variable de acuerdo con el significado técnico proporcionado junto a ella.\n\n"
    "Explica las relaciones y contrastes que puedan observarse directamente entre los resultados proporcionados, especialmente cuando exista información de condición inicial y residual, diferentes rodales, UMM, especies, tratamientos o escenarios.\n\n"
    "NO recalcules los indicadores proporcionados por SIMFI.\n\n"
    "NO modifiques los valores recibidos.\n\n"
    "NO generes valores, variables, porcentajes, índices, clasificaciones o categorías que no hayan sido proporcionados por SIMFI.\n\n"
    "NO sustituyas una clasificación proporcionada por SIMFI por otra diferente.\n\n"
    "Puedes explicar relaciones directamente observables entre los resultados. Estas relaciones deben describirse e interpretarse técnicamente sin convertirlas en predicciones sobre el comportamiento futuro del rodal.\n\n"
    "NO clasifiques los resultados como buenos, malos, óptimos, adecuados, inadecuados, altos, bajos, sostenibles, deficientes, favorables o desfavorables, salvo que SIMFI proporcione explícitamente esa clasificación.\n\n"
    "NO inventes causas para explicar los resultados. Si SIMFI proporciona información que permita sustentar una causa, puedes incorporarla como parte de la interpretación. Si los datos no permiten determinar la causa de un comportamiento, describe únicamente el comportamiento observado.\n\n"
    "NO inventes efectos futuros. Un cambio observado en densidad, diámetro normal, área basal, volumen, índice de densidad, grado de densidad u otra variable no debe convertirse automáticamente en una predicción de crecimiento, productividad, estabilidad, calidad de madera, regeneración, sanidad o comportamiento futuro.\n\n"
    "NO confundas cambios en variables estructurales con cambios en calidad de madera o calidad de fuste.\n\n"
    "NO emitas recomendaciones, prescripciones silvícolas ni decisiones de manejo que no hayan sido proporcionadas explícitamente por SIMFI.\n\n"
    "Cuando exista condición inicial y condición residual, explica los principales cambios observados y su significado estructural. Cuando existan diferentes especies, rodales, UMM, tratamientos o escenarios, establece los contrastes relevantes únicamente con base en los resultados proporcionados por SIMFI.\n\n"
    "Si un escenario, método, UMM o variable no cuenta con información suficiente para ser evaluado, indícalo claramente y no intentes completar la información mediante estimaciones o conocimiento externo.\n\n"
    "La interpretación debe priorizar los hallazgos técnicamente relevantes y evitar la repetición mecánica de los datos. No te limites a enumerar cifras: explica qué relación existe entre ellas y cuál es su significado técnico, siempre dentro de los límites establecidos por los resultados proporcionados.\n\n"
    "Redacta en prosa técnica continua, con la extensión necesaria para explicar adecuadamente los hallazgos. NO utilices listas, viñetas, Markdown, encabezados internos ni fichas independientes por especie o UMM. La interpretación debe parecer elaborada por un profesional forestal que analiza resultados de inventario y manejo forestal.\n\n"
    "Devuelve únicamente texto limpio en párrafos, sin Markdown, sin listas y sin nombres internos de variables. Conserva exactamente los valores, unidades, nombres de especies, rodales, UMM, métodos y demás denominaciones proporcionadas por SIMFI.\n\n"
    "Datos ya calculados por SIMFI:\n{datos}"
)


class _ReporteNoDisponible(Exception):
    pass


def cargar_config(ruta=None):
    if not _BASE_IA_OK:
        return {}
    return _cargar_config_ia(ruta)


def habilitada(config=None):
    """Indica si la interpretacion ampliada de reportes debe ofrecerse.

    Depende de que el modulo base exista, de la habilitacion general de la IA y
    del interruptor propio de reportes. Nunca realiza llamadas de red.
    """
    if not _BASE_IA_OK:
        return False
    config = config or cargar_config()
    if not config:
        return False
    if not config.get("habilitada", False):
        return False
    return bool(config.get("reportes_habilitado", True))


def _max_tokens(config):
    for clave in ("max_completion_tokens", "max_tokens"):
        try:
            limite = int(config.get(clave, 0) or 0)
        except (TypeError, ValueError):
            continue
        if limite > 0:
            return max(64, limite)
    return 4000


def _serializar_contexto(datos):
    # Sin sort_keys para conservar el orden: los bloques de totales van primero
    # y son los que nunca se pierden si la instantanea se acota por caracteres.
    try:
        texto = json.dumps(datos, ensure_ascii=False, indent=2)
    except (TypeError, ValueError):
        texto = str(datos)
    if len(texto) > _MAX_CONTEXTO_CARACTERES:
        texto = texto[:_MAX_CONTEXTO_CARACTERES] + "\n... (los datos adicionales se omitieron)"
    return texto


def interpretar(tipo, datos, config=None):
    """Envia a la IA una interpretacion ampliada de una instantanea de SIMFI.

    Devuelve (ok, texto, mensaje, metadatos):
      ok=True     -> texto contiene la interpretacion recibida completa.
      ok=False    -> texto es None y mensaje explica el motivo de forma elegante.
      metadatos   -> diagnostico del proveedor (finish_reason, tokens y si la
                     respuesta quedo truncada por el limite de tokens).
    """
    if not _BASE_IA_OK:
        return False, None, (
            "La interpretacion ampliada con IA local no esta disponible en "
            "esta instalacion de SIMFI."
        ), {}
    titulo = TITULOS.get(tipo)
    if not titulo:
        return False, None, "Este tipo de reporte no esta habilitado para interpretacion con IA.", {}
    config = config or cargar_config()
    if not config:
        return False, None, "No se pudo leer la configuracion de la IA local.", {}
    if not config.get("habilitada", False):
        return False, None, (
            "La integracion con la IA local esta deshabilitada en la "
            "configuracion (config_ia.json, clave habilitada)."
        ), {}
    if not config.get("reportes_habilitado", True):
        return False, None, (
            "La interpretacion ampliada de reportes esta deshabilitada en la "
            "configuracion (config_ia.json, clave reportes_habilitado)."
        ), {}
    contexto = _INSTRUCCION.format(titulo=titulo,
                                   estructura=_ESTRUCTURAS_POR_TIPO.get(tipo, ""),
                                   datos=_serializar_contexto(datos))
    resultado = _SERVICIO.interpret(datos, tipo, contexto, config)
    metadatos = resultado.get("metadatos") or {}
    return resultado["ok"], resultado["texto"], resultado["mensaje"], metadatos
