"""Análisis local, trazable y estratificado de muestreo MOREDIF."""
import hashlib
import math
from collections import Counter


VERSION_MOTOR = "3.0"
ESTADOS_INCLUIDOS = {"completado_datos", "completado_cero"}
# MOREDIF redondea los campos exportados a seis decimales. Al multiplicar un
# volumen ya redondeado por el factor de expansión el desfase puede superar 1e-6.
TOLERANCIA_RELATIVA = 1e-6
TOLERANCIA_ABSOLUTA = 1e-4


class ErrorMuestreoValidacion(ValueError):
    pass


def hash_archivo(contenido):
    return hashlib.sha256(contenido).hexdigest()


def _numero(valor, campo):
    if isinstance(valor, bool):
        raise ErrorMuestreoValidacion(f"{campo} debe ser numérico.")
    try:
        numero = float(valor)
    except (TypeError, ValueError):
        raise ErrorMuestreoValidacion(f"{campo} debe ser numérico.")
    if not math.isfinite(numero):
        raise ErrorMuestreoValidacion(f"{campo} debe ser finito.")
    return numero


def _casi_igual(uno, dos):
    return math.isclose(uno, dos, rel_tol=TOLERANCIA_RELATIVA, abs_tol=TOLERANCIA_ABSOLUTA)


def valor_t(confianza, grados_libertad):
    if confianza not in (90, 95, 99) or grados_libertad <= 0:
        return None
    from scipy.stats import t as student_t
    return float(student_t.ppf(1 - (1 - confianza / 100) / 2, grados_libertad))


def _agrupar_advertencias(advertencias):
    agrupadas = []
    for codigo, total in Counter(item.get("codigo", "ADVERTENCIA") for item in advertencias or []).items():
        if codigo == "FECHA_LEVANTAMIENTO_FALTANTE":
            agrupadas.append(f"{total} sitios no tienen fecha histórica de levantamiento.")
        elif codigo == "SITIOS_PREDIO_INVALIDO":
            agrupadas.append(next((item.get("mensaje", codigo) for item in advertencias if item.get("codigo") == codigo), codigo))
        else:
            agrupadas.append(f"{total} advertencia(s): {codigo}.")
    return agrupadas


def normalizar_documento(documento):
    """Valida el contrato real y devuelve sólo los sitios incluidos por MOREDIF."""
    if not isinstance(documento, dict) or documento.get("schema") != "simfi.muestreo" or str(documento.get("version")) != "1.0":
        raise ErrorMuestreoValidacion("Se requiere un archivo simfi.muestreo versión 1.0.")
    for bloque in ("predio", "configuracion", "resumen_validacion", "resumen_muestreo", "rodales", "trazabilidad"):
        if bloque not in documento:
            raise ErrorMuestreoValidacion(f"Falta el bloque {bloque}.")
    if documento.get("errores"):
        raise ErrorMuestreoValidacion("MOREDIF reporta errores críticos; corrija el archivo de origen.")
    configuracion = documento["configuracion"]
    confianza = int(_numero(configuracion.get("nivel_confianza"), "nivel_confianza"))
    if confianza not in (90, 95, 99):
        raise ErrorMuestreoValidacion("El nivel de confianza debe ser 90, 95 o 99.")
    if configuracion.get("variable_volumen") != "VTACC" or configuracion.get("unidad") != "m3_ha":
        raise ErrorMuestreoValidacion("La variable debe ser VTACC con unidad m3_ha.")

    incluidos = list(documento["trazabilidad"].get("sitios_incluidos", []))
    if len(incluidos) != len(set(incluidos)):
        raise ErrorMuestreoValidacion("La trazabilidad contiene identificadores de sitio duplicados.")
    sitios_vistos, rodales = [], []
    for rodal in documento["rodales"]:
        superficie = _numero(rodal.get("superficie_ha"), "superficie del rodal")
        if superficie <= 0:
            raise ErrorMuestreoValidacion("La superficie de un rodal debe ser positiva.")
        sitios = []
        for sitio in rodal.get("sitios", []):
            if sitio.get("estado") not in ESTADOS_INCLUIDOS:
                raise ErrorMuestreoValidacion("Un sitio exportado no está completado.")
            try:
                numero_sitio = int(sitio.get("numero"))
            except (TypeError, ValueError):
                raise ErrorMuestreoValidacion("Un sitio no tiene un número válido.")
            if numero_sitio <= 0:
                raise ErrorMuestreoValidacion("El número de sitio debe ser positivo.")
            if sitio.get("id") in sitios_vistos:
                raise ErrorMuestreoValidacion("Existe un identificador de sitio duplicado.")
            if sitio.get("rodal_id") != rodal.get("id"):
                raise ErrorMuestreoValidacion("Un sitio no coincide con su rodal exportado.")
            area = _numero(sitio.get("tamano_m2"), "superficie del sitio")
            fe = _numero(sitio.get("factor_expansion"), "factor de expansión")
            vol_sitio = _numero(sitio.get("volumen_sitio_m3"), "volumen dentro del sitio")
            vol_ha = _numero(sitio.get("volumen_ha_m3"), "volumen total por hectárea")
            if area <= 0 or vol_sitio < 0 or vol_ha < 0 or not _casi_igual(fe, 10000 / area) or not _casi_igual(vol_ha, vol_sitio * fe):
                raise ErrorMuestreoValidacion("Un sitio tiene superficie, factor o volumen inconsistente.")
            especies = sitio.get("volumen_especies", [])
            suma_especies = sum(_numero(especie.get("volumen_sitio_m3"), "volumen de especie") for especie in especies)
            if suma_especies < 0 or not _casi_igual(suma_especies, vol_sitio):
                raise ErrorMuestreoValidacion("El volumen por especies no coincide con el total del sitio.")
            sitios_vistos.append(sitio["id"])
            sitios.append({"id": sitio["id"], "numero": numero_sitio, "tamano_m2": area,
                           "volumen_sitio_m3": vol_sitio, "volumen_ha_m3": vol_ha,
                           "estado": sitio["estado"]})
        if sitios:
            rodales.append({"id": rodal.get("id"), "clave": rodal.get("clave") or str(rodal.get("id")),
                            "superficie_ha": superficie, "sitios": sitios})
    if sorted(sitios_vistos) != sorted(incluidos):
        raise ErrorMuestreoValidacion("Los sitios exportados no coinciden con trazabilidad.sitios_incluidos.")
    resumen = documento["resumen_validacion"]
    if resumen.get("validos_para_simfi") != len(sitios_vistos):
        raise ErrorMuestreoValidacion("El conteo de sitios válidos no coincide con los sitios exportados.")
    ceros = sum(1 for rodal in rodales for sitio in rodal["sitios"] if sitio["estado"] == "completado_cero")
    if resumen.get("completados_cero") is not None and ceros != resumen.get("completados_cero"):
        raise ErrorMuestreoValidacion("El conteo de sitios en cero no coincide.")
    superficie_representada = sum(rodal["superficie_ha"] for rodal in rodales)
    superficie_predio = _numero(documento["predio"].get("superficie_total_ha"), "superficie total del predio")
    superficie_muestreada = sum(sitio["tamano_m2"] for rodal in rodales for sitio in rodal["sitios"]) / 10000
    return {"predio": documento["predio"], "configuracion": configuracion, "rodales": rodales,
            "sitios_validos": len(sitios_vistos), "sitios_cero": ceros,
            "superficie_predio_ha": superficie_predio, "superficie_representada_ha": superficie_representada,
            "superficie_muestreada_ha": superficie_muestreada,
            "intensidad_total_pct": superficie_muestreada / superficie_predio * 100,
            "superficie_no_representada_ha": superficie_predio - superficie_representada,
            "advertencias": _agrupar_advertencias(documento.get("advertencias")),
            "resumen_muestreo": documento["resumen_muestreo"]}


def _estadistica(valores, confianza, fpc_n=None, superficie_rodal_ha=None, superficie_sitio_ha=None,
                 forzar_sin_fpc=False):
    """Estadística de un rodal sobre sitios válidos (numéricos, no booleanos, >= 0).

    Un sitio con volumen 0 (estado completado_cero) es una observación válida y se
    incluye en media y varianza; solo se ignoran valores None, vacíos, booleanos o
    negativos.

    N se obtiene dinámicamente como superficie_rodal_ha / superficie_sitio_ha, salvo N_h
    manual (fpc_n) o forzar_sin_fpc. Aplica la FPC histórica de SIMFI/hoja de cálculo:
    sx = sqrt((s2/n) * (1-n/N)), es decir, factor sqrt(1-n/N) sobre el error estándar.
    """
    validos = [v for v in (valores or [])
               if isinstance(v, (int, float)) and not isinstance(v, bool) and v >= 0]
    n = len(validos)
    base = {"n": n, "media_m3_ha": None, "varianza": None, "desviacion_estandar": None,
            "cv_pct": None, "error_estandar": None, "t_critico": None, "error_absoluto_m3_ha": None,
            "error_relativo_pct": None, "li_m3_ha": None, "ls_m3_ha": None,
            "li_practico_m3_ha": None, "estado": "Sin información" if n == 0 else "No evaluable",
            "poblacion_N": None, "superficie_sitio_ha": superficie_sitio_ha,
            "superficie_sitio_m2": (superficie_sitio_ha * 10000 if superficie_sitio_ha else None),
            "intensidad_muestreo_pct": None, "fpc_factor": 1.0, "error_relativo_final_pct": None,
            "grados_libertad": (n - 1) if n >= 1 else None, "advertencia_fpc": None,
            "mensaje": ("No es posible calcular el error de muestreo con menos de 2 sitios válidos."
                        if n < 2 else None)}
    if n < 2:
        return base
    base["estado"] = "Evaluable"
    media = sum(validos) / n
    varianza = sum((valor - media) ** 2 for valor in validos) / (n - 1)
    desviacion = math.sqrt(varianza)
    se = desviacion / math.sqrt(n)
    fpc = 1.0
    poblacion = None
    advertencia = None
    if fpc_n is not None:
        if fpc_n < n or fpc_n <= 1:
            raise ErrorMuestreoValidacion("N_h debe ser mayor o igual que n y mayor que uno.")
        poblacion = float(fpc_n)
    elif not forzar_sin_fpc and superficie_rodal_ha and superficie_sitio_ha:
        if superficie_rodal_ha > 0 and superficie_sitio_ha > 0:
            poblacion = superficie_rodal_ha / superficie_sitio_ha
    intensidad = (n / poblacion * 100) if poblacion else None
    if poblacion is not None:
        if n > poblacion:
            return {**base, "media_m3_ha": media, "varianza": varianza,
                    "desviacion_estandar": desviacion,
                    "cv_pct": desviacion / media * 100 if media else None,
                    "poblacion_N": poblacion, "intensidad_muestreo_pct": intensidad,
                    "estado": "No evaluable",
                    "advertencia_fpc": ("El número de sitios muestreados supera el número de unidades "
                                        "de muestreo posibles."),
                    "mensaje": ("El número de sitios muestreados supera el número de unidades "
                                "de muestreo posibles.")}
        if poblacion <= 1:
            advertencia = "N <= 1: no se aplica la corrección por población finita."
        elif n >= poblacion:
            fpc = 0.0
        else:
            fpc = math.sqrt(max(0.0, 1 - n / poblacion))
        se *= fpc
    critico = valor_t(confianza, n - 1)
    error = critico * se
    li = media - error
    relativo = error / media * 100 if media else None
    return {**base, "media_m3_ha": media, "varianza": varianza, "desviacion_estandar": desviacion,
            "cv_pct": desviacion / media * 100 if media else None, "error_estandar": se,
            "t_critico": critico, "error_absoluto_m3_ha": error,
            "error_relativo_pct": relativo,
            # error_relativo_final_pct se conserva por compatibilidad de nombre de campo
            # con plantillas, reportes y proyectos guardados; ya no se divide entre 10.
            "error_relativo_final_pct": relativo,
            "li_m3_ha": li, "ls_m3_ha": media + error,
            "li_practico_m3_ha": max(0.0, li), "fpc_factor": fpc,
            "poblacion_N": poblacion, "intensidad_muestreo_pct": intensidad,
            "advertencia_fpc": advertencia}


def _tamano_muestra(cv_pct, error_objetivo, confianza, poblacion_N=None):
    """Tamaño de muestra orientativo por rodal (t iterado con gl = n - 1).

    Si se conoce poblacion_N (N_h), aplica la corrección por población finita:
    n0 = (t·CV/E)²; n = ceil(n0 / (1 + n0/N)). Sin N, es el tamaño sin FPC.
    """
    if cv_pct is None or not error_objetivo or cv_pct <= 0 or error_objetivo <= 0:
        return None
    n = 2
    for _ in range(100):
        t = valor_t(confianza, n - 1)
        if t is None:
            return None
        n0 = (t * (cv_pct / 100) / (error_objetivo / 100)) ** 2
        if poblacion_N:
            nuevo = max(2, math.ceil(n0 / (1 + n0 / poblacion_N)))
        else:
            nuevo = max(2, math.ceil(n0))
        if nuevo == n:
            return n
        n = nuevo
    return n


def _tamano_muestra_predio(resultados, area_total, media, error_objetivo, confianza):
    """Sitios requeridos a nivel predio, asignación proporcional a la superficie.

    W_h = A_h/A; S²_w = Σ(W_h·s²_h); E_abs = error_objetivo% · media;
    n0 = t²·S²_w/E_abs²; n = ceil(n0/(1+n0/N_total)), N_total = ΣN_h.
    Itera t con gl = n - L (L = número de estratos) hasta estabilizar.
    """
    estratos = len(resultados)
    if not error_objetivo or error_objetivo <= 0 or not media or media <= 0 or estratos < 1 or not area_total:
        return None
    varianzas = [(rodal.get("estadistica") or {}).get("varianza") for rodal in resultados]
    if any(v is None for v in varianzas):
        return None
    pesos = [rodal["superficie_ha"] / area_total for rodal in resultados]
    s2_ponderada = sum(w * v for w, v in zip(pesos, varianzas))
    if s2_ponderada <= 0:
        return None
    error_abs = error_objetivo / 100 * media
    if error_abs <= 0:
        return None
    poblaciones = [(rodal.get("estadistica") or {}).get("poblacion_N") for rodal in resultados]
    poblacion_total = sum(poblaciones) if all(p is not None for p in poblaciones) else None
    n = estratos + 1
    for _ in range(200):
        gl = max(1, n - estratos)
        t = valor_t(confianza, gl)
        if t is None:
            return None
        n0 = (t ** 2) * s2_ponderada / (error_abs ** 2)
        if poblacion_total:
            nuevo = max(estratos + 1, math.ceil(n0 / (1 + n0 / poblacion_total)))
        else:
            nuevo = max(estratos + 1, math.ceil(n0))
        if nuevo == n:
            return n
        n = nuevo
    return n


def _distribucion_sugerida_por_rodal(resultados, area_total, n_total):
    """n_h = ceil(n_total · W_h), con mínimo 2 sitios por rodal (referencial)."""
    if n_total is None or not area_total:
        return []
    distribucion = []
    for rodal in resultados:
        w_h = rodal["superficie_ha"] / area_total
        n_h = max(2, math.ceil(n_total * w_h))
        distribucion.append({"id": rodal.get("id"), "clave": rodal.get("clave"), "n_h": n_h})
    return distribucion


def verificar_independiente(rodales, confianza):
    """Verificador separado del motor: aplica directamente las fórmulas básicas."""
    comparados, diferencias = 0, []
    for rodal in rodales:
        valores = [sitio["volumen_ha_m3"] for sitio in rodal["sitios"]
                   if isinstance(sitio.get("volumen_ha_m3"), (int, float))
                   and not isinstance(sitio["volumen_ha_m3"], bool) and sitio["volumen_ha_m3"] >= 0]
        estadistica = rodal["estadistica"]
        if len(valores) < 2:
            continue
        media = sum(valores) / len(valores)
        varianza = sum((valor - media) ** 2 for valor in valores) / (len(valores) - 1)
        tolerancia = max(1e-6, 1e-9 * max(abs(media), abs(varianza)))
        comparados += 2
        if abs(media - estadistica["media_m3_ha"]) > tolerancia:
            diferencias.append(f"Media distinta en {rodal['clave']}")
        if abs(varianza - estadistica["varianza"]) > tolerancia:
            diferencias.append(f"Varianza distinta en {rodal['clave']}")
    return {"metodo_principal": "Motor SIMFI", "metodo_independiente": "Fórmulas directas de media y varianza muestral",
            "resultados_comparados": comparados, "diferencias": diferencias,
            "tolerancia": "max(1e-6, 1e-9 × magnitud)",
            "estado": "Coincide" if not diferencias else "No coincide"}


def _estratificado_general(resultados, area_total, confianza):
    """Cálculo estratificado del predio (ponderación por superficie, grados de
    libertad de Welch-Satterthwaite). Devuelve dict con media y error, o None
    si no es calculable. Solo lectura: no modifica los datos."""
    if not resultados or not area_total:
        return None
    try:
        componentes = [(r["superficie_ha"] / area_total) ** 2 * r["estadistica"]["error_estandar"] ** 2
                       for r in resultados]
        varianza = sum(componentes)
        denominador = sum((c ** 2) / (r["estadistica"]["n"] - 1) for c, r in zip(componentes, resultados))
        gl = varianza ** 2 / denominador if denominador else None
        se = math.sqrt(varianza)
        tcrit = valor_t(confianza, gl) if gl else None
        media = sum(r["superficie_ha"] / area_total * r["estadistica"]["media_m3_ha"] for r in resultados)
    except (TypeError, KeyError):
        return None
    if tcrit is None:
        error, relativo = 0.0, (0.0 if media else None)
    else:
        error = tcrit * se
        relativo = error / media * 100 if media else None
    return {"media_m3_ha": media, "varianza": varianza, "error_estandar": se,
            "grados_libertad": gl, "t_critico": tcrit,
            "error_absoluto_m3_ha": error, "error_relativo_pct": relativo}


def calcular_error_muestreo(documento=None, fpc_nh=None, continuar_sin_fpc=False, datos_normalizados=None):
    """Calcula a partir del documento original o de un borrador ya validado y editado."""
    datos = datos_normalizados if datos_normalizados is not None else normalizar_documento(documento)
    configuracion, confianza = datos["configuracion"], int(datos["configuracion"]["nivel_confianza"])
    fpc_solicitada = bool(configuracion.get("aplicar_correccion_poblacion_finita"))
    fpc_nh = fpc_nh or {}
    if fpc_solicitada and not fpc_nh and not continuar_sin_fpc:
        raise ErrorMuestreoValidacion("La FPC fue solicitada; confirme continuar sin FPC, capture N_h o cancele.")
    resultados = []
    for rodal in datos["rodales"]:
        nh = fpc_nh.get(str(rodal["id"]))
        areas = [s.get("tamano_m2") for s in rodal.get("sitios", [])
                 if isinstance(s.get("tamano_m2"), (int, float)) and s.get("tamano_m2") > 0]
        superficie_sitio_ha = (sum(areas) / len(areas) / 10000) if areas else None
        total = _estadistica([sitio["volumen_ha_m3"] for sitio in rodal["sitios"]], confianza, nh,
                             superficie_rodal_ha=rodal.get("superficie_ha"),
                             superficie_sitio_ha=superficie_sitio_ha,
                             forzar_sin_fpc=bool(fpc_solicitada and continuar_sin_fpc and not fpc_nh))
        area_muestreada = sum(sitio["tamano_m2"] for sitio in rodal["sitios"]) / 10000
        error_total = total["error_absoluto_m3_ha"] * rodal["superficie_ha"] if total["error_absoluto_m3_ha"] is not None else None
        resultados.append({**rodal, "intensidad_pct": area_muestreada / rodal["superficie_ha"] * 100,
                            "superficie_muestreada_ha": area_muestreada, "estadistica": total,
                            "volumen_estimado_m3": ((total["media_m3_ha"] or 0) * rodal["superficie_ha"]),
                            "error_total_m3": error_total,
                            "li_total_m3": (total["li_m3_ha"] * rodal["superficie_ha"] if error_total is not None else None),
                            "ls_total_m3": (total["ls_m3_ha"] * rodal["superficie_ha"] if error_total is not None else None),
                            "n_requerido": _tamano_muestra(total["cv_pct"], configuracion.get("error_objetivo_pct"), confianza, total.get("poblacion_N"))})
    no_evaluables = [rodal["clave"] for rodal in resultados if rodal["estadistica"]["estado"] != "Evaluable"]
    sin_muestra = abs(datos["superficie_no_representada_ha"]) > TOLERANCIA_ABSOLUTA
    general_evaluable = not no_evaluables and not sin_muestra and not (fpc_solicitada and not fpc_nh)
    general = {"estado": "No evaluable", "clasificacion": "Provisional / No evaluable",
               "error_relativo_final_pct": None}
    if general_evaluable:
        area = datos["superficie_predio_ha"]
        componentes = [(rodal["superficie_ha"] / area) ** 2 * rodal["estadistica"]["error_estandar"] ** 2 for rodal in resultados]
        varianza = sum(componentes)
        denominador = sum((componente ** 2) / (rodal["estadistica"]["n"] - 1) for componente, rodal in zip(componentes, resultados))
        gl = varianza ** 2 / denominador if denominador else None
        se = math.sqrt(varianza)
        tcrit = valor_t(confianza, gl) if gl else None
        media = sum(rodal["superficie_ha"] / area * rodal["estadistica"]["media_m3_ha"] for rodal in resultados)
        objetivo = configuracion.get("error_objetivo_pct")
        if tcrit is None:
            error, relativo = 0.0, (0.0 if media else None)
        else:
            error = tcrit * se
            relativo = error / media * 100 if media else None
        final = relativo
        estado = "Cumple" if final is not None and objetivo is not None and final <= objetivo else "No cumple"
        n_requerido_predio = _tamano_muestra_predio(resultados, area, media, objetivo, confianza)
        n_faltantes_predio = (max(0, n_requerido_predio - datos["sitios_validos"])
                              if n_requerido_predio is not None else None)
        distribucion_sugerida = _distribucion_sugerida_por_rodal(resultados, area, n_requerido_predio)
        general = {"estado": estado, "clasificacion": estado, "media_m3_ha": media, "varianza": varianza,
                   "error_estandar": se, "grados_libertad": gl, "t_critico": tcrit,
                   "error_absoluto_m3_ha": error, "error_relativo_pct": relativo,
                   "error_relativo_final_pct": final,
                   "li_m3_ha": media - error, "ls_m3_ha": media + error,
                   "volumen_estimado_m3": sum(rodal["volumen_estimado_m3"] for rodal in resultados),
                   "n_requerido_predio": n_requerido_predio, "n_faltantes_predio": n_faltantes_predio,
                   "distribucion_sugerida_por_rodal": distribucion_sugerida}
    if not general_evaluable and not no_evaluables and resultados:
        # Error informativo: todos los rodales tienen varianza estimable pero el
        # resultado general no es oficialmente evaluable (p. ej. FPC solicitada
        # y no aplicada). Se muestra solo como referencia con los datos
        # disponibles; el estado sigue siendo "No evaluable" y no se declara
        # Cumple / No cumple (ese criterio queda a juicio del usuario).
        info = _estratificado_general(resultados, datos["superficie_predio_ha"], confianza)
        if info and info["error_relativo_pct"] is not None:
            if fpc_solicitada and not fpc_nh:
                motivo = "FPC solicitada y no aplicada"
            elif sin_muestra:
                motivo = "superficie sin muestra"
            else:
                motivo = "resultado no evaluable"
            general["media_informativa_m3_ha"] = info["media_m3_ha"]
            general["error_absoluto_informativo_m3_ha"] = info["error_absoluto_m3_ha"]
            general["error_relativo_informativo_pct"] = info["error_relativo_pct"]
            general["motivo_informativo"] = motivo
    limitaciones = list(datos["advertencias"])
    if sin_muestra:
        limitaciones.append("Existe un rodal o estrato sin muestra cuya superficie forma parte del predio. El error estratificado completo no puede estimarse con la información disponible.")
    if no_evaluables:
        limitaciones.append("Se requiere más de un sitio para estimar la varianza en: " + ", ".join(no_evaluables) + ".")
    if fpc_solicitada and not fpc_nh:
        limitaciones.append("La FPC fue solicitada y no aplicada porque no se proporcionó N_h.")
    for rodal in resultados:
        advertencia = (rodal.get("estadistica") or {}).get("advertencia_fpc")
        if advertencia:
            mensaje = f"Rodal {rodal.get('clave')}: {advertencia}"
            if mensaje not in limitaciones:
                limitaciones.append(mensaje)
    uso_dinamico = any((r.get("estadistica") or {}).get("poblacion_N") is not None
                       and str(r.get("id")) not in (fpc_nh or {}) for r in resultados)
    if fpc_solicitada and fpc_nh:
        fpc_estado = "Fue solicitada y aplicada"
    elif fpc_solicitada:
        fpc_estado = "Fue solicitada y no aplicada"
    elif uso_dinamico:
        fpc_estado = "Aplicada automáticamente (N dinámico)"
    else:
        fpc_estado = "No fue solicitada"
    conjunto = [sitio["volumen_ha_m3"] for rodal in resultados for sitio in rodal["sitios"]]
    diagnostico = _estadistica(conjunto, confianza)
    if conjunto:
        diagnostico.update({"minimo_m3_ha": min(conjunto), "maximo_m3_ha": max(conjunto),
                            "rango_m3_ha": max(conjunto) - min(conjunto)})
    comprobacion = verificar_independiente(resultados, confianza)
    return {"version_motor": VERSION_MOTOR, "predio": datos["predio"], "configuracion": configuracion,
            "resumen_muestreo": datos.get("resumen_muestreo", {}),
            "validacion": {k: datos[k] for k in ("sitios_validos", "sitios_cero", "superficie_predio_ha", "superficie_representada_ha", "superficie_muestreada_ha", "intensidad_total_pct", "superficie_no_representada_ha")},
            "fpc_estado": fpc_estado, "rodales": resultados, "resultado_general": general,
            "diagnostico_conjunto": diagnostico, "comprobacion": comprobacion,
            "limitaciones": limitaciones, "matriz": resultados}
