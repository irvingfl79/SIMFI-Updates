"""Reporte Word e interpretación del cuadro de clasificación de superficies."""

from docx import Document
from cuadros_word import crear_cuadro
from reportes_tecnicos import _configurar_documento_institucional


def _filas_principales(cuadro):
    return [fila for fila in cuadro["filas"]
            if fila["nivel"] == "principal"]


def _texto_situacion(nombre, cuadro, campo_ha, campo_porcentaje):
    total = next(fila for fila in cuadro["filas"] if fila["clave"] == "total")
    superficie = total[campo_ha]
    if not superficie:
        return [f"No se registró superficie para la situación {nombre.lower()}."]
    principales = _filas_principales(cuadro)
    dominante = max(principales, key=lambda fila: fila[campo_ha])
    restringidas = next(fila for fila in principales if fila["clave"] == "restringidas")
    textos = [
        f"La situación {nombre.lower()} registra una superficie total de {superficie:,.3f} ha.",
        f"La clasificación con mayor superficie es {dominante['nombre']} con {dominante[campo_ha]:,.3f} ha, equivalente a {dominante[campo_porcentaje]:,.3f} % del total de esta situación.",
    ]
    if restringidas[campo_ha]:
        textos.append(f"Las áreas de conservación y aprovechamiento restringido abarcan {restringidas[campo_ha]:,.3f} ha ({restringidas[campo_porcentaje]:,.3f} %).")
    return textos


def interpretar_superficies(cuadro):
    total = next(fila for fila in cuadro["filas"] if fila["clave"] == "total")
    cambios = _filas_principales(cuadro)
    mayor_cambio = max(cambios, key=lambda fila: abs(fila["variacion"]))
    ambos = [
        f"La superficie total pasa de {total['anterior']:,.3f} ha en la situación anterior a {total['actual']:,.3f} ha en la situación actual.",
        f"La variación registrada en el cuadro es de {total['variacion']:,.3f} ha (anterior menos actual). Los totales de ambas situaciones se conservan como valores independientes.",
    ]
    if mayor_cambio["variacion"]:
        direccion = "disminuye" if mayor_cambio["variacion"] > 0 else "aumenta"
        ambos.append(f"El cambio de mayor magnitud corresponde a {mayor_cambio['nombre']}, que {direccion} {abs(mayor_cambio['variacion']):,.3f} ha entre ambas situaciones.")
    else:
        ambos.append("No se registran variaciones de superficie entre las clasificaciones principales.")
    return {
        "anterior": _texto_situacion("anterior", cuadro, "anterior", "porcentaje_anterior"),
        "actual": _texto_situacion("actual", cuadro, "actual", "porcentaje_actual"),
        "comparativa": ambos,
    }


def generar_word_superficies(pmf, cuadro):
    analisis = {
        "titulo": "Reporte de clasificación de superficies",
        "estado_datos": "Captura registrada" if any(fila["anterior"] or fila["actual"] for fila in cuadro["filas"]) else "Sin captura de superficies",
        "trazabilidad": "Captura del módulo Superficies y cálculo automático de totales, porcentajes y variaciones.",
    }
    interpretacion = interpretar_superficies(cuadro)
    documento = Document()
    _configurar_documento_institucional(documento, pmf, analisis)
    documento.add_heading("Reporte de clasificación de superficies", level=0)
    documento.add_paragraph("El presente reporte documenta la situación anterior, la situación actual y la comparación entre ambas, con base exclusivamente en las hectáreas capturadas en el módulo Superficies.")

    documento.add_heading("1. Cuadro de clasificación de superficies", level=1)
    encabezados = [
        [{"texto": "Clasificación de superficies", "span": 1},
         {"texto": "Situación anterior", "span": 2},
         {"texto": "Situación actual", "span": 2},
         {"texto": "Variación", "span": 2}],
        ["", "ha", "%", "ha", "%", "ha", "%"],
    ]
    filas = [
        {"valores": [fila["nombre"], fila["anterior"], fila["porcentaje_anterior"],
                     fila["actual"], fila["porcentaje_actual"],
                     fila["variacion"], fila["porcentaje_variacion"]],
         "negrita": fila["nivel"] in ("principal", "total")}
        for fila in cuadro["filas"]
    ]
    crear_cuadro(documento,
                 titulo="Clasificación de superficies", numero_tabla=1,
                 encabezados=encabezados,
                 filas=filas,
                 anchos_relativos=[5.0, 1.35, 1.25, 1.35, 1.25, 1.35, 1.25],
                 alineaciones={0: "left"},
                 decimales={1: 3, 2: 3, 3: 3, 4: 3, 5: 3, 6: 3},
                 columnas_verticales=(0,))

    documento.add_heading("2. Interpretación de la situación anterior", level=1)
    for texto in interpretacion["anterior"]:
        documento.add_paragraph(texto)
    documento.add_heading("3. Interpretación de la situación actual", level=1)
    for texto in interpretacion["actual"]:
        documento.add_paragraph(texto)
    documento.add_heading("4. Interpretación comparativa", level=1)
    for texto in interpretacion["comparativa"]:
        documento.add_paragraph(texto)
    documento.add_heading("5. Trazabilidad", level=1)
    documento.add_paragraph(analisis["trazabilidad"])
    from io import BytesIO
    salida = BytesIO()
    documento.save(salida)
    salida.seek(0)
    return salida
