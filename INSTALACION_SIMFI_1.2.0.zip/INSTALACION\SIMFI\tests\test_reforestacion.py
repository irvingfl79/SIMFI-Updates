import unittest
import os
import tempfile
import zipfile
import json
from io import BytesIO

from lxml import etree
from lxml import html as html_mod
from openpyxl import load_workbook

from app import app
from modelos import (ClaseDiametrica, IntervencionCorta, PMFProyecto, Rodal,
                     TablaInventarioRodal, es_conifera)


class ReforestacionTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.ruta = self._preparar(self.tmp.name)
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba_reforestacion"
            sesion["ruta_actual"] = self.ruta
        self.cliente = cliente
        self.plan_antes = self._plan_serializado()

    def _preparar(self, tmp_name):
        import app as app_module
        app_module.DATA_DIR = tmp_name
        app_module.PROJECTS_DIR = os.path.join(tmp_name, "projects")
        app_module.PROJECT_STATE_DIR = os.path.join(tmp_name, "state")
        os.makedirs(app_module.PROJECTS_DIR, exist_ok=True)
        pmf = PMFProyecto("Rf")
        pmf.especies = ["Pinus patula", "Abies oaxacana", "Quercus rugosa"]
        pmf.agregar_rodal(Rodal("R1", 100, sitios=1, area_sitio_m2=10000))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Pinus patula", [ClaseDiametrica(20, 15, 10)]))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Quercus rugosa", [ClaseDiametrica(15, 20, 8)]))
        pmf.intensidad_corta["R1"] = {"Pinus patula": 10, "Quercus rugosa": 10}
        pmf.plan_cortas.intervenciones.append(IntervencionCorta(
            "area-uno", 1, "R1", 12.0, "Aclareo", superficie_completa=True))
        ruta = os.path.join(app_module.PROJECTS_DIR, "rf.json")
        pmf.guardar(ruta)
        return ruta

    def _plan_serializado(self):
        pmf = PMFProyecto.cargar(self.ruta)
        return json.dumps(pmf.serializar()["plan_cortas"], sort_keys=True)

    def test_es_conifera_detecta_generos(self):
        self.assertTrue(es_conifera("Pinus patula"))
        self.assertTrue(es_conifera("Abies religiosa"))
        self.assertTrue(es_conifera("Cupressus lindleyi"))
        self.assertTrue(es_conifera("Juniperus deppeana"))
        self.assertFalse(es_conifera("Quercus rugosa"))
        self.assertFalse(es_conifera("Arbutus xalapensis"))
        self.assertFalse(es_conifera("Alnus acuminata"))

    def test_agregados_excluye_latifoliadas_del_calculo(self):
        pmf = PMFProyecto.cargar(self.ruta)
        disponible = pmf.agregados_reforestacion()
        self.assertEqual(len(disponible), 1)
        area = disponible[0]
        self.assertAlmostEqual(area["superficie"], 12.0)
        especies = dict(area["especies"])
        self.assertIn("Pinus patula", especies)
        self.assertIn("Quercus rugosa", especies)
        coniferas = [e for e in especies if es_conifera(e)]
        self.assertEqual(coniferas, ["Pinus patula"])

    def test_cuadro_y_persistencia(self):
        respuesta = self.cliente.post("/reportes/reforestacion/guardar", json={
            "densidad": 1100,
            "selecciones": [{"anualidad": 1, "especies": ["Pinus patula"]}]})
        self.assertEqual(respuesta.status_code, 200)
        self.assertTrue(respuesta.get_json()["success"])

        recuperado = PMFProyecto.cargar(self.ruta)
        self.assertEqual(recuperado.reforestacion["densidad"], 1100)
        self.assertEqual(
            recuperado.reforestacion["selecciones"],
            [{"anualidad": 1, "especies": ["Pinus patula"]}])

        datos = recuperado.datos_reforestacion()
        self.assertEqual(len(datos["areas"]), 1)
        area = datos["areas"][0]
        self.assertAlmostEqual(area["superficie"], 12.0)
        fila = area["filas"][0]
        self.assertEqual(fila["especie"], "Pinus patula")
        # 1100 plantas/ha x 12 ha x 100 % de la proporcion de coniferas
        self.assertAlmostEqual(fila["plantas"], 13200.0)
        self.assertAlmostEqual(area["subtotal_plantas"], 13200.0)
        self.assertAlmostEqual(datos["total_general"], 13200.0)
        self.assertEqual(datos["totales_especie"]["Pinus patula"], 13200.0)

    def test_proporcion_queda_sobre_coniferas_seleccionadas(self):
        import app as app_module
        pmf = PMFProyecto.cargar(self.ruta)
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Abies oaxacana", [ClaseDiametrica(18, 10, 5)]))
        pmf.intensidad_corta["R1"]["Abies oaxacana"] = 10
        pmf.guardar(self.ruta)
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba_reforestacion"
            sesion["ruta_actual"] = self.ruta
        respuesta = cliente.post("/reportes/reforestacion/guardar", json={
            "densidad": 1000,
            "selecciones": [{"anualidad": 1,
                             "especies": ["Pinus patula", "Abies oaxacana"]}]})
        self.assertEqual(respuesta.status_code, 200)

        pmf2 = PMFProyecto.cargar(self.ruta)
        datos = pmf2.datos_reforestacion()
        filas = datos["areas"][0]["filas"]
        sumatoria = sum(f["proporcion"] for f in filas)
        self.assertAlmostEqual(sumatoria, 100.0)
        plantas = [f["plantas"] for f in filas]
        self.assertAlmostEqual(sum(plantas), 12000.0)
        self.assertAlmostEqual(plantas[0] + plantas[1], 12000.0)

        cliente2 = app.test_client()
        with cliente2.session_transaction() as sesion2:
            sesion2["usuario"] = "prueba_reforestacion"
            sesion2["ruta_actual"] = self.ruta
        excel2 = cliente2.get("/reportes/reforestacion/exportar/excel")
        hoja2 = load_workbook(BytesIO(excel2.data)).active
        fila2 = next(celda.row for fila in hoja2.iter_rows()
                     for celda in fila if celda.value == "Pinus patula")
        self.assertIn(f"A{fila2}:A{fila2 + 1}",
                      {str(rango) for rango in hoja2.merged_cells.ranges})
        self.assertIn(f"B{fila2}:B{fila2 + 1}",
                      {str(rango) for rango in hoja2.merged_cells.ranges})

        html2 = cliente2.get("/reportes/reforestacion").get_data(as_text=True)
        self._verificar_rejilla_pantalla(html2)

        word2 = cliente2.get("/reportes/reforestacion/exportar/word")
        with zipfile.ZipFile(BytesIO(word2.data)) as comprimido:
            raiz2 = etree.fromstring(comprimido.read("word/document.xml"))
        ns2 = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
        W2 = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
        tabla2 = next(t for t in raiz2.xpath("//w:tbl", namespaces=ns2)
                      if any("Pinus patula" in (c.xpath("string(.)") or "")
                             for r in t.xpath("./w:tr", namespaces=ns2)
                             for c in r.xpath("./w:tc", namespaces=ns2)))
        fusiones = tabla2.xpath("./w:tr/w:tc/w:tcPr/w:vMerge", namespaces=ns2)
        reinicios = [n.get(W2 + "val") for n in fusiones if n.get(W2 + "val") == "restart"]
        continuos = [n.get(W2 + "val") for n in fusiones if n.get(W2 + "val") == "continue"]
        # area, superficie y año fusionados: 1 reinicio + 1 continuidad c/u
        self.assertEqual(len(reinicios), 3)
        self.assertEqual(len(continuos), 3)

    def _verificar_rejilla_pantalla(self, html):
        doc = html_mod.fromstring(html)
        tabla = doc.xpath('//div[@id="cuadro-reforestacion"]//table')[0]
        filas = tabla.xpath('.//tr')
        columnas = 6
        ocupadas = []
        for fila in filas:
            ocupadas.append([False] * columnas)
        for indice, tr in enumerate(filas):
            col = 0
            for td in tr.xpath('./td|./th'):
                while col < columnas and ocupadas[indice][col]:
                    col += 1
                colspan = int(td.get("colspan", "1"))
                rowspan = int(td.get("rowspan", "1"))
                self.assertLessEqual(col + colspan, columnas + 1,
                                     f"fila {indice} desborde de columnas")
                for i in range(indice, min(indice + rowspan, len(filas))):
                    for j in range(col, min(col + colspan, columnas)):
                        self.assertFalse(ocupadas[i][j],
                                         f"superposición en fila {i}, col {j}")
                        ocupadas[i][j] = True
                col += colspan
        for indice in range(len(filas)):
            for j in range(columnas):
                self.assertTrue(ocupadas[indice][j],
                                f"fila {indice} incompleta, col {j} vacía")

    def test_rechaza_latifoliada_y_densidad_invalida(self):
        respuesta = self.cliente.post("/reportes/reforestacion/guardar", json={
            "densidad": 100,
            "selecciones": [{"anualidad": 1, "especies": ["Quercus rugosa"]}]})
        self.assertEqual(respuesta.status_code, 400)
        self.assertFalse(respuesta.get_json()["success"])
        respuesta = self.cliente.post("/reportes/reforestacion/guardar", json={
            "densidad": -5,
            "selecciones": [{"anualidad": 1, "especies": ["Pinus patula"]}]})
        self.assertEqual(respuesta.status_code, 400)
        self.assertFalse(respuesta.get_json()["success"])

    def test_pantalla_muestra_seleccion_y_cuadro(self):
        self.cliente.post("/reportes/reforestacion/guardar", json={
            "densidad": 1100,
            "selecciones": [{"anualidad": 1, "especies": ["Pinus patula"]}]})
        html = self.cliente.get("/reportes/reforestacion").get_data(as_text=True)
        self.assertIn("Pinus patula", html)
        self.assertIn("Quercus rugosa", html)
        self.assertIn("1100", html)
        self.assertIn("13,200", html)
        self.assertIn("Subtotal 1", html)
        self.assertIn("TOTAL GENERAL", html)
        self.assertIn("Exportar cuadro", html)
        self.assertIn("Reforestación", html)

    def test_exportaciones_excel_word_pdf(self):
        self.cliente.post("/reportes/reforestacion/guardar", json={
            "densidad": 1100,
            "selecciones": [{"anualidad": 1, "especies": ["Pinus patula"]}]})
        excel = self.cliente.get("/reportes/reforestacion/exportar/excel")
        self.assertEqual(excel.status_code, 200)
        libro = load_workbook(BytesIO(excel.data))
        hoja = libro.active
        self.assertEqual(hoja["A1"].value, "Cuadro de reforestación")
        fila_patula = next(celda.row for fila in hoja.iter_rows()
                           for celda in fila if celda.value == "Pinus patula")
        self.assertEqual(hoja.cell(fila_patula, 1).value, 1)
        fila_subtotal = next(
            fila[0].row for fila in hoja.iter_rows()
            if isinstance(fila[0].value, str) and fila[0].value.startswith("Subtotal"))
        self.assertEqual(hoja.cell(fila_subtotal, 5).number_format, "#,##0")
        self.assertAlmostEqual(hoja.cell(fila_subtotal, 5).value, 13200.0)

        word = self.cliente.get("/reportes/reforestacion/exportar/word")
        self.assertEqual(word.status_code, 200)
        with zipfile.ZipFile(BytesIO(word.data)) as comprimido:
            xml = comprimido.read("word/document.xml")
        texto = etree.fromstring(xml).xpath("string()") or ""
        self.assertIn("13,200", texto)
        self.assertIn("Interpretación del cuadro", texto)

        pdf = self.cliente.get("/reportes/reforestacion/exportar/pdf")
        self.assertEqual(pdf.status_code, 200)
        self.assertTrue(pdf.data.startswith(b"%PDF"))

    def test_anio_ejecucion_calculado_y_editable(self):
        self.cliente.post("/reportes/reforestacion/guardar", json={
            "densidad": 1100,
            "selecciones": [{"anualidad": 1, "especies": ["Pinus patula"]}]})
        pmf = PMFProyecto.cargar(self.ruta)
        anio_plan = pmf.plan_cortas.anualidades[0].anio
        datos = pmf.datos_reforestacion()
        self.assertEqual(datos["areas"][0]["anio_plan"], anio_plan)
        self.assertEqual(datos["areas"][0]["anio"], anio_plan + 1)

        respuesta = self.cliente.post("/reportes/reforestacion/anio", json={
            "anualidad": 1, "anio": 2030})
        self.assertEqual(respuesta.status_code, 200)
        pmf = PMFProyecto.cargar(self.ruta)
        self.assertEqual(pmf.reforestacion["anios"]["1"], 2030)
        datos = pmf.datos_reforestacion()
        self.assertEqual(datos["areas"][0]["anio"], 2030)

        respuesta = self.cliente.post("/reportes/reforestacion/anio", json={
            "anualidad": 1, "anio": None})
        self.assertEqual(respuesta.status_code, 200)
        pmf = PMFProyecto.cargar(self.ruta)
        self.assertEqual(pmf.reforestacion["anios"], {})
        datos = pmf.datos_reforestacion()
        self.assertEqual(datos["areas"][0]["anio"], anio_plan + 1)

        respuesta = self.cliente.post("/reportes/reforestacion/anio", json={
            "anualidad": 1, "anio": "abc"})
        self.assertEqual(respuesta.status_code, 400)

        html = self.cliente.get("/reportes/reforestacion").get_data(as_text=True)
        self.assertIn("anio-reforestacion", html)
        self.assertIn(f'value="{anio_plan + 1}"', html)
        self.assertIn(f'data-plan="{anio_plan}"', html)
        # En la selección, el año es el del plan (fijo); el editado va en el cuadro.
        self.assertIn(f'data-anio-plan="1">{anio_plan}<', html)

    def test_exportaciones_requieren_seleccion(self):
        respuesta = self.cliente.get("/reportes/reforestacion/exportar/pdf",
                                     follow_redirects=True)
        self.assertEqual(respuesta.status_code, 200)
        self.assertIn("reforestacion", respuesta.request.path)

    def test_superficie_editada_y_restaurada(self):
        self.cliente.post("/reportes/reforestacion/guardar", json={
            "densidad": 1100,
            "selecciones": [{"anualidad": 1, "especies": ["Pinus patula"]}]})
        respuesta = self.cliente.post("/reportes/reforestacion/superficie", json={
            "anualidad": 1, "superficie": 10.0})
        self.assertEqual(respuesta.status_code, 200)
        pmf = PMFProyecto.cargar(self.ruta)
        self.assertEqual(pmf.reforestacion["superficies"]["1"], 10.0)
        datos = pmf.datos_reforestacion()
        self.assertAlmostEqual(datos["areas"][0]["superficie"], 10.0)
        self.assertAlmostEqual(datos["total_general"], 11000.0)

        respuesta = self.cliente.post("/reportes/reforestacion/superficie", json={
            "anualidad": 1, "superficie": None})
        self.assertEqual(respuesta.status_code, 200)
        pmf = PMFProyecto.cargar(self.ruta)
        self.assertEqual(pmf.reforestacion["superficies"], {})
        datos = pmf.datos_reforestacion()
        self.assertAlmostEqual(datos["areas"][0]["superficie"], 12.0)
        self.assertAlmostEqual(datos["total_general"], 13200.0)

        respuesta = self.cliente.post("/reportes/reforestacion/superficie", json={
            "anualidad": 1, "superficie": -3})
        self.assertEqual(respuesta.status_code, 400)

    def test_area_manual_agregar_eliminar(self):
        respuesta = self.cliente.post("/reportes/reforestacion/area_manual/agregar",
                                      json={
            "nombre": "La Rinconada", "anio": 2027, "superficie": 5.0,
            "filas": [{"especie": "Pinus ayacahuite", "proporcion": 60.0},
                      {"especie": "Cupressus lindleyi", "proporcion": 40.0}]})
        self.assertEqual(respuesta.status_code, 200)
        pmf = PMFProyecto.cargar(self.ruta)
        manuales = pmf.reforestacion["manuales"]
        self.assertEqual(len(manuales), 1)
        self.assertEqual(manuales[0]["nombre"], "La Rinconada")
        self.assertEqual(len(manuales[0]["filas"]), 2)

        respuesta = self.cliente.post(
            "/reportes/reforestacion/area_manual/agregar",
            json={"nombre": "Latifoliada", "anio": 2027, "superficie": 5.0,
                  "filas": [{"especie": "Quercus rugosa",
                             "proporcion": 100.0}]})
        self.assertEqual(respuesta.status_code, 400)

        pmf.reforestacion["densidad"] = 1100
        pmf.guardar(self.ruta)
        datos = pmf.datos_reforestacion()
        etiquetas = [a["etiqueta"] for a in datos["areas"]]
        self.assertIn("La Rinconada", etiquetas)
        area = next(a for a in datos["areas"] if a["manual"])
        plantas = {f["especie"]: f["plantas"] for f in area["filas"]}
        # 1100 x 5 ha x 60 % / 40 %
        self.assertAlmostEqual(plantas["Pinus ayacahuite"], 3300.0)
        self.assertAlmostEqual(plantas["Cupressus lindleyi"], 2200.0)
        self.assertAlmostEqual(area["subtotal_plantas"], 5500.0)
        self.assertAlmostEqual(area["subtotal_proporcion"], 100.0)
        self.assertAlmostEqual(datos["totales_especie"]["Cupressus lindleyi"], 2200.0)

        respuesta = self.cliente.post("/reportes/reforestacion/area_manual/eliminar",
                                      json={"id": manuales[0]["id"]})
        self.assertEqual(respuesta.status_code, 200)
        pmf = PMFProyecto.cargar(self.ruta)
        self.assertEqual(pmf.reforestacion["manuales"], [])

        respuesta = self.cliente.post("/reportes/reforestacion/area_manual/agregar",
                                      json={"nombre": "", "anio": 2027,
                                            "superficie": 5.0,
                                            "filas": [{"especie": "Pinus patula",
                                                       "proporcion": 100.0}]})
        self.assertEqual(respuesta.status_code, 400)
        respuesta = self.cliente.post("/reportes/reforestacion/area_manual/agregar",
                                      json={"nombre": "X", "anio": 2027,
                                            "superficie": 5.0, "filas": []})
        self.assertEqual(respuesta.status_code, 400)

    def test_exportaciones_incluyen_area_manual(self):
        self.cliente.post("/reportes/reforestacion/guardar", json={
            "densidad": 1100,
            "selecciones": [{"anualidad": 1, "especies": ["Pinus patula"]}]})
        pmf = PMFProyecto.cargar(self.ruta)
        pmf.agregar_area_manual_reforestacion(
            "La Rinconada", 2027, 5.0,
            [{"especie": "Pinus ayacahuite", "proporcion": 100.0}])
        pmf.guardar(self.ruta)
        cliente2 = app.test_client()
        with cliente2.session_transaction() as sesion:
            sesion["usuario"] = "prueba_reforestacion"
            sesion["ruta_actual"] = self.ruta

        excel = cliente2.get("/reportes/reforestacion/exportar/excel")
        hoja = load_workbook(BytesIO(excel.data)).active
        etiqueta = next(celda.value for fila in hoja.iter_rows()
                        for celda in fila if celda.value == "La Rinconada")
        fila_sup = next(fila[0].row for fila in hoja.iter_rows()
                        if isinstance(fila[0].value, str)
                        and fila[0].value.startswith("Subtotal La Rinconada"))
        self.assertAlmostEqual(hoja.cell(fila_sup, 5).value, 5500.0)
        self.assertAlmostEqual(hoja.cell(fila_sup, 4).value, 100.0)

        word = cliente2.get("/reportes/reforestacion/exportar/word")
        with zipfile.ZipFile(BytesIO(word.data)) as comprimido:
            texto = etree.fromstring(comprimido.read("word/document.xml")).xpath("string()") or ""
        self.assertIn("La Rinconada", texto)
        self.assertIn("5,500", texto)

        pdf = cliente2.get("/reportes/reforestacion/exportar/pdf")
        self.assertEqual(pdf.status_code, 200)
        self.assertTrue(pdf.data.startswith(b"%PDF"))

    def test_plan_cortas_intacto_tras_ajustes(self):
        """Ninguna acción de reforestación altera el Plan de Cortas."""
        self.cliente.post("/reportes/reforestacion/guardar", json={
            "densidad": 1100,
            "selecciones": [{"anualidad": 1, "especies": ["Pinus patula"]}]})
        self.cliente.post("/reportes/reforestacion/superficie", json={
            "anualidad": 1, "superficie": 10.0})
        self.cliente.post("/reportes/reforestacion/anio", json={
            "anualidad": 1, "anio": 2030})
        self.cliente.post("/reportes/reforestacion/area_manual/agregar",
                          json={"nombre": "Extra", "anio": 2031,
                                "superficie": 2.0,
                                "filas": [{"especie": "Pinus rudis",
                                           "proporcion": 100.0}]})
        self.cliente.get("/reportes/reforestacion/exportar/excel")
        self.cliente.get("/reportes/reforestacion/exportar/word")

        self.assertEqual(self._plan_serializado(), self.plan_antes,
                         "Los ajustes de reforestación modificaron el Plan de Cortas")

        tabla8_antes = self.cliente.get("/cortas").get_data(as_text=True)
        pmf = PMFProyecto.cargar(self.ruta)
        pmf.eliminar_area_manual_reforestacion("extra-ficticio")
        pmf.guardar(self.ruta)
        self.assertEqual(self.cliente.get("/cortas").get_data(as_text=True),
                         tabla8_antes,
                         "La Tabla 8 del Plan de Cortas cambió tras reforestación")
        self.assertEqual(self._plan_serializado(), self.plan_antes)


if __name__ == "__main__":
    unittest.main()
