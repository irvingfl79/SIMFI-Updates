import datetime
import io

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Cm, Pt, RGBColor
from reportlab.lib import colors
from reportlab.lib.pagesizes import landscape, letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from interpretacion_forestal import construir_contexto_interpretacion
from reporte_densidad import (_agregar_nombre_cientifico, _configurar_pie, _margenes_celda,
                              _tabla, VERDE, VERDE_CLARO, VERDE_OSCURO, FIRMA_EXPORTACION)
from reportes_tecnicos import _drawing, _grafica_word_png


NIVELES = {"ejecutivo", "tecnico", "completo"}


def _filas(data):
    return [fila for fila in data.get("filas", []) if not fila.get("_type")]


def construir_contexto(pmf):
    return construir_contexto_interpretacion(pmf)


def _confianza(contexto):
    nivel = contexto.get("confianza", "Bajo")
    if nivel == "Bajo":
        return nivel, "No existen datos de inventario suficientes para los indicadores principales."
    if contexto["guias"]:
        return nivel, "El inventario permite cálculo; las guías disponibles sólo respaldan las combinaciones donde existe modelo aplicable."
    return nivel, "El inventario permite cálculos descriptivos, pero no hay referencia de guía de densidad válida para contrastar la condición."


def _texto_rodal(rodal):
    return rodal.get("interpretacion", "")


def _configurar_documento(documento, pmf, nivel):
    seccion = documento.sections[0]
    seccion.top_margin, seccion.bottom_margin = Cm(1.5), Cm(1.7)
    seccion.left_margin, seccion.right_margin = Cm(1.8), Cm(1.8)
    estilos = documento.styles
    estilos["Normal"].font.name, estilos["Normal"].font.size = "Aptos", Pt(9.5)
    estilos["Normal"].paragraph_format.space_after = Pt(5)
    for nombre, tamano in (("Title", 17), ("Heading 1", 13), ("Heading 2", 10.5)):
        estilos[nombre].font.name, estilos[nombre].font.size = "Aptos Display", Pt(tamano)
        estilos[nombre].font.color.rgb = RGBColor(15, 61, 35)
    encabezado = documento.add_table(1, 2)
    encabezado.autofit = False
    logo, titulo = encabezado.rows[0].cells
    logo.width, titulo.width = Cm(5.2), Cm(12.2)
    logo.paragraphs[0].add_run().add_picture(__import__("os").path.join(__import__("os").path.dirname(__file__), "img", "SIMFI GDE.png"), width=Cm(4.8))
    p = titulo.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = p.add_run("SIMFI"); run.bold = True; run.font.size = Pt(22); run.font.color.rgb = RGBColor(15, 61, 35)
    p.add_run("\nSistema para el Manejo Forestal Mejorado por Dr.PIFL").font.size = Pt(9)
    p.add_run("\nREPORTE INTEGRAL DE INTERPRETACIÓN FORESTAL").bold = True
    for celda in encabezado.rows[0].cells:
        _margenes_celda(celda, 0, 0, 40, 0)
    documento.add_paragraph()
    info = documento.add_table(3, 4)
    valores = [("Predio", pmf.predio or pmf.nombre or "No registrado", "Nivel", nivel.title()),
               ("Propietario", pmf.propietario or "No registrado", "Fecha", datetime.date.today().strftime("%d/%m/%Y")),
               ("Estado / municipio", " / ".join(x for x in (pmf.estado, pmf.municipio) if x) or "No registrado", "Programa", pmf.nombre or "No registrado")]
    for fila, valores_fila in zip(info.rows, valores):
        for indice, valor in enumerate(valores_fila):
            fila.cells[indice].text = valor; _margenes_celda(fila.cells[indice])
            if indice % 2 == 0:
                from reporte_densidad import _sombrear
                _sombrear(fila.cells[indice], VERDE_CLARO)
                fila.cells[indice].paragraphs[0].runs[0].bold = True
            for run in fila.cells[indice].paragraphs[0].runs: run.font.size = Pt(8)
    _configurar_pie(documento, "Interpretación Integral")


def generar_word_integral(pmf, nivel="tecnico"):
    nivel = nivel if nivel in NIVELES else "tecnico"
    contexto = construir_contexto(pmf)
    confianza, explicacion_confianza = _confianza(contexto)
    documento = Document(); _configurar_documento(documento, pmf, nivel)
    numero = 1
    documento.add_heading(f"{numero}. Resumen general", level=1)
    total = contexto["existencias"].get("total_vol_umm", 0)
    posibilidad = contexto["existencias"].get("total_pos_umm", 0)
    dominante = max(contexto["resumen"].get("filas", []), key=lambda fila: fila.get("existencias", 0), default=None)
    texto = f"El inventario integra {len(contexto['rodales'])} UMM."
    if dominante:
        texto += f" {dominante['especie']} concentra la mayor existencia por especie."
    documento.add_paragraph(texto)
    _tabla(documento, ("Indicador", "Resultado", "Unidad"), [("UMM evaluadas", len(contexto["rodales"]), "número"), ("Existencias", f"{total:,.3f}", "m3 VTA"), ("Posibilidad", f"{posibilidad:,.3f}", "m3 VTA"), ("Nivel de confianza", confianza, "cualitativo")],
           titulo="Indicadores generales", numero_tabla=1)
    numero += 1
    numero += 1
    documento.add_heading(f"{numero}. Interpretación por rodal", level=1)
    for rodal in contexto["rodales"]:
        documento.add_heading(f"UMM {rodal['id']}", level=2)
        documento.add_paragraph(_texto_rodal(rodal))
        if rodal.get("intervencion"):
            documento.add_paragraph(rodal["intervencion"])
    if len(contexto["rodales"]) > 1:
        numero += 1
        documento.add_heading(f"{numero}. Comparación entre rodales", level=1)
        _tabla(documento, ("UMM", "Árboles/ha", "AB m2/ha", "Volumen m3 VTA", "Posibilidad m3 VTA"), [(r["id"], f"{r['n']:,.0f}", f"{r['g']:,.2f}", f"{r['volumen']:,.3f}", f"{r['posibilidad']:,.3f}") for r in contexto["rodales"]],
               titulo="Comparación entre rodales", numero_tabla=2)
        mayor = max(contexto["rodales"], key=lambda r: r["volumen"])
        documento.add_paragraph(f"La UMM {mayor['id']} registra el mayor volumen dentro del inventario evaluado.")
        documento.add_heading("Gráfica comparativa de existencias", level=2)
        p = documento.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(_grafica_word_png([(r["id"], r["volumen"]) for r in contexto["rodales"]]), width=Cm(16.5))
    if contexto["guias"]:
        numero += 1
        documento.add_heading(f"{numero}. Guías de densidad disponibles", level=1)
    if contexto["guias"]:
        _tabla(documento, ("UMM", "Especie", "Guía disponible", "Región"), [(g["rodal"], g["especie"], g["modelo"], g["region"]) for g in contexto["guias"]],
               titulo="Guías de densidad disponibles", numero_tabla=3)
    if contexto["alertas"]:
        numero += 1; documento.add_heading(f"{numero}. Observaciones", level=1)
        for alerta in contexto["alertas"]: documento.add_paragraph(alerta, style="List Bullet")
    numero += 1; documento.add_heading(f"{numero}. Conclusiones", level=1)
    for hallazgo in contexto["hallazgos"]: documento.add_paragraph(hallazgo, style="List Bullet")
    numero += 1; documento.add_heading(f"{numero}. Fuentes", level=1)
    documento.add_paragraph("Inventario y ecuaciones registrados en el proyecto SIMFI.")
    if contexto["guias"]: documento.add_paragraph("Catálogo de guías de densidad SIMFI para las especies con modelo aplicable.")
    salida = io.BytesIO(); documento.save(salida); salida.seek(0); return salida


def generar_pdf_integral(pmf, nivel="tecnico"):
    contexto = construir_contexto(pmf); nivel = nivel if nivel in NIVELES else "tecnico"
    salida = io.BytesIO(); documento = SimpleDocTemplate(salida, pagesize=landscape(letter), leftMargin=1.3*cm, rightMargin=1.3*cm, topMargin=1.2*cm, bottomMargin=1.2*cm)
    estilos = getSampleStyleSheet(); estilos.add(ParagraphStyle("Simfi", parent=estilos["Title"], textColor=colors.HexColor("#0F3D23")))
    elementos = [Paragraph("SIMFI - REPORTE DE INTERPRETACIÓN FORESTAL", estilos["Simfi"]), Paragraph(f"{pmf.predio or pmf.nombre or 'Proyecto sin nombre'} | {datetime.date.today().isoformat()}", estilos["Heading2"]), Spacer(1, 8)]
    total, posibilidad = contexto["existencias"].get("total_vol_umm", 0), contexto["existencias"].get("total_pos_umm", 0)
    elementos += [Paragraph("1. Resumen general", estilos["Heading2"]), Paragraph(f"El inventario integra {len(contexto['rodales'])} UMM.", estilos["BodyText"])]
    filas = [["Indicador", "Resultado", "Unidad"], ["Existencias", f"{total:,.3f}", "m3 VTA"], ["Posibilidad", f"{posibilidad:,.3f}", "m3 VTA"]]
    tabla = Table(filas, repeatRows=1); tabla.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,0), colors.HexColor("#1A5632")), ("TEXTCOLOR", (0,0), (-1,0), colors.white), ("GRID", (0,0), (-1,-1), .3, colors.grey), ("FONTSIZE", (0,0), (-1,-1), 8), ("PADDING", (0,0), (-1,-1), 4)])); elementos += [tabla, Spacer(1, 8), Paragraph("2. Interpretación por rodal", estilos["Heading2"])]
    for rodal in contexto["rodales"]:
        elementos += [Paragraph(f"UMM {rodal['id']}", estilos["Heading3"]), Paragraph(_texto_rodal(rodal), estilos["BodyText"])]
        if rodal.get("intervencion"):
            elementos.append(Paragraph(rodal["intervencion"], estilos["BodyText"]))
    if len(contexto["rodales"]) > 1:
        elementos += [Paragraph("3. Comparación entre rodales", estilos["Heading2"]), _drawing([(r["id"], r["volumen"]) for r in contexto["rodales"]]), Spacer(1, 6)]
    if contexto["guias"]:
        elementos.append(Paragraph("4. Guías de densidad disponibles", estilos["Heading2"]))
        elementos.append(Paragraph("Se listan sólo modelos aplicables a las especies registradas.", estilos["BodyText"]))
    if contexto["alertas"]:
        elementos.append(Paragraph("Observaciones", estilos["Heading2"]))
        elementos += [Paragraph("- " + alerta, estilos["BodyText"]) for alerta in contexto["alertas"]]
    elementos += [Paragraph("Conclusiones", estilos["Heading2"])]
    elementos += [Paragraph("- " + hallazgo, estilos["BodyText"]) for hallazgo in contexto["hallazgos"]]
    elementos += [Paragraph("Fuentes", estilos["Heading2"]), Paragraph("Inventario y ecuaciones registrados en el proyecto SIMFI.", estilos["BodyText"]), Spacer(1, 8), Paragraph(FIRMA_EXPORTACION, estilos["BodyText"])]
    documento.build(elementos); salida.seek(0); return salida
