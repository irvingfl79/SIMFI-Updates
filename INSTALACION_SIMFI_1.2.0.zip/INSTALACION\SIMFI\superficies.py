"""Cuadro de clasificación de superficies, aislado de los cálculos forestales."""

from io import BytesIO

RESTRINGIDAS = (
    ("anp", "a) Áreas naturales protegidas."),
    ("habitat", "b) Superficies para conservar y proteger el hábitat existente de especies y subespecies de flora y fauna silvestre en riesgo."),
    ("riberenia", "c) Franja protectora de vegetación ribereña (cauces y cuerpos de agua)."),
    ("pendientes", "d) Superficies con pendientes mayores al cien por ciento o cuarenta y cinco grados."),
    ("altitud", "e) Superficies arriba de los 3,000 metros sobre el nivel del mar."),
    ("manglar", "f) Superficies con vegetación de manglar y bosque mesófilo de montaña."),
)
DIRECTAS = (
    ("produccion", "II. Áreas de producción"),
    ("restauracion", "III. Áreas de restauración"),
    ("proteccion", "IV. Áreas de protección forestal declaradas por la Secretaría"),
    ("otros", "V. Áreas de otros usos"),
)
CLAVES_CAPTURA = tuple(clave for clave, _ in RESTRINGIDAS + DIRECTAS)


def formato_numero(valor):
    return f"{float(valor or 0):,.3f}"


def captura_inicial(datos):
    datos = datos if isinstance(datos, dict) else {}
    return {
        situacion: {
            clave: float(datos.get(situacion, {}).get(clave, 0) or 0)
            for clave in CLAVES_CAPTURA
        }
        for situacion in ("anterior", "actual")
    }


def leer_captura(formulario):
    captura = {"anterior": {}, "actual": {}}
    for situacion in captura:
        for clave in CLAVES_CAPTURA:
            texto = formulario.get(f"{situacion}_{clave}", "")
            try:
                valor = numero_superficie(texto)
            except ValueError as exc:
                raise ValueError("Las hectáreas deben ser valores numéricos.") from exc
            if valor < 0:
                raise ValueError("Las hectáreas no pueden ser negativas.")
            captura[situacion][clave] = valor
    return captura


def numero_superficie(valor):
    texto = str(valor or "").strip().replace(" ", "").replace("\u00a0", "")
    if not texto:
        return 0.0
    if "." in texto and "," in texto:
        decimal = "." if texto.rfind(".") > texto.rfind(",") else ","
        miles = "," if decimal == "." else "."
        texto = texto.replace(miles, "").replace(decimal, ".")
    elif texto.count(",") > 1:
        partes = texto.split(",")
        texto = "".join(partes) if all(len(parte) == 3 for parte in partes[1:]) else "".join(partes[:-1]) + "." + partes[-1]
    elif texto.count(".") > 1:
        partes = texto.split(".")
        texto = "".join(partes) if all(len(parte) == 3 for parte in partes[1:]) else "".join(partes[:-1]) + "." + partes[-1]
    elif "," in texto:
        texto = texto.replace(",", ".")
    return float(texto)


def calcular_cuadro(captura):
    captura = captura_inicial(captura)
    restringidas = {
        situacion: sum(captura[situacion][clave] for clave, _ in RESTRINGIDAS)
        for situacion in ("anterior", "actual")
    }
    totales = {
        situacion: restringidas[situacion] + sum(
            captura[situacion][clave] for clave, _ in DIRECTAS
        )
        for situacion in ("anterior", "actual")
    }

    def fila(clave, nombre, nivel, anterior, actual, editable=False):
        porcentaje_anterior = anterior / totales["anterior"] * 100 if totales["anterior"] else 0.0
        porcentaje_actual = actual / totales["actual"] * 100 if totales["actual"] else 0.0
        variacion = anterior - actual
        porcentaje_variacion = (
            (variacion / anterior * 100 if anterior else 0.0)
            if clave == "total"
            else porcentaje_anterior - porcentaje_actual
        )
        return {
            "clave": clave, "nombre": nombre, "nivel": nivel, "editable": editable,
            "anterior": anterior, "porcentaje_anterior": porcentaje_anterior,
            "actual": actual, "porcentaje_actual": porcentaje_actual,
            "variacion": variacion,
            "porcentaje_variacion": porcentaje_variacion,
        }

    filas = [fila("restringidas", "I. Áreas de conservación y aprovechamiento restringido", "principal", restringidas["anterior"], restringidas["actual"])]
    filas.extend(fila(clave, nombre, "inciso", captura["anterior"][clave], captura["actual"][clave], True) for clave, nombre in RESTRINGIDAS)
    filas.extend(fila(clave, nombre, "principal", captura["anterior"][clave], captura["actual"][clave], True) for clave, nombre in DIRECTAS)
    filas.append(fila("total", "Superficie total", "total", totales["anterior"], totales["actual"]))
    return {"filas": filas, "captura": captura}


def exportar_excel(cuadro):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill

    libro = Workbook()
    hoja = libro.active
    hoja.title = "Superficies"
    hoja.merge_cells("A1:G1")
    hoja["A1"] = "Cuadro de clasificación de superficies"
    hoja["A1"].font = Font(bold=True, size=14, color="FFFFFF")
    hoja["A1"].fill = PatternFill("solid", fgColor="1A5632")
    hoja["A1"].alignment = Alignment(horizontal="center")
    hoja.append(["Clasificación de superficies", "Situación anterior: ha", "Situación anterior: %", "Situación actual: ha", "Situación actual: %", "Variación: ha", "Variación: %"])
    for celda in hoja[2]:
        celda.font = Font(bold=True, color="183126")
        celda.fill = PatternFill("solid", fgColor="AABF91")
        celda.alignment = Alignment(horizontal="center", wrap_text=True)
    for fila in cuadro["filas"]:
        hoja.append([fila["nombre"], fila["anterior"], fila["porcentaje_anterior"],
                      fila["actual"], fila["porcentaje_actual"], fila["variacion"],
                      fila["porcentaje_variacion"]])
        numero_fila = hoja.max_row
        if fila["nivel"] == "principal":
            for celda in hoja[numero_fila]:
                celda.font = Font(bold=True)
                celda.fill = PatternFill("solid", fgColor="EDF2E9")
        elif fila["nivel"] == "total":
            for celda in hoja[numero_fila]:
                celda.font = Font(bold=True, color="FFFFFF")
                celda.fill = PatternFill("solid", fgColor="486C37")
        for columna in range(2, 8):
            hoja.cell(numero_fila, columna).number_format = "0.00"
    hoja.column_dimensions["A"].width = 95
    for columna in "BCDEFG":
        hoja.column_dimensions[columna].width = 20
    hoja.freeze_panes = "B3"
    salida = BytesIO()
    libro.save(salida)
    salida.seek(0)
    return salida
