import unittest

from ai_interpretation_service import (AIInterpretationService,
                                       limpiar_cache_estado)
from ia_config import cargar_config


class ProveedorPrueba:
    def __init__(self, disponible=True, ok=True, motor="prueba"):
        self.disponible = disponible
        self.ok = ok
        self.motor = motor
        # Nombre distinto por rol, como los proveedores reales
        # ("ollama_local" frente a "ia_en_linea").
        self.nombre = "prueba_" + motor
        self.llamadas = []

    def estado(self, config):
        return {"disponible": self.disponible, "mensaje": self.motor, "modelos": []}

    def interpretar(self, datos, modulo, contexto, config):
        self.llamadas.append((datos, modulo, contexto))
        return {"ok": self.ok, "texto": "texto " + self.motor if self.ok else None,
                "motor": self.motor, "modelo": self.motor,
                "mensaje": None if self.ok else "fallo " + self.motor}


class ServicioInterpretacionTest(unittest.TestCase):
    def setUp(self):
        limpiar_cache_estado()
        self.config = cargar_config()

    def tearDown(self):
        limpiar_cache_estado()

    def test_automatico_prefiere_online_disponible(self):
        online, local = ProveedorPrueba(motor="online"), ProveedorPrueba(motor="local")
        resultado = AIInterpretationService(local, online).interpret({"v": 1}, "turnos", "contexto", self.config)
        self.assertTrue(resultado["ok"])
        self.assertEqual(resultado["motor"], "online")
        self.assertEqual(len(local.llamadas), 0)

    def test_automatico_recurre_a_ollama_si_online_falla(self):
        online, local = ProveedorPrueba(ok=False, motor="online"), ProveedorPrueba(motor="local")
        resultado = AIInterpretationService(local, online).interpret({"v": 1}, "turnos", "contexto", self.config)
        self.assertTrue(resultado["ok"])
        self.assertEqual(resultado["motor"], "local")
        self.assertEqual(len(local.llamadas), 1)

    def test_automatico_recurre_a_ollama_si_online_no_disponible(self):
        online, local = ProveedorPrueba(disponible=False, motor="online"), ProveedorPrueba(motor="local")
        resultado = AIInterpretationService(local, online).interpret({"v": 1}, "turnos", "contexto", self.config)
        self.assertTrue(resultado["ok"])
        self.assertEqual(resultado["motor"], "local")

    def test_modo_local_no_consulta_online(self):
        self.config["modo"] = "local"
        online, local = ProveedorPrueba(motor="online"), ProveedorPrueba(motor="local")
        resultado = AIInterpretationService(local, online).interpret({}, "turnos", "contexto", self.config)
        self.assertEqual(resultado["motor"], "local")
        self.assertEqual(len(online.llamadas), 0)


class ProveedorContado(ProveedorPrueba):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.sondeos = 0

    def estado(self, config):
        self.sondeos += 1
        return super().estado(config)


class CacheDisponibilidadTest(unittest.TestCase):
    def setUp(self):
        limpiar_cache_estado()
        self.config = cargar_config()

    def tearDown(self):
        limpiar_cache_estado()

    def test_el_sondeo_no_se_repite_dentro_del_ttl(self):
        online, local = ProveedorContado(motor="online"), ProveedorContado(motor="local")
        servicio = AIInterpretationService(local, online)
        servicio.estado(self.config)
        servicio.estado(self.config)
        self.assertEqual(online.sondeos, 1)
        self.assertEqual(local.sondeos, 1)

    def test_limpiar_cache_obliga_a_sondear_de_nuevo(self):
        online, local = ProveedorContado(motor="online"), ProveedorContado(motor="local")
        servicio = AIInterpretationService(local, online)
        servicio.estado(self.config)
        limpiar_cache_estado()
        servicio.estado(self.config)
        self.assertEqual(online.sondeos, 2)

    def test_un_cambio_de_configuracion_vuelve_a_sondear(self):
        online, local = ProveedorContado(motor="online"), ProveedorContado(motor="local")
        servicio = AIInterpretationService(local, online)
        servicio.estado(self.config)
        self.config["en_linea"]["modelo"] = "otro-modelo"
        servicio.estado(self.config)
        self.assertEqual(online.sondeos, 2)

    def test_interpret_reutiliza_la_disponibilidad_cacheada(self):
        online, local = ProveedorContado(motor="online"), ProveedorContado(motor="local")
        servicio = AIInterpretationService(local, online)
        servicio.estado(self.config)
        servicio.interpret({"v": 1}, "turnos", "contexto", self.config)
        self.assertEqual(online.sondeos, 1)
