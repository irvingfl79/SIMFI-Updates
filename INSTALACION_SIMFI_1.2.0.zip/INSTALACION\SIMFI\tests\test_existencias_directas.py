"""Pruebas del tipo de inventario "Valores de existencias".

Los rodales tipo existencias capturan N/ha, AB/ha y V/ha directamente por
especie y esos valores se integran a los cuadros oficiales como renglones.
"""

import os
import tempfile
import unittest

import app as app_module
from modelos import ExistenciaDirecta, PMFProyecto, Rodal


def _proyecto_existente(ruta):
    pmf = PMFProyecto("Directos", predio="Directos")
    pmf.agregar_rodal(Rodal("RX", 8, sitios=0, area_sitio_m2=0,
                            tipo_inventario="existencias"))
    pmf.agregar_especie("Pinus patula")
    pmf.agregar_especie("Encino")
    assert pmf.guardar(ruta)
    return pmf


class ModeloExistenciasDirectasTest(unittest.TestCase):
    def test_validacion_rechaza_negativos(self):
        for kwargs in ({"arboles_ha": -1}, {"ab_ha": -1}, {"vol_ha": -1},
                       {"arboles_ha": "abc"}):
            with self.assertRaises(ValueError, msg=str(kwargs)):
                ExistenciaDirecta("RX", "Pino", **kwargs)

    def test_fijar_crea_actualiza_y_guarda_ceros(self):
        pmf = PMFProyecto("D")
        pmf.agregar_rodal(Rodal("RX", 8, tipo_inventario="existencias"))
        pmf.fijar_existencia_directa("RX", "Pino", 100, 12.5, 80.0)
        registro = pmf.buscar_existencia_directa("RX", "Pino")
        self.assertEqual((registro.arboles_ha, registro.ab_ha, registro.vol_ha),
                         (100.0, 12.5, 80.0))
        pmf.fijar_existencia_directa("RX", "Pino", 110, 13.0, 85.0)
        self.assertEqual(len(pmf.existencias_directas), 1)
        self.assertEqual(pmf.buscar_existencia_directa("RX", "Pino").vol_ha, 85.0)
        # Los ceros explicitos se guardan (el borrado vive en la ruta, con todo vacio).
        pmf.fijar_existencia_directa("RX", "Pino", 0, 0, 0)
        registro = pmf.buscar_existencia_directa("RX", "Pino")
        self.assertIsNotNone(registro)
        self.assertEqual((registro.arboles_ha, registro.ab_ha, registro.vol_ha),
                         (0.0, 0.0, 0.0))

    def test_valores_fluyen_a_los_cuadros(self):
        pmf = PMFProyecto("D")
        pmf.agregar_rodal(Rodal("RX", 8, tipo_inventario="existencias"))
        pmf.fijar_existencia_directa("RX", "Pino", 100, 12.5, 80.0)
        self.assertEqual(pmf.especies_inventario_rodal("RX"), ["Pino"])
        valores = pmf._calc_valores_rodal_especie("RX", "Pino")
        self.assertAlmostEqual(valores["Arb/ha"], 100.0)
        self.assertAlmostEqual(valores["AB m2/ha"], 12.5)
        self.assertAlmostEqual(valores["ER m3/ha"], 80.0)
        self.assertAlmostEqual(valores["ERT VTA"], 640.0)
        filas = [f for f in pmf.cuadro_existencias()["filas"] if not f.get("_type")]
        self.assertEqual(len(filas), 1)
        self.assertAlmostEqual(filas[0]["vol_umm"], 640.0)
        # Sin incrementos capturados no hay renglon en incrementos (separados).
        filas_inc = [f for f in pmf.resumen_incrementos()["filas"] if not f.get("_type")]
        self.assertEqual(filas_inc, [])

    def test_sobreviven_al_guardar_y_cargar(self):
        temporal = tempfile.TemporaryDirectory()
        try:
            ruta = os.path.join(temporal.name, "d.json")
            pmf = PMFProyecto("D")
            pmf.agregar_rodal(Rodal("RX", 8, tipo_inventario="existencias"))
            pmf.fijar_existencia_directa("RX", "Pino", 100, 12.5, 80.0)
            self.assertTrue(pmf.guardar(ruta))
            recargado = PMFProyecto.cargar(ruta)
            self.assertEqual(len(recargado.existencias_directas), 1)
            self.assertAlmostEqual(recargado.existencias_directas[0].vol_ha, 80.0)
            tambien = PMFProyecto.desde_dict(
                __import__("json").load(open(ruta, encoding="utf-8")))
            self.assertEqual(len(tambien.existencias_directas), 1)
        finally:
            temporal.cleanup()

    def test_proyectos_anteriores_cargan_igual(self):
        pmf = PMFProyecto("Viejo")
        self.assertEqual(pmf.existencias_directas, [])
        self.assertEqual(PMFProyecto.desde_dict({"nombre": "X"}).existencias_directas, [])

    def test_incrementos_opcionales_y_validados(self):
        pmf = PMFProyecto("D")
        pmf.agregar_rodal(Rodal("RX", 8, tipo_inventario="existencias"))
        registro = pmf.fijar_incremento_directo("RX", "Pino", 100, 12.5,
                                                tp=12.0, ica_ha=3.5, ica_pct=3.5,
                                                ima_ha=4.0, edad=20.0,
                                                dq_cm=22.5, h_m=18.0)
        self.assertEqual((registro.tp, registro.ica_ha, registro.ica_pct,
                          registro.ima_ha, registro.edad,
                          registro.dq_cm, registro.h_m),
                         (12.0, 3.5, 3.5, 4.0, 20.0, 22.5, 18.0))
        for malo in ({"tp": 0}, {"tp": -2}, {"edad": 0}, {"ica_ha": -1},
                     {"arboles_ha": -1}, {"arboles_ha": "abc"},
                     {"dq_cm": -1}, {"h_m": "abc"}):
            with self.assertRaises(ValueError, msg=str(malo)):
                kwargs = {"arboles_ha": 100, "ab_ha": 12.5}
                kwargs.update(malo)
                pmf.fijar_incremento_directo("RX", "Pino", **kwargs)

    def test_incrementos_fluyen_al_resumen(self):
        pmf = PMFProyecto("D")
        pmf.agregar_rodal(Rodal("RX", 8, tipo_inventario="existencias"))
        pmf.fijar_incremento_directo("RX", "Pino", 100, 12.5,
                                      tp=12.0, ica_ha=3.5, ica_pct=3.5,
                                      ima_ha=4.0, edad=20.0)
        filas = [f for f in pmf.resumen_incrementos()["filas"] if not f.get("_type")]
        self.assertEqual(len(filas), 1)
        fila = filas[0]
        self.assertAlmostEqual(fila["arb_ha"], 100.0)
        self.assertAlmostEqual(fila["ab"], 12.5)
        self.assertAlmostEqual(fila["tp"], 12.0)
        self.assertAlmostEqual(fila["ica"], 3.5)
        self.assertAlmostEqual(fila["ica_pct"], 3.5)
        self.assertAlmostEqual(fila["ima"], 4.0)
        self.assertAlmostEqual(fila["edad"], 20.0)

    def test_grupos_son_independientes(self):
        pmf = PMFProyecto("D")
        pmf.agregar_rodal(Rodal("RX", 8, tipo_inventario="existencias"))
        # Solo incrementos: hay renglon en incrementos pero no en existencias.
        pmf.fijar_incremento_directo("RX", "Pino", 90, 11.0, tp=10.0)
        filas_inc = [f for f in pmf.resumen_incrementos()["filas"] if not f.get("_type")]
        self.assertEqual(len(filas_inc), 1)
        filas_exi = [f for f in pmf.cuadro_existencias()["filas"] if not f.get("_type")]
        self.assertEqual(filas_exi, [])
        # Solo existencias: hay renglon en existencias pero no en incrementos.
        pmf2 = PMFProyecto("D2")
        pmf2.agregar_rodal(Rodal("RY", 8, tipo_inventario="existencias"))
        pmf2.fijar_existencia_directa("RY", "Pino", 100, 12.5, 80.0)
        filas_inc2 = [f for f in pmf2.resumen_incrementos()["filas"] if not f.get("_type")]
        self.assertEqual(filas_inc2, [])
        filas_exi2 = [f for f in pmf2.cuadro_existencias()["filas"] if not f.get("_type")]
        self.assertEqual(len(filas_exi2), 1)

    def test_sin_renglones_no_hay_subtotal_ni_superficie(self):
        # Regresion: los rodales sin renglones generaban subtotales en ceros.
        pmf = PMFProyecto("D")
        pmf.agregar_rodal(Rodal("AR-1983", 13.497, sitios=0, area_sitio_m2=0,
                                tipo_inventario="existencias"))
        pmf.agregar_rodal(Rodal("AR-1984", 5.0, sitios=0, area_sitio_m2=0,
                                tipo_inventario="existencias"))
        pmf.agregar_especie("Pino")
        pmf.fijar_existencia_directa("AR-1983", "Pino", 310.0, 20.9, 150.0)
        pmf.fijar_incremento_directo("AR-1983", "Pino", 310.0, 20.9, tp=8.0)
        pmf.fijar_existencia_directa("AR-1984", "Pino", 200, 15.0, 100.0)
        datos = pmf.resumen_incrementos()
        datos_filas = [f for f in datos["filas"] if not f.get("_type")]
        subs = [f for f in datos["filas"] if f.get("_type") == "subtotal"]
        self.assertEqual([f["rodal"] for f in datos_filas], ["AR-1983"])
        self.assertEqual(len(subs), 1)
        self.assertAlmostEqual(subs[0]["arb_ha"], 310.0)
        self.assertAlmostEqual(datos["total_superficie"], 13.497)

    def test_incrementos_sobreviven_al_guardar_y_cargar(self):
        temporal = tempfile.TemporaryDirectory()
        try:
            ruta = os.path.join(temporal.name, "d.json")
            pmf = PMFProyecto("D")
            pmf.agregar_rodal(Rodal("RX", 8, tipo_inventario="existencias"))
            pmf.fijar_incremento_directo("RX", "Pino", 100, 12.5,
                                          tp=12.0, ica_ha=3.5, ica_pct=3.5,
                                          ima_ha=4.0, edad=20.0)
            self.assertTrue(pmf.guardar(ruta))
            recargado = PMFProyecto.cargar(ruta)
            registro = recargado.buscar_incremento_directo("RX", "Pino")
            self.assertEqual((registro.tp, registro.ica_ha, registro.ica_pct,
                              registro.ima_ha, registro.edad),
                             (12.0, 3.5, 3.5, 4.0, 20.0))
            tambien = PMFProyecto.desde_dict(
                __import__("json").load(open(ruta, encoding="utf-8")))
            self.assertEqual(len(tambien.incrementos_directos), 1)
        finally:
            temporal.cleanup()


class CapturaExistenciasTest(unittest.TestCase):
    def setUp(self):
        self.temporal = tempfile.TemporaryDirectory()
        self.originales = (app_module.DATA_DIR, app_module.PROJECTS_DIR,
                           app_module.PROJECT_STATE_DIR, app_module.LAST_PROJECT_FILE)
        app_module.DATA_DIR = self.temporal.name
        app_module.PROJECTS_DIR = os.path.join(self.temporal.name, "projects")
        app_module.PROJECT_STATE_DIR = os.path.join(self.temporal.name, "state")
        app_module.LAST_PROJECT_FILE = os.path.join(
            app_module.PROJECT_STATE_DIR, "ultimo_proyecto.json")
        os.makedirs(app_module.PROJECTS_DIR, exist_ok=True)
        self.ruta = os.path.join(app_module.PROJECTS_DIR, "directos.json")
        _proyecto_existente(self.ruta)
        self.cliente = app_module.app.test_client()
        with self.cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["ruta_actual"] = self.ruta

    def tearDown(self):
        (app_module.DATA_DIR, app_module.PROJECTS_DIR,
         app_module.PROJECT_STATE_DIR, app_module.LAST_PROJECT_FILE) = self.originales
        self.temporal.cleanup()

    def test_pantalla_muestra_especies_del_catalogo(self):
        html = self.cliente.get("/inventario/existencias/RX").get_data(as_text=True)
        self.assertEqual(self.cliente.get("/inventario/existencias/RX").status_code, 200)
        self.assertIn("Pinus patula", html)
        self.assertIn("Encino", html)

    def test_selector_resalta_especies_con_registros(self):
        html_antes = self.cliente.get("/inventario/existencias/RX").get_data(as_text=True)
        self.assertNotIn("color:#1B5E3F", html_antes)
        self.cliente.post(
            "/inventario/existencias/RX/guardar",
            data={"grupo": "existencias", "especie_sel": "Pinus patula",
                  "arb_Pinus patula": "100", "ab_Pinus patula": "12.5",
                  "vol_Pinus patula": "80"})
        html = self.cliente.get("/inventario/existencias/RX").get_data(as_text=True)
        self.assertIn("color:#1B5E3F", html)
        # Solo la especie con registro lleva el resaltado.
        self.assertEqual(html.count("color:#1B5E3F"), 1)

    def test_boton_importar_solo_en_incrementos(self):
        base = "/inventario/existencias/RX?esp=Pinus+patula&grupo="
        html_inc = self.cliente.get(base + "incrementos").get_data(as_text=True)
        self.assertIn("Importar datos", html_inc)
        self.assertIn("modal-importar-incrementos", html_inc)
        self.assertIn("Especie | N/ha | AB/ha | DQ (cm)", html_inc)
        html_exi = self.cliente.get(base + "existencias").get_data(as_text=True)
        self.assertNotIn("Importar datos", html_exi)
        self.assertNotIn("modal-importar-incrementos", html_exi)

    def test_importar_pegado_multiplica_especies(self):
        respuesta = self.cliente.post(
            "/inventario/existencias/RX/guardar",
            data={"grupo": "incrementos",
                  "arb_Pinus patula": "100", "ab_Pinus patula": "12.5",
                  "dq_Pinus patula": "22.5", "h_Pinus patula": "18",
                  "tp_Pinus patula": "12", "ica_Pinus patula": "3.5",
                  "icapct_Pinus patula": "3.5", "ima_Pinus patula": "4",
                  "edad_Pinus patula": "20",
                  "arb_Encino": "80", "ab_Encino": "9",
                  "dq_Encino": "20", "h_Encino": "15",
                  "tp_Encino": "10", "ica_Encino": "2.8",
                  "icapct_Encino": "3", "ima_Encino": "3.2",
                  "edad_Encino": "18"})
        self.assertEqual(respuesta.status_code, 302)
        pmf = PMFProyecto.cargar(self.ruta)
        self.assertEqual(len(pmf.incrementos_directos), 2)
        filas = {f["especie"]: f for f in pmf.resumen_incrementos()["filas"]
                 if not f.get("_type")}
        self.assertAlmostEqual(filas["Pinus patula"]["tp"], 12.0)
        self.assertAlmostEqual(filas["Encino"]["ima"], 3.2)

    def test_selector_muestra_distintivos(self):
        self.cliente.post(
            "/inventario/existencias/RX/guardar",
            data={"grupo": "existencias", "especie_sel": "Pinus patula",
                  "arb_Pinus patula": "100", "ab_Pinus patula": "12.5",
                  "vol_Pinus patula": "80"})
        self.cliente.post(
            "/inventario/existencias/RX/guardar",
            data={"grupo": "incrementos", "especie_sel": "Encino",
                  "arb_Encino": "90", "ab_Encino": "11",
                  "tp_Encino": "10", "ica_Encino": "3", "icapct_Encino": "3",
                  "ima_Encino": "3.5", "edad_Encino": "19"})
        html = self.cliente.get("/inventario/existencias/RX").get_data(as_text=True)
        self.assertEqual(self.cliente.get("/inventario/existencias/RX").status_code, 200)
        self.assertIn("(E)", html)
        self.assertIn("(I)", html)
        self.assertIn("Pinus patula", html)
        self.assertIn("Encino", html)

    def test_guardar_por_grupo_existencias(self):
        respuesta = self.cliente.post(
            "/inventario/existencias/RX/guardar",
            data={"grupo": "existencias", "especie_sel": "Pinus patula",
                  "arb_Pinus patula": "100", "ab_Pinus patula": "12.5",
                  "vol_Pinus patula": "80"})
        self.assertEqual(respuesta.status_code, 302)
        pmf = PMFProyecto.cargar(self.ruta)
        registro = pmf.buscar_existencia_directa("RX", "Pinus patula")
        self.assertAlmostEqual(registro.vol_ha, 80.0)
        # El grupo incrementos sigue vacio: independencia.
        self.assertIsNone(pmf.buscar_incremento_directo("RX", "Pinus patula"))
        html = self.cliente.get("/reportes/cuadro_existencias").get_data(as_text=True)
        self.assertIn("640.000", html)

    def test_guardar_por_grupo_incrementos(self):
        respuesta = self.cliente.post(
            "/inventario/existencias/RX/guardar",
            data={"grupo": "incrementos", "especie_sel": "Pinus patula",
                  "arb_Pinus patula": "100", "ab_Pinus patula": "12.5",
                  "tp_Pinus patula": "12", "ica_Pinus patula": "3.5",
                  "icapct_Pinus patula": "3.5", "ima_Pinus patula": "4",
                  "edad_Pinus patula": "20", "dq_Pinus patula": "22.5",
                  "h_Pinus patula": "18"})
        self.assertEqual(respuesta.status_code, 302)
        pmf = PMFProyecto.cargar(self.ruta)
        registro = pmf.buscar_incremento_directo("RX", "Pinus patula")
        self.assertAlmostEqual(registro.tp, 12.0)
        self.assertAlmostEqual(registro.edad, 20.0)
        self.assertAlmostEqual(registro.dq_cm, 22.5)
        self.assertAlmostEqual(registro.h_m, 18.0)
        # El grupo existencias sigue vacio: independencia.
        self.assertIsNone(pmf.buscar_existencia_directa("RX", "Pinus patula"))
        filas = [f for f in pmf.resumen_incrementos()["filas"] if not f.get("_type")]
        self.assertEqual(len(filas), 1)
        self.assertAlmostEqual(filas[0]["tp"], 12.0)
        self.assertAlmostEqual(filas[0]["ima"], 4.0)
        # La pantalla muestra DQ y H capturados.
        html = self.cliente.get(
            "/inventario/existencias/RX?esp=Pinus+patula&grupo=incrementos"
        ).get_data(as_text=True)
        self.assertIn("22.5", html)
        self.assertIn("18.0", html)

    def test_ceros_explicitos_se_guardan(self):
        respuesta = self.cliente.post(
            "/inventario/existencias/RX/guardar",
            data={"grupo": "existencias", "especie_sel": "Pinus patula",
                  "arb_Pinus patula": "0", "ab_Pinus patula": "0",
                  "vol_Pinus patula": "0"})
        self.assertEqual(respuesta.status_code, 302)
        registro = PMFProyecto.cargar(self.ruta).buscar_existencia_directa(
            "RX", "Pinus patula")
        self.assertIsNotNone(registro)
        self.assertEqual((registro.arboles_ha, registro.ab_ha, registro.vol_ha),
                         (0.0, 0.0, 0.0))

    def test_eliminar_por_ruta_y_por_vaciado(self):
        datos = {"grupo": "incrementos", "especie_sel": "Pinus patula",
                 "arb_Pinus patula": "100", "ab_Pinus patula": "12.5",
                 "tp_Pinus patula": "12"}
        self.cliente.post("/inventario/existencias/RX/guardar", data=datos)
        self.assertIsNotNone(PMFProyecto.cargar(self.ruta).buscar_incremento_directo(
            "RX", "Pinus patula"))
        # Ruta explicita de eliminar.
        respuesta = self.cliente.get(
            "/inventario/existencias/RX/eliminar/incrementos/Pinus%20patula")
        self.assertEqual(respuesta.status_code, 302)
        self.assertIsNone(PMFProyecto.cargar(self.ruta).buscar_incremento_directo(
            "RX", "Pinus patula"))
        # Y tambien vaciando todos los campos.
        self.cliente.post("/inventario/existencias/RX/guardar", data=datos)
        respuesta = self.cliente.post(
            "/inventario/existencias/RX/guardar",
            data={"grupo": "incrementos", "especie_sel": "Pinus patula",
                  "arb_Pinus patula": "", "ab_Pinus patula": "",
                  "tp_Pinus patula": "", "ica_Pinus patula": "",
                  "icapct_Pinus patula": "", "ima_Pinus patula": "",
                  "edad_Pinus patula": ""})
        self.assertEqual(respuesta.status_code, 302)
        self.assertIsNone(PMFProyecto.cargar(self.ruta).buscar_incremento_directo(
            "RX", "Pinus patula"))

    def test_celdas_del_cuadro_editan_tp_y_edad_directos(self):
        self.cliente.post(
            "/inventario/existencias/RX/guardar",
            data={"grupo": "incrementos", "especie_sel": "Pinus patula",
                  "arb_Pinus patula": "100", "ab_Pinus patula": "12.5",
                  "tp_Pinus patula": "12", "edad_Pinus patula": "20"})
        respuesta = self.cliente.post(
            "/reportes/resumen_incrementos/guardar_parametros",
            json={"ajustes": [{"rodal": "RX", "especie": "Pinus patula",
                               "tp": "14", "edad": "22"}]})
        self.assertEqual(respuesta.status_code, 200)
        registro = PMFProyecto.cargar(self.ruta).buscar_incremento_directo(
            "RX", "Pinus patula")
        self.assertAlmostEqual(registro.tp, 14.0)
        self.assertAlmostEqual(registro.edad, 22.0)
        # Vaciar restablece (None) sin tocar los aprobados globales.
        self.cliente.post(
            "/reportes/resumen_incrementos/guardar_parametros",
            json={"ajustes": [{"rodal": "RX", "especie": "Pinus patula",
                               "tp": "", "edad": ""}]})
        pmf = PMFProyecto.cargar(self.ruta)
        registro = pmf.buscar_incremento_directo("RX", "Pinus patula")
        self.assertIsNone(registro.tp)
        self.assertIsNone(registro.edad)
        self.assertEqual(pmf.tp_aprobados, {})
        self.assertEqual(pmf.edad_aprobada, {})

    def test_incrementos_invalidos_se_rechazan(self):
        base = {"grupo": "incrementos", "especie_sel": "Pinus patula",
                "arb_Pinus patula": "100", "ab_Pinus patula": "12.5",
                "tp_Pinus patula": "12", "ica_Pinus patula": "3.5",
                "icapct_Pinus patula": "3.5", "ima_Pinus patula": "4",
                "edad_Pinus patula": "20"}
        for campo, valor in (("tp_Pinus patula", "0"), ("edad_Pinus patula", "-5"),
                             ("ica_Pinus patula", "abc")):
            datos = dict(base)
            datos[campo] = valor
            respuesta = self.cliente.post("/inventario/existencias/RX/guardar", data=datos)
            self.assertEqual(respuesta.status_code, 302)
        pmf = PMFProyecto.cargar(self.ruta)
        self.assertEqual(pmf.incrementos_directos, [])

    def test_valores_invalidos_se_rechazan(self):
        for datos in ({"arb_Pinus patula": "-1", "ab_Pinus patula": "5",
                       "vol_Pinus patula": "5"},
                      {"arb_Pinus patula": "abc", "ab_Pinus patula": "5",
                       "vol_Pinus patula": "5"}):
            respuesta = self.cliente.post("/inventario/existencias/RX/guardar", data=datos)
            self.assertEqual(respuesta.status_code, 302)
        pmf = PMFProyecto.cargar(self.ruta)
        self.assertEqual(pmf.existencias_directas, [])

    def test_vaciar_elimina_y_cuadro_lo_refleja(self):
        self.cliente.post(
            "/inventario/existencias/RX/guardar",
            data={"arb_Pinus patula": "100", "ab_Pinus patula": "12.5",
                  "vol_Pinus patula": "80"})
        self.assertEqual(len(PMFProyecto.cargar(self.ruta).existencias_directas), 1)
        self.cliente.post(
            "/inventario/existencias/RX/guardar",
            data={"arb_Pinus patula": "", "ab_Pinus patula": "", "vol_Pinus patula": ""})
        self.assertEqual(PMFProyecto.cargar(self.ruta).existencias_directas, [])

    def test_crear_rodal_acepta_el_nuevo_tipo(self):
        respuesta = self.cliente.post(
            "/rodales/agregar",
            data={"id": "RY", "superficie_ha": "6", "tipo_inventario": "existencias",
                  "tipo_bosque": "", "calidad_sitio": "Media"})
        self.assertEqual(respuesta.status_code, 302)
        rodal = PMFProyecto.cargar(self.ruta).buscar_rodal("RY")
        self.assertEqual(rodal.tipo_inventario, "existencias")
        self.assertEqual(rodal.sitios, 0)

    def test_editar_tabla_redirige_a_la_captura(self):
        respuesta = self.cliente.get("/inventario/rodal/editar/RX/Pinus%20patula")
        self.assertEqual(respuesta.status_code, 302)
        self.assertIn("/inventario/existencias/RX", respuesta.headers["Location"])

    def test_dashboard_muestra_valores_directos(self):
        self.cliente.post(
            "/inventario/existencias/RX/guardar",
            data={"arb_Pinus patula": "100", "ab_Pinus patula": "12.5",
                  "vol_Pinus patula": "80"})
        html = self.cliente.get("/inventario/dashboard/rodal/RX").get_data(as_text=True)
        self.assertEqual(self.cliente.get("/inventario/dashboard/rodal/RX").status_code, 200)
        self.assertIn("100.00", html)
        self.assertIn("640.000", html)

    def test_reporte_tabla_muestra_valores_directos(self):
        self.cliente.post(
            "/inventario/existencias/RX/guardar",
            data={"arb_Pinus patula": "100", "ab_Pinus patula": "12.5",
                  "vol_Pinus patula": "80"})
        respuesta = self.cliente.get("/inventario/rodal/reporte/RX/Pinus%20patula")
        self.assertEqual(respuesta.status_code, 200)
        self.assertIn("640.000", respuesta.get_data(as_text=True))


if __name__ == "__main__":
    unittest.main()
