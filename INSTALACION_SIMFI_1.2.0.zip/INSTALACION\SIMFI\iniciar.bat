@echo off
start "" "%~dp0python\pythonw.exe" "%~dp0run.py"
exit
