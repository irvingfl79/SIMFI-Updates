import base64
import datetime
import io
import re
import unicodedata

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from PIL import Image, ImageDraw

from cuadros_word import agregar_caption, crear_cuadro

from motor_aclareos import tabla_intensidades_aplicadas


VERDE = "1A5632"
VERDE_OSCURO = "0F3D23"
VERDE_CLARO = "E8F2E9"
GRIS = "E9ECEA"
FIRMA_EXPORTACION = "SIMFI — Sistema para el Manejo Forestal Mejorado por Dr.PIFL"


def decodificar_png(data_url):
    prefijo = "data:image/png;base64,"
    if not data_url or not data_url.startswith(prefijo):
        raise ValueError("No se recibió una gráfica PNG válida.")
    try:
        datos = base64.b64decode(data_url[len(prefijo):], validate=True)
    except (ValueError, TypeError) as exc:
        raise ValueError("No se pudo interpretar la gráfica enviada.") from exc
    if len(datos) > 12 * 1024 * 1024 or not datos.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError("La gráfica PNG no es válida o excede el tamaño permitido.")
    return io.BytesIO(datos)


def nombre_archivo_reporte(especie, rodal, fecha=None):
    fecha = fecha or datetime.date.today().isoformat()

    def limpiar(texto):
        normalizado = unicodedata.normalize("NFKD", texto or "")
        ascii_texto = "".join(c for c in normalizado if not unicodedata.combining(c))
        return re.sub(r"[^A-Za-z0-9_-]+", "_", ascii_texto).strip("_") or "Sin_dato"

    return f"SIMFI_Guia_Densidad_{limpiar(especie)}_{limpiar(rodal)}_{fecha}.docx"


def nombre_archivo_aclareos(especie, rodal, fecha=None):
    base = nombre_archivo_reporte(especie, rodal, fecha)
    return base.replace("SIMFI_Guia_Densidad_", "SIMFI_Escenarios_Aclareo_")


def nombre_archivo_aclareos_multirodal(fecha=None):
    fecha = fecha or datetime.date.today().isoformat()
    return f"Reporte_Aclareos_Intensidad_Corta_{fecha}.docx"


def nombre_archivo_turno(especie, proyecto, fecha=None):
    base = nombre_archivo_reporte(especie, proyecto, fecha)
    return base.replace("SIMFI_Guia_Densidad_", "SIMFI_Turno_Tecnico_")


def _sombrear(celda, color):
    propiedades = celda._tc.get_or_add_tcPr()
    sombreado = propiedades.find(qn("w:shd"))
    if sombreado is None:
        sombreado = OxmlElement("w:shd")
        propiedades.append(sombreado)
    sombreado.set(qn("w:fill"), color)


def _margenes_celda(celda, superior=90, inicio=110, inferior=90, fin=110):
    propiedades = celda._tc.get_or_add_tcPr()
    margenes = propiedades.first_child_found_in("w:tcMar")
    if margenes is None:
        margenes = OxmlElement("w:tcMar")
        propiedades.append(margenes)
    for nombre, valor in (("top", superior), ("start", inicio), ("bottom", inferior), ("end", fin)):
        nodo = margenes.find(qn(f"w:{nombre}"))
        if nodo is None:
            nodo = OxmlElement(f"w:{nombre}")
            margenes.append(nodo)
        nodo.set(qn("w:w"), str(valor))
        nodo.set(qn("w:type"), "dxa")


def _tabla(documento, encabezados, filas, anchos=None, titulo=None,
           numero_tabla=None):
    """Cuadro estandar de SIMFI delegado al componente reutilizable.

    Los anchos, cuando se indican, se interpretan como proporciones relativas;
    la tabla ocupa siempre el 100% del ancho util de la pagina.
    """
    filas = [list(fila) for fila in filas]
    tabla, _ = crear_cuadro(
        documento,
        titulo=titulo, numero_tabla=numero_tabla,
        encabezados=[list(encabezados)],
        filas=filas,
        anchos_relativos=list(anchos) if anchos else None,
    )
    return tabla


def _agregar_nombre_cientifico(parrafo, nombre):
    partes = (nombre or "").split()
    binomio = " ".join(partes[:2])
    autoridad = " ".join(partes[2:])
    run = parrafo.add_run(binomio)
    run.italic = True
    if autoridad:
        parrafo.add_run(" " + autoridad)


def _campo_word(parrafo, instruccion):
    inicio = OxmlElement("w:fldChar")
    inicio.set(qn("w:fldCharType"), "begin")
    texto = OxmlElement("w:instrText")
    texto.set(qn("xml:space"), "preserve")
    texto.text = instruccion
    fin = OxmlElement("w:fldChar")
    fin.set(qn("w:fldCharType"), "end")
    run = parrafo.add_run()._r
    run.append(inicio)
    run.append(texto)
    run.append(fin)


def _configurar_pie(documento, modulo="Guías de Densidad"):
    for seccion in documento.sections:
        pie = seccion.footer
        tabla = pie.add_table(1, 2, Cm(17.4))
        tabla.alignment = WD_TABLE_ALIGNMENT.CENTER
        izquierda, derecha = tabla.rows[0].cells
        p = izquierda.paragraphs[0]
        p.add_run(FIRMA_EXPORTACION + "\n").bold = True
        p.add_run(f"Reporte generado por el módulo de {modulo}")
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        p = derecha.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p.add_run("Página ")
        _campo_word(p, "PAGE")
        p.add_run(" de ")
        _campo_word(p, "NUMPAGES")
        for celda in (izquierda, derecha):
            for run in celda.paragraphs[0].runs:
                run.font.size = Pt(7.5)
                run.font.color.rgb = RGBColor(90, 100, 94)


def _referencia(modelo):
    fuente = modelo.get("fuente", {})
    partes = [fuente.get("autores_cita", "")]
    anio = fuente.get("anio") or fuente.get("anio_numero")
    if anio:
        partes.append(f"({anio}).")
    if fuente.get("titulo"):
        partes.append(fuente["titulo"] + ".")
    if fuente.get("revista"):
        publicacion = fuente["revista"]
        if fuente.get("volumen"):
            publicacion += f" {fuente['volumen']}"
            if fuente.get("numero"):
                publicacion += f"({fuente['numero']})"
        if fuente.get("paginas"):
            publicacion += f": {fuente['paginas']}"
        partes.append(publicacion + ".")
    elif fuente.get("institucion"):
        partes.append(fuente["institucion"] + ".")
    if fuente.get("doi"):
        partes.append("DOI: " + fuente["doi"] + ".")
    return " ".join(parte for parte in partes if parte)


def _metodologia(modelo):
    metodologia = modelo.get("metodologia", {})
    metodos = metodologia.get("metodos")
    if isinstance(metodos, list):
        return " + ".join(metodos)
    elementos = [metodologia.get("indice"), metodologia.get("estimacion_frontera"),
                 metodologia.get("distribucion"), metodologia.get("ajuste")]
    return " — ".join(str(e) for e in elementos if e) or modelo.get("tipo_modelo", "")


def _encabezado(documento, pmf, analisis, logo, fecha):
    modelo = analisis["modelo"]
    datos = analisis["datos_rodal"]
    tabla = documento.add_table(1, 2)
    tabla.alignment = WD_TABLE_ALIGNMENT.CENTER
    tabla.autofit = False
    celda_logo, celda_titulo = tabla.rows[0].cells
    celda_logo.width = Cm(5.2)
    celda_titulo.width = Cm(12.2)
    celda_logo.paragraphs[0].add_run().add_picture(logo, width=Cm(4.8))
    p = celda_titulo.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = p.add_run("SIMFI")
    run.bold = True
    run.font.size = Pt(22)
    run.font.color.rgb = RGBColor(15, 61, 35)
    p.add_run("\nSistema para el Manejo Forestal Mejorado por Dr.PIFL").font.size = Pt(9)
    p.add_run("\nREPORTE DE EVALUACIÓN DE DENSIDAD DEL RODAL").bold = True
    for celda in tabla.rows[0].cells:
        _margenes_celda(celda, 0, 0, 40, 0)
    documento.add_paragraph()
    info = documento.add_table(3, 4)
    info.alignment = WD_TABLE_ALIGNMENT.CENTER
    valores = [
        ("Especie", modelo["especie"]["nombre_cientifico"], "Rodal", datos["rodal_id"]),
        ("Predio", pmf.predio or pmf.nombre or "No registrado", "Fecha", fecha.strftime("%d/%m/%Y")),
        ("Modelo", modelo.get("nombre_corto", modelo["modelo_id"]), "Región", modelo["region_aplicacion"]),
    ]
    for fila, valores_fila in zip(info.rows, valores):
        for indice, valor in enumerate(valores_fila):
            fila.cells[indice].text = valor
            _margenes_celda(fila.cells[indice])
            if indice % 2 == 0:
                _sombrear(fila.cells[indice], VERDE_CLARO)
                fila.cells[indice].paragraphs[0].runs[0].bold = True
            for run in fila.cells[indice].paragraphs[0].runs:
                run.font.size = Pt(8)
    especie_celda = info.rows[0].cells[1]
    especie_celda.text = ""
    _agregar_nombre_cientifico(especie_celda.paragraphs[0], modelo["especie"]["nombre_cientifico"])
    for run in especie_celda.paragraphs[0].runs:
        run.font.size = Pt(8)
    documento.add_paragraph()


def generar_reporte_densidad(pmf, analisis, grafica_png, logo_path):
    documento = Document()
    seccion = documento.sections[0]
    seccion.top_margin = Cm(1.5)
    seccion.bottom_margin = Cm(1.7)
    seccion.left_margin = Cm(1.8)
    seccion.right_margin = Cm(1.8)

    estilos = documento.styles
    estilos["Normal"].font.name = "Aptos"
    estilos["Normal"].font.size = Pt(9.5)
    estilos["Normal"].paragraph_format.space_after = Pt(5)
    for nombre, tamano in (("Title", 17), ("Heading 1", 13), ("Heading 2", 10.5)):
        estilos[nombre].font.name = "Aptos Display"
        estilos[nombre].font.size = Pt(tamano)
        estilos[nombre].font.color.rgb = RGBColor(15, 61, 35)
    estilos["Heading 1"].paragraph_format.space_before = Pt(9)
    estilos["Heading 1"].paragraph_format.space_after = Pt(5)

    modelo = analisis["modelo"]
    condicion = analisis["condicion"]
    interpretacion = analisis["interpretacion"]
    fecha = datetime.datetime.now()
    propiedades = documento.core_properties
    propiedades.title = "Reporte de evaluación de densidad del rodal"
    propiedades.subject = modelo.get("nombre_corto", modelo["modelo_id"])
    propiedades.author = "Dr.PIFL"
    propiedades.keywords = (f"modelo_id={modelo['modelo_id']}; version={modelo['version_modelo']}; "
                            f"especie={modelo['especie']['nombre_cientifico']}; "
                            f"fechaGeneracion={fecha.isoformat(timespec='seconds')}")

    _encabezado(documento, pmf, analisis, logo_path, fecha)
    _configurar_pie(documento)

    numero = 1
    documento.add_heading(f"{numero}. Datos dasométricos", level=1)
    filas = [
        ("Número de árboles", f"{condicion['n']:,.0f}", "árboles/ha"),
        ("Área basal", f"{condicion['g']:,.2f}", "m²/ha"),
        ("Diámetro cuadrático", f"{condicion['dq']:,.2f}", "cm"),
    ]
    if condicion.get("indice_densidad") is not None:
        filas.append((condicion.get("indice_nombre") or "Índice de densidad",
                      f"{condicion['indice_densidad']:,.2f}", "—"))
    filas.append(("Grado de densidad",
                  f"{condicion['grado_densidad']:,.1f}" if condicion.get("grado_densidad") is not None else "Pendiente", "%"))
    _tabla(documento, ("Variable", "Resultado", "Unidad"), filas, (7.5, 4.5, 4.0),
           titulo="Datos dasométricos", numero_tabla=1)

    numero += 1
    documento.add_heading(f"{numero}. Guía utilizada", level=1)
    tabla_guia = _tabla(documento, ("Concepto", "Información"), [
        ("Especie objetivo", modelo["especie"]["nombre_cientifico"]),
        ("Modelo", modelo.get("nombre_corto", modelo["modelo_id"])),
        ("Región de desarrollo", modelo["region_aplicacion"]),
        ("Metodología", _metodologia(modelo)),
        ("Fuente", _referencia(modelo)),
    ], (5.0, 11.5), titulo="Guía utilizada", numero_tabla=2)
    especie_celda = tabla_guia.rows[1].cells[1]
    especie_celda.text = ""
    _agregar_nombre_cientifico(especie_celda.paragraphs[0], modelo["especie"]["nombre_cientifico"])
    for run in especie_celda.paragraphs[0].runs:
        run.font.size = Pt(8.5)
    if analisis["datos_rodal"].get("es_mixto") and modelo.get("advertencia_mezcla"):
        p = documento.add_paragraph()
        run = p.add_run("Nota de aplicación. ")
        run.bold = True
        p.add_run(modelo["advertencia_mezcla"])

    numero += 1
    documento.add_heading(f"{numero}. Gráfica de densidad", level=1)
    p = documento.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(grafica_png, width=Cm(16.5))
    p = documento.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(f"Figura 1. Posición del rodal dentro de la guía de densidad correspondiente a ")
    run.font.size = Pt(8.5)
    _agregar_nombre_cientifico(p, modelo["especie"]["nombre_cientifico"])
    p.add_run(".")

    numero += 1
    documento.add_heading(f"{numero}. Interpretación de la condición actual", level=1)
    p = documento.add_paragraph()
    p.add_run(interpretacion["titulo"] + ". ").bold = True
    p.add_run(interpretacion["texto"])
    if condicion.get("condicion_competencia"):
        p = documento.add_paragraph()
        p.add_run("Condición de competencia: ").bold = True
        p.add_run(condicion["condicion_competencia"] + ".")

    if analisis["escenarios"]:
        numero += 1
        documento.add_heading(f"{numero}. Evaluación de escenarios", level=1)
        encabezados = ["Variable", "Actual"] + [e["nombre"] for e in analisis["escenarios"]]
        filas = []
        variables = [
            ("N (árboles/ha)", "n", ",.0f"), ("G (m²/ha)", "g", ",.2f"),
            ("Dq (cm)", "dq", ",.2f"), (condicion.get("indice_nombre") or "Índice", "indice_densidad", ",.2f"),
            ("Densidad (%)", "grado_densidad", ",.1f"), ("Clasificación", "clasificacion", None),
        ]
        for etiqueta, clave, formato in variables:
            valores = [etiqueta]
            for estado in [condicion] + [e["condicion"] for e in analisis["escenarios"]]:
                valor = estado.get(clave)
                valores.append(format(valor, formato) if formato and valor is not None else (valor or "—"))
            filas.append(valores)
        _tabla(documento, encabezados, filas, titulo="Evaluación de escenarios", numero_tabla=3)
        for escenario in analisis["escenarios"]:
            documento.add_heading(escenario["nombre"], level=2)
            documento.add_paragraph(escenario["comparacion"])
            remocion = escenario["remocion"]
            p = documento.add_paragraph()
            p.add_run("Resultados del escenario simulado: ").bold = True
            p.add_run(f"remoción de {remocion['n']:,.0f} árboles/ha ({remocion['reduccion_n_pct']:.1f} %) "
                      f"y {remocion['g']:,.2f} m²/ha de área basal ({remocion['reduccion_g_pct']:.1f} %).")

    numero += 1
    documento.add_heading(f"{numero}. Consideraciones técnicas", level=1)
    documento.add_paragraph(interpretacion["consideracion"])
    documento.add_paragraph(
        "Los resultados constituyen elementos de apoyo para la toma de decisiones silvícolas y deben "
        "interpretarse conjuntamente con la estructura del rodal, calidad y condición del arbolado, "
        "objetivos del tratamiento y demás información disponible del programa de manejo forestal."
    )

    numero += 1
    documento.add_heading(f"{numero}. Fuente de la guía", level=1)
    documento.add_paragraph(_referencia(modelo))
    documento.add_paragraph(
        "Los parámetros utilizados por SIMFI corresponden al modelo registrado para la especie y región indicadas."
    )
    p = documento.add_paragraph()
    p.add_run("Trazabilidad interna: ").bold = True
    p.add_run(f"{modelo['modelo_id']} · versión {modelo['version_modelo']} · "
              f"generado {fecha.isoformat(timespec='seconds')}")

    salida = io.BytesIO()
    documento.save(salida)
    salida.seek(0)
    return salida


def _grafica_estructura_diametrica_rodal(rodal, filas):
    """Construye una gráfica real de clases diamétricas por especie."""
    ancho, alto = 1100, 620
    imagen = Image.new("RGB", (ancho, alto), "white")
    dibujo = ImageDraw.Draw(imagen)
    colores = ["#1A5632", "#2D7A4A", "#C58A16", "#6B46A1", "#1769AA", "#A83232"]
    especies = [fila["especie"] for fila in filas]
    series = {}
    for fila in filas:
        valores = {clase["dncc"]: float(clase.get("n", 0) or 0)
                   for clase in fila.get("clases", [])}
        if valores:
            series[fila["especie"]] = valores
    diametros = sorted({diametro for valores in series.values() for diametro in valores})
    titulo = f"Estructura diamétrica — Rodal {rodal}"
    if not diametros:
        # La estructura no está disponible; se representa únicamente N real.
        series = {fila["especie"]: {"N": float(fila.get("n", 0) or 0)} for fila in filas}
        diametros = ["N"]
        etiqueta_x = "Especie"
        etiqueta_y = "Árboles/ha"
        nota = "Sin clases diamétricas disponibles; se muestra N real por especie."
    else:
        etiqueta_x = "Clase diamétrica (cm)"
        etiqueta_y = "Árboles/ha"
        nota = "Fuente: clases diamétricas reales del inventario SIMFI."

    izquierda, derecha, arriba, abajo = 110, ancho - 35, 85, alto - 100
    maximo = max((valor for valores in series.values() for valor in valores.values()), default=1.0) or 1.0
    dibujo.text((ancho // 2 - 250, 18), titulo, fill="#0F3D23")
    dibujo.line((izquierda, arriba, izquierda, abajo), fill="#333333", width=2)
    dibujo.line((izquierda, abajo, derecha, abajo), fill="#333333", width=2)
    for paso in range(6):
        valor = maximo * paso / 5
        y = abajo - int((abajo - arriba) * paso / 5)
        dibujo.line((izquierda - 5, y, derecha, y), fill="#E5EAE7", width=1)
        dibujo.text((18, y - 8), f"{valor:,.0f}", fill="#333333")

    ancho_grupo = (derecha - izquierda) / max(len(diametros), 1)
    especies_validas = [especie for especie in especies if especie in series]
    ancho_barra = max(4, min(28, ancho_grupo / max(len(especies_validas) * 1.4, 1)))
    for indice, diametro in enumerate(diametros):
        centro = izquierda + ancho_grupo * (indice + 0.5)
        for especie_indice, especie in enumerate(especies_validas):
            valor = series[especie].get(diametro, 0.0)
            x1 = centro + (especie_indice - (len(especies_validas) - 1) / 2) * ancho_barra * 1.2
            x2 = x1 + ancho_barra
            y2 = abajo
            y1 = abajo - int((abajo - arriba) * valor / maximo)
            dibujo.rectangle((x1, y1, x2, y2), fill=colores[especie_indice % len(colores)])
        etiqueta = str(diametro)
        dibujo.text((centro - len(etiqueta) * 4, abajo + 12), etiqueta, fill="#333333")

    dibujo.text((ancho // 2 - 85, alto - 45), etiqueta_x, fill="#333333")
    dibujo.text((10, arriba - 22), etiqueta_y, fill="#333333")
    leyenda_x = izquierda
    leyenda_y = 48
    for indice, especie in enumerate(especies_validas):
        x = leyenda_x + indice * 175
        dibujo.rectangle((x, leyenda_y, x + 14, leyenda_y + 14), fill=colores[indice % len(colores)])
        dibujo.text((x + 20, leyenda_y - 1), especie, fill="#333333")
    dibujo.text((izquierda, alto - 20), nota, fill="#56645A")
    salida = io.BytesIO()
    imagen.save(salida, format="PNG")
    salida.seek(0)
    return salida


_COLUMNAS_APLICADAS = (
    ("Rodal", "rodal", None), ("Especie", "especie", None),
    ("Criterio", "criterio", None), ("Intensidad %", "intensidad", 2),
    ("Arboles/ha", "n_ha", 2), ("Arboles/total", "n_total", 2),
    ("ER/m3/ha", "v_ha", 3), ("ERT/m3", "v_total", 3),
    ("Arboles a remover/ha", "n_rem_ha", 2), ("Arboles a remover/total", "n_rem_total", 2),
    ("Volumen a remover/ha", "v_rem_ha", 3), ("Volumen a remover/total", "v_rem_total", 3),
    ("Arboles residuales/ha", "n_res_ha", 2), ("Arboles residuales/totales", "n_res_total", 2),
    ("Volumen residual/ha", "v_res_ha", 3), ("Volumen residual/total", "v_res_total", 3),
)


def _filas_aplicadas(pmf):
    filas = tabla_intensidades_aplicadas(pmf)
    if not filas:
        raise ValueError("No hay intensidades aplicadas para exportar.")
    return filas


def _texto_numero(valor, decimales):
    if not isinstance(valor, (int, float)) or decimales is None:
        return str(valor)
    return ("{:,.%df}" % decimales).format(valor)


_COLUMNAS_REPORTE_RODALES = tuple(
    columna for columna in _COLUMNAS_APLICADAS if columna[1] != "criterio"
)


def generar_excel_intensidades_aplicadas(pmf, filas=None, titulo=None,
                                           hoja_titulo="Intensidades aplicadas",
                                           columnas=None, horizontal=False):
    """Exporta el cuadro de intensidades aplicadas a Excel."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    if filas is None:
        filas = _filas_aplicadas(pmf)
    if not filas:
        raise ValueError("No hay filas para exportar.")
    if columnas is None:
        columnas = _COLUMNAS_APLICADAS
    libro = Workbook()
    hoja = libro.active
    hoja.title = hoja_titulo
    hoja.merge_cells(start_row=1, start_column=1,
                     end_row=1, end_column=len(columnas))
    titulo = hoja["A1"]
    titulo.value = "%s - %s" % (
        titulo or "INTENSIDADES APLICADAS AL CUADRO DE EXISTENCIAS",
        pmf.predio or pmf.nombre)
    titulo.font = Font(bold=True, size=13)
    titulo.alignment = Alignment(horizontal="center")
    if horizontal:
        hoja.page_setup.orientation = "landscape"
        hoja.page_setup.fitToPage = True
        hoja.page_setup.fitToWidth = 1
        hoja.page_setup.fitToHeight = 0
    negrita = Font(bold=True)
    fina = Side(style="thin")
    borde = Border(left=fina, right=fina, top=fina, bottom=fina)
    for columna, (encabezado, _, _) in enumerate(columnas, 1):
        celda = hoja.cell(row=3, column=columna, value=encabezado)
        celda.font = negrita
        celda.border = borde
        celda.alignment = Alignment(horizontal="center", wrap_text=True)
        celda.fill = PatternFill(start_color="D9D9D9", end_color="D9D9D9",
                                 fill_type="solid")
    for indice, fila in enumerate(filas, 4):
        for columna, (_, clave, decimales) in enumerate(columnas, 1):
            valor = fila.get(clave, "")
            celda = hoja.cell(row=indice, column=columna, value=valor)
            celda.border = borde
            if isinstance(valor, (int, float)):
                celda.number_format = "#,##0.%s" % ("0" * decimales) if decimales else "#,##0"
                celda.alignment = Alignment(horizontal="right")
    salida = io.BytesIO()
    libro.save(salida)
    salida.seek(0)
    return salida


def generar_word_intensidades_aplicadas(pmf, logo_path, filas=None, titulo=None,
                                          titulo_tabla="Intensidades elegidas aplicadas",
                                          columnas=None, horizontal=False):
    """Exporta el cuadro de intensidades aplicadas a Word."""
    from docx import Document
    from docx.enum.section import WD_ORIENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Cm
    if filas is None:
        filas = _filas_aplicadas(pmf)
    if not filas:
        raise ValueError("No hay filas para exportar.")
    if columnas is None:
        columnas = _COLUMNAS_APLICADAS
    documento = Document()
    if horizontal:
        seccion = documento.sections[0]
        seccion.orientation = WD_ORIENT.LANDSCAPE
        seccion.page_width, seccion.page_height = seccion.page_height, seccion.page_width
    cabecera = documento.add_table(1, 2)
    cabecera.rows[0].cells[0].paragraphs[0].add_run().add_picture(logo_path, width=Cm(4.5))
    parrafo = cabecera.rows[0].cells[1].paragraphs[0]
    parrafo.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    parrafo.add_run("SIMFI\n").bold = True
    parrafo.add_run(("%s\n" % (titulo or "INTENSIDADES APLICADAS AL CUADRO DE EXISTENCIAS"))).bold = True
    parrafo.add_run(pmf.predio or pmf.nombre)
    encabezados = [columna[0] for columna in columnas]
    filas_tabla = []
    for fila in filas:
        valores = []
        for _, clave, decimales in columnas:
            valores.append(_texto_numero(fila.get(clave, ""), decimales))
        filas_tabla.append(tuple(valores))
    _tabla(documento, encabezados, filas_tabla,
           titulo=titulo_tabla, numero_tabla=1)
    documento.add_paragraph(
        "Remoción = base × intensidad elegida; residual = base − remoción. "
        "Los totales usan la superficie del rodal.")
    salida = io.BytesIO()
    documento.save(salida)
    salida.seek(0)
    return salida


def generar_pdf_intensidades_aplicadas(pmf, filas=None, titulo=None, columnas=None):
    """Exporta el cuadro de intensidades aplicadas a PDF."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import landscape, letter
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
    if filas is None:
        filas = _filas_aplicadas(pmf)
    if not filas:
        raise ValueError("No hay filas para exportar.")
    if columnas is None:
        columnas = _COLUMNAS_APLICADAS
    salida = io.BytesIO()
    documento = SimpleDocTemplate(
        salida, pagesize=landscape(letter), leftMargin=1 * cm,
        rightMargin=1 * cm, topMargin=1.2 * cm, bottomMargin=1.2 * cm)
    estilos = getSampleStyleSheet()
    elementos = [Paragraph(titulo or "Intensidades aplicadas al cuadro de existencias",
                           estilos["Title"]),
                 Paragraph(pmf.predio or pmf.nombre, estilos["Normal"]),
                 Spacer(1, 10)]
    tabla = [[columna[0] for columna in columnas]]
    for fila in filas:
        valores = []
        for _, clave, decimales in columnas:
            valores.append(_texto_numero(fila.get(clave, ""), decimales))
        tabla.append(valores)
    cuadro = Table(tabla, repeatRows=1)
    cuadro.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1A5632")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), .3, colors.grey),
        ("FONTSIZE", (0, 0), (-1, -1), 6),
        ("ALIGN", (3, 1), (-1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    elementos.append(cuadro)
    documento.build(elementos)
    salida.seek(0)
    return salida


def _interpretacion_rodal_aclareos(rodal, filas, evaluaciones):
    """Redacta una interpretación determinística a partir de datos ya calculados."""
    especies = [fila["especie"] for fila in filas]
    n_total = sum(float(fila.get("n", 0) or 0) for fila in filas)
    g_total = sum(float(fila.get("g", 0) or 0) for fila in filas)
    v_total = sum(float(fila.get("v", 0) or 0) for fila in filas)
    especie_dominante = max(filas, key=lambda fila: float(fila.get("n", 0) or 0))
    edades = [fila["edad"] for fila in filas if fila.get("edad") is not None]
    dqs = [fila["dq"] for fila in filas if fila.get("dq") is not None]
    clases = {}
    for fila in filas:
        for clase in fila.get("clases", []):
            clases[clase["dncc"]] = clases.get(clase["dncc"], 0.0) + float(clase.get("n", 0) or 0)
    parrafos = [
        f"El rodal {rodal} está integrado por {', '.join(especies)} y registra "
        f"{n_total:,.2f} árboles/ha, {g_total:,.3f} m²/ha de área basal y "
        f"{v_total:,.3f} m³/ha de volumen, con base en los resúmenes dasométricos de SIMFI.",
        f"La especie con mayor número de árboles/ha es {especie_dominante['especie']} "
        f"({float(especie_dominante.get('n', 0) or 0):,.2f} árboles/ha). "
        f"Los diámetros cuadráticos disponibles se encuentran entre "
        f"{min(dqs):.2f} y {max(dqs):.2f} cm." if dqs else
        "No se dispone de diámetro cuadrático válido para todas las especies del rodal.",
    ]
    if edades:
        parrafos.append(f"La edad registrada se encuentra entre {min(edades):.0f} y {max(edades):.0f} años.")
    if clases:
        clase_modal = max(clases, key=clases.get)
        parrafos.append(
            f"La estructura diamétrica incluye {len(clases)} clases; la clase con mayor número "
            f"de árboles/ha es {clase_modal:g} cm ({clases[clase_modal]:,.2f} árboles/ha acumulados).")
    for fila in filas:
        indicadores = []
        for clave, etiqueta, formato in (("tp", "TP", ".3f"), ("ica", "ICA", ".3f"),
                                          ("ica_indicador_historico", "ICA %", ".3f"),
                                          ("ima", "IMA", ".3f")):
            if fila.get(clave) is not None:
                indicadores.append(f"{etiqueta} {fila[clave]:{formato}}")
        if indicadores:
            parrafos.append(f"Para {fila['especie']}: " + "; ".join(indicadores) + ".")

    for clave, evaluacion in evaluaciones.items():
        escenarios = evaluacion.get("escenarios", {}) if evaluacion else {}
        if not evaluacion:
            continue
        mmobi = escenarios.get("mmobi") or {}
        if mmobi.get("estado") == "disponible":
            parrafos.append(f"MMOBI cuenta con una intensidad calculada de {mmobi.get('intensidad_original', 0):.2f} % sobre {mmobi.get('unidad_original', 'la variable objetivo')}.")
        veiga = escenarios.get("veiga") or {}
        if veiga.get("estado") == "disponible":
            parrafos.append(
                f"Veiga cuenta con una intensidad de {veiga.get('intensidad_original', 0):.2f} % de árboles, "
                f"derivada de {veiga.get('n_residual', 0):,.2f} árboles/ha residuales y "
                f"{veiga.get('n_extraer', 0):,.2f} árboles/ha a extraer.")
        elif veiga.get("estado") in {"diagnostico", "no_disponible"}:
            parrafos.append("Veiga: pendiente de cálculo de regulación para este rodal; su indicador de crecimiento no se presenta como intensidad de corta.")
    return parrafos


def generar_reporte_aclareos_multirodal(pmf, filas, evaluaciones, logo_path):
    """Genera el reporte técnico completo para todos los rodales seleccionados."""
    fecha = datetime.datetime.now()
    documento = Document()
    seccion = documento.sections[0]
    seccion.top_margin, seccion.bottom_margin = Cm(1.5), Cm(1.7)
    seccion.left_margin, seccion.right_margin = Cm(1.8), Cm(1.8)
    documento.styles["Normal"].font.name = "Aptos"
    documento.styles["Normal"].font.size = Pt(9.5)
    for nombre, tamano in (("Title", 17), ("Heading 1", 13), ("Heading 2", 10.5)):
        documento.styles[nombre].font.name = "Aptos Display"
        documento.styles[nombre].font.size = Pt(tamano)
        documento.styles[nombre].font.color.rgb = RGBColor(15, 61, 35)
    documento.core_properties.title = "Evaluación de intensidad de corta – Aclareos"
    documento.core_properties.author = "Dr.PIFL"
    documento.core_properties.keywords = f"aclareos; rodales; generado {fecha.isoformat(timespec='seconds')}"
    _configurar_pie(documento)

    cabecera = documento.add_table(1, 2)
    cabecera.alignment = WD_TABLE_ALIGNMENT.CENTER
    cabecera.rows[0].cells[0].paragraphs[0].add_run().add_picture(logo_path, width=Cm(4.5))
    parrafo = cabecera.rows[0].cells[1].paragraphs[0]
    parrafo.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    parrafo.add_run("SIMFI\n").bold = True
    parrafo.add_run("EVALUACIÓN DE INTENSIDAD DE CORTA – ACLAREOS\n").bold = True
    parrafo.add_run(f"{len({fila['rodal'] for fila in filas})} rodal(es) seleccionado(s)")

    documento.add_heading("1. Datos dasométricos disponibles", level=1)
    encabezados = ("Rodal", "Especie", "N/ha", "G (m²/ha)", "V (m³/ha)", "DQ (cm)",
                   "H prom (m)",
                   "TP", "ICA", "ICA % (MMOBI)", "Edad", "IMA", "Evaluación")
    filas_tabla = []
    for fila in filas:
        filas_tabla.append((
            fila.get("rodal", "—"), fila.get("especie", "—"), f"{fila.get('n', 0):,.2f}",
            f"{fila.get('g', 0):,.3f}", f"{fila.get('v', 0):,.3f}",
            f"{fila.get('dq', 0):,.2f}",
            f"{fila['h_prom']:.2f}" if fila.get("h_prom") is not None else "—",
            f"{fila['tp']:.3f}" if fila.get("tp") is not None else "—",
            f"{fila['ica']:.3f}" if fila.get("ica") is not None else "—",
            f"{fila['ica_indicador_historico']:.3f}" if fila.get("ica_indicador_historico") is not None else "—",
            f"{fila['edad']:.0f}" if fila.get("edad") is not None else "—",
            f"{fila['ima']:.3f}" if fila.get("ima") is not None else "—",
            "Evaluación guardada" if evaluaciones.get(
                f"{fila['rodal']}||{fila['especie']}") else "Pendiente de evaluación",
        ))
    _tabla(documento, encabezados, filas_tabla, titulo="Cuadro dasométrico general", numero_tabla=1)

    aplicadas = tabla_intensidades_aplicadas(pmf)
    if aplicadas:
        documento.add_heading("Intensidades aplicadas al cuadro de existencias", level=1)
        documento.add_paragraph(
            "Remoción = base × intensidad elegida; residual = base − remoción. "
            "Los totales usan la superficie del rodal.")
        enc_aplicadas = ("Rodal", "Especie", "Criterio", "Intensidad %", "Arboles/ha", "Arboles/total",
                         "ER/m3/ha", "ERT/m3", "Arboles a remover/ha", "Arboles a remover/total",
                         "Volumen a remover/ha", "Volumen a remover/total", "Arboles residuales/ha",
                         "Arboles residuales/totales", "Volumen residual/ha", "Volumen residual/total")
        filas_aplicadas = [(
            f["rodal"], f["especie"], f["criterio"], f"{f['intensidad']:,.2f}",
            f"{f['n_ha']:,.2f}", f"{f['n_total']:,.2f}",
            f"{f['v_ha']:,.3f}", f"{f['v_total']:,.3f}",
            f"{f['n_rem_ha']:,.2f}", f"{f['n_rem_total']:,.2f}",
            f"{f['v_rem_ha']:,.3f}", f"{f['v_rem_total']:,.3f}",
            f"{f['n_res_ha']:,.2f}", f"{f['n_res_total']:,.2f}",
            f"{f['v_res_ha']:,.3f}", f"{f['v_res_total']:,.3f}",
        ) for f in aplicadas]
        _tabla(documento, enc_aplicadas, filas_aplicadas,
               titulo="Intensidades elegidas aplicadas", numero_tabla=2)

    por_rodal = {}
    orden_rodales = []
    for fila in filas:
        rodal = fila["rodal"]
        if rodal not in por_rodal:
            por_rodal[rodal] = []
            orden_rodales.append(rodal)
        por_rodal[rodal].append(fila)

    for indice, rodal in enumerate(orden_rodales, start=1):
        documento.add_page_break()
        filas_rodal = por_rodal[rodal]
        documento.add_heading(f"2.{indice} Rodal: {rodal}", level=1)
        documento.add_paragraph("Especies presentes: " + ", ".join(fila["especie"] for fila in filas_rodal) + ".")
        _tabla(documento, encabezados, [fila for fila in filas_tabla if fila[0] == rodal],
               titulo=f"Datos del rodal {rodal}", numero_tabla=indice + 2)
        documento.add_heading("Gráfica del rodal", level=2)
        parrafo_grafica = documento.add_paragraph()
        parrafo_grafica.alignment = WD_ALIGN_PARAGRAPH.CENTER
        parrafo_grafica.paragraph_format.keep_with_next = True
        parrafo_grafica.add_run().add_picture(_grafica_estructura_diametrica_rodal(rodal, filas_rodal), width=Cm(16.5))
        documento.add_paragraph(
            "Figura. Estructura diamétrica por especie del rodal; eje vertical en árboles/ha y eje horizontal en cm.")
        documento.add_heading("Interpretación técnica del rodal", level=2)
        for texto in _interpretacion_rodal_aclareos(
                rodal, filas_rodal,
                {f"{rodal}||{fila['especie']}": evaluaciones.get(f"{rodal}||{fila['especie']}")
                 for fila in filas_rodal}):
            documento.add_paragraph(texto)

    salida = io.BytesIO()
    documento.save(salida)
    salida.seek(0)
    return salida


def generar_reporte_aclareos(pmf, evaluacion, grafica_png, logo_path):
    actual = evaluacion["actual"]
    modelo = evaluacion.get("modelo")
    fecha = datetime.datetime.now()
    documento = Document()
    seccion = documento.sections[0]
    seccion.top_margin = Cm(1.5)
    seccion.bottom_margin = Cm(1.7)
    seccion.left_margin = Cm(1.8)
    seccion.right_margin = Cm(1.8)
    documento.styles["Normal"].font.name = "Aptos"
    documento.styles["Normal"].font.size = Pt(9.5)
    for nombre, tamano in (("Title", 17), ("Heading 1", 13), ("Heading 2", 10.5)):
        documento.styles[nombre].font.name = "Aptos Display"
        documento.styles[nombre].font.size = Pt(tamano)
        documento.styles[nombre].font.color.rgb = RGBColor(15, 61, 35)
    documento.core_properties.title = "Evaluación comparativa de escenarios de aclareo"
    documento.core_properties.author = "Dr.PIFL"
    documento.core_properties.keywords = (
        f"motor={evaluacion.get('version_motor')}; modelo={evaluacion.get('modelo_densidad_utilizado')}; "
        f"fecha={fecha.isoformat(timespec='seconds')}")
    _configurar_pie(documento)

    cabecera = documento.add_table(1, 2)
    cabecera.alignment = WD_TABLE_ALIGNMENT.CENTER
    cabecera.rows[0].cells[0].paragraphs[0].add_run().add_picture(logo_path, width=Cm(4.5))
    p = cabecera.rows[0].cells[1].paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p.add_run("SIMFI\n").bold = True
    p.add_run("EVALUACIÓN COMPARATIVA DE ESCENARIOS DE ACLAREO\n").bold = True
    p.add_run(f"{actual['rodal']} — {actual['especie']}")

    documento.add_heading("1. Condición actual", level=1)
    _tabla(documento, ("Variable", "Valor", "Unidad"), [
        ("Número de árboles", f"{actual['n']:,.2f}", "árboles/ha"),
        ("Área basal", f"{actual['g']:,.3f}", "m²/ha"),
        ("Volumen", f"{actual['v']:,.3f}", "m³/ha"),
        ("Diámetro cuadrático", f"{actual['dq']:,.2f}" if actual.get("dq") is not None else "—", "cm"),
        ("Incremento corriente anual", f"{actual['ica']:,.3f}" if actual.get("ica") is not None else "—", "m³/ha/año"),
        ("Tasa volumétrica anual", f"{actual['tasa_incremento_volumetrico_pct']:,.3f}" if actual.get("tasa_incremento_volumetrico_pct") is not None else "—", "%/año"),
    ], titulo="Condición actual", numero_tabla=1)

    documento.add_heading("2. Métodos y estado", level=1)
    escenarios = list(evaluacion.get("escenarios", {}).values())

    def _format_intensidad(escenario):
        if escenario.get("intensidad_original") is not None:
            return f"{escenario['intensidad_original']:.2f} %"
        if escenario.get("estado") == "diagnostico":
            return "Diagnóstico"
        return escenario.get("mensaje", "—")

    _tabla(documento, ("Escenario", "Estado", "Intensidad", "Unidad original"), [
        (escenario["nombre"], escenario["estado"], _format_intensidad(escenario),
         escenario.get("unidad_original", "—"))
        for escenario in escenarios
    ], titulo="Métodos y estado", numero_tabla=2)

    # Detalle específico del método de Veiga.
    veiga = evaluacion.get("escenarios", {}).get("veiga")
    if veiga and veiga.get("estado") == "disponible":
        documento.add_heading("2.1 Regulación Veiga", level=2)
        _tabla(documento, ("Concepto", "Valor", "Unidad"), [
            ("Número de árboles actual", f"{veiga['n_actual']:,.2f}", "árboles/ha"),
            ("Área basal actual", f"{veiga['g_actual']:,.3f}", "m²/ha"),
            ("Diámetro cuadrático actual", f"{veiga['dq_actual']:,.2f}", "cm"),
            ("Diámetro deseado", f"{veiga['diametro_deseado']:,.2f}", "cm"),
            ("Densidad objetivo", f"{veiga['densidad_objetivo']:,.2f}" if veiga.get("densidad_objetivo") is not None else "—", "árboles/ha"),
            ("Área basal guía", f"{veiga['g_guia']:,.3f}", "m²/ha"),
            ("Número de árboles residual", f"{veiga['n_residual']:,.2f}", "árboles/ha"),
            ("Número de árboles a extraer", f"{veiga['n_extraer']:,.2f}", "árboles/ha"),
            ("Área basal residual", f"{veiga['g_residual']:,.3f}", "m²/ha"),
            ("Área basal a extraer", f"{veiga['g_extraer']:,.3f}", "m²/ha"),
            ("Intensidad de corta", f"{veiga['intensidad_original']:,.2f}", "% árboles"),
        ], titulo="Resultado del método de Veiga", numero_tabla=2)
        documento.add_paragraph(
            f"Modelo de crecimiento de referencia: {veiga['parametros']['modelo_referencia']} "
            f"({veiga['parametros']['ce_modelo']}). Especie real: {actual['especie']}. "
            "Cálculo: AB_individual_deseado = π × (D_deseado / 100)² / 4; "
            "G_guía = densidad_objetivo × AB_individual_deseado; "
            "N_residual = densidad_objetivo; "
            "IC = (N_extraer / N_actual) × 100.")
        if veiga.get("diagnostico_crecimiento"):
            diag = veiga["diagnostico_crecimiento"]
            documento.add_paragraph(
                f"Diagnóstico de crecimiento — Edad actual {diag['edad_actual']:.0f} años; "
                f"edad de referencia {diag['edad_retroproyeccion']:.0f} años. "
                f"DQ actual {diag['dq_actual']:.2f} cm; DQ estimado {diag['dq_retroproyectado']:.2f} cm. "
                f"Indicador T = {diag['t_veiga']:.2f} %. "
                "El indicador T no representa la intensidad de corta.")
    elif veiga and veiga.get("estado") == "diagnostico":
        documento.add_paragraph(
            f"Veiga — indicador T calculado con el modelo de referencia {veiga['modelo_referencia']} "
            f"({veiga['ce_modelo']}). Especie real: {actual['especie']}. "
            f"Edad actual {veiga['edad_actual']:.0f} años; edad de referencia {veiga['edad_retroproyeccion']:.0f} años. "
            f"DQ actual {veiga['dq_actual']:.2f} cm; DQ estimado {veiga['dq_retroproyectado']:.2f} cm. "
            f"T = {veiga['t_veiga']:.2f} %. "
            "El indicador T no constituye por sí mismo una intensidad de corta; "
            "la regulación residual requiere indicar un diámetro deseado y un área basal guía.")
    elif veiga and veiga.get("estado") == "no_disponible":
        documento.add_paragraph(f"Veiga — {veiga.get('mensaje', 'No disponible.')}")
    else:
        documento.add_paragraph(
            "MMOBI usa p = ICA/V como tasa volumétrica anual. El indicador histórico ICA % de SIMFI no se usa "
            "porque representa ICA/N × 100 y no una tasa volumétrica. Veiga permanece pendiente hasta incorporar "
            "una fórmula validada.")
    documento.add_paragraph(
        "Supuesto de simulación estructural: extracción desde clases diamétricas menores hacia mayores, "
        "incluyendo una fracción de la última clase necesaria. No constituye una recomendación de marqueo.")

    documento.add_heading("3. Comparación de escenarios disponibles", level=1)
    disponibles = [escenario for escenario in escenarios if escenario.get("estado") == "disponible"]
    filas = []
    for escenario in disponibles:
        residual = escenario["residual"]
        equivalentes = escenario["intensidades_equivalentes"]
        guia = escenario.get("guia", {})
        resultado = guia.get("resultado") or {}
        filas.append((
            escenario["nombre"],
            f"{equivalentes['n']:.2f}",
            f"{equivalentes['g']:.2f}",
            f"{equivalentes['v']:.2f}" if equivalentes.get("v") is not None else "—",
            f"{residual['n']:.2f}",
            f"{residual['g']:.3f}",
            f"{residual['v']:.3f}" if residual.get("v") is not None else "—",
            resultado.get("clasificacion", "Sin guía"),
        ))
    _tabla(documento, ("Escenario", "IC N %", "IC G %", "IC V %", "N residual",
                       "G residual", "V residual", "Evaluación guía"), filas,
               titulo="Comparación de escenarios disponibles", numero_tabla=3)

    documento.add_heading("4. Gráfica conjunta de densidad", level=1)
    p = documento.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(grafica_png, width=Cm(16.5))
    if modelo:
        documento.add_paragraph(
            f"Guía utilizada: {modelo.get('nombre_corto', modelo['modelo_id'])}; "
            f"versión {modelo.get('version_modelo', 'no indicada')}.")

    documento.add_heading("5. Criterio adoptado y trazabilidad", level=1)
    adoptado = evaluacion.get("adoptado")
    if adoptado:
        documento.add_paragraph(
            f"Escenario adoptado: {adoptado['criterio']}; intensidad {adoptado['intensidad']:.2f} % "
            f"sobre {adoptado['unidad']}; usuario {adoptado.get('usuario') or 'no identificado'}; "
            f"fecha {adoptado.get('fecha', 'no registrada')}.")
    else:
        documento.add_paragraph("No se ha adoptado un escenario. La comparación no selecciona automáticamente una alternativa.")
    documento.add_paragraph(
        f"Motor {evaluacion.get('version_motor', '—')}; ciclo de corta {evaluacion.get('ciclo_corta', '—')} años; "
        f"modelo {evaluacion.get('modelo_densidad_utilizado') or 'sin guía'}; "
        f"versión {evaluacion.get('version_modelo') or '—'}; generado {fecha.isoformat(timespec='seconds')}.")

    salida = io.BytesIO()
    documento.save(salida)
    salida.seek(0)
    return salida


def generar_reporte_turno(pmf, calculo, grafica_png, logo_path):
    documento = Document()
    seccion = documento.sections[0]
    seccion.top_margin = Cm(1.5)
    seccion.bottom_margin = Cm(1.7)
    seccion.left_margin = Cm(1.8)
    seccion.right_margin = Cm(1.8)
    documento.styles["Normal"].font.name = "Aptos"
    documento.styles["Normal"].font.size = Pt(9.5)
    for nombre, tamano in (("Title", 17), ("Heading 1", 13), ("Heading 2", 10.5)):
        documento.styles[nombre].font.name = "Aptos Display"
        documento.styles[nombre].font.size = Pt(tamano)
        documento.styles[nombre].font.color.rgb = RGBColor(15, 61, 35)
    documento.core_properties.title = "Turno técnico por diámetro objetivo"
    documento.core_properties.author = "Dr.PIFL"
    documento.core_properties.keywords = (
        f"modelo={calculo['modelo_clave']}; version={calculo['modelo_version']}; "
        f"fecha={calculo['fecha_calculo']}")
    _configurar_pie(documento, "Turnos")

    cabecera = documento.add_table(1, 2)
    cabecera.alignment = WD_TABLE_ALIGNMENT.CENTER
    cabecera.rows[0].cells[0].paragraphs[0].add_run().add_picture(logo_path, width=Cm(4.5))
    p = cabecera.rows[0].cells[1].paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p.add_run("SIMFI\n").bold = True
    p.add_run("REPORTE DE TURNO TÉCNICO\n").bold = True
    p.add_run(pmf.predio or pmf.nombre or "Programa de manejo sin nombre")

    documento.add_heading("1. Resultado", level=1)
    p = documento.add_paragraph()
    p.add_run("Turno técnico estimado: ").bold = True
    p.add_run(
        f"{calculo['edad_redondeada']} años, para alcanzar un diámetro sin corteza de "
        f"{calculo['diametro_objetivo']:.2f} cm en calidad de estación {calculo['calidad_estacion']}.")
    tabla = _tabla(documento, ("Concepto", "Resultado"), [
        ("Programa de manejo", calculo.get("proyecto_id") or pmf.nombre),
        ("Especie", calculo["nombre_cientifico"]),
        ("Calidad de estación", calculo["calidad_estacion"]),
        ("Diámetro meta sin corteza", f"{calculo['diametro_objetivo']:.2f} cm"),
        ("Edad calculada", f"{calculo['edad_calculada']:.2f} años"),
        ("Turno técnico redondeado", f"{calculo['edad_redondeada']} años"),
        ("Diámetro verificado", f"{calculo['diametro_verificacion']:.3f} cm"),
        ("Condición del modelo", calculo.get("condicion_tabular") or
         ("Extrapolación" if calculo.get("extrapolacion") else "Interpolación")),
    ], (6.0, 10.5), titulo="Resultado", numero_tabla=1)
    especie_celda = tabla.rows[2].cells[1]
    especie_celda.text = ""
    _agregar_nombre_cientifico(especie_celda.paragraphs[0], calculo["nombre_cientifico"])

    documento.add_heading("2. Modelo de crecimiento", level=1)
    _tabla(documento, ("Elemento", "Información"), [
        ("Modelo", calculo["modelo"]),
        ("Ecuación", calculo["ecuacion"]),
        ("Clave", calculo["modelo_clave"]),
        ("Versión", calculo["modelo_version"]),
        ("Referencia publicada", (f"{calculo['turno_referencia_publicado']} años para "
                                  f"{calculo['diametro_referencia_publicado']:.2f} cm")
         if calculo.get("turno_referencia_publicado") is not None else "—"),
    ], (5.0, 11.5), titulo="Modelo de crecimiento", numero_tabla=2)
    documento.add_paragraph(
        "La edad se obtuvo mediante bisección sobre la rama de crecimiento técnicamente válida y se verificó "
        "sustituyéndola en la ecuación de diámetro. Este turno técnico no es un turno absoluto basado en ICA e IMA en volumen.")

    documento.add_heading("3. Gráfica Edad-Diámetro", level=1)
    p = documento.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(grafica_png, width=Cm(16.5))

    documento.add_heading("4. Advertencias", level=1)
    if calculo.get("advertencias"):
        for advertencia in calculo["advertencias"]:
            documento.add_paragraph(advertencia, style="List Bullet")
    else:
        documento.add_paragraph("El cálculo no generó advertencias metodológicas o de extrapolación.")

    documento.add_heading("5. Fuente y trazabilidad", level=1)
    documento.add_paragraph(calculo["fuente"])
    if calculo.get("paginas_fuente"):
        documento.add_paragraph("Localización en la fuente: " + calculo["paginas_fuente"])
    documento.add_paragraph(
        f"Registro {calculo['id']}; catálogo {calculo.get('catalogo_version', '—')}; "
        f"fecha {calculo['fecha_calculo']}; usuario {calculo.get('usuario') or 'no identificado'}.")

    salida = io.BytesIO()
    documento.save(salida)
    salida.seek(0)
    return salida
