"""Proveedor local Ollama para interpretaciones de resultados ya calculados."""

import json
import time
import urllib.error
import urllib.request

from ia_config import cargar_config, normalizar_terminologia, registrar_ia


DATOS_PRUEBA_IA = {
    "proyecto": "Predio de prueba (no real)",
    "informacion": "Datos de prueba para validar la conexion con la IA local.",
    "rodales": [{"rodal": "R-01", "superficie_ha": 4.5, "arboles_ha": 410,
                 "area_basal_ha_m2": 22.8, "volumen_ha_m3": 168.4,
                 "existencias_m3": 757.8, "incremento_anual_m3_ha": 8.9}],
}


def _local(config):
    return config.get("local", config)


def _endpoint(config, ruta):
    servidor = str(_local(config).get("servidor", "")).strip().rstrip("/")
    return servidor + ruta if servidor else ""


def _timeout_disponibilidad(config):
    try:
        return max(1, int(_local(config).get("timeout_disponibilidad_segundos", 5)))
    except (TypeError, ValueError):
        return 5


def _timeout_generacion(config):
    try:
        return max(1, int(_local(config).get("timeout_generacion_segundos", 180)))
    except (TypeError, ValueError):
        return 180


def _timeout(config):
    """Compatibilidad para llamadas anteriores: timeout de generacion."""
    return _timeout_generacion(config)


def _limite_generacion(config):
    """Limite de tokens de salida: max_completion_tokens o max_tokens."""
    local = _local(config)
    for clave in ("max_completion_tokens", "max_tokens"):
        try:
            valor = int(local.get(clave) or 0)
            if valor > 0:
                return valor
        except (TypeError, ValueError):
            continue
    return 4000


def _http_get_json(uri, timeout, headers=None):
    peticion = urllib.request.Request(uri, headers=headers or {})
    with urllib.request.urlopen(peticion, timeout=timeout) as respuesta:
        return json.loads(respuesta.read().decode("utf-8"))


def _http_post_json(uri, body, timeout, headers=None):
    datos = json.dumps(body).encode("utf-8")
    cabeceras = {"Content-Type": "application/json"}
    cabeceras.update(headers or {})
    peticion = urllib.request.Request(uri, data=datos, method="POST", headers=cabeceras)
    # stream=False hace que Ollama devuelva un JSON final; read() espera el cuerpo completo.
    with urllib.request.urlopen(peticion, timeout=timeout) as respuesta:
        return json.loads(respuesta.read().decode("utf-8"))


def _formatear_solicitud(datos):
    if isinstance(datos, str):
        return datos
    try:
        texto = json.dumps(datos, ensure_ascii=False, indent=2, sort_keys=True)
    except (TypeError, ValueError):
        texto = str(datos)
    return "Resultados ya calculados y validados por SIMFI:\n" + texto


class LocalOllamaProvider:
    nombre = "ollama_local"

    def estado(self, config=None):
        config = config or cargar_config()
        local = _local(config)
        if not config.get("habilitada", True):
            return {"disponible": False, "modelos": [], "mensaje": "La IA local esta deshabilitada."}
        uri = _endpoint(config, "/api/tags")
        if not uri:
            return {"disponible": False, "modelos": [], "mensaje": "No se ha configurado Ollama."}
        inicio = time.monotonic()
        try:
            respuesta = _http_get_json(uri, _timeout_disponibilidad(config))
            modelos = sorted({m.get("name") for m in respuesta.get("models", []) if m.get("name")})
            registrar_ia("info", "ollama estado endpoint=%s modelo=%s duracion=%.3fs",
                         uri, local.get("modelo", ""), time.monotonic() - inicio)
            return {"disponible": True, "modelos": modelos,
                    "mensaje": "Ollama disponible." if modelos else "Ollama disponible, sin modelos detectados."}
        except (OSError, ValueError, urllib.error.URLError) as error:
            registrar_ia("error", "ollama estado endpoint=%s modelo=%s duracion=%.3fs error=%r",
                         uri, local.get("modelo", ""), time.monotonic() - inicio, error, exc_info=True)
            return {"disponible": False, "modelos": [],
                    "mensaje": "La IA local no esta disponible ahora. Ollama no respondio: %s" % error}

    def interpretar(self, datos, modulo="", contexto="", config=None):
        config = config or cargar_config()
        local = _local(config)
        uri = _endpoint(config, "/api/chat")
        modelo = str(local.get("modelo", "qwen2.5:3b"))
        if not config.get("habilitada", True) or not uri:
            return {"ok": False, "texto": None, "motor": self.nombre, "modelo": modelo,
                    "mensaje": "La IA local no esta configurada o esta deshabilitada."}
        cuerpo = {"model": modelo, "stream": False,
                  "messages": [{"role": "system", "content": config.get("prompt_sistema", "")},
                               {"role": "user", "content": contexto or _formatear_solicitud(datos)}],
                  "options": {"num_predict": _limite_generacion(config)}}
        inicio = time.monotonic()
        try:
            respuesta = _http_post_json(uri, cuerpo, _timeout_generacion(config))
            contenido = (respuesta.get("message") or {}).get("content")
            if not isinstance(contenido, str) or not contenido.strip():
                return {"ok": False, "texto": None, "motor": self.nombre, "modelo": modelo,
                        "mensaje": "Ollama respondio sin contenido de texto."}
            metadatos = {
                "finish_reason": respuesta.get("done_reason"),
                "prompt_tokens": respuesta.get("prompt_eval_count"),
                "completion_tokens": respuesta.get("eval_count"),
                "truncada": respuesta.get("done_reason") == "length",
            }
            duracion = time.monotonic() - inicio
            if metadatos["truncada"]:
                registrar_ia("warning",
                             "ollama generacion TRUNCADA por limite de tokens "
                             "done_reason=length prompt_tokens=%r completion_tokens=%r "
                             "limite=%s endpoint=%s modelo=%s modulo=%s duracion=%.3fs",
                             metadatos["prompt_tokens"], metadatos["completion_tokens"],
                             _limite_generacion(config), uri, modelo, modulo, duracion)
            else:
                registrar_ia("info", "ollama generacion done_reason=%r prompt_tokens=%r "
                             "completion_tokens=%r endpoint=%s modelo=%s modulo=%s duracion=%.3fs",
                             metadatos["finish_reason"], metadatos["prompt_tokens"],
                             metadatos["completion_tokens"], uri, modelo, modulo, duracion)
            return {"ok": True, "texto": normalizar_terminologia(contenido.strip()),
                    "motor": self.nombre, "modelo": modelo, "mensaje": None,
                    "metadatos": metadatos}
        except Exception as error:  # La falla nunca interrumpe SIMFI.
            registrar_ia("error", "ollama generacion endpoint=%s modelo=%s modulo=%s duracion=%.3fs error=%r",
                         uri, modelo, modulo, time.monotonic() - inicio, error, exc_info=True)
            return {"ok": False, "texto": None, "motor": self.nombre, "modelo": modelo,
                    "mensaje": "La interpretacion con IA local no esta disponible ahora. "
                               "Error al comunicarse con Ollama: %s" % error}


_PROVEEDOR = LocalOllamaProvider()


def estado_servicio(config=None):
    config = config or cargar_config()
    estado = _PROVEEDOR.estado(config)
    estado["configuracion"] = config
    return estado


def interpretar_resultados(datos, config=None):
    resultado = _PROVEEDOR.interpretar(datos, "prueba_local", config=config)
    return (resultado["ok"], resultado["texto"], resultado["mensaje"],
            resultado.get("metadatos") or {})
