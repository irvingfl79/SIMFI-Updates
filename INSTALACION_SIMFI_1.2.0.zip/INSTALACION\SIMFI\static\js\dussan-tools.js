/* Dussan — puente con el backend de SIMFI.
   Todas las consultas viajan al servidor local, que invoca las funciones ya
   existentes de SIMFI. Aqui no se calcula nada ni se accede a la base de datos. */
(function (global) {
  'use strict';

  function pedir(url, cuerpo) {
    if (!url) {
      return Promise.resolve({ok: false, mensaje: 'Dussan no esta disponible en esta pagina.'});
    }
    var opciones = {
      method: cuerpo ? 'POST' : 'GET',
      credentials: 'same-origin',
      headers: {'X-Requested-With': 'XMLHttpRequest'}
    };
    if (cuerpo) {
      opciones.headers['Content-Type'] = 'application/json';
      opciones.body = JSON.stringify(cuerpo);
    }
    return global.fetch(url, opciones).then(function (respuesta) {
      if (respuesta.status === 401) {
        return {ok: false, mensaje: 'La sesion de SIMFI no esta activa. Vuelve a iniciar sesion.'};
      }
      return respuesta.json().catch(function () {
        return {ok: false, mensaje: 'SIMFI no devolvio una respuesta valida.'};
      });
    }).catch(function () {
      return {ok: false, mensaje: 'No se pudo conectar con el servidor local de SIMFI.'};
    });
  }

  global.DussanTools = {
    /* Consulta una herramienta de lectura puntual. */
    consultar: function (herramienta, argumentos) {
      var base = (global.SIMFI_DUSSAN && global.SIMFI_DUSSAN.endpoints) || {};
      return pedir(base.herramienta, {
        herramienta: herramienta,
        argumentos: argumentos || {}
      });
    },

    /* Pregunta abierta: el servidor consulta lo necesario y responde. */
    preguntar: function (pregunta, opciones) {
      var base = (global.SIMFI_DUSSAN && global.SIMFI_DUSSAN.endpoints) || {};
      var ajustes = opciones || {};
      return pedir(base.chat, {
        pregunta: pregunta,
        rodal: ajustes.rodal || '',
        herramientas: ajustes.herramientas || null
      });
    },

    /* Contexto vigente en el servidor (predio, UMM, modulo, reporte). */
    contexto: function () {
      var base = (global.SIMFI_DUSSAN && global.SIMFI_DUSSAN.endpoints) || {};
      return pedir(base.contexto);
    }
  };
}(window));
