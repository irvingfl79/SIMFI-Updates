import math
import json
import datetime
import os
import uuid
from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict
from data_municipios import MUNICIPIOS


def _promedio_simple(valores):
    valores = [v for v in valores if v is not None]
    return sum(valores) / len(valores) if valores else 0.0


def _clave_categoria(dncc):
    """Clave canonica de categoria diametrica para los valores aprobados.

    Normaliza 25, 25.0 y "25" a "25", y 22.5 a "22.5", para que la consulta
    coincida sin importar el tipo numerico de origen (incluido JSON).
    """
    try:
        valor = float(dncc)
    except (TypeError, ValueError):
        return str(dncc)
    if not math.isfinite(valor):
        return str(dncc)
    return str(int(valor)) if valor.is_integer() else str(valor)


def _leer_aprobados(datos, canonizar_claves=False):
    """Lee valores aprobados del proyecto tolerando formatos parciales.

    Solo conserva numeros finitos mayores que cero; ignora el resto sin
    interrumpir la carga. Los proyectos anteriores no traen estas claves.
    Con canonizar_claves, las categorias diametricas se normalizan para que
    25, 25.0 y "25" coincidan al consultar.
    """
    limpios = {}
    if not isinstance(datos, dict):
        return limpios
    for grupo, valores in datos.items():
        if not isinstance(valores, dict):
            continue
        for clave, valor in valores.items():
            try:
                numero = float(valor)
            except (TypeError, ValueError):
                continue
            if math.isfinite(numero) and numero > 0:
                clave_final = _clave_categoria(clave) if canonizar_claves else str(clave)
                limpios.setdefault(str(grupo), {})[clave_final] = numero
    return limpios


@dataclass
class EcuacionVolumen:
    a0: float = 0.0001
    a1: float = 1.8
    a2: float = 0.9
    b0: float = 0.0
    especie: str = ""

    def calcular(self, d_cm: float, h_m: float) -> float:
        return self.a0 * (d_cm ** self.a1) * (h_m ** self.a2) + self.b0 * (d_cm ** 2)


@dataclass
class Rodal:
    id: str
    superficie_ha: float
    sitios: int = 1
    area_sitio_m2: float = 500.0
    tipo_bosque: str = ""
    calidad_sitio: str = "Media"
    factor_correccion: Optional[float] = None
    finalizado: bool = False
    oculto: bool = False
    tipo_inventario: str = "sitios"

    def factor_expansion(self) -> float:
        return 10000.0 / self.area_sitio_m2 if self.area_sitio_m2 > 0 else 0


@dataclass
class CrecimientoData:
    volumen_actual_m3ha: float = 0
    edad_actual_anios: float = 0
    calidad_sitio: str = "Media"
    ima_esperado: Optional[float] = None

    def ima(self) -> float:
        if self.edad_actual_anios <= 0:
            return 0.0
        return self.volumen_actual_m3ha / self.edad_actual_anios

    def proyectar(self, anos) -> tuple:
        ima = self.ima_esperado if self.ima_esperado else self.ima()
        vol_fut = ima * (self.edad_actual_anios + anos)
        return vol_fut, ima

    def turno_rotacion(self, ima_objetivo) -> Optional[float]:
        if ima_objetivo <= 0:
            return None
        edad_est = self.volumen_actual_m3ha / ima_objetivo
        if edad_est < self.edad_actual_anios:
            return None
        return edad_est


@dataclass
class ClaseDiametrica:
    dncc: float
    altura_m: float = 0
    no_arboles: int = 0

    def __post_init__(self):
        if self.dncc <= 0:
            raise ValueError("DNCC debe ser > 0")


@dataclass
class TablaInventarioRodal:
    rodal_id: str
    especie: str
    clases: List[ClaseDiametrica] = field(default_factory=list)

    def agregar_clase(self, clase: ClaseDiametrica):
        self.clases.append(clase)

    def no_arb_ha(self, clase: ClaseDiametrica, factor_exp: float,
                  num_sitios: int, usar_factor_ajuste: bool = False) -> float:
        if num_sitios <= 0:
            return 0
        return (clase.no_arboles / num_sitios) * factor_exp

    def area_basal_ha(self, clase: ClaseDiametrica, no_arb_ha: float) -> float:
        ab_por_arbol = (clase.dncc / 100) ** 2 * 0.7854
        return ab_por_arbol * no_arb_ha

    def volumen_unitario(self, clase: ClaseDiametrica, pmf) -> float:
        return pmf.volumen_arbol(self.especie, clase.dncc, clase.altura_m)

    def diametro_cuadratico(self, clase: ClaseDiametrica, no_arb_ha: float) -> float:
        if no_arb_ha <= 0:
            return 0.0
        ab_ha = self.area_basal_ha(clase, no_arb_ha)
        return 200.0 * math.sqrt(ab_ha / (math.pi * no_arb_ha))


@dataclass
class ArbolCenso:
    rodal_id: str
    especie: str
    dap_cm: float
    altura_m: float
    no_arboles: int = 1
    id: str = field(default_factory=lambda: uuid.uuid4().hex)


@dataclass
class ExistenciaDirecta:
    """Valores de existencias capturados directamente (rodales tipo existencias).

    No provienen de medicion de arboles: el usuario registra los valores por
    hectarea ya conocidos y SIMFI los integra a los cuadros de existencias.
    """
    rodal_id: str
    especie: str
    arboles_ha: float = 0.0
    ab_ha: float = 0.0
    vol_ha: float = 0.0

    def __post_init__(self):
        for campo in ("arboles_ha", "ab_ha", "vol_ha"):
            setattr(self, campo, _numero_no_negativo(getattr(self, campo), campo))


@dataclass
class IncrementoDirecto:
    """Valores de incrementos capturados directamente (rodales tipo existencias).

    Se consideran por separado de las existencias: el cuadro de incrementos
    no tiene por que coincidir con el de existencias en volumenes ni en area
    basal. Los incrementos son opcionales e independientes. DQ y H describen
    el estado del rodal/especie (diametro cuadratico y altura media).
    """
    rodal_id: str
    especie: str
    arboles_ha: float = 0.0
    ab_ha: float = 0.0
    tp: Optional[float] = None
    ica_ha: Optional[float] = None
    ica_pct: Optional[float] = None
    ima_ha: Optional[float] = None
    edad: Optional[float] = None
    dq_cm: Optional[float] = None
    h_m: Optional[float] = None

    def __post_init__(self):
        for campo in ("arboles_ha", "ab_ha"):
            setattr(self, campo, _numero_no_negativo(getattr(self, campo), campo))
        for campo in ("tp", "edad"):
            valor = getattr(self, campo)
            if valor is None or (isinstance(valor, str) and not valor.strip()):
                setattr(self, campo, None)
                continue
            numero = _numero_no_negativo(valor, campo)
            if numero <= 0:
                raise ValueError(f"{campo} debe ser un numero mayor que cero")
            setattr(self, campo, numero)
        for campo in ("ica_ha", "ica_pct", "ima_ha", "dq_cm", "h_m"):
            valor = getattr(self, campo)
            if valor is None or (isinstance(valor, str) and not valor.strip()):
                setattr(self, campo, None)
            else:
                setattr(self, campo, _numero_no_negativo(valor, campo))


def _numero_no_negativo(valor, campo):
    try:
        numero = float(valor)
    except (TypeError, ValueError):
        raise ValueError(f"{campo} debe ser un numero mayor o igual que cero")
    if not math.isfinite(numero) or numero < 0:
        raise ValueError(f"{campo} debe ser un numero mayor o igual que cero")
    return numero


@dataclass
class AnualidadCorta:
    numero: int
    anio: int


@dataclass
class IntervencionCorta:
    id: str
    anualidad: int
    rodal_id: str
    superficie_ha: float
    tratamiento: str
    superficie_completa: bool = False
    intervencion_origen_id: str = ""
    posibilidad_editada: Dict[str, float] = field(default_factory=dict)
    infraestructura: Dict[str, float] = field(default_factory=dict)
    orden: Optional[int] = None


@dataclass
class PlanCortasData:
    anio_inicio: int = field(default_factory=lambda: datetime.datetime.now().year)
    superficie_total_ha: float = 0
    volumen_m3ha: float = 0
    ciclo_corta_anios: float = 10
    intensidad_corta: float = 0.30
    area_anual_ha: float = 0
    tipo_programacion: str = "anual"
    cantidad_personalizada: int = 10
    anualidades: List[AnualidadCorta] = field(default_factory=list)
    intervenciones: List[IntervencionCorta] = field(default_factory=list)

    def __post_init__(self):
        self.anualidades = [a if isinstance(a, AnualidadCorta) else AnualidadCorta(**a)
                            for a in self.anualidades]
        self.intervenciones = [i if isinstance(i, IntervencionCorta) else IntervencionCorta(**i)
                               for i in self.intervenciones]
        if not self.anualidades:
            self.generar_anualidades()
        if self.area_anual_ha == 0 and self.ciclo_corta_anios > 0:
            self.area_anual_ha = self.superficie_total_ha / self.ciclo_corta_anios

    def generar_anualidades(self):
        configuraciones = {
            "anual": (10, 1),
            "bianual": (5, 2),
            "trianual": (3, 3),
        }
        if self.tipo_programacion == "personalizado":
            cantidad, paso = max(1, int(self.cantidad_personalizada)), 1
        else:
            cantidad, paso = configuraciones.get(self.tipo_programacion, (10, 1))
        self.anualidades = [AnualidadCorta(numero=n, anio=self.anio_inicio + ((n - 1) * paso))
                            for n in range(1, cantidad + 1)]

    def volumen_corta_permitido(self) -> float:
        return self.area_anual_ha * self.volumen_m3ha * self.intensidad_corta

    def volumen_cortar_ha(self) -> float:
        return self.volumen_m3ha * self.intensidad_corta

    def corta_total_volumen(self, area_cortar_ha) -> float:
        return area_cortar_ha * self.volumen_cortar_ha()

    def numero_rodales(self, area_rodal_ha=20.0) -> int:
        if area_rodal_ha <= 0:
            return 0
        return math.ceil(self.superficie_total_ha / area_rodal_ha)


_ECUACIONES_PREDET = {
    'Pinus rudis':      {'a0': 0.0000763, 'a1': 1.7990995, 'a2': 1.0374198, 'b0': 0.0000815},
    'Pinus montezumae':    {'a0': 0.000043,  'a1': 1.9890309, 'a2': 0.9999733, 'b0': 0.0000959},
    'Pinus teocote':       {'a0': 0.000044,  'a1': 1.979673,  'a2': 0.9786562, 'b0': 0.0000603},
    'Pinus patula':        {'a0': 0.0001149, 'a1': 1.9813385, 'a2': 0.6306969, 'b0': 0.0000453},
    'Pinus leiophylla':    {'a0': 0.0000318, 'a1': 2.0016571, 'a2': 1.0418818, 'b0': 0.0000949},
    'Pinus pseudostrobus': {'a0': 0.000054,  'a1': 1.5534118, 'a2': 1.3944669, 'b0': 0.000058},
    'Abies religiosa':  {'a0': 0.0000335, 'a1': 1.5680023, 'a2': 1.4785289, 'b0': 0.0000266},
    'Pinus ayacahuite':    {'a0': 0.0000826, 'a1': 1.6370591, 'a2': 1.1328258, 'b0': 0.0000466},
    'Quercus affinis':  {'a0': 0.0000576, 'a1': 1.856037,   'a2': 0.9789798, 'b0': 0.0001512},
    'Quercus candicans':{'a0': 0.000061,  'a1': 1.8293128, 'a2': 0.9859336, 'b0': 0.0001374},
    'Quercus crassifolia':   {'a0': 0.0000511, 'a1': 1.9153686, 'a2': 0.9314777, 'b0': 0.0001647},
    'Quercus crassipes':     {'a0': 0.000119,  'a1': 1.4012428, 'a2': 1.2446428, 'b0': 0.0001881},
    'Quercus laurina':  {'a0': 0.0000294, 'a1': 1.7949641, 'a2': 1.2551233, 'b0': 0.0001874},
    'Quercus mexicana': {'a0': 0.000032,  'a1': 1.6403249, 'a2': 1.4144319, 'b0': 0.0001873},
    'Quercus obtusata':      {'a0': 0.0000553, 'a1': 1.8925001, 'a2': 0.9413444, 'b0': 0.000181},
    'Quercus rugosa':        {'a0': 0.0000556, 'a1': 1.9501717, 'a2': 0.8537239, 'b0': 0.0001927},
    'Alnus arguta':            {'a0': 0.0000457, 'a1': 1.9076452, 'a2': 0.9878668, 'b0': 0.0001296},
    'Arbutus xalapensis':          {'a0': 0.000062,  'a1': 1.8215443, 'a2': 0.9612368, 'b0': 0.0001334},
    'Juniperus deppeana':{'a0': 0.0001401, 'a1': 1.6156095, 'a2': 0.9375533, 'b0': 0.0001165},
    'Cupressus lindleyi':{'a0': 0.0000797, 'a1': 1.8317317, 'a2': 0.9278618, 'b0': 0.000014},
    'Pinus greggii':       {'a0': 0.0000622, 'a1': 1.9635088, 'a2': 0.8628189, 'b0': 0.0000708},
}

_TP_ECUACIONES_PREDET = {
    'Pinus patula':        {'a': 9.4322, 'b': -0.9294, 'c': 0.02695},
    'Pinus ayacahuite':    {'a': 9.4322, 'b': -0.9294, 'c': 0.02695},
    'Pinus leiophylla':    {'a': 13.8465, 'b': -1.0502, 'c': 0.02978},
    'Pinus rudis':      {'a': 15.7326, 'b': -1.1777, 'c': 0.032806},
    'Abies religiosa':  {'a': 9.3299, 'b': -0.6979, 'c': 0.019705},
    'Cupressus lindleyi':{'a': 9.4322, 'b': -0.9294, 'c': 0.02695},
    'Pinus teocote':       {'a': 13.8465, 'b': -1.0502, 'c': 0.02978},
    'Pinus montezumae':    {'a': 8.378, 'b': -0.2755, 'c': 0.008254},
    'Pinus pseudostrobus': {'a': 9.3299, 'b': -0.6979, 'c': 0.019705},
    'Pinus greggii':       {'a': 13.8465, 'b': -1.0502, 'c': 0.02978},
    'Juniperus deppeana':{'a': 17.2841, 'b': -1.4368, 'c': 0.04162},
}

_EDAD_ECUACIONES_PREDET = {
    'Pinus patula':        {'a': 0.9195, 'b': 1.9724, 'c': -0.086395, 'd': 0.001514},
    'Pinus rudis':      {'a': 1.3773, 'b': 3.1471, 'c': -0.124992, 'd': 0.002336},
    'Pinus teocote':       {'a': 4.2773, 'b': 1.4698, 'c': -0.007009, 'd': 0.0003537},
    'Abies religiosa':  {'a': -0.1471, 'b': 2.5639, 'c': -0.100925, 'd': 0.001685},
    'Juniperus deppeana':{'a': 4.3048, 'b': 3.4905, 'c': -0.121395, 'd': 0.002684},
    'Pinus ayacahuite':    {'a': 0.9195, 'b': 1.9724, 'c': -0.086395, 'd': 0.001514},
    'Pinus leiophylla':    {'a': 4.2773, 'b': 1.4698, 'c': -0.007009, 'd': 0.0003537},
    'Pinus montezumae':    {'a': 0.9195, 'b': 1.9724, 'c': -0.086395, 'd': 0.001514},
    'Pinus pseudostrobus': {'a': -0.1471, 'b': 2.5639, 'c': -0.100925, 'd': 0.001685},
    'Pinus greggii':       {'a': 4.2773, 'b': 1.4698, 'c': -0.007009, 'd': 0.0003537},
    'Cupressus lindleyi':{'a': 0.9195, 'b': 1.9724, 'c': -0.086395, 'd': 0.001514},
}

_FACTOR_MS = 0.5
_FACTOR_RAICES = 1.3
_FACTOR_CO2 = 3.67

_CARBONO_FRACCION = {
    'Pinus rudis': 0.47, 'Pinus montezumae': 0.47, 'Pinus teocote': 0.47,
    'Pinus patula': 0.47, 'Pinus leiophylla': 0.47, 'Pinus pseudostrobus': 0.47,
    'Abies religiosa': 0.47, 'Pinus ayacahuite': 0.47,
    'Quercus affinis': 0.5, 'Quercus candicans': 0.5, 'Quercus crassifolia': 0.5,
    'Quercus crassipes': 0.5, 'Quercus laurina': 0.5, 'Quercus mexicana': 0.5,
    'Quercus obtusata': 0.5, 'Quercus rugosa': 0.5,
    'Alnus arguta': 0.5, 'Arbutus xalapensis': 0.5,
    'Juniperus deppeana': 0.47, 'Cupressus lindleyi': 0.47, 'Pinus greggii': 0.47,
}
_CARBONO_FRACCION_DEFAULT = 0.47


def _orden_especies(esp: str) -> tuple:
    nombre = str(esp or '').strip()
    nombre_cf = nombre.casefold()
    if nombre_cf.startswith(('abies', 'pinus', 'cupressus', 'a.', 'p.')):
        grupo = 1
    elif nombre_cf.startswith(('quercus', 'q.')):
        grupo = 2
    else:
        grupo = 3
    return (grupo, nombre_cf)


def _orden_especie_volumen(especie: str, volumen=0) -> tuple:
    """Ordena por grupo y volumen descendente, con especie como desempate."""
    try:
        volumen = float(volumen or 0)
    except (TypeError, ValueError):
        volumen = 0.0
    grupo, nombre = _orden_especies(especie)
    return (grupo, -volumen, nombre)


# Generos de coniferas sujetos a reforestacion por planta; las latifoliadas
# se regeneran por rebrotes y quedan fuera del cuadro de reforestacion.
GENEROS_CONIFERAS = ("abies", "cupressus", "juniperus", "pinus")


def es_conifera(especie: str) -> bool:
    """Identifica los generos de coniferas que se reforestan por planta."""
    genero = (especie or "").strip().split()
    return bool(genero) and genero[0].casefold() in GENEROS_CONIFERAS


class PMFProyecto:
    def __init__(self, nombre="Sin nombre", ruta_archivo="",
                 predio="", municipio="", propietario="", estado=""):
        self.nombre = nombre
        self.ruta_archivo = ruta_archivo
        self.predio = predio
        self.municipio = municipio
        self.propietario = propietario
        self.estado = estado
        self.especies: List[str] = []
        self.ecuaciones: Dict[str, EcuacionVolumen] = {}
        self.area_sitio_m2: float = 500.0
        self.usar_factor_ajuste: bool = False
        self.factor_ajuste: float = 0.0
        self.creado = datetime.datetime.now().isoformat()
        self.modificado = self.creado
        self.rodales: List[Rodal] = []
        self.tablas_inventario: List[TablaInventarioRodal] = []
        self.censos_totales: List[ArbolCenso] = []
        self.existencias_directas: List[ExistenciaDirecta] = []
        self.incrementos_directos: List[IncrementoDirecto] = []
        self.crecimiento = CrecimientoData()
        self.plan_cortas = PlanCortasData()
        self.tiempo_paso: Dict[str, Dict[int, float]] = {}
        self.tp_ecuaciones: Dict[str, Dict[str, float]] = {}
        self.edad_ecuaciones: Dict[str, Dict[str, float]] = {}
        # Valores aprobados manualmente por el usuario en el cuadro de
        # incrementos. Tienen prioridad sobre ecuaciones y tablas al calcular,
        # sin modificar las fuentes originales. Claves canonicas de categoria.
        self.tp_aprobados: Dict[str, Dict[str, float]] = {}
        # Edad aprobada por rodal y especie (clave: id de rodal).
        self.edad_aprobada: Dict[str, Dict[str, float]] = {}
        self.intensidad_corta: Dict[str, Dict[str, float]] = {}
        # Procedencia de intensidades aplicadas desde aclareos al cuadro de
        # existencias: {rodal: {especie: {criterio, intensidad, fecha, usuario}}}.
        # Se limpia cuando la celda se edita directamente en el cuadro.
        self.origen_intensidad: Dict[str, Dict[str, dict]] = {}
        self.rodales_aclareo: List[str] = []
        self.escenarios_aclareo: Dict[str, dict] = {}
        self.calculos_turno: List[dict] = []
        # Capturas silvícolas estructuradas. Permanecen vacías en proyectos legacy.
        self.regeneracion: List[dict] = []
        self.observaciones_sanitarias: List[dict] = []
        self.inventarios_historicos: List[dict] = []
        self.tratamientos_silvicola: List[dict] = []
        self.metas_manejo: Dict[str, object] = {}
        # Registros inmutables de generación para reproducir conclusiones posteriores.
        self.reportes_generados: List[dict] = []
        # Importaciones y resultados del módulo aislado de error de muestreo.
        self.muestreo_error: List[dict] = []
        self.muestreo_borradores: List[dict] = []
        self.reportes_error_muestreo: List[dict] = []
        # Capa geográfica opcional asociada al proyecto y lista para el visor.
        self.cartografia: dict = {}
        # Captura independiente del cuadro de clasificación de superficies.
        self.superficies: dict = {}
        # Reforestación derivada del plan de cortas: densidad de plantación y
        # especies de coníferas seleccionadas por área de regeneración.
        self.reforestacion: dict = {"densidad": None, "selecciones": [],
                                    "superficies": {}, "anios": {},
                                    "manuales": []}

    def registrar_reporte(self, contexto: dict, nivel: str, usuario: str = "", observaciones: str = "") -> dict:
        reporte = {
            "id": uuid.uuid4().hex,
            "fecha": datetime.datetime.now().isoformat(),
            "nivel": nivel,
            "usuario": usuario,
            "observaciones": observaciones.strip(),
            "version_reglas": contexto.get("version_reglas", ""),
            "contexto": contexto,
        }
        self.reportes_generados.append(reporte)
        return reporte

    @property
    def superficie_total_ha(self) -> float:
        return sum(r.superficie_ha for r in self.rodales if not r.oculto)

    @property
    def num_rodales(self) -> int:
        return sum(1 for r in self.rodales if not r.oculto)

    @property
    def total_sitios(self) -> int:
        return sum(r.sitios for r in self.rodales if not r.oculto)

    @property
    def rodales_visibles(self) -> List[Rodal]:
        return [rodal for rodal in self.rodales if not rodal.oculto]

    def asignar_ecuacion(self, especie: str, ecuacion: EcuacionVolumen):
        self.ecuaciones[especie] = ecuacion

    def obtener_ecuacion(self, especie: str) -> Optional[EcuacionVolumen]:
        return self.ecuaciones.get(especie)

    def eliminar_ecuacion(self, especie: str) -> bool:
        if especie in self.ecuaciones:
            del self.ecuaciones[especie]
            return True
        return False

    def volumen_arbol(self, especie: str, dap_cm: float, altura_m: float) -> float:
        ec = self.obtener_ecuacion(especie)
        if ec:
            return ec.calcular(dap_cm, altura_m)
        return math.pi * (dap_cm ** 2) / 40000.0 * altura_m * 0.65

    def agregar_especie(self, nombre: str):
        nombre = nombre.strip()
        if nombre and nombre not in self.especies:
            self.especies.append(nombre)

    def eliminar_especie(self, nombre: str) -> bool:
        if nombre in self.especies:
            self.especies.remove(nombre)
            return True
        return False

    def obtener_factor_expansion(self, rodal: Optional[Rodal] = None) -> float:
        if self.usar_factor_ajuste and self.factor_ajuste > 0:
            return self.factor_ajuste
        area = rodal.area_sitio_m2 if (rodal and rodal.area_sitio_m2 > 0) else self.area_sitio_m2
        return 10000.0 / area if area > 0 else 0

    def agregar_rodal(self, rodal: Rodal, despues_de: Optional[str] = None):
        if despues_de is None:
            self.rodales.append(rodal)
            return
        for indice, existente in enumerate(self.rodales):
            if existente.id.casefold() == despues_de.casefold():
                self.rodales.insert(indice + 1, rodal)
                return
        raise ValueError(f"No existe el rodal de referencia '{despues_de}'")

    def buscar_rodal(self, id_rodal: str) -> Optional[Rodal]:
        for r in self.rodales:
            if r.id.lower() == id_rodal.lower():
                return r
        return None

    def eliminar_rodal(self, id_rodal: str) -> bool:
        r = self.buscar_rodal(id_rodal)
        if r:
            self.rodales.remove(r)
            return True
        return False

    def renombrar_rodal(self, id_rodal: str, nuevo_id: str) -> bool:
        rodal = self.buscar_rodal(id_rodal)
        if not rodal:
            return False
        nuevo_id = " ".join(str(nuevo_id or "").strip().split())
        if not nuevo_id:
            raise ValueError("El nombre del rodal es obligatorio")
        if len(nuevo_id) > 120 or any(ord(caracter) < 32 for caracter in nuevo_id):
            raise ValueError("El nombre del rodal no es válido")
        existente = self.buscar_rodal(nuevo_id)
        if existente and existente is not rodal:
            raise ValueError(f"Ya existe un rodal con ID '{nuevo_id}'")

        anterior = rodal.id
        if anterior == nuevo_id:
            return True
        rodal.id = nuevo_id
        for tabla in self.tablas_inventario:
            if tabla.rodal_id.casefold() == anterior.casefold():
                tabla.rodal_id = nuevo_id
        for arbol in self.censos_totales:
            if arbol.rodal_id.casefold() == anterior.casefold():
                arbol.rodal_id = nuevo_id
        for intervencion in self.plan_cortas.intervenciones:
            if intervencion.rodal_id.casefold() == anterior.casefold():
                intervencion.rodal_id = nuevo_id

        for clave in list(self.intensidad_corta):
            if clave.casefold() == anterior.casefold():
                self.intensidad_corta[nuevo_id] = self.intensidad_corta.pop(clave)
        self.rodales_aclareo = [
            nuevo_id if rid.casefold() == anterior.casefold() else rid
            for rid in self.rodales_aclareo
        ]

        escenarios = {}
        for clave, evaluacion in self.escenarios_aclareo.items():
            partes = clave.split("||", 1)
            nueva_clave = (f"{nuevo_id}||{partes[1]}"
                           if len(partes) == 2 and partes[0].casefold() == anterior.casefold()
                           else clave)
            actual = evaluacion.get("actual") if isinstance(evaluacion, dict) else None
            if isinstance(actual, dict) and str(actual.get("rodal", "")).casefold() == anterior.casefold():
                actual["rodal"] = nuevo_id
            escenarios[nueva_clave] = evaluacion
        self.escenarios_aclareo = escenarios
        return True

    def buscar_tabla_inventario(self, rodal_id: str, especie: str) -> Optional[TablaInventarioRodal]:
        for t in self.tablas_inventario:
            if t.rodal_id.lower() == rodal_id.lower() and t.especie.lower() == especie.lower():
                return t
        return None

    def agregar_tabla_inventario(self, tabla: TablaInventarioRodal):
        self.tablas_inventario.append(tabla)

    def eliminar_tabla_inventario(self, rodal_id: str, especie: str) -> bool:
        t = self.buscar_tabla_inventario(rodal_id, especie)
        if t:
            self.tablas_inventario.remove(t)
            return True
        return False

    def limpiar_tablas_inventario(self) -> int:
        total = len(self.tablas_inventario)
        self.tablas_inventario.clear()
        return total

    def buscar_existencia_directa(self, rodal_id: str, especie: str) -> Optional[ExistenciaDirecta]:
        for registro in self.existencias_directas:
            if (registro.rodal_id.casefold() == rodal_id.casefold() and
                    registro.especie.casefold() == especie.casefold()):
                return registro
        return None

    def fijar_existencia_directa(self, rodal_id: str, especie: str,
                                 arboles_ha=0.0, ab_ha=0.0, vol_ha=0.0):
        """Registra o actualiza los valores directos de existencias."""
        arboles = _numero_no_negativo(arboles_ha, "No. arboles/ha")
        ab = _numero_no_negativo(ab_ha, "Area basal (m2/ha)")
        vol = _numero_no_negativo(vol_ha, "Volumen (m3/ha)")
        existente = self.buscar_existencia_directa(rodal_id, especie)
        if existente:
            existente.arboles_ha = arboles
            existente.ab_ha = ab
            existente.vol_ha = vol
            return existente
        registro = ExistenciaDirecta(rodal_id=rodal_id, especie=especie,
                                     arboles_ha=arboles, ab_ha=ab, vol_ha=vol)
        self.existencias_directas.append(registro)
        return registro

    def buscar_incremento_directo(self, rodal_id: str, especie: str) -> Optional[IncrementoDirecto]:
        for registro in self.incrementos_directos:
            if (registro.rodal_id.casefold() == rodal_id.casefold() and
                    registro.especie.casefold() == especie.casefold()):
                return registro
        return None

    def fijar_incremento_directo(self, rodal_id: str, especie: str,
                                 arboles_ha=0.0, ab_ha=0.0,
                                 tp=None, ica_ha=None, ica_pct=None,
                                 ima_ha=None, edad=None,
                                 dq_cm=None, h_m=None):
        """Registra o actualiza los valores directos de incrementos."""
        arboles = _numero_no_negativo(arboles_ha, "No. arboles/ha")
        ab = _numero_no_negativo(ab_ha, "Area basal (m2/ha)")
        existente = self.buscar_incremento_directo(rodal_id, especie)
        if existente:
            existente.arboles_ha = arboles
            existente.ab_ha = ab
            for campo, valor in (("tp", tp), ("ica_ha", ica_ha),
                                 ("ica_pct", ica_pct), ("ima_ha", ima_ha),
                                 ("edad", edad), ("dq_cm", dq_cm), ("h_m", h_m)):
                if valor is None or (isinstance(valor, str) and not valor.strip()):
                    setattr(existente, campo, None)
                    continue
                numero = _numero_no_negativo(valor, campo)
                if campo in ("tp", "edad") and numero <= 0:
                    raise ValueError(f"{campo} debe ser un numero mayor que cero")
                setattr(existente, campo, numero)
            return existente
        registro = IncrementoDirecto(rodal_id=rodal_id, especie=especie,
                                     arboles_ha=arboles, ab_ha=ab,
                                     tp=tp, ica_ha=ica_ha, ica_pct=ica_pct,
                                     ima_ha=ima_ha, edad=edad,
                                     dq_cm=dq_cm, h_m=h_m)
        self.incrementos_directos.append(registro)
        return registro

    def eliminar_incremento_directo(self, rodal_id: str, especie: str) -> bool:
        existente = self.buscar_incremento_directo(rodal_id, especie)
        if existente:
            self.incrementos_directos.remove(existente)
            return True
        return False

    def arboles_censo(self, rodal_id: str = "", especie: str = "") -> List[ArbolCenso]:
        return [arbol for arbol in self.censos_totales
                if (not rodal_id or arbol.rodal_id.casefold() == rodal_id.casefold()) and
                (not especie or arbol.especie.casefold() == especie.casefold())]

    def agregar_arbol_censo(self, arbol: ArbolCenso):
        if arbol.dap_cm <= 0 or arbol.altura_m <= 0 or arbol.no_arboles <= 0:
            raise ValueError("El DAP, la altura y el número de árboles deben ser mayores que cero")
        self.censos_totales.append(arbol)

    def eliminar_arbol_censo(self, arbol_id: str) -> bool:
        for arbol in self.censos_totales:
            if arbol.id == arbol_id:
                self.censos_totales.remove(arbol)
                return True
        return False

    def resumen_censo_total(self, rodal_id: str) -> dict:
        rodal = self.buscar_rodal(rodal_id)
        arboles = self.arboles_censo(rodal_id)
        por_especie = {}
        for arbol in arboles:
            volumen = self.volumen_arbol(arbol.especie, arbol.dap_cm, arbol.altura_m) * arbol.no_arboles
            fila = por_especie.setdefault(arbol.especie, {"especie": arbol.especie,
                                                          "arboles": 0, "volumen_m3": 0.0})
            fila["arboles"] += arbol.no_arboles
            fila["volumen_m3"] += volumen
        superficie = rodal.superficie_ha if rodal else 0.0
        filas = []
        for especie in sorted(por_especie, key=_orden_especies):
            fila = por_especie[especie]
            fila["volumen_ha"] = fila["volumen_m3"] / superficie if superficie > 0 else 0.0
            filas.append(fila)
        volumen_total = sum(fila["volumen_m3"] for fila in filas)
        return {"filas": filas, "arboles": sum(arbol.no_arboles for arbol in arboles), "superficie_ha": superficie,
                "volumen_m3": volumen_total,
                "volumen_ha": volumen_total / superficie if superficie > 0 else 0.0}

    def cargar_tp_predeterminadas(self):
        for especie, params in _TP_ECUACIONES_PREDET.items():
            self.agregar_especie(especie)
            self.tp_ecuaciones[especie] = params
        return len(_TP_ECUACIONES_PREDET)

    def cargar_edad_predeterminadas(self):
        for especie, params in _EDAD_ECUACIONES_PREDET.items():
            self.agregar_especie(especie)
            self.edad_ecuaciones[especie] = params
        return len(_EDAD_ECUACIONES_PREDET)

    def calcular_tp(self, especie: str, dncc: float) -> Optional[float]:
        aprobados = self.tp_aprobados.get(especie, {})
        if aprobados:
            manual = aprobados.get(_clave_categoria(dncc))
            try:
                if manual is not None and float(manual) > 0:
                    return float(manual)
            except (TypeError, ValueError):
                pass
        ecu = self.tp_ecuaciones.get(especie)
        if ecu:
            tp = ecu.get("a", 0) + ecu.get("b", 0) * dncc + ecu.get("c", 0) * dncc ** 2
            return max(tp, 0.5) if tp else None
        return self.tiempo_paso.get(especie, {}).get(dncc)

    def calcular_edad(self, especie: str, dncc: float) -> Optional[float]:
        ecu = self.edad_ecuaciones.get(especie)
        if ecu:
            e = ecu.get("a", 0) + ecu.get("b", 0) * dncc + ecu.get("c", 0) * dncc ** 2 + ecu.get("d", 0) * dncc ** 3
            return max(e, 0.5) if e else None
        return None

    def fijar_tp_aprobado(self, especie: str, categoria, valor):
        """Registra el TP aprobado para especie y categoria diametrica.

        Un valor vacio restablece el calculado (elimina el aprobado). Las
        ecuaciones y tablas originales no se modifican.
        """
        clave = _clave_categoria(categoria)
        if valor is None or (isinstance(valor, str) and not valor.strip()):
            if especie in self.tp_aprobados:
                self.tp_aprobados[especie].pop(clave, None)
                if not self.tp_aprobados[especie]:
                    del self.tp_aprobados[especie]
            return None
        try:
            numero = float(valor)
        except (TypeError, ValueError):
            raise ValueError("El tiempo de paso debe ser un numero mayor que cero")
        if not math.isfinite(numero) or numero <= 0:
            raise ValueError("El tiempo de paso debe ser un numero mayor que cero")
        self.tp_aprobados.setdefault(especie, {})[clave] = numero
        return numero

    def fijar_edad_aprobada(self, rodal_id: str, especie: str, valor):
        """Registra la edad aprobada para rodal y especie.

        Un valor vacio restablece la calculada (elimina la aprobada).
        """
        rid = str(rodal_id or "").strip()
        if valor is None or (isinstance(valor, str) and not valor.strip()):
            if rid in self.edad_aprobada:
                self.edad_aprobada[rid].pop(especie, None)
                if not self.edad_aprobada[rid]:
                    del self.edad_aprobada[rid]
            return None
        try:
            numero = float(valor)
        except (TypeError, ValueError):
            raise ValueError("La edad debe ser un numero mayor que cero")
        if not math.isfinite(numero) or numero <= 0:
            raise ValueError("La edad debe ser un numero mayor que cero")
        self.edad_aprobada.setdefault(rid, {})[especie] = numero
        return numero

    def especies_inventario_rodal(self, rodal_id: str) -> List[str]:
        rodal = self.buscar_rodal(rodal_id)
        if not rodal:
            return []
        if rodal.tipo_inventario == "censo_total":
            especies = {arbol.especie for arbol in self.arboles_censo(rodal_id)}
        elif rodal.tipo_inventario == "existencias":
            especies = {registro.especie for registro in self.existencias_directas
                        if registro.rodal_id.casefold() == rodal_id.casefold()}
        else:
            especies = {tabla.especie for tabla in self.tablas_inventario
                         if tabla.rodal_id == rodal_id}
        return sorted(especies, key=_orden_especies)

    def _calc_valores_censo_total(self, rodal: Rodal, especie: str):
        arboles = self.arboles_censo(rodal.id, especie)
        if not arboles or rodal.superficie_ha <= 0:
            return None
        total_arboles = sum(arbol.no_arboles for arbol in arboles)
        volumen_total = area_basal_total = suma_d2_n = suma_h_n = 0.0
        for arbol in arboles:
            cantidad = arbol.no_arboles
            volumen_total += self.volumen_arbol(especie, arbol.dap_cm, arbol.altura_m) * cantidad
            area_basal_total += math.pi * (arbol.dap_cm / 100) ** 2 / 4 * cantidad
            suma_d2_n += arbol.dap_cm ** 2 * cantidad
            suma_h_n += arbol.altura_m * cantidad
        sup = rodal.superficie_ha
        ica = 0.0
        tiene_tp = (especie in self.tp_ecuaciones or bool(self.tiempo_paso.get(especie))
                    or bool(self.tp_aprobados.get(especie)))
        if tiene_tp:
            for arbol in arboles:
                tp = self.calcular_tp(especie, arbol.dap_cm)
                if tp:
                    volumen_ha_celda = (self.volumen_arbol(especie, arbol.dap_cm, arbol.altura_m)
                                        * arbol.no_arboles / sup)
                    ica += volumen_ha_celda / (arbol.dap_cm * tp) * 10.0
        arb_ha = total_arboles / sup
        return {
            "Arb/ha": arb_ha,
            "AB m2/ha": area_basal_total / sup,
            "ER m3/ha": volumen_total / sup,
            "ERT VTA": volumen_total,
            "ICA m3": ica if tiene_tp else None,
            "ICA %": ica / arb_ha * 100 if tiene_tp and arb_ha > 0 else None,
            "Dg cm": (suma_d2_n / total_arboles) ** 0.5 if total_arboles else 0,
            "H prom m": suma_h_n / total_arboles if total_arboles else 0,
        }

    def _calc_valores_rodal_especie(self, rodal_id: str, especie: str):
        rodal = self.buscar_rodal(rodal_id)
        if not rodal or rodal.oculto:
            return None
        if rodal.tipo_inventario == "censo_total":
            return self._calc_valores_censo_total(rodal, especie)
        if rodal.tipo_inventario == "existencias":
            return self._calc_valores_existencias_directas(rodal, especie)
        tabla = self.buscar_tabla_inventario(rodal_id, especie)
        if not tabla:
            return None
        factor_exp = self.obtener_factor_expansion(rodal)
        num_sitios = rodal.sitios
        sup = rodal.superficie_ha
        suma_nah = 0.0
        suma_ab = 0.0
        suma_er = 0.0
        suma_ert = 0.0
        suma_d2_nah = 0.0
        suma_h_nah = 0.0
        for c in tabla.clases:
            if c.no_arboles == 0:
                continue
            nah = tabla.no_arb_ha(c, factor_exp, num_sitios, self.usar_factor_ajuste)
            ab = tabla.area_basal_ha(c, nah)
            vu = tabla.volumen_unitario(c, self)
            er = vu * nah
            ert = er * sup
            suma_nah += nah
            suma_ab += ab
            suma_er += er
            suma_ert += ert
            suma_d2_nah += c.dncc ** 2 * nah
            suma_h_nah += c.altura_m * nah
        dg = (suma_d2_nah / suma_nah) ** 0.5 if suma_nah > 0 else 0
        hprom = suma_h_nah / suma_nah if suma_nah > 0 else 0
        tiene_tp = (especie in self.tp_ecuaciones or bool(self.tiempo_paso.get(especie))
                    or bool(self.tp_aprobados.get(especie)))
        suma_ica = 0.0
        for c in tabla.clases:
            if c.no_arboles == 0:
                continue
            tp = self.calcular_tp(especie, c.dncc)
            if tp is None:
                continue
            nah = tabla.no_arb_ha(c, factor_exp, num_sitios, self.usar_factor_ajuste)
            vu = tabla.volumen_unitario(c, self)
            vol_ha = vu * nah
            suma_ica += vol_ha / (c.dncc * tp) * 10.0
        ica_pct = suma_ica / suma_nah * 100 if suma_nah > 0 else 0
        return {
            'Arb/ha': suma_nah,
            'AB m2/ha': suma_ab,
            'ER m3/ha': suma_er,
            'ERT VTA': suma_ert,
            'ICA m3': suma_ica if tiene_tp else None,
            'ICA %': ica_pct if tiene_tp else None,
            'Dg cm': dg,
            'H prom m': hprom,
        }

    def _calc_valores_existencias_directas(self, rodal: Rodal, especie: str):
        """Valores capturados directamente (rodales tipo existencias).

        Devuelve la misma estructura que los demas metodos para que los
        cuadros oficiales los integren sin cambios.
        """
        registro = self.buscar_existencia_directa(rodal.id, especie)
        if not registro:
            return None
        sup = rodal.superficie_ha or 0
        return {
            'Arb/ha': registro.arboles_ha,
            'AB m2/ha': registro.ab_ha,
            'ER m3/ha': registro.vol_ha,
            'ERT VTA': registro.vol_ha * sup,
            'ICA m3': None,
            'ICA %': None,
            'Dg cm': 0,
            'H prom m': 0,
        }

    def concentrado_datos(self):
        especies = sorted({especie for rodal in self.rodales_visibles
                           for especie in self.especies_inventario_rodal(rodal.id)}, key=_orden_especies)
        rodales_ids = [r.id for r in self.rodales_visibles
                       if self.especies_inventario_rodal(r.id)]
        if not especies or not rodales_ids:
            return []
        variables = ['Arb/ha', 'AB m2/ha', 'ER m3/ha', 'ERT VTA', 'ICA m3', 'ICA %', 'Dg cm', 'H prom m']
        vals = {}
        for esp in especies:
            for rid in rodales_ids:
                v = self._calc_valores_rodal_especie(rid, esp)
                if v:
                    vals[(rid, esp)] = v
        return {"especies": especies, "rodales": rodales_ids, "variables": variables, "valores": vals}

    def cuadro_existencias(self):
        rodales_con_datos = [r for r in self.rodales_visibles
                             if self.especies_inventario_rodal(r.id)]
        filas = []
        g_tot_vol_umm = g_res_vol = g_pos_umm = 0.0
        detalle_vol_ha = []
        detalle_ab = []
        detalle_res_ab = []
        detalle_pos_ha = []
        detalle_intensidad = []
        for rodal in rodales_con_datos:
            rid = rodal.id
            sup = rodal.superficie_ha
            valores_especies = [(especie, self._calc_valores_rodal_especie(rid, especie))
                                 for especie in self.especies_inventario_rodal(rid)]
            valores_especies = sorted(
                (item for item in valores_especies if item[1]),
                key=lambda item: _orden_especie_volumen(item[0], item[1].get('ER m3/ha', 0)))
            sub_vol_ha = sub_vol_umm = sub_ab = 0.0
            sub_res_vol = sub_res_ab = sub_pos_ha = sub_pos_umm = 0.0
            inicio_rodal = len(filas)
            for esp, v in valores_especies:
                vol_ha = v['ER m3/ha']
                vol_umm = v['ERT VTA']
                ab = v['AB m2/ha']
                intensidad = self.intensidad_corta.get(rodal.id, {}).get(esp, 0)
                intensidad = min(100, max(0, intensidad))
                res_vol = vol_umm * (100 - intensidad) / 100
                res_ab = ab * (100 - intensidad) / 100
                pos_ha = vol_ha * intensidad / 100
                pos_umm = vol_umm * intensidad / 100
                sub_vol_ha += vol_ha
                sub_vol_umm += vol_umm
                sub_ab += ab
                sub_res_vol += res_vol
                sub_res_ab += res_ab
                sub_pos_ha += pos_ha
                sub_pos_umm += pos_umm
                filas.append({"rodal": rid, "superficie": sup, "especie": esp,
                            "vol_ha": vol_ha, "vol_umm": vol_umm, "ab": ab,
                            "intensidad": intensidad, "res_vol": res_vol,
                            "res_ab": res_ab, "pos_ha": pos_ha, "pos_umm": pos_umm})
                detalle_vol_ha.append(vol_ha)
                detalle_ab.append(ab)
                detalle_res_ab.append(res_ab)
                detalle_pos_ha.append(pos_ha)
                detalle_intensidad.append(intensidad)
            if len(filas) - inicio_rodal > 0:
                filas.append({"_type": "subtotal", "rodal": rid, "superficie": sup,
                              "vol_ha": sub_vol_ha, "vol_umm": sub_vol_umm, "ab": sub_ab,
                              "res_vol": sub_res_vol, "res_ab": sub_res_ab,
                              "pos_ha": sub_pos_ha, "pos_umm": sub_pos_umm})
            g_tot_vol_umm += sub_vol_umm
            g_res_vol += sub_res_vol
            g_pos_umm += sub_pos_umm
        grupos = {}
        for f in filas:
            if f.get("_type") == "subtotal":
                continue
            rid = f["rodal"]
            grupos.setdefault(rid, []).append(f)
        for rid, items in grupos.items():
            for i, f in enumerate(items):
                f["_rowspan"] = len(items) if i == 0 else 0
        n_detalle = len(detalle_vol_ha)
        return {"filas": filas, "num_rodales": len(rodales_con_datos),
                "total_vol_ha": sum(detalle_vol_ha) / n_detalle if n_detalle else 0.0,
                "total_vol_umm": g_tot_vol_umm,
                "total_ab": sum(detalle_ab) / n_detalle if n_detalle else 0.0,
                "total_intensidad": sum(detalle_intensidad) / n_detalle if n_detalle else 0.0,
                "total_res_vol": g_res_vol,
                "total_res_ab": sum(detalle_res_ab) / n_detalle if n_detalle else 0.0,
                "total_pos_ha": sum(detalle_pos_ha) / n_detalle if n_detalle else 0.0,
                "total_pos_umm": g_pos_umm}

    def resumen_existencias_predio(self):
        acumulados = {}
        superficie_total = sum(float(rodal.superficie_ha or 0)
                               for rodal in self.rodales_visibles)
        for fila in self.cuadro_existencias().get("filas", []):
            if fila.get("_type") == "subtotal":
                continue
            especie = fila.get("especie", "")
            valores = acumulados.setdefault(
                especie, {"existencias": 0.0, "posibilidad": 0.0, "residuales": 0.0}
            )
            valores["existencias"] += float(fila.get("vol_umm", 0) or 0)
            valores["posibilidad"] += float(fila.get("pos_umm", 0) or 0)
            valores["residuales"] += float(fila.get("res_vol", 0) or 0)
        filas = [{"especie": especie, **acumulados[especie]}
                 for especie in sorted(
                     acumulados,
                     key=lambda especie: _orden_especie_volumen(
                         especie,
                         acumulados[especie]["existencias"] / superficie_total
                         if superficie_total else 0.0))]
        totales = {clave: sum(fila[clave] for fila in filas)
                   for clave in ("existencias", "posibilidad", "residuales")}
        return {"filas": filas, "totales": totales}

    def buscar_intervencion_corta(self, intervencion_id: str) -> Optional[IntervencionCorta]:
        return next((i for i in self.plan_cortas.intervenciones if i.id == intervencion_id), None)

    def datos_intervencion_corta(self, intervencion: IntervencionCorta,
                                 cache=None, procesando=None) -> dict:
        cache = cache if cache is not None else {}
        procesando = procesando if procesando is not None else set()
        if intervencion.id in cache:
            return cache[intervencion.id]
        if intervencion.id in procesando:
            return {"filas": [], "residuales": {}}
        procesando.add(intervencion.id)

        rodal = self.buscar_rodal(intervencion.rodal_id)
        if not rodal or rodal.oculto:
            return {"intervencion": intervencion, "rodal": rodal, "filas": [],
                    "residuales": {}, "especies": [], "valores_especies": {},
                    "es_origen_vinculado": False}
        # Incluye especies registradas por sitios de muestreo y por censo total.
        especies = self.especies_inventario_rodal(intervencion.rodal_id)
        volumen_base = {}
        origen = self.buscar_intervencion_corta(intervencion.intervencion_origen_id)
        if origen:
            datos_origen = self.datos_intervencion_corta(origen, cache, procesando)
            volumen_base.update(datos_origen.get("residuales", {}))
        else:
            for especie in especies:
                valores = self._calc_valores_rodal_especie(intervencion.rodal_id, especie)
                if valores:
                    volumen_base[especie] = valores.get("ER m3/ha", 0) * intervencion.superficie_ha

        filas = []
        residuales = {}
        valores_especies = {}
        todas_especies = sorted(
            set(especies) | set(volumen_base) |
            set(intervencion.infraestructura) |
            set(intervencion.posibilidad_editada),
            key=lambda especie: _orden_especie_volumen(
                especie, volumen_base.get(especie, 0)))
        for especie in todas_especies:
            base = max(0.0, float(volumen_base.get(especie, 0) or 0))
            intensidad = float(self.intensidad_corta.get(intervencion.rodal_id, {}).get(especie, 0) or 0)
            intensidad = min(100, max(0, intensidad))
            posibilidad_automatica = base if origen else base * intensidad / 100
            posibilidad = float(intervencion.posibilidad_editada.get(especie, posibilidad_automatica) or 0)
            posibilidad = max(0.0, posibilidad)
            infraestructura = max(0.0, float(intervencion.infraestructura.get(especie, 0) or 0))
            residual = max(0.0, base - posibilidad)
            residuales[especie] = residual
            valores_especies[especie] = {"posibilidad": posibilidad,
                                          "infraestructura": infraestructura,
                                          "base": base, "residual": residual}
            if posibilidad > 0 or infraestructura > 0:
                filas.append({"especie": especie, "posibilidad": posibilidad,
                              "infraestructura": infraestructura,
                              "total": posibilidad + infraestructura,
                              "base": base, "residual": residual})

        filas.sort(key=lambda fila: _orden_especie_volumen(
            fila["especie"], fila.get("total", 0)))
        resultado = {"intervencion": intervencion, "rodal": rodal, "filas": filas,
                     "residuales": residuales, "especies": todas_especies,
                     "valores_especies": valores_especies,
                     "es_origen_vinculado": bool(origen)}
        cache[intervencion.id] = resultado
        procesando.discard(intervencion.id)
        return resultado

    def agregados_reforestacion(self):
        """Agrega por área de corta la superficie y la posibilidad por especie.

        Sirve tanto para la pantalla de selección (muestra las especies del
        área) como para el cuadro final de reforestación. Respeta las
        superficies editadas por el usuario. Es solo lectura: nunca
        modifica el Plan de Cortas.
        """
        estado = self.reforestacion if isinstance(self.reforestacion, dict) else {}
        superficies = estado.get("superficies", {}) if isinstance(estado.get("superficies", {}), dict) else {}
        anios_editados = estado.get("anios", {}) if isinstance(estado.get("anios", {}), dict) else {}
        cache = {}
        disponibles = []
        for anualidad in sorted(self.plan_cortas.anualidades, key=lambda a: a.numero):
            intervenciones = [i for i in self.plan_cortas.intervenciones
                              if i.anualidad == anualidad.numero]
            if not intervenciones:
                continue
            superficie_auto = sum(max(0.0, float(i.superficie_ha or 0))
                                  for i in intervenciones)
            anulada = str(anualidad.numero)
            superficie = superficies.get(anulada, superficie_auto)
            # El año de ejecución de reforestación se calcula como el año de
            # corta + 1; el usuario puede editarlo por área.
            anio_cuadro = anios_editados.get(anulada, anualidad.anio + 1)
            posibilidad = {}
            for intervencion in intervenciones:
                datos = (self.datos_intervencion_corta(intervencion, cache)
                         if self.buscar_rodal(intervencion.rodal_id)
                         else {"filas": []})
                for fila in datos.get("filas", []):
                    posibilidad[fila["especie"]] = (
                        posibilidad.get(fila["especie"], 0.0)
                        + float(fila.get("posibilidad", 0) or 0))
            opcion = {e: v for e, v in posibilidad.items() if v > 0}
            if not opcion:
                continue
            disponibilidad = sorted(opcion.items(),
                                    key=lambda par: (-par[1], par[0]))
            disponibles.append({
                "numero": anualidad.numero, "anio": anualidad.anio,
                "anio_reforestacion": anio_cuadro,
                "anio_editado": anulada in anios_editados,
                "superficie": superficie,
                "superficie_calculada": superficie_auto,
                "superficie_editada": anulada in superficies,
                "etiqueta": str(anualidad.numero),
                "especies": disponibilidad,
                "seleccionadas": [],
            })
        return disponibles

    def datos_reforestacion(self):
        """Cuadro de reforestación.

        Combina las áreas coníferas seleccionadas desde el Plan de Cortas
        (lectura; nunca modifica el plan) con las áreas de regeneración
        capturadas manualmente. En las áreas del plan la proporción es el
        porcentaje de la posibilidad de cada conífera dentro de la
        sumatoria de las coníferas seleccionadas del área, y el número de
        plantas se obtiene con la densidad del proyecto: densidad x
        superficie x proporción.
        """
        estado = self.reforestacion if isinstance(self.reforestacion, dict) else {}
        try:
            densidad = float(estado.get("densidad"))
        except (TypeError, ValueError):
            densidad = None
        seleccionadas = {}
        for seleccion in estado.get("selecciones", []):
            if isinstance(seleccion, dict):
                try:
                    seleccionadas[int(seleccion.get("anualidad", 0))] = list(
                        seleccion.get("especies", []))
                except (TypeError, ValueError):
                    continue

        disponible = {d["numero"]: d for d in self.agregados_reforestacion()}
        areas = []
        totales_especie = {}
        total_general = 0.0
        for numero in sorted(seleccionadas):
            base = disponible.get(numero)
            seleccion = [e for e in dict.fromkeys(seleccionadas[numero])
                         if base and any(e == par[0] for par in base["especies"])
                         and es_conifera(e)]
            if not base or not seleccion:
                continue
            posibilidad = dict(base["especies"])
            sumatoria = sum(posibilidad[e] for e in seleccion)
            filas = []
            subtotal_plantas = 0.0
            ordenadas = sorted(seleccion,
                               key=lambda e: (-posibilidad[e], e))
            for especie in ordenadas:
                proporc = (posibilidad[especie] / sumatoria * 100.0
                           if sumatoria > 0 else 0.0)
                plantas = (densidad * base["superficie"] * proporc / 100.0
                           if densidad is not None else None)
                if plantas is not None:
                    subtotal_plantas += plantas
                    totales_especie[especie] = (
                        totales_especie.get(especie, 0.0) + plantas)
                filas.append({"especie": especie,
                              "posibilidad": posibilidad[especie],
                              "proporcion": proporc, "plantas": plantas})
            total_general += subtotal_plantas
            areas.append({"numero": numero, "anio": base["anio_reforestacion"],
                          "anio_plan": base["anio"],
                          "anio_editado": base.get("anio_editado", False),
                          "etiqueta": base["etiqueta"], "manual": False,
                          "superficie": base["superficie"], "filas": filas,
                          "subtotal_plantas": subtotal_plantas,
                          "subtotal_proporcion": 100.0})
        for manual in estado.get("manuales", []):
            if not isinstance(manual, dict):
                continue
            filas = []
            subtotal_plantas = 0.0
            subtotal_proporcion = 0.0
            for fila_manual in manual.get("filas", []):
                proporc = float(fila_manual.get("proporcion", 0) or 0)
                subtotal_proporcion += proporc
                plantas = (densidad * float(manual["superficie"]) * proporc / 100.0
                           if densidad is not None else None)
                if plantas is not None:
                    subtotal_plantas += plantas
                    totales_especie[fila_manual["especie"]] = (
                        totales_especie.get(fila_manual["especie"], 0.0) + plantas)
                filas.append({"especie": fila_manual["especie"],
                              "posibilidad": None,
                              "proporcion": proporc, "plantas": plantas})
            total_general += subtotal_plantas
            areas.append({"numero": None, "manual": True,
                          "etiqueta": manual.get("nombre", ""),
                          "anio": manual.get("anio"),
                          "superficie": float(manual.get("superficie", 0)),
                          "filas": filas,
                          "subtotal_plantas": subtotal_plantas,
                          "subtotal_proporcion": subtotal_proporcion})
        return {"densidad": densidad, "areas": areas,
                "totales_especie": totales_especie,
                "total_general": total_general}

    # ------------------------------------------------------------------
    # Captura manual del cuadro de reforestación.
    # ------------------------------------------------------------------

    def establecer_superficie_reforestacion(self, anualidad: int, superficie):
        """Fija (o restablece con None) la superficie editada de un área."""
        estado = self.reforestacion if isinstance(self.reforestacion, dict) else {"densidad": None, "selecciones": []}
        superficies = estado.get("superficies") if isinstance(estado.get("superficies"), dict) else {}
        if not isinstance(superficies, dict):
            superficies = {}
        clave = str(int(anualidad))
        if superficie is None or superficie in ("",):
            superficies.pop(clave, None)
        else:
            try:
                valor = float(superficie)
            except (TypeError, ValueError) as error:
                raise ValueError("La superficie debe ser un número") from error
            if valor <= 0:
                raise ValueError("La superficie debe ser mayor a cero")
            superficies[clave] = valor
        estado["superficies"] = superficies
        self.reforestacion = estado

    def establecer_anio_reforestacion(self, anualidad: int, anio):
        """Fija (o restablece con None) el año de ejecución editado de un área.

        Sin edición, el cuadro calcula el año del plan de cortas + 1.
        """
        estado = self.reforestacion if isinstance(self.reforestacion, dict) else {"densidad": None, "selecciones": []}
        anios = estado.get("anios") if isinstance(estado.get("anios"), dict) else {}
        if not isinstance(anios, dict):
            anios = {}
        clave = str(int(anualidad))
        if anio is None or anio in ("",):
            anios.pop(clave, None)
        else:
            try:
                valor = int(anio)
            except (TypeError, ValueError) as error:
                raise ValueError("El año de ejecución debe ser un número") from error
            if valor <= 0:
                raise ValueError("El año de ejecución debe ser mayor a cero")
            anios[clave] = valor
        estado["anios"] = anios
        self.reforestacion = estado

    def agregar_area_manual_reforestacion(self, nombre, anio, superficie, filas):
        """Registra un área de regeneración capturada manualmente.

        `filas` es una lista de dicts {especie, proporcion}; el número de
        plantas se calcula con la densidad del proyecto.
        """
        estado = self.reforestacion if isinstance(self.reforestacion, dict) else {"densidad": None, "selecciones": []}
        manuales = estado.get("manuales") if isinstance(estado.get("manuales"), list) else []
        nombre_limpio = (nombre or "").strip()
        if not nombre_limpio:
            raise ValueError("Indique el nombre del área de regeneración")
        try:
            anio_valor = int(anio)
        except (TypeError, ValueError) as error:
            raise ValueError("El año de ejecución debe ser un número") from error
        if anio_valor <= 0:
            raise ValueError("El año de ejecución debe ser mayor a cero")
        try:
            superficie_valor = float(superficie)
        except (TypeError, ValueError) as error:
            raise ValueError("La superficie debe ser un número") from error
        if superficie_valor <= 0:
            raise ValueError("La superficie debe ser mayor a cero")
        filas_limpias = []
        for fila in filas or []:
            if not isinstance(fila, dict):
                continue
            especie = (fila.get("especie") or "").strip()
            if not especie:
                continue
            if not es_conifera(especie):
                raise ValueError(
                    f"{especie} no es una conífera; solo se reforestan "
                    "Pinus, Abies, Cupressus y Juniperus")
            try:
                proporcion = float(fila.get("proporcion", 0))
            except (TypeError, ValueError):
                continue
            if proporcion <= 0:
                continue
            filas_limpias.append({"especie": especie, "proporcion": proporcion})
        if not filas_limpias:
            raise ValueError("Registre al menos una especie con proporción")
        manuales.append({"id": uuid.uuid4().hex, "nombre": nombre_limpio,
                         "anio": anio_valor, "superficie": superficie_valor,
                         "filas": filas_limpias})
        estado["manuales"] = manuales
        self.reforestacion = estado
        return manuales[-1]["id"]

    def eliminar_area_manual_reforestacion(self, identificador: str) -> bool:
        estado = self.reforestacion if isinstance(self.reforestacion, dict) else {"densidad": None, "selecciones": []}
        manuales = estado.get("manuales") if isinstance(estado.get("manuales"), list) else []
        restantes = [m for m in manuales
                     if not (isinstance(m, dict) and str(m.get("id", "")) == str(identificador))]
        if len(restantes) == len(manuales):
            return False
        estado["manuales"] = restantes
        self.reforestacion = estado
        return True

    def resumen_incrementos(self):
        rodales_con_datos = [r for r in self.rodales_visibles
                             if self.especies_inventario_rodal(r.id) or
                             any(reg.rodal_id.casefold() == r.id.casefold()
                                 for reg in self.incrementos_directos)]
        filas = []
        g_sup = 0.0
        detalle_arb_ha = []
        detalle_ab = []
        detalle_tp = []
        detalle_ica = []
        detalle_ica_pct = []
        detalle_ima = []
        detalle_edad = []
        for rodal in rodales_con_datos:
            rid = rodal.id
            sup = rodal.superficie_ha
            especies = sorted(self.especies_inventario_rodal(rid), key=_orden_especies)
            sub_arb_ha = sub_ab = sub_ica = sub_ima = 0.0
            inicio_rodal = len(filas)
            valores_especies = []
            es_directo = rodal.tipo_inventario == "existencias"
            if es_directo:
                # Renglones directos: solo existen si se capturaron incrementos,
                # por separado de las existencias.
                for esp in sorted({reg.especie for reg in self.incrementos_directos
                                   if reg.rodal_id.casefold() == rid.casefold()},
                                  key=_orden_especies):
                    valores_especies.append((esp, None))
            else:
                for esp in especies:
                    v = self._calc_valores_rodal_especie(rodal.id, esp)
                    if not v:
                        continue
                    valores_especies.append((esp, v))
                valores_especies.sort(key=lambda item: _orden_especie_volumen(
                    item[0], item[1].get('ER m3/ha', 0)))
            for esp, v in valores_especies:
                if es_directo:
                    inc = self.buscar_incremento_directo(rid, esp)
                    if not inc:
                        continue
                    nah = inc.arboles_ha
                    ab = inc.ab_ha
                    tp_dg = inc.tp
                    tp_categoria = ""
                    ica = inc.ica_ha or 0
                    ica_pct = inc.ica_pct or 0
                    edad = inc.edad
                    ima = inc.ima_ha or 0
                    hay_ica = inc.ica_ha is not None
                    hay_ica_pct = inc.ica_pct is not None
                else:
                    nah = v.get('Arb/ha', 0)
                    ab = v.get('AB m2/ha', 0)
                    ica = v.get('ICA m3') or 0
                    ica_pct = v.get('ICA %') or 0
                    dg = v.get('Dg cm', 0)
                    tabla = self.buscar_tabla_inventario(rid, esp)
                    tp_dg = None
                    tp_categoria = ""
                    if rodal.tipo_inventario == "censo_total" and dg > 0:
                        tp_categoria = _clave_categoria(dg)
                        tp_dg = self.calcular_tp(esp, dg)
                    elif tabla and dg > 0:
                        dnccs = [c.dncc for c in tabla.clases if c.no_arboles > 0]
                        if dnccs:
                            cercano = min(dnccs, key=lambda x: abs(x - dg))
                            tp_categoria = _clave_categoria(cercano)
                            tp_dg = self.calcular_tp(esp, cercano)
                    edad = self.calcular_edad(esp, int(round(dg))) if dg > 0 else None
                    aprobada = self.edad_aprobada.get(rid, {}).get(esp)
                    try:
                        if aprobada is not None and float(aprobada) > 0:
                            edad = float(aprobada)
                    except (TypeError, ValueError):
                        pass
                    vol_ha = v.get('ER m3/ha', 0) or 0
                    ima = vol_ha / edad if edad else 0
                    hay_ica = v.get('ICA m3') is not None
                    hay_ica_pct = v.get('ICA %') is not None
                sub_arb_ha += nah
                sub_ab += ab
                sub_ica += ica
                sub_ima += ima
                filas.append({"rodal": rid, "especie": esp, "superficie": sup,
                            "arb_ha": nah, "ab": ab, "tp": tp_dg,
                            "tp_categoria": tp_categoria,
                            "ica": ica, "ica_pct": ica_pct, "ima": ima, "edad": edad})
                detalle_arb_ha.append(nah)
                detalle_ab.append(ab)
                if tp_dg is not None:
                    detalle_tp.append(tp_dg)
                if hay_ica:
                    detalle_ica.append(ica)
                if hay_ica_pct:
                    detalle_ica_pct.append(ica_pct)
                if edad:
                    detalle_ima.append(ima)
                    detalle_edad.append(edad)
            cantidad_especies = len(filas) - inicio_rodal
            if cantidad_especies == 0:
                # Sin renglones no hay subtotal: evita filas en ceros.
                continue
            g_sup += sup
            for indice in range(inicio_rodal, len(filas)):
                filas[indice]["_rowspan"] = cantidad_especies if indice == inicio_rodal else 0
            filas.append({"_type": "subtotal", "rodal": rid, "superficie": sup,
                          "arb_ha": sub_arb_ha, "ab": sub_ab,
                          "ica": sub_ica, "ima": sub_ima})
        return {"filas": filas, "total_superficie": g_sup,
                "total_arb_ha": _promedio_simple(detalle_arb_ha),
                "total_ab": _promedio_simple(detalle_ab),
                "total_tp": _promedio_simple(detalle_tp),
                "total_ica": _promedio_simple(detalle_ica),
                "total_ica_pct": _promedio_simple(detalle_ica_pct),
                "total_ima": _promedio_simple(detalle_ima),
                "total_edad": _promedio_simple(detalle_edad)}

    def factor_carbono(self, especie: str) -> float:
        return _CARBONO_FRACCION.get(especie, _CARBONO_FRACCION_DEFAULT)

    def reporte_carbono(self):
        rodales_con_datos = [r for r in self.rodales_visibles
                             if self.especies_inventario_rodal(r.id)]
        filas = []
        g_vol = g_ms = g_carbono = g_co2 = 0.0
        prom_vol_ha = []
        prom_ms_ha = []
        prom_carbono_ha = []
        prom_co2_ha = []
        for rodal in rodales_con_datos:
            rid = rodal.id
            sup = rodal.superficie_ha
            especies = sorted(self.especies_inventario_rodal(rid), key=_orden_especies)
            s_vol = s_ms = s_carbono = s_co2 = 0.0
            valores_especies = []
            for esp in especies:
                v = self._calc_valores_rodal_especie(rid, esp)
                if not v:
                    continue
                valores_especies.append((esp, v))
            valores_especies.sort(key=lambda item: _orden_especie_volumen(
                item[0], item[1].get('ER m3/ha', 0)))
            for esp, v in valores_especies:
                vol_ha = v.get('ER m3/ha', 0) or 0
                vol_ert = v.get('ERT VTA', 0) or 0
                cf = self.factor_carbono(esp)
                ms_ha = vol_ha * _FACTOR_MS
                ms_total = vol_ert * _FACTOR_MS
                carbono_ha = ms_ha * cf * _FACTOR_RAICES
                carbono_total = ms_total * cf * _FACTOR_RAICES
                co2_ha = carbono_ha * _FACTOR_CO2
                co2_total = carbono_total * _FACTOR_CO2
                s_vol += vol_ha; s_ms += ms_ha
                s_carbono += carbono_ha; s_co2 += co2_ha
                g_vol += vol_ert; g_ms += ms_total
                g_carbono += carbono_total; g_co2 += co2_total
                filas.append({"rodal": rid, "especie": esp, "superficie": sup,
                              "vol_ha": vol_ha, "cf": cf,
                              "ms_ha": ms_ha, "ms_total": ms_total,
                              "carbono_ha": carbono_ha, "carbono_total": carbono_total,
                              "co2_ha": co2_ha, "co2_total": co2_total})
                prom_vol_ha.append(vol_ha)
                prom_ms_ha.append(ms_ha)
                prom_carbono_ha.append(carbono_ha)
                prom_co2_ha.append(co2_ha)
            filas.append({"_type": "subtotal", "rodal": rid, "superficie": sup,
                          "vol_ha": s_vol, "ms_ha": s_ms,
                          "carbono_ha": s_carbono, "co2_ha": s_co2})
        grupos = {}
        for fila in filas:
            if fila.get("_type") == "subtotal":
                continue
            grupos.setdefault(fila.get("rodal"), []).append(fila)
        for grupo in grupos.values():
            for indice, fila in enumerate(grupo):
                fila["_rowspan"] = len(grupo) if indice == 0 else 0
        return {"filas": filas, "total_vol": g_vol, "total_ms": g_ms,
                "total_carbono": g_carbono, "total_co2": g_co2,
                "prom_vol_ha": _promedio_simple(prom_vol_ha),
                "prom_ms_ha": _promedio_simple(prom_ms_ha),
                "prom_carbono_ha": _promedio_simple(prom_carbono_ha),
                "prom_co2_ha": _promedio_simple(prom_co2_ha)}

    def serializar(self) -> dict:
        return {
            "nombre": self.nombre, "predio": self.predio,
            "municipio": self.municipio, "propietario": self.propietario,
            "estado": self.estado,
            "especies": self.especies,
            "ecuaciones": {k: asdict(v) for k, v in self.ecuaciones.items()},
            "area_sitio_m2": self.area_sitio_m2,
            "usar_factor_ajuste": self.usar_factor_ajuste,
            "factor_ajuste": self.factor_ajuste,
            "creado": self.creado, "modificado": self.modificado,
            "rodales": [asdict(r) for r in self.rodales],
            "tablas_inventario": [{"rodal_id": t.rodal_id, "especie": t.especie,
                                     "clases": [asdict(c) for c in t.clases]} for t in self.tablas_inventario],
            "censos_totales": [asdict(arbol) for arbol in self.censos_totales],
            "existencias_directas": [asdict(registro) for registro in self.existencias_directas],
            "incrementos_directos": [asdict(registro) for registro in self.incrementos_directos],
            "crecimiento": asdict(self.crecimiento),
            "plan_cortas": asdict(self.plan_cortas),
            "tiempo_paso": self.tiempo_paso,
            "tp_aprobados": self.tp_aprobados,
            "edad_aprobada": self.edad_aprobada,
            "intensidad_corta": self.intensidad_corta,
            "origen_intensidad": self.origen_intensidad,
            "rodales_aclareo": self.rodales_aclareo,
            "escenarios_aclareo": self.escenarios_aclareo,
            "calculos_turno": self.calculos_turno,
            "regeneracion": self.regeneracion,
            "observaciones_sanitarias": self.observaciones_sanitarias,
            "inventarios_historicos": self.inventarios_historicos,
            "tratamientos_silvicola": self.tratamientos_silvicola,
            "metas_manejo": self.metas_manejo,
            "reportes_generados": self.reportes_generados,
            "muestreo_error": self.muestreo_error,
            "muestreo_borradores": self.muestreo_borradores,
            "reportes_error_muestreo": self.reportes_error_muestreo,
            "cartografia": self.cartografia,
            "superficies": self.superficies,
            "reforestacion": self.reforestacion,
            "tp_ecuaciones": self.tp_ecuaciones,
            "edad_ecuaciones": self.edad_ecuaciones
        }

    def guardar(self, ruta: str = "") -> bool:
        if ruta:
            self.ruta_archivo = ruta
        if not self.ruta_archivo:
            return False
        try:
            os.makedirs(os.path.dirname(os.path.abspath(self.ruta_archivo)), exist_ok=True)
            temporal = self.ruta_archivo + ".tmp"
            self.modificado = datetime.datetime.now().isoformat()
            with open(temporal, "w", encoding="utf-8") as f:
                json.dump(self.serializar(), f, indent=2, ensure_ascii=False)
                f.flush()
                os.fsync(f.fileno())
            os.replace(temporal, self.ruta_archivo)
            return True
        except Exception:
            return False

    @staticmethod
    def desde_dict(data: dict):
        pmf = PMFProyecto(nombre=data.get("nombre", "Sin nombre"),
                          predio=data.get("predio", ""),
                          municipio=data.get("municipio", ""),
                          propietario=data.get("propietario", ""),
                          estado=data.get("estado", ""))
        pmf.creado = data.get("creado", pmf.creado)
        pmf.modificado = data.get("modificado", pmf.modificado)
        pmf.especies = data.get("especies", [])
        pmf.area_sitio_m2 = data.get("area_sitio_m2", 500) or 500
        pmf.usar_factor_ajuste = data.get("usar_factor_ajuste", False)
        pmf.factor_ajuste = data.get("factor_ajuste", 0)
        for k, v in data.get("ecuaciones", {}).items():
            pmf.ecuaciones[k] = EcuacionVolumen(**v) if isinstance(v, dict) else v
        for rd in data.get("rodales", []):
            pmf.rodales.append(Rodal(**rd) if isinstance(rd, dict) else rd)
        for td in data.get("tablas_inventario", []):
            if isinstance(td, dict):
                tabla = TablaInventarioRodal(rodal_id=td["rodal_id"], especie=td["especie"])
                for cd in td.get("clases", []):
                    tabla.agregar_clase(ClaseDiametrica(**cd) if isinstance(cd, dict) else cd)
                pmf.tablas_inventario.append(tabla)
            else:
                pmf.tablas_inventario.append(td)
        for arbol in data.get("censos_totales", []):
            pmf.censos_totales.append(ArbolCenso(**arbol) if isinstance(arbol, dict) else arbol)
        for registro in data.get("existencias_directas", []):
            if isinstance(registro, dict):
                try:
                    pmf.existencias_directas.append(ExistenciaDirecta(**registro))
                except (TypeError, ValueError):
                    continue
            else:
                pmf.existencias_directas.append(registro)
        for registro in data.get("incrementos_directos", []):
            if isinstance(registro, dict):
                try:
                    pmf.incrementos_directos.append(IncrementoDirecto(**registro))
                except (TypeError, ValueError):
                    continue
            else:
                pmf.incrementos_directos.append(registro)
        c = data.get("crecimiento", {})
        pmf.crecimiento = CrecimientoData(**c) if isinstance(c, dict) else c
        pc = data.get("plan_cortas", {})
        pmf.plan_cortas = PlanCortasData(**pc) if isinstance(pc, dict) else pc
        tp = data.get("tiempo_paso", {})
        pmf.tiempo_paso = {esp: {int(k): v for k, v in vals.items()} for esp, vals in tp.items()}
        pmf.tp_aprobados = _leer_aprobados(data.get("tp_aprobados", {}), canonizar_claves=True)
        pmf.edad_aprobada = _leer_aprobados(data.get("edad_aprobada", {}))
        pmf.tp_ecuaciones = data.get("tp_ecuaciones", {})
        pmf.edad_ecuaciones = data.get("edad_ecuaciones", {})
        pmf.rodales_aclareo = list(data.get("rodales_aclareo", []))
        pmf.escenarios_aclareo = dict(data.get("escenarios_aclareo", {}))
        pmf.calculos_turno = list(data.get("calculos_turno", []))
        pmf.regeneracion = list(data.get("regeneracion", []))
        pmf.observaciones_sanitarias = list(data.get("observaciones_sanitarias", []))
        pmf.inventarios_historicos = list(data.get("inventarios_historicos", []))
        pmf.tratamientos_silvicola = list(data.get("tratamientos_silvicola", []))
        pmf.metas_manejo = dict(data.get("metas_manejo", {}))
        pmf.reportes_generados = list(data.get("reportes_generados", []))
        pmf.muestreo_error = list(data.get("muestreo_error", []))
        pmf.muestreo_borradores = list(data.get("muestreo_borradores", []))
        pmf.reportes_error_muestreo = list(data.get("reportes_error_muestreo", []))
        pmf.cartografia = data.get("cartografia", {}) if isinstance(data.get("cartografia", {}), dict) else {}
        pmf.superficies = data.get("superficies", {}) if isinstance(data.get("superficies", {}), dict) else {}
        rf = data.get("reforestacion", {})
        if not isinstance(rf, dict):
            rf = {}
        try:
            densidad_rf = float(rf.get("densidad"))
        except (TypeError, ValueError):
            densidad_rf = None
        if densidad_rf is not None and densidad_rf <= 0:
            densidad_rf = None
        selecciones_rf = []
        for seleccion in rf.get("selecciones", []):
            if not isinstance(seleccion, dict):
                continue
            try:
                anualidad_rf = int(seleccion.get("anualidad", 0))
            except (TypeError, ValueError):
                continue
            especies_rf = [esp for esp in seleccion.get("especies", [])
                           if isinstance(esp, str) and esp.strip()]
            if anualidad_rf > 0 and especies_rf:
                selecciones_rf.append({"anualidad": anualidad_rf,
                                       "especies": especies_rf})
        superficies_rf = {}
        for clave, valor in (rf.get("superficies", {}) if isinstance(rf.get("superficies", {}), dict) else {}).items():
            try:
                valor_rf = float(valor)
            except (TypeError, ValueError):
                continue
            if valor_rf > 0:
                superficies_rf[str(clave)] = valor_rf
        anios_rf = {}
        for clave, valor in (rf.get("anios", {}) if isinstance(rf.get("anios", {}), dict) else {}).items():
            try:
                anio_rf = int(valor)
            except (TypeError, ValueError):
                continue
            if anio_rf > 0:
                anios_rf[str(clave)] = anio_rf
        manuales_rf = []
        for manual in rf.get("manuales", []):
            if not isinstance(manual, dict):
                continue
            nombre_m = manual.get("nombre")
            if not isinstance(nombre_m, str) or not nombre_m.strip():
                continue
            try:
                anio_m = int(manual.get("anio", 0))
            except (TypeError, ValueError):
                continue
            try:
                superficie_m = float(manual.get("superficie", 0))
            except (TypeError, ValueError):
                continue
            filas_m = []
            for fila_m in manual.get("filas", []):
                if not isinstance(fila_m, dict):
                    continue
                especie_m = fila_m.get("especie")
                if not isinstance(especie_m, str) or not especie_m.strip():
                    continue
                try:
                    proporcion_m = float(fila_m.get("proporcion", 0))
                except (TypeError, ValueError):
                    continue
                if proporcion_m > 0:
                    filas_m.append({"especie": especie_m.strip(),
                                    "proporcion": proporcion_m})
            if anio_m > 0 and superficie_m > 0 and filas_m:
                manuales_rf.append({"id": str(manual.get("id") or uuid.uuid4().hex),
                                    "nombre": nombre_m.strip(),
                                    "anio": anio_m, "superficie": superficie_m,
                                    "filas": filas_m})
        pmf.reforestacion = {"densidad": densidad_rf,
                             "selecciones": selecciones_rf,
                             "superficies": superficies_rf,
                             "anios": anios_rf,
                             "manuales": manuales_rf}
        ic_raw = data.get("intensidad_corta", {})
        if isinstance(ic_raw, dict) and ic_raw:
            first_val = next(iter(ic_raw.values()))
            if isinstance(first_val, (int, float)):
                pmf.intensidad_corta = {}
                for td in data.get("tablas_inventario", []):
                    rid = td["rodal_id"]
                    esp = td["especie"]
                    pmf.intensidad_corta.setdefault(rid, {})[esp] = ic_raw.get(esp, 0)
            else:
                pmf.intensidad_corta = ic_raw
        else:
            pmf.intensidad_corta = {}
        pmf.origen_intensidad = {rid: dict(especies) for rid, especies in
                                 data.get("origen_intensidad", {}).items()
                                 if isinstance(especies, dict)}
        return pmf

    @staticmethod
    def cargar(ruta: str):
        with open(ruta, "r", encoding="utf-8") as f:
            data = json.load(f)
        pmf = PMFProyecto(nombre=data.get("nombre", "Sin nombre"),
                          ruta_archivo=ruta,
                          predio=data.get("predio", ""),
                          municipio=data.get("municipio", ""),
                          propietario=data.get("propietario", ""),
                          estado=data.get("estado", ""))
        pmf.creado = data.get("creado", pmf.creado)
        pmf.modificado = data.get("modificado", pmf.modificado)
        pmf.especies = data.get("especies", [])
        pmf.area_sitio_m2 = data.get("area_sitio_m2", 500) or 500
        pmf.usar_factor_ajuste = data.get("usar_factor_ajuste", False)
        pmf.factor_ajuste = data.get("factor_ajuste", 0)
        for k, v in data.get("ecuaciones", {}).items():
            pmf.ecuaciones[k] = EcuacionVolumen(**v)
        for rd in data.get("rodales", []):
            pmf.rodales.append(Rodal(**rd))
        for td in data.get("tablas_inventario", []):
            tabla = TablaInventarioRodal(rodal_id=td["rodal_id"], especie=td["especie"])
            for cd in td.get("clases", []):
                tabla.agregar_clase(ClaseDiametrica(**cd))
            pmf.tablas_inventario.append(tabla)
        for arbol in data.get("censos_totales", []):
            pmf.censos_totales.append(ArbolCenso(**arbol))
        for registro in data.get("existencias_directas", []):
            try:
                pmf.existencias_directas.append(ExistenciaDirecta(**registro))
            except (TypeError, ValueError):
                continue
        for registro in data.get("incrementos_directos", []):
            try:
                pmf.incrementos_directos.append(IncrementoDirecto(**registro))
            except (TypeError, ValueError):
                continue
        c = data.get("crecimiento", {})
        pmf.crecimiento = CrecimientoData(**c)
        pc = data.get("plan_cortas", {})
        pmf.plan_cortas = PlanCortasData(**pc)
        tp = data.get("tiempo_paso", {})
        pmf.tiempo_paso = {esp: {int(k): v for k, v in vals.items()} for esp, vals in tp.items()}
        pmf.tp_aprobados = _leer_aprobados(data.get("tp_aprobados", {}), canonizar_claves=True)
        pmf.edad_aprobada = _leer_aprobados(data.get("edad_aprobada", {}))
        pmf.tp_ecuaciones = data.get("tp_ecuaciones", {})
        pmf.edad_ecuaciones = data.get("edad_ecuaciones", {})
        pmf.rodales_aclareo = list(data.get("rodales_aclareo", []))
        pmf.escenarios_aclareo = dict(data.get("escenarios_aclareo", {}))
        pmf.calculos_turno = list(data.get("calculos_turno", []))
        pmf.regeneracion = list(data.get("regeneracion", []))
        pmf.observaciones_sanitarias = list(data.get("observaciones_sanitarias", []))
        pmf.inventarios_historicos = list(data.get("inventarios_historicos", []))
        pmf.tratamientos_silvicola = list(data.get("tratamientos_silvicola", []))
        pmf.metas_manejo = dict(data.get("metas_manejo", {}))
        pmf.reportes_generados = list(data.get("reportes_generados", []))
        pmf.muestreo_error = list(data.get("muestreo_error", []))
        pmf.muestreo_borradores = list(data.get("muestreo_borradores", []))
        pmf.reportes_error_muestreo = list(data.get("reportes_error_muestreo", []))
        pmf.cartografia = data.get("cartografia", {}) if isinstance(data.get("cartografia", {}), dict) else {}
        pmf.superficies = data.get("superficies", {}) if isinstance(data.get("superficies", {}), dict) else {}
        rf = data.get("reforestacion", {})
        if not isinstance(rf, dict):
            rf = {}
        try:
            densidad_rf = float(rf.get("densidad"))
        except (TypeError, ValueError):
            densidad_rf = None
        if densidad_rf is not None and densidad_rf <= 0:
            densidad_rf = None
        selecciones_rf = []
        for seleccion in rf.get("selecciones", []):
            if not isinstance(seleccion, dict):
                continue
            try:
                anualidad_rf = int(seleccion.get("anualidad", 0))
            except (TypeError, ValueError):
                continue
            especies_rf = [esp for esp in seleccion.get("especies", [])
                           if isinstance(esp, str) and esp.strip()]
            if anualidad_rf > 0 and especies_rf:
                selecciones_rf.append({"anualidad": anualidad_rf,
                                       "especies": especies_rf})
        superficies_rf = {}
        for clave, valor in (rf.get("superficies", {}) if isinstance(rf.get("superficies", {}), dict) else {}).items():
            try:
                valor_rf = float(valor)
            except (TypeError, ValueError):
                continue
            if valor_rf > 0:
                superficies_rf[str(clave)] = valor_rf
        anios_rf = {}
        for clave, valor in (rf.get("anios", {}) if isinstance(rf.get("anios", {}), dict) else {}).items():
            try:
                anio_rf = int(valor)
            except (TypeError, ValueError):
                continue
            if anio_rf > 0:
                anios_rf[str(clave)] = anio_rf
        manuales_rf = []
        for manual in rf.get("manuales", []):
            if not isinstance(manual, dict):
                continue
            nombre_m = manual.get("nombre")
            if not isinstance(nombre_m, str) or not nombre_m.strip():
                continue
            try:
                anio_m = int(manual.get("anio", 0))
            except (TypeError, ValueError):
                continue
            try:
                superficie_m = float(manual.get("superficie", 0))
            except (TypeError, ValueError):
                continue
            filas_m = []
            for fila_m in manual.get("filas", []):
                if not isinstance(fila_m, dict):
                    continue
                especie_m = fila_m.get("especie")
                if not isinstance(especie_m, str) or not especie_m.strip():
                    continue
                try:
                    proporcion_m = float(fila_m.get("proporcion", 0))
                except (TypeError, ValueError):
                    continue
                if proporcion_m > 0:
                    filas_m.append({"especie": especie_m.strip(),
                                    "proporcion": proporcion_m})
            if anio_m > 0 and superficie_m > 0 and filas_m:
                manuales_rf.append({"id": str(manual.get("id") or uuid.uuid4().hex),
                                    "nombre": nombre_m.strip(),
                                    "anio": anio_m, "superficie": superficie_m,
                                    "filas": filas_m})
        pmf.reforestacion = {"densidad": densidad_rf,
                             "selecciones": selecciones_rf,
                             "superficies": superficies_rf,
                             "anios": anios_rf,
                             "manuales": manuales_rf}
        ic_raw = data.get("intensidad_corta", {})
        if isinstance(ic_raw, dict) and ic_raw:
            first_val = next(iter(ic_raw.values()))
            if isinstance(first_val, (int, float)):
                pmf.intensidad_corta = {}
                for td in data.get("tablas_inventario", []):
                    rid = td["rodal_id"]
                    esp = td["especie"]
                    pmf.intensidad_corta.setdefault(rid, {})[esp] = ic_raw.get(esp, 0)
            else:
                pmf.intensidad_corta = ic_raw
        else:
            pmf.intensidad_corta = {}
        pmf.origen_intensidad = {rid: dict(especies) for rid, especies in
                                 data.get("origen_intensidad", {}).items()
                                 if isinstance(especies, dict)}
        return pmf
