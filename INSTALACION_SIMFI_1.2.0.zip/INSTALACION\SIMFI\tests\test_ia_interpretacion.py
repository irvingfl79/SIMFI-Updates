import os
import tempfile
import unittest
import ia_interpretacion
import ia_ollama

_SERVICIO_ORIGINAL = ia_interpretacion._SERVICIO


class RegistroTiposTest(unittest.TestCase):
    def test_estan_registrados_los_reportes_en_pantalla(self):
        esperados = {"integral", "concentrado", "cuadro_existencias",
                     "incrementos", "carbono", "muestreo", "reporte_tabla",
                     "dashboard_rodal", "klepac", "superficies", "aclareos",
                     "turnos"}
        self.assertTrue(esperados.issubset(ia_interpretacion.TITULOS))
        for tipo in esperados:
            self.assertTrue(ia_interpretacion.TITULOS[tipo])


class PromptMaestroV2Test(unittest.TestCase):
    def test_prompt_maestro_delimita_interpretacion_y_decisiones(self):
        prompt = ia_ollama.cargar_config(
            ruta=os.path.join(tempfile.gettempdir(), "simfi_prompt_v2_inexistente.json")
        )["prompt_sistema"]
        self.assertIn("SIMFI CALCULA, VALIDA Y GENERA LOS HALLAZGOS", prompt)
        self.assertIn("No emitas recomendaciones", prompt)
        self.assertIn("No confundas variables estructurales", prompt)
        self.assertIn("No inventes efectos futuros", prompt)
        self.assertIn("competencia edáfica", prompt)


class DisponibilidadIaReportesTest(unittest.TestCase):
    def test_habilitada_por_defecto(self):
        self.assertTrue(ia_interpretacion.habilitada())

    def test_se_apaga_con_reportes_habilitado_falso(self):
        config = ia_ollama.cargar_config()
        config["reportes_habilitado"] = False
        self.assertFalse(ia_interpretacion.habilitada(config))

    def test_se_apaga_con_ia_deshabilitada(self):
        config = ia_ollama.cargar_config()
        config["habilitada"] = False
        self.assertFalse(ia_interpretacion.habilitada(config))

    def test_no_hace_llamadas_de_red(self):
        llamadas = []

        def falso_get(uri, timeout):
            llamadas.append(uri)
            return {}
        ia_ollama._http_get_json = falso_get
        ia_interpretacion.habilitada()
        self.assertEqual(llamadas, [])


class InterpretacionReporteTest(unittest.TestCase):
    def tearDown(self):
        ia_interpretacion._SERVICIO = _SERVICIO_ORIGINAL

    def test_respuesta_se_devuelve_como_solo_texto_con_el_contexto(self):
        cuerpo_capturado = {}

        class ServicioPrueba:
            def interpret(self, datos, modulo, contexto, config):
                cuerpo_capturado.update({"model": config["local"]["modelo"],
                                         "contexto": contexto,
                                         "datos": datos})
                return {"ok": True, "texto": "Interpretacion ampliada tecnica.", "mensaje": None}
        ia_interpretacion._SERVICIO = ServicioPrueba()
        datos = {"rodal": "R-01", "volumen_umm_m3": 168.4}
        ok, texto, mensaje, metadatos = ia_interpretacion.interpretar("integral", datos)
        self.assertTrue(ok)
        self.assertEqual(texto, "Interpretacion ampliada tecnica.")
        self.assertIsNone(mensaje)
        self.assertEqual(metadatos, {})
        self.assertEqual(cuerpo_capturado["model"], "qwen2.5:3b")
        self.assertEqual(cuerpo_capturado["model"], "qwen2.5:3b")
        self.assertIn("dasometría", ia_ollama.cargar_config()["prompt_sistema"])
        contenido = cuerpo_capturado["contexto"]
        self.assertIn("Reporte integral", contenido)
        self.assertIn("168.4", contenido)
        self.assertIn("Datos ya calculados por SIMFI", contenido)
        self.assertIn("SIMFI CALCULA, VALIDA Y GENERA LOS HALLAZGOS", contenido)
        self.assertIn("NO emitas recomendaciones", contenido)
        self.assertIn("168.4", contenido)

    def test_metadatos_de_truncamiento_se_propagan(self):
        class ServicioPrueba:
            def interpret(self, *args):
                return {"ok": True, "texto": "Texto.", "mensaje": None,
                        "metadatos": {"finish_reason": "length",
                                      "prompt_tokens": 400, "completion_tokens": 4000,
                                      "truncada": True}}
        ia_interpretacion._SERVICIO = ServicioPrueba()
        ok, texto, mensaje, metadatos = ia_interpretacion.interpretar("integral", {"a": 1})
        self.assertTrue(ok)
        self.assertTrue(metadatos["truncada"])
        self.assertEqual(metadatos["completion_tokens"], 4000)

    def test_tipo_no_registrado_se_rechaza(self):
        ok, texto, mensaje, metadatos = ia_interpretacion.interpretar("inexistente", {"a": 1})
        self.assertFalse(ok)
        self.assertIsNone(texto)
        self.assertIn("no esta habilitado", mensaje)
        self.assertEqual(metadatos, {})

    def test_fallo_de_conexion_es_elegante(self):
        class ServicioPrueba:
            def interpret(self, *args):
                return {"ok": False, "texto": None, "mensaje": "Fallo de prueba"}
        ia_interpretacion._SERVICIO = ServicioPrueba()
        ok, texto, mensaje, metadatos = ia_interpretacion.interpretar("carbono", {"t": 12})
        self.assertFalse(ok)
        self.assertIsNone(texto)
        self.assertIn("Fallo de prueba", mensaje)

    def test_respuesta_sin_contenido_se_ignora(self):
        class ServicioPrueba:
            def interpret(self, *args):
                return {"ok": False, "texto": None, "mensaje": "sin contenido"}
        ia_interpretacion._SERVICIO = ServicioPrueba()
        ok, texto, mensaje, metadatos = ia_interpretacion.interpretar("turnos", {"a": 1})
        self.assertFalse(ok)
        self.assertIn("sin contenido", mensaje)

    def test_ia_deshabilitada_no_realiza_peticiones(self):
        llamadas = []

        def falso_post(uri, body, timeout):
            llamadas.append(uri)
            return {"message": {"content": "x"}}
        ia_interpretacion._http_post_json = falso_post
        config = ia_ollama.cargar_config()
        config["habilitada"] = False
        ok, texto, mensaje, metadatos = ia_interpretacion.interpretar("integral", {"a": 1}, config)
        self.assertFalse(ok)
        self.assertEqual(llamadas, [])

    def test_reportes_deshabilitados_no_realizan_peticiones(self):
        llamadas = []

        def falso_post(uri, body, timeout):
            llamadas.append(uri)
            return {"message": {"content": "x"}}
        ia_interpretacion._http_post_json = falso_post
        config = ia_ollama.cargar_config()
        config["reportes_habilitado"] = False
        ok, texto, mensaje, metadatos = ia_interpretacion.interpretar("integral", {"a": 1}, config)
        self.assertFalse(ok)
        self.assertIn("reportes", mensaje)
        self.assertEqual(llamadas, [])


class SerializacionContextoTest(unittest.TestCase):
    def test_contexto_grande_se_acota(self):
        datos = {"claves": [{"v": float(i)} for i in range(3000)]}
        texto = ia_interpretacion._serializar_contexto(datos)
        self.assertLessEqual(len(texto), ia_interpretacion._MAX_CONTEXTO_CARACTERES + 60)
        self.assertIn("se omitieron", texto)

    def test_config_malformada_usa_valor_predeterminado_de_tokens(self):
        config = {"max_tokens_reporte": "muchos"}
        self.assertEqual(ia_interpretacion._max_tokens(config), 4000)

    def test_max_completion_tokens_tiene_prioridad(self):
        config = {"max_completion_tokens": 6000, "max_tokens": 512}
        self.assertEqual(ia_interpretacion._max_tokens(config), 6000)

    def test_serializacion_preserva_el_orden_de_las_claves(self):
        datos = {"totales": {"vol": 1}, "filas": [{"v": 2}]}
        texto = ia_interpretacion._serializar_contexto(datos)
        self.assertLess(texto.index('"totales"'), texto.index('"filas"'))


if __name__ == "__main__":
    unittest.main()
