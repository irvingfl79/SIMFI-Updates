﻿param(
    [string]$Destination = "",
    [string]$ShortcutTestRoot = "",
    [switch]$NoLaunch,
    # Raiz del paquete a aplicar. Por defecto, la carpeta del propio
    # script (modo USB/ACTUALIZAR.bat). consultar_actualizaciones.ps1
    # pasa explicitamente la carpeta descargada; el script que se
    # EJECUTA sigue siendo la copia local confiable de la instalacion.
    [string]$PackageRoot = ""
)

$ErrorActionPreference = "Stop"
$TargetVersion = $null
$TargetVersionLine = $null
$OldLineMaxVersion = "1.0.20"
if (-not $PackageRoot) { $PackageRoot = $PSScriptRoot }
$PayloadArchive = $null
$TempRoot = Join-Path $env:TEMP ("SIMFI_Update_" + [guid]::NewGuid().ToString("N"))
$BackupDir = $null
$BackedUp = New-Object System.Collections.Generic.List[string]
$NewFiles = New-Object System.Collections.Generic.List[string]
$RecoveredFiles = New-Object System.Collections.Generic.List[string]
$RecoveryRecords = New-Object System.Collections.ArrayList
$ProtectedDirectories = @("data", "backups", "exports", "config", "logs", "updates", "proyectos", "inventarios", "configuraciones", "capturas", "resultados", "reportes")

# Claves publicas (hex, 64 caracteres) autorizadas para firmar
# paquetes de SIMFI (Ed25519, esquema 1). Debe reflejar las claves de
# produccion autorizadas y coincide con CLAVES_PUBLICAS_CONFIABLES
# (firmas_actualizacion.py). La clave se integro en fase autorizada;
# su semilla vive unicamente en custodia cifrada fuera del
# repositorio. Mientras NO exista ninguna coincidencia con estas
# claves, NINGUN paquete se acepta: fail-closed. El mecanismo de
# pruebas (SIMFI_UPDATE_TEST_CLAVES) solo opera cuando
# SIMFI_UPDATE_TEST_DEST esta definido y jamas se honra en produccion.
$ClavesPublicasProduccion = @(
    "b7338ef372a5dcc51edfc09dac2e59ad9ad281682ee1f9c1eee60d254f9f31cc"
)

# These variables are used only by the automated end-to-end package test.
if (-not $Destination -and $env:SIMFI_UPDATE_TEST_DEST) {
    $Destination = $env:SIMFI_UPDATE_TEST_DEST
    $ShortcutTestRoot = $env:SIMFI_UPDATE_TEST_SHORTCUT_ROOT
    $NoLaunch = $true
}
if ($env:SIMFI_UPDATE_TEST_DEST -and -not $ShortcutTestRoot) {
    # Por seguridad, las pruebas nunca reescriben los accesos directos
    # reales del usuario; usan una carpeta temporal.
    $ShortcutTestRoot = Join-Path $env:TEMP "SIMFI_E2E_Atajos"
}

function Get-InstallDir {
    param([string]$Requested)
    if ($Requested) {
        return [IO.Path]::GetFullPath($Requested)
    }
    $ShortcutCandidates = @()
    try {
        $Shell = New-Object -ComObject WScript.Shell
        $ShortcutPaths = @(
            (Join-Path ([Environment]::GetFolderPath("Desktop")) "SIMFI.lnk"),
            (Join-Path ([Environment]::GetFolderPath("Programs")) "SIMFI\SIMFI.lnk")
        )
        foreach ($ShortcutPath in $ShortcutPaths) {
            if (-not (Test-Path -LiteralPath $ShortcutPath -PathType Leaf)) { continue }
            $Shortcut = $Shell.CreateShortcut($ShortcutPath)
            $Target = [string]$Shortcut.TargetPath
            if (-not $Target) { continue }
            $Candidate = Split-Path (Split-Path $Target -Parent) -Parent
            if (Test-Path -LiteralPath (Join-Path $Candidate "app.py")) {
                $ShortcutCandidates += $Candidate
            }
        }
    } catch {
        # Si no se pueden leer accesos directos, se usa la lista de instalaciones conocidas.
    }
    $Candidates = @($ShortcutCandidates) + @(
        (Join-Path $env:LOCALAPPDATA "SIMFI"),
        (Join-Path $env:ProgramFiles "SIMFI"),
        (Join-Path ${env:ProgramFiles(x86)} "SIMFI"),
        (Join-Path $env:SystemDrive "SISTEMAS_PIFL\SISTEMA_MANEJO_FORESTAL_PIFL"),
        (Join-Path $env:SystemDrive "SISTEMAS_PIFL\SIMFI")
    )
    foreach ($Candidate in $Candidates) {
        if ($Candidate -and (Test-Path -LiteralPath (Join-Path $Candidate "app.py"))) {
            return $Candidate
        }
    }
    throw "No se encontro una instalacion existente de SIMFI. Instale primero la version completa."
}

function Get-InstalledVersion {
    param([string]$InstallDir)
    $VersionFile = Join-Path $InstallDir "version.json"
    if (-not (Test-Path -LiteralPath $VersionFile)) {
        return "1.0.0"
    }
    try {
        return (Get-Content -LiteralPath $VersionFile -Raw | ConvertFrom-Json).version
    } catch {
        throw "El archivo version.json instalado no es valido. No se modifico la aplicacion."
    }
}

function Get-VersionLine {
    param([string]$InstallDir)
    $VersionFile = Join-Path $InstallDir "version.json"
    if (-not (Test-Path -LiteralPath $VersionFile)) {
        return 1
    }
    try {
        $Data = Get-Content -LiteralPath $VersionFile -Raw | ConvertFrom-Json
        $Property = $Data.PSObject.Properties["linea_version"]
        if ($Property -and $Property.Value) {
            $Value = 0
            if ([int]::TryParse([string]$Property.Value, [ref]$Value)) {
                return $Value
            }
        }
        return 1
    } catch {
        throw "El archivo version.json instalado no es valido. No se modifico la aplicacion."
    }
}

function Stop-SimfiProcesses {
    param([string]$InstallDir)
    $Python = (Join-Path $InstallDir "python\python.exe").ToLowerInvariant()
    $Pythonw = (Join-Path $InstallDir "python\pythonw.exe").ToLowerInvariant()
    try {
        Get-CimInstance Win32_Process -ErrorAction Stop | Where-Object {
            $_.ExecutablePath -and (@($Python, $Pythonw) -contains $_.ExecutablePath.ToLowerInvariant())
        } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop }
    } catch {
        Write-Host "No fue necesario cerrar un proceso activo de SIMFI." -ForegroundColor DarkGray
    }
}

function Restore-Backup {
    param([string]$InstallDir, [string]$BackupDir)
    foreach ($Relative in $RecoveredFiles) {
        $Path = Join-Path $InstallDir $Relative
        if (Test-Path -LiteralPath $Path -PathType Leaf) {
            Remove-Item -LiteralPath $Path -Force
        }
    }
    foreach ($Relative in $NewFiles) {
        $Path = Join-Path $InstallDir $Relative
        if (Test-Path -LiteralPath $Path -PathType Leaf) {
            Remove-Item -LiteralPath $Path -Force
        }
    }
    foreach ($Relative in $BackedUp) {
        $Source = Join-Path $BackupDir $Relative
        $Target = Join-Path $InstallDir $Relative
        $Parent = Split-Path -Parent $Target
        New-Item -ItemType Directory -Path $Parent -Force | Out-Null
        Copy-Item -LiteralPath $Source -Destination $Target -Force
    }
}

function Set-SimfiShortcut {
    param([object]$Shell, [string]$Path, [string]$InstallDir)
    New-Item -ItemType Directory -Path (Split-Path -Parent $Path) -Force | Out-Null
    $Shortcut = $Shell.CreateShortcut($Path)
    $Shortcut.TargetPath = Join-Path $InstallDir "python\pythonw.exe"
    $Shortcut.Arguments = '"' + (Join-Path $InstallDir "run.py") + '"'
    $Shortcut.WorkingDirectory = $InstallDir
    $Shortcut.IconLocation = (Join-Path $InstallDir "img\SIMFI_icon.ico") + ",0"
    $Shortcut.Description = "SIMFI - Sistema para el Manejo Forestal Mejorado"
    $Shortcut.WindowStyle = 3
    $Shortcut.Save()
}

function Repair-SimfiShortcuts {
    param([string]$InstallDir, [string]$TestRoot)
    $Shell = New-Object -ComObject WScript.Shell
    if ($TestRoot) {
        $DesktopShortcut = Join-Path $TestRoot "Desktop\SIMFI.lnk"
        $MenuShortcut = Join-Path $TestRoot "Programs\SIMFI\SIMFI.lnk"
        Set-SimfiShortcut $Shell $DesktopShortcut $InstallDir
        Set-SimfiShortcut $Shell $MenuShortcut $InstallDir
        return
    }
    $DesktopShortcut = Join-Path ([Environment]::GetFolderPath("Desktop")) "SIMFI.lnk"
    $MenuShortcut = Join-Path ([Environment]::GetFolderPath("Programs")) "SIMFI\SIMFI.lnk"
    Set-SimfiShortcut $Shell $DesktopShortcut $InstallDir
    Set-SimfiShortcut $Shell $MenuShortcut $InstallDir

    $PinnedShortcut = Join-Path $env:APPDATA "Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\SIMFI.lnk"
    if (Test-Path -LiteralPath $PinnedShortcut) {
        Set-SimfiShortcut $Shell $PinnedShortcut $InstallDir
    }
}

function Get-LegacyInstallDirs {
    param([string]$InstallDir)
    $Candidates = New-Object System.Collections.Generic.List[string]
    if ($env:SIMFI_UPDATE_TEST_LEGACY_DIRS) {
        foreach ($Path in $env:SIMFI_UPDATE_TEST_LEGACY_DIRS.Split(";")) {
            if ($Path) { $Candidates.Add($Path) }
        }
    }

    $ActiveFullPath = [IO.Path]::GetFullPath($InstallDir).TrimEnd("\")
    $Unique = @{}
    foreach ($Candidate in $Candidates) {
        if (-not $Candidate) { continue }
        try { $FullPath = [IO.Path]::GetFullPath($Candidate).TrimEnd("\") } catch { continue }
        if ($FullPath -ieq $ActiveFullPath -or $Unique.ContainsKey($FullPath)) { continue }
        if (Test-Path -LiteralPath (Join-Path $FullPath "data") -PathType Container) {
            $Unique[$FullPath] = $true
            $FullPath
        }
    }
}

function Backup-ProtectedData {
    param([string]$InstallDir, [string[]]$LegacyDirs, [string]$BackupDir)
    $Sources = @($InstallDir) + @($LegacyDirs)
    $BackupRoot = Join-Path $BackupDir "DATOS_ANTES_ACTUALIZACION"
    $SourceIndex = 0
    foreach ($SourceRoot in $Sources) {
        # Evita que una ruta de instalación extensa lleve el respaldo al límite de Windows.
        $SourceLabel = "ORIGEN_{0:D2}" -f $SourceIndex
        $SourceIndex++
        foreach ($Directory in $ProtectedDirectories) {
            $Source = Join-Path $SourceRoot $Directory
            if (-not (Test-Path -LiteralPath $Source -PathType Container)) { continue }
            $Target = Join-Path $BackupRoot (Join-Path $SourceLabel $Directory)
            New-Item -ItemType Directory -Path (Split-Path -Parent $Target) -Force | Out-Null
            Copy-Item -LiteralPath $Source -Destination $Target -Recurse -Force
        }
    }
}

function Get-ProtectedDataHashes {
    param([string]$InstallDir)
    $Hashes = @{}
    foreach ($Directory in $ProtectedDirectories) {
        $Source = Join-Path $InstallDir $Directory
        if (-not (Test-Path -LiteralPath $Source -PathType Container)) { continue }
        foreach ($File in Get-ChildItem -LiteralPath $Source -File -Recurse) {
            $Relative = $File.FullName.Substring($InstallDir.TrimEnd("\").Length + 1)
            $Hashes[$Relative] = (Get-FileHash -LiteralPath $File.FullName -Algorithm SHA256).Hash
        }
    }
    return $Hashes
}

function Assert-ProtectedDataUnchanged {
    param([hashtable]$Before, [hashtable]$After)
    foreach ($Relative in $Before.Keys) {
        if (-not $After.ContainsKey($Relative) -or $After[$Relative] -ne $Before[$Relative]) {
            throw "Se detecto un cambio no autorizado en datos protegidos: $Relative"
        }
    }
}

function Recover-LegacyData {
    param([string]$InstallDir, [string[]]$LegacyDirs, [string]$Timestamp)
    foreach ($LegacyDir in $LegacyDirs) {
        foreach ($Directory in $ProtectedDirectories) {
            $SourceRoot = Join-Path $LegacyDir $Directory
            if (-not (Test-Path -LiteralPath $SourceRoot -PathType Container)) { continue }
            foreach ($SourceFile in Get-ChildItem -LiteralPath $SourceRoot -File -Recurse) {
                $Relative = $SourceFile.FullName.Substring($SourceRoot.Length + 1)
                if ($Directory -eq "data" -and $Relative -ieq ".simfi\ultimo_proyecto.json") {
                    continue
                }
                $TargetRelative = Join-Path $Directory $Relative
                $Target = Join-Path $InstallDir $TargetRelative
                if (-not (Test-Path -LiteralPath $Target -PathType Leaf)) {
                    New-Item -ItemType Directory -Path (Split-Path -Parent $Target) -Force | Out-Null
                    Copy-Item -LiteralPath $SourceFile.FullName -Destination $Target -Force
                    $RecoveredFiles.Add($TargetRelative)
                    [void]$RecoveryRecords.Add([ordered]@{ origen = $SourceFile.FullName; destino = $TargetRelative; estado = "recuperado" })
                    continue
                }
                $SourceHash = (Get-FileHash -LiteralPath $SourceFile.FullName -Algorithm SHA256).Hash
                $TargetHash = (Get-FileHash -LiteralPath $Target -Algorithm SHA256).Hash
                if ($SourceHash -eq $TargetHash -or ($Directory -eq "data" -and $Relative -ieq "usuarios.json")) {
                    continue
                }
                $Parent = Split-Path -Parent $Target
                $BaseName = [IO.Path]::GetFileNameWithoutExtension($Target)
                $Extension = [IO.Path]::GetExtension($Target)
                $RecoveredName = "{0}_RECUPERADO_ANTERIOR_{1}{2}" -f $BaseName, $Timestamp, $Extension
                $RecoveredTarget = Join-Path $Parent $RecoveredName
                $Counter = 2
                while (Test-Path -LiteralPath $RecoveredTarget) {
                    $RecoveredName = "{0}_RECUPERADO_ANTERIOR_{1}_{2}{3}" -f $BaseName, $Timestamp, $Counter, $Extension
                    $RecoveredTarget = Join-Path $Parent $RecoveredName
                    $Counter++
                }
                Copy-Item -LiteralPath $SourceFile.FullName -Destination $RecoveredTarget -Force
                $RecoveredRelative = $RecoveredTarget.Substring($InstallDir.TrimEnd("\").Length + 1)
                $RecoveredFiles.Add($RecoveredRelative)
                [void]$RecoveryRecords.Add([ordered]@{ origen = $SourceFile.FullName; destino = $RecoveredRelative; estado = "conflicto_conservado" })
            }
        }
    }
}

try {
    $PayloadArchives = @(Get-ChildItem -LiteralPath $PackageRoot -Filter "SIMFI_payload_*.zip" -File)
    if ($PayloadArchives.Count -ne 1) {
        throw "El paquete debe contener exactamente un archivo SIMFI_payload_*.zip."
    }
    $PayloadArchive = $PayloadArchives[0].FullName

    $InstallDir = Get-InstallDir $Destination
    $RequiredInstalled = @("app.py", "run.py")
    foreach ($Relative in $RequiredInstalled) {
        if (-not (Test-Path -LiteralPath (Join-Path $InstallDir $Relative))) {
            throw "La instalacion esta incompleta. Falta: $Relative"
        }
    }

    $CurrentVersion = Get-InstalledVersion $InstallDir
    $InstalledLine = Get-VersionLine $InstallDir
    $LegacyInstallDirs = @(Get-LegacyInstallDirs $InstallDir)

    New-Item -ItemType Directory -Path $TempRoot -Force | Out-Null
    Expand-Archive -LiteralPath $PayloadArchive -DestinationPath $TempRoot -Force
    $PayloadDir = Join-Path $TempRoot "payload"
    $ManifestFile = Join-Path $TempRoot "payload_manifest.json"
    if (-not (Test-Path -LiteralPath $ManifestFile)) {
        throw "No se encontro el manifiesto de seguridad del paquete."
    }
    $Manifest = Get-Content -LiteralPath $ManifestFile -Raw | ConvertFrom-Json
    if ($Manifest.sistema -ne "SIMFI") {
        throw "El manifiesto no corresponde a SIMFI."
    }

    # ============================================================
    # Verificacion de autenticidad Ed25519 del manifiesto.
    # Ningun archivo se instala antes de validar la firma; durante la
    # verificacion solo se usa el directorio temporal, que al fracaso
    # se descarta en el finally. La integridad SHA-256 de cada archivo
    # y la proteccion de datos posteriores no cambian y actuan como
    # segunda barrera independiente.
    # ============================================================
    $FirmaFile = Join-Path $TempRoot "SIMFI_firma.json"
    if (-not (Test-Path -LiteralPath $FirmaFile -PathType Leaf)) {
        throw "El paquete no incluye la firma de autenticidad (SIMFI_firma.json)."
    }
    # Claves confiables: en produccion SOLO la lista constante
    # $ClavesPublicasProduccion. El listado de pruebas
    # (SIMFI_UPDATE_TEST_CLAVES, claves efimeras) se honra
    # exclusivamente con SIMFI_UPDATE_TEST_DEST definido; el resto del
    # verificador y el formato del sobre no cambian.
    $ClavesConfiables = @()
    if ($env:SIMFI_UPDATE_TEST_DEST) {
        if ($env:SIMFI_UPDATE_TEST_CLAVES) {
            $ClavesConfiables = @(
                $env:SIMFI_UPDATE_TEST_CLAVES.Split(";") |
                    Where-Object { $_ } |
                    ForEach-Object { $_.Trim().ToLowerInvariant() })
        }
    } else {
        $ClavesConfiables = @($ClavesPublicasProduccion)
    }
    if ($ClavesConfiables.Count -eq 0) {
        throw "No hay claves publicas confiables habilitadas; el paquete no se acepta (fail-closed)."
    }
    # Se prefieren los modulos de la instalacion (cadena confiable de
    # actualizaciones anteriores); el respaldo del payload se usa solo
    # en la transicion inicial y en modo de pruebas, porque los
    # modulos del propio paquete no son de confianza.
    $RaizModulos = $InstallDir
    if (-not (Test-Path -LiteralPath (Join-Path $InstallDir "firmas_actualizacion.py")) -or
            -not (Test-Path -LiteralPath (Join-Path $InstallDir "ed25519_puro.py"))) {
        if ($env:SIMFI_UPDATE_TEST_DEST) {
            $RaizModulos = $PayloadDir
        } else {
            throw "La instalacion no cuenta con los modulos de verificacion (ed25519_puro.py / firmas_actualizacion.py); aplique primero el paquete base que los incluye."
        }
    }
    $PythonVerificador = $null
    if ($env:SIMFI_UPDATE_TEST_DEST -and $env:SIMFI_UPDATE_TEST_PYTHON) {
        $PythonVerificador = $env:SIMFI_UPDATE_TEST_PYTHON
    }
    if (-not $PythonVerificador) {
        $CandidatoPython = Join-Path $InstallDir "python\python.exe"
        if (Test-Path -LiteralPath $CandidatoPython -PathType Leaf) {
            $PythonVerificador = $CandidatoPython
        }
    }
    if (-not $PythonVerificador) {
        $PythonVerificador = "python"
    }
    $CodigoVerificacion = @'
# -*- coding: utf-8 -*-
import json
import sys

# Verifica la firma del manifiesto con el modulo publico de SIMFI.
# Recibe: raiz de modulos, ruta del manifiesto, ruta de la firma y
# claves publicas confiables (hex, 64 caracteres). No recibe material
# criptografico privado. Solo usa comillas simples: PowerShell 5.1
# consume las comillas dobles al pasar el codigo a python.
sys.path.insert(0, sys.argv[1])
from firmas_actualizacion import (
    validar_estructura_manifesto,
    verificar_manifesto,
)
manifesto = json.load(open(sys.argv[2], 'r', encoding='utf-8-sig'))
objeto = json.load(open(sys.argv[3], 'r', encoding='utf-8-sig'))
validar_estructura_manifesto(manifesto)
verificar_manifesto(manifesto, objeto, frozenset(sys.argv[4:]))
print('FIRMA VALIDA')
'@
    $ArgumentosVerificacion = @(
        $PayloadDir,
        (Join-Path $TempRoot "payload_manifest.json"),
        $FirmaFile
    ) + $ClavesConfiables
    & $PythonVerificador -c $CodigoVerificacion @ArgumentosVerificacion
    if ($LASTEXITCODE -ne 0) {
        throw "La firma del paquete no es valida o la clave del emisor no es confiable."
    }

    $TargetVersion = [string]$Manifest.version
    try {
        [void][version]$TargetVersion
    } catch {
        throw "El manifiesto contiene una versión de destino no válida."
    }
    $LineaManifest = $Manifest.PSObject.Properties["linea_version"]
    $TargetVersionLine = 0
    if (-not $LineaManifest -or -not [int]::TryParse([string]$LineaManifest.Value, [ref]$TargetVersionLine) -or $TargetVersionLine -lt 1) {
        throw "El manifiesto no contiene una línea de versión válida."
    }
    $ExpectedArchive = "SIMFI_payload_{0}.zip" -f $TargetVersion
    if ([IO.Path]::GetFileName($PayloadArchive) -ne $ExpectedArchive) {
        throw "El archivo de datos no corresponde a la versión indicada en el manifiesto ($TargetVersion)."
    }

    $InstalacionCompleta = $true
    $Faltantes = @()
    foreach ($Entry in $Manifest.archivos) {
        $Relative = $Entry.ruta.Replace("/", "\")
        if (-not (Test-Path -LiteralPath (Join-Path $InstallDir $Relative) -PathType Leaf)) {
            $InstalacionCompleta = $false
            if ($Faltantes.Count -lt 20) {
                $Faltantes += $Relative
            }
        }
    }

    if ($InstalledLine -eq $TargetVersionLine) {
        # Linea nueva: comparacion semver normal dentro de la misma linea.
        if ([version]$CurrentVersion -gt [version]$TargetVersion) {
            throw "La version instalada ($CurrentVersion) es posterior a esta actualizacion ($TargetVersion)."
        }
        if ([version]$CurrentVersion -eq [version]$TargetVersion) {
            if ($InstalacionCompleta) {
                # Misma version: verificar el contenido. Un paquete reconstruido
                # bajo la misma version puede traer archivos actualizados.
                $Diferentes = @()
                foreach ($Entry in $Manifest.archivos) {
                    $Relative = $Entry.ruta.Replace("/", "\")
                    $HashInstalado = ""
                    try {
                        $HashInstalado = (Get-FileHash -LiteralPath (
                            Join-Path $InstallDir $Relative) -Algorithm SHA256).Hash.ToLowerInvariant()
                    } catch {
                        $HashInstalado = ""
                    }
                    if ($HashInstalado -ne ([string]$Entry.sha256).ToLowerInvariant()) {
                        $Diferentes += $Relative
                    }
                }
                if ($Diferentes.Count -eq 0) {
                    Write-Host "SIMFI $TargetVersion ya esta instalado y completo. No se realizaron cambios." -ForegroundColor Green
                    exit 0
                }
                Write-Host ("SIMFI ya esta en $TargetVersion, pero {0} archivo(s) difieren. " -f $Diferentes.Count +
                            "Se aplica la actualizacion...") -ForegroundColor Cyan
            } else {
                Write-Host ("SIMFI ya esta en $TargetVersion, pero faltan archivos. " +
                            "Se repara la instalacion..." ) -ForegroundColor Cyan
            }
        } else {
            Write-Host "Actualizando SIMFI $CurrentVersion a $TargetVersion..." -ForegroundColor Cyan
        }
    } else {
        # Linea anterior sin marcador: se permite el reinicio desde cualquier version de esa linea.
        if ([version]$CurrentVersion -gt [version]$OldLineMaxVersion) {
            throw "La version instalada ($CurrentVersion) no pertenece a una linea anterior reconocida."
        }
        Write-Host "Aplicando el reinicio de linea de version desde $CurrentVersion a $TargetVersion..." -ForegroundColor Cyan
    }

    foreach ($Entry in $Manifest.archivos) {
        $Relative = $Entry.ruta.Replace("/", "\")
        if ([IO.Path]::IsPathRooted($Relative) -or $Relative -match '(^|\\)\.\.(\\|$)') {
            throw "Ruta no autorizada en el paquete: $Relative"
        }
        if ($Relative -match '^(data|backups|exports|config|logs|updates|RESPALDO_VERSIONES|proyectos|inventarios|reportes|respaldos)(\\|$)') {
            throw "El paquete intenta modificar datos protegidos: $Relative"
        }
        $Source = Join-Path $PayloadDir $Relative
        if (-not (Test-Path -LiteralPath $Source -PathType Leaf)) {
            throw "Falta un archivo declarado en el paquete: $Relative"
        }
        $ActualHash = (Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($ActualHash -ne $Entry.sha256.ToLowerInvariant()) {
            throw "Fallo la integridad del archivo: $Relative"
        }
    }

    Stop-SimfiProcesses $InstallDir
    $Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $BackupDir = Join-Path $InstallDir ("RESPALDO_VERSIONES\SIMFI_{0}_{1}" -f $CurrentVersion, $Timestamp)
    New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
    Backup-ProtectedData $InstallDir $LegacyInstallDirs $BackupDir
    $DataHashesBefore = Get-ProtectedDataHashes $InstallDir

    foreach ($Entry in $Manifest.archivos) {
        $Relative = $Entry.ruta.Replace("/", "\")
        $Target = Join-Path $InstallDir $Relative
        if (Test-Path -LiteralPath $Target -PathType Leaf) {
            $BackupTarget = Join-Path $BackupDir $Relative
            New-Item -ItemType Directory -Path (Split-Path -Parent $BackupTarget) -Force | Out-Null
            Copy-Item -LiteralPath $Target -Destination $BackupTarget -Force
            $BackedUp.Add($Relative)
        } else {
            $NewFiles.Add($Relative)
        }
    }
    @{
        sistema = "SIMFI"
        version_respaldada = $CurrentVersion
        version_destino = $TargetVersion
        fecha = (Get-Date).ToString("s")
        archivos = @($BackedUp)
    } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $BackupDir "MANIFIESTO_RESPALDO.json") -Encoding UTF8

    foreach ($Entry in $Manifest.archivos) {
        $Relative = $Entry.ruta.Replace("/", "\")
        $Source = Join-Path $PayloadDir $Relative
        $Target = Join-Path $InstallDir $Relative
        New-Item -ItemType Directory -Path (Split-Path -Parent $Target) -Force | Out-Null
        Copy-Item -LiteralPath $Source -Destination $Target -Force
    }

    if ($Manifest.migracion_datos) {
        & (Join-Path $InstallDir "migrar_almacenamiento.ps1") -InstallDir $InstallDir
    }

    Recover-LegacyData $InstallDir $LegacyInstallDirs $Timestamp
    $DataHashesAfter = Get-ProtectedDataHashes $InstallDir
    Assert-ProtectedDataUnchanged $DataHashesBefore $DataHashesAfter
    @{
        fecha = (Get-Date).ToString("s")
        archivos_antes = @($DataHashesBefore.GetEnumerator() | ForEach-Object { [ordered]@{ ruta = $_.Key; sha256 = $_.Value } } | Sort-Object ruta)
        archivos_despues = @($DataHashesAfter.GetEnumerator() | ForEach-Object { [ordered]@{ ruta = $_.Key; sha256 = $_.Value } } | Sort-Object ruta)
    } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $BackupDir "VERIFICACION_DATOS.json") -Encoding UTF8
    @{
        fecha = (Get-Date).ToString("s")
        instalaciones_anteriores = @($LegacyInstallDirs)
        archivos_recuperados = @($RecoveryRecords)
    } | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $BackupDir "RECUPERACION_DATOS.json") -Encoding UTF8

    # La verificacion posterior (import de scipy y de la aplicacion
    # completa) se omite SOLO en el entorno de pruebas
    # (SIMFI_UPDATE_TEST_DEST + SIMFI_UPDATE_TEST_SKIP_POSTCHECK);
    # jamas en produccion. En pruebas estas instalaciones no traen el
    # runtime cientifico real.
    if (-not ($env:SIMFI_UPDATE_TEST_DEST -and $env:SIMFI_UPDATE_TEST_SKIP_POSTCHECK)) {
        Push-Location $InstallDir
        try {
            $Python = Join-Path $InstallDir "python\python.exe"
            if (-not (Test-Path -LiteralPath $Python)) { $Python = "python" }
            & $Python -c "import json; import scipy; from app import app; v=json.load(open('version.json', encoding='utf-8')); assert v['version']=='$TargetVersion'; print('SIMFI $TargetVersion OK')"
            if ($LASTEXITCODE -ne 0) {
                throw "SIMFI no supero la verificacion posterior."
            }
        } finally {
            Pop-Location
        }
    }

    Repair-SimfiShortcuts $InstallDir $ShortcutTestRoot

    Write-Host "Actualizacion completada correctamente." -ForegroundColor Green
    Write-Host "Version instalada: $TargetVersion"
    Write-Host "Respaldo recuperable: $BackupDir"
    Write-Host "Los datos y proyectos existentes no fueron modificados."
    Write-Host "Proyectos recuperados desde instalaciones anteriores: $($RecoveryRecords.Count)"
    Write-Host "Accesos directos de SIMFI reparados."
    @{ estado = "correcto"; fecha = (Get-Date).ToString("s"); version = $TargetVersion } |
        ConvertTo-Json | Set-Content -LiteralPath (Join-Path $BackupDir "RESULTADO_ACTUALIZACION.json") -Encoding UTF8
    if (-not $NoLaunch) {
        $Pythonw = Join-Path $InstallDir "python\pythonw.exe"
        if (Test-Path -LiteralPath $Pythonw) {
            Start-Process -FilePath $Pythonw -ArgumentList ('"' + (Join-Path $InstallDir "run.py") + '"') -WorkingDirectory $InstallDir
        } else {
            Start-Process -FilePath "python" -ArgumentList ('"' + (Join-Path $InstallDir "run.py") + '"') -WorkingDirectory $InstallDir
        }
    }
    exit 0
} catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    if ($BackupDir -and (Test-Path -LiteralPath $BackupDir)) {
        @{ estado = "error"; fecha = (Get-Date).ToString("s"); mensaje = $_.Exception.Message } |
            ConvertTo-Json | Set-Content -LiteralPath (Join-Path $BackupDir "RESULTADO_ACTUALIZACION.json") -Encoding UTF8
        try {
            Restore-Backup $InstallDir $BackupDir
            Write-Host "Se restauro automaticamente la version anterior." -ForegroundColor Yellow
        } catch {
            Write-Host "No se pudo completar la restauracion automatica: $($_.Exception.Message)" -ForegroundColor Red
        }
    }
    exit 1
} finally {
    if (Test-Path -LiteralPath $TempRoot) {
        Remove-Item -LiteralPath $TempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
