import io
import json
import os
import tempfile
import unittest
import urllib.error
from unittest import mock

import ia_online
from ia_config import cargar_config

_GET_ORIGINAL = ia_online._http_get_json
_POST_ORIGINAL = ia_online._http_post_json

_CLAVE_GROQ = "gsk_" + "a" * 40


def _config_groq():
    config = cargar_config()
    config["en_linea"]["habilitada"] = True
    config["en_linea"]["proveedor"] = "groq"
    config["en_linea"]["servidor"] = "https://api.groq.com/openai/v1"
    config["en_linea"]["modelo"] = "openai/gpt-oss-120b"
    config["en_linea"]["api_key_env"] = "SIMFI_ONLINE_API_KEY"
    return config


def _config_openrouter():
    config = cargar_config()
    config["en_linea"]["habilitada"] = True
    config["en_linea"]["proveedor"] = "openrouter"
    config["en_linea"]["servidor"] = "https://openrouter.ai/api/v1"
    config["en_linea"]["modelo"] = "openrouter/free"
    config["en_linea"]["api_key_env"] = "OPENROUTER_API_KEY"
    return config


class URLNormalizacionTest(unittest.TestCase):
    def test_openrouter_construye_endpoint_de_chat(self):
        self.assertEqual(
            ia_online._endpoint(_config_openrouter(), "/chat/completions"),
            "https://openrouter.ai/api/v1/chat/completions")

    def test_agrega_ruta_si_el_servidor_termina_en_v1(self):
        config = _config_groq()
        self.assertEqual(ia_online._endpoint(config, "/chat/completions"),
                         "https://api.groq.com/openai/v1/chat/completions")
        self.assertEqual(ia_online._endpoint(config, "/models"),
                         "https://api.groq.com/openai/v1/models")

    def test_configuracion_openrouter_aplica_predeterminados(self):
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", suffix=".json", delete=False) as archivo:
            json.dump({"en_linea": {"proveedor": "openrouter"}}, archivo)
            ruta = archivo.name
        try:
            config = cargar_config(ruta=ruta)
        finally:
            os.remove(ruta)
        self.assertEqual(config["en_linea"]["servidor"], "https://openrouter.ai/api/v1")
        self.assertEqual(config["en_linea"]["modelo"], "openrouter/free")
        self.assertEqual(config["en_linea"]["api_key_env"], "OPENROUTER_API_KEY")

    def test_no_duplica_si_el_servidor_ya_incluye_la_ruta(self):
        config = _config_groq()
        config["en_linea"]["servidor"] = "https://api.groq.com/openai/v1/chat/completions"
        self.assertEqual(ia_online._endpoint(config, "/chat/completions"),
                         "https://api.groq.com/openai/v1/chat/completions")
        config["en_linea"]["servidor"] = "https://api.groq.com/openai/v1/models"
        self.assertEqual(ia_online._endpoint(config, "/models"),
                         "https://api.groq.com/openai/v1/models")

    def test_corrige_duplicacion_v1_v1(self):
        config = _config_groq()
        config["en_linea"]["servidor"] = "https://api.groq.com/openai/v1/v1"
        self.assertEqual(ia_online._endpoint(config, "/chat/completions"),
                         "https://api.groq.com/openai/v1/chat/completions")

    def test_servidor_vacio_devuelve_vacio(self):
        config = _config_groq()
        config["en_linea"]["servidor"] = ""
        self.assertEqual(ia_online._endpoint(config, "/chat/completions"), "")


class ClaveGroqTest(unittest.TestCase):
    def test_sin_variable_se_reporta_metodologia(self):
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("GROQ_API_KEY", None)
            clave, error = ia_online._clave_api(_config_groq())
        self.assertEqual(clave, "")
        self.assertIn("GROQ_API_KEY", error)

    def test_clave_valida_se_recorta(self):
        with mock.patch.dict(os.environ, {"GROQ_API_KEY": "  " + _CLAVE_GROQ + "\n"}, clear=False):
            clave, error = ia_online._clave_api(_config_groq())
        self.assertEqual(clave, _CLAVE_GROQ)
        self.assertIsNone(error)

    def test_clave_invalida_se_rechaza(self):
        for valor in ("sin-prefijo", 'gsk_abc"', "gsk_abc'", "Bearer gsk_abc", ""):
            with mock.patch.dict(os.environ, {"GROQ_API_KEY": valor}, clear=False):
                clave, error = ia_online._clave_api(_config_groq())
            self.assertEqual(clave, "", "debe rechazarse: %r" % valor)
            self.assertIsNotNone(error)


class ClaveOpenRouterTest(unittest.TestCase):
    def test_sin_variable_se_diagnostica_sin_exponer_clave(self):
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("OPENROUTER_API_KEY", None)
            clave, error = ia_online._clave_api(_config_openrouter())
        self.assertEqual(clave, "")
        self.assertIn("OPENROUTER_API_KEY", error)
        self.assertNotIn("Bearer", error)

    def test_usa_la_variable_configurada(self):
        with mock.patch.dict(os.environ, {"OPENROUTER_API_KEY": "or-test-key"}, clear=False):
            clave, error = ia_online._clave_api(_config_openrouter())
        self.assertEqual(clave, "or-test-key")
        self.assertIsNone(error)


class SolicitudGroqTest(unittest.TestCase):
    def tearDown(self):
        ia_online._http_get_json = _GET_ORIGINAL
        ia_online._http_post_json = _POST_ORIGINAL

    def test_headers_y_cuerpo_minimo(self):
        captura = {}

        def falso_post(uri, body, timeout, headers=None):
            captura["uri"] = uri
            captura["body"] = body
            captura["timeout"] = timeout
            return {"choices": [{"message": {"content": "conexion correcta"}}]}

        with mock.patch.dict(os.environ, {"GROQ_API_KEY": _CLAVE_GROQ}, clear=False):
            ia_online._http_post_json = falso_post
            respuesta, meta = ia_online.OnlineAIProvider()._solicitud(
                "Responde solamente: conexion correcta", "prueba", _config_groq())
        self.assertEqual(captura["uri"], "https://api.groq.com/openai/v1/chat/completions")
        self.assertEqual(captura["body"], {
            "model": "openai/gpt-oss-120b",
            "messages": [{"role": "system", "content": cargar_config()["prompt_sistema"]},
                         {"role": "user", "content": "Responde solamente: conexion correcta"}],
            "max_completion_tokens": 6000,
        })
        self.assertEqual(respuesta["choices"][0]["message"]["content"], "conexion correcta")
        self.assertEqual(meta["modelo"], "openai/gpt-oss-120b")

    def test_diagnostico_tokens_y_finish_reason(self):
        captura = {}

        def falso_post(uri, body, timeout, headers=None):
            captura["body"] = body
            return {"choices": [{"message": {"content": "texto ok"},
                                 "finish_reason": "stop"}],
                    "usage": {"prompt_tokens": 120, "completion_tokens": 900}}

        with mock.patch.dict(os.environ, {"GROQ_API_KEY": _CLAVE_GROQ}, clear=False):
            ia_online._http_post_json = falso_post
            resultado = ia_online.OnlineAIProvider().interpretar(
                {}, "prueba", "texto", _config_groq())
        self.assertTrue(resultado["ok"])
        self.assertEqual(resultado["metadatos"]["finish_reason"], "stop")
        self.assertEqual(resultado["metadatos"]["prompt_tokens"], 120)
        self.assertEqual(resultado["metadatos"]["completion_tokens"], 900)
        self.assertFalse(resultado["metadatos"]["truncada"])
        self.assertEqual(captura["body"]["max_completion_tokens"], 6000)

    def test_truncamiento_se_marca_cuando_finish_reason_es_length(self):
        def falso_post(uri, body, timeout, headers=None):
            return {"choices": [{"message": {"content": "texto parcial"},
                                 "finish_reason": "length"}],
                    "usage": {"prompt_tokens": 100, "completion_tokens": 4000}}

        with mock.patch.dict(os.environ, {"GROQ_API_KEY": _CLAVE_GROQ}, clear=False):
            ia_online._http_post_json = falso_post
            resultado = ia_online.OnlineAIProvider().interpretar(
                {}, "prueba", "texto", _config_groq())
        self.assertTrue(resultado["ok"])
        self.assertTrue(resultado["metadatos"]["truncada"])
        self.assertEqual(resultado["metadatos"]["finish_reason"], "length")

    def test_terminologia_forestal_se_normaliza_en_la_salida(self):
        def falso_post(uri, body, timeout, headers=None):
            return {"choices": [{"message": {"content": "la finca del predio"},
                                 "finish_reason": "stop"}],
                    "usage": {"prompt_tokens": 10, "completion_tokens": 5}}

        with mock.patch.dict(os.environ, {"GROQ_API_KEY": _CLAVE_GROQ}, clear=False):
            ia_online._http_post_json = falso_post
            resultado = ia_online.OnlineAIProvider().interpretar(
                {}, "prueba", "texto", _config_groq())
        self.assertTrue(resultado["ok"])
        self.assertNotIn("finca", resultado["texto"])
        self.assertIn("predio", resultado["texto"])
        self.assertTrue("finish_reason" in resultado["metadatos"])

    def test_autorizacion_bearer_sin_formato_duplicado(self):
        cabeceras = ia_online.OnlineAIProvider()._cabeceras(_CLAVE_GROQ)
        self.assertEqual(cabeceras, {"Authorization": "Bearer " + _CLAVE_GROQ})
        self.assertNotIn("Bearer Bearer", cabeceras["Authorization"])
        self.assertEqual(cabeceras["Authorization"].count("Bearer"), 1)

    def test_clave_no_se_usa_como_api_key_ni_x_api_key(self):
        cabeceras = ia_online.OnlineAIProvider()._cabeceras(_CLAVE_GROQ)
        self.assertNotIn("api-key", cabeceras)
        self.assertNotIn("x-api-key", cabeceras)


class SolicitudOpenRouterTest(unittest.TestCase):
    def tearDown(self):
        ia_online._http_post_json = _POST_ORIGINAL

    def test_headers_y_cuerpo_openai_compatible(self):
        captura = {}

        def falso_post(uri, body, timeout, headers=None):
            captura.update(uri=uri, body=body, headers=headers)
            return {"choices": [{"message": {"content": "conexion correcta"}}]}

        with mock.patch.dict(os.environ, {"OPENROUTER_API_KEY": "or-test-key"}, clear=False):
            ia_online._http_post_json = falso_post
            respuesta, meta = ia_online.OnlineAIProvider()._solicitud(
                "Responde solamente: conexion correcta", "prueba", _config_openrouter())
        self.assertEqual(captura["uri"], "https://openrouter.ai/api/v1/chat/completions")
        self.assertEqual(captura["headers"], {"Authorization": "Bearer or-test-key"})
        self.assertEqual(captura["body"]["model"], "openrouter/free")
        self.assertEqual(len(captura["body"]["messages"]), 2)
        self.assertEqual(meta["modelo"], "openrouter/free")

    def test_prueba_de_conexion_identifica_openrouter(self):
        def falso_post(uri, body, timeout, headers=None):
            return {"choices": [{"message": {"content": "conexion correcta"}}]}

        with mock.patch.dict(os.environ, {"OPENROUTER_API_KEY": "or-test-key"}, clear=False):
            ia_online._http_post_json = falso_post
            resultado = ia_online.OnlineAIProvider().probar_conexion(_config_openrouter())
        self.assertTrue(resultado["ok"])
        self.assertIn("OpenRouter", resultado["mensaje"])
        self.assertIn("openrouter/free", resultado["mensaje"])
        self.assertNotIn("or-test-key", resultado["mensaje"])


class DiagnosticoErrorGroqTest(unittest.TestCase):
    def tearDown(self):
        ia_online._http_post_json = _POST_ORIGINAL

    def test_errores_http_muestran_detalle_sin_clave(self):
        cuerpo_error = json.dumps({
            "error": {"message": "Invalid API key", "type": "invalid_request_error",
                      "code": "invalid_api_key"}}).encode("utf-8")

        def falso_post(uri, body, timeout, headers=None):
            raise urllib.error.HTTPError("https://api.groq.com/openai/v1/chat/completions",
                                         403, "Forbidden", {}, io.BytesIO(cuerpo_error))

        with mock.patch.dict(os.environ, {"GROQ_API_KEY": _CLAVE_GROQ}, clear=False):
            ia_online._http_post_json = falso_post
            resultado = ia_online.OnlineAIProvider().interpretar(
                {}, "prueba", "Responde solamente: conexion correcta", _config_groq())
        self.assertFalse(resultado["ok"])
        mensaje = resultado["mensaje"]
        self.assertIn("Proveedor: Groq", mensaje)
        self.assertIn("https://api.groq.com/openai/v1/chat/completions", mensaje)
        self.assertIn("openai/gpt-oss-120b", mensaje)
        self.assertIn("HTTP: 403", mensaje)
        self.assertIn("Invalid API key", mensaje)
        self.assertIn("invalid_request_error", mensaje)
        self.assertIn("invalid_api_key", mensaje)
        self.assertNotIn(_CLAVE_GROQ, mensaje)
        self.assertIsNone(resultado["texto"])

    def test_fallo_no_elimina_el_reporte_previo(self):
        resultado_previo = {"ok": True, "texto": "Reporte existente protegido."}

        def falso_post(uri, body, timeout, headers=None):
            raise OSError("sin conexion")

        with mock.patch.dict(os.environ, {"GROQ_API_KEY": _CLAVE_GROQ}, clear=False):
            ia_online._http_post_json = falso_post
            resultado = ia_online.OnlineAIProvider().interpretar(
                {}, "prueba", "texto", _config_groq())
        self.assertFalse(resultado["ok"])
        self.assertIsNone(resultado["texto"])
        self.assertTrue(resultado_previo["ok"])
        self.assertEqual(resultado_previo["texto"], "Reporte existente protegido.")


class PruebaConexionGroqTest(unittest.TestCase):
    def tearDown(self):
        ia_online._http_post_json = _POST_ORIGINAL

    def test_respuesta_esperada_confirma_conexion(self):
        def falso_post(uri, body, timeout, headers=None):
            return {"choices": [{"message": {"content": "conexion correcta"}}]}

        with mock.patch.dict(os.environ, {"GROQ_API_KEY": _CLAVE_GROQ}, clear=False):
            ia_online._http_post_json = falso_post
            resultado = ia_online.OnlineAIProvider().probar_conexion(_config_groq())
        self.assertTrue(resultado["ok"])
        self.assertIn("CONEXIÓN CORRECTA", resultado["mensaje"])
        self.assertIn("openai/gpt-oss-120b", resultado["mensaje"])

    def test_respuesta_diferente_no_confirma_conexion(self):
        def falso_post(uri, body, timeout, headers=None):
            return {"choices": [{"message": {"content": "texto distinto"}}]}

        with mock.patch.dict(os.environ, {"GROQ_API_KEY": _CLAVE_GROQ}, clear=False):
            ia_online._http_post_json = falso_post
            resultado = ia_online.OnlineAIProvider().probar_conexion(_config_groq())
        self.assertFalse(resultado["ok"])
        self.assertIn("openai/gpt-oss-120b", resultado["mensaje"])


class ProveedorNoGroqTest(unittest.TestCase):
    def test_usa_variable_indicada_para_apoyo_generico(self):
        config = _config_groq()
        config["en_linea"]["proveedor"] = "openai_compatible"
        config["en_linea"]["servidor"] = "https://api.otro-proveedor.example/openai/v1"
        config["en_linea"]["api_key_env"] = "OTRA_API_KEY"
        with mock.patch.dict(os.environ, {"OTRA_API_KEY": "  clave-generica  "}, clear=False):
            clave, error = ia_online._clave_api(config)
        self.assertEqual(clave, "clave-generica")
        self.assertIsNone(error)


if __name__ == "__main__":
    unittest.main()
