import unittest
import math
import io

from docx import Document

from app import app
from modelos import ClaseDiametrica, PMFProyecto, Rodal, TablaInventarioRodal
from motor_aclareos import (construir_evaluacion, escenario_mmobi, escenario_usuario,
                            escenario_veiga, intensidad_volumetrica_equivalente,
                            resumen_rodal_especie,
                            tabla_intensidades_aplicadas,
                            _evaluar_modelo_veiga)


def proyecto_prueba():
    pmf = PMFProyecto("Aclareos")
    pmf.cargar_edad_predeterminadas()
    pmf.agregar_rodal(Rodal("R1", 12.5, sitios=1, area_sitio_m2=10000))
    pmf.agregar_rodal(Rodal("R2", 8.0, sitios=1, area_sitio_m2=10000))
    pmf.agregar_tabla_inventario(
        TablaInventarioRodal("R1", "Pinus patula", [ClaseDiametrica(25, 18, 100)]))
    return pmf


def proyecto_estructurado():
    pmf = PMFProyecto("Aclareos estructurados")
    pmf.cargar_edad_predeterminadas()
    pmf.agregar_rodal(Rodal("R1", 10, sitios=1, area_sitio_m2=10000))
    pmf.agregar_tabla_inventario(TablaInventarioRodal("R1", "Pinus patula", [
        ClaseDiametrica(15, 12, 120), ClaseDiametrica(25, 18, 80),
        ClaseDiametrica(35, 24, 40),
    ]))
    pmf.tiempo_paso["Pinus patula"] = {15: 5, 25: 6, 35: 7}
    return pmf


class IntensidadAclareosTest(unittest.TestCase):
    def test_seleccion_se_serializa(self):
        pmf = proyecto_prueba()
        pmf.rodales_aclareo = ["R1"]
        restaurado = PMFProyecto.desde_dict(pmf.serializar())
        self.assertEqual(restaurado.rodales_aclareo, ["R1"])

    def test_importa_solo_rodales_del_cuadro_y_guarda_seleccion(self):
        pmf = proyecto_prueba()
        inventario_antes = pmf.serializar()["tablas_inventario"]
        intensidad_antes = dict(pmf.intensidad_corta)
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()

        pagina = cliente.get("/aclareos/intensidad-corta?importar=1")
        html = pagina.get_data(as_text=True)
        self.assertEqual(pagina.status_code, 200)
        self.assertIn("R1", html)
        self.assertNotIn("<strong>R2</strong>", html)

        respuesta = cliente.post(
            "/aclareos/intensidad-corta", data={"rodales_aclareo": ["R1", "R2"]})
        self.assertEqual(respuesta.status_code, 302)
        with cliente.session_transaction() as sesion:
            self.assertNotIn("pmf_data", sesion)
            ruta = sesion["ruta_actual"]
        guardado = PMFProyecto.cargar(ruta)
        self.assertEqual(guardado.rodales_aclareo, ["R1"])
        self.assertEqual(guardado.intensidad_corta, intensidad_antes)
        self.assertEqual(guardado.serializar()["tablas_inventario"], inventario_antes)

    def test_tabla_dasometrica_elimina_ref_y_muestra_exportacion(self):
        pmf = proyecto_prueba()
        pmf.rodales_aclareo = ["R1"]
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()
        pagina = cliente.get("/aclareos/intensidad-corta?importar=1")
        html = pagina.get_data(as_text=True)
        self.assertIn("Exportar reporte", html)
        self.assertNotIn('title="Edad de referencia opcional para el diagnóstico de crecimiento"', html)
        self.assertIn('name="ciclo_corta"', html)

    def test_exportacion_incluye_todos_los_rodales_y_graficas(self):
        pmf = PMFProyecto("Exportación aclareos")
        pmf.cargar_edad_predeterminadas()
        pmf.agregar_rodal(Rodal("R1", 10, sitios=1, area_sitio_m2=10000))
        pmf.agregar_rodal(Rodal("R2", 8, sitios=1, area_sitio_m2=10000))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Pinus montezumae",
            [ClaseDiametrica(10, 8, 120), ClaseDiametrica(15, 12, 100)]))
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R2", "Pinus patula",
            [ClaseDiametrica(15, 10, 90), ClaseDiametrica(25, 18, 60)]))
        pmf.rodales_aclareo = ["R1", "R2"]
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()
        respuesta = cliente.post("/aclareos/intensidad-corta/reporte",
                                 data={"accion": "exportar_todos"})
        self.assertEqual(respuesta.status_code, 200)
        documento = Document(io.BytesIO(respuesta.data))
        texto = "\n".join(parrafo.text for parrafo in documento.paragraphs)
        self.assertIn("R1", texto)
        self.assertIn("R2", texto)
        self.assertEqual(texto.count("Interpretación técnica del rodal"), 2)
        self.assertEqual(sum(1 for relacion in documento.part.rels.values()
                             if "image" in relacion.reltype), 3)  # logo + una gráfica por rodal

    def test_mmobi_usa_ica_porcentaje_y_estructura_diametrica(self):
        pmf = proyecto_estructurado()
        actual = resumen_rodal_especie(pmf, "R1", "Pinus patula")
        evaluacion = construir_evaluacion(pmf, "R1", "Pinus patula", 10)
        mmobi = evaluacion["escenarios"]["mmobi"]
        ica_porcentaje = actual["ica_indicador_historico"]
        esperada = (1 - 1 / ((1 + ica_porcentaje / 100) ** 10)) * 100
        self.assertAlmostEqual(mmobi["intensidad_original"], esperada)
        self.assertEqual(mmobi["parametros"]["ica_porcentaje"], ica_porcentaje)
        self.assertAlmostEqual(mmobi["residual"]["v"], actual["v"] * (1 - esperada / 100))
        equivalentes = mmobi["intensidades_equivalentes"]
        self.assertFalse(math.isclose(equivalentes["n"], equivalentes["v"], rel_tol=1e-6))
        # Sin edad de retroproyección, Veiga permanece no disponible.
        self.assertEqual(evaluacion["escenarios"]["veiga"]["estado"], "no_disponible")

    def test_veiga_calcula_con_retroproyeccion(self):
        pmf = proyecto_estructurado()
        evaluacion = construir_evaluacion(
            pmf, "R1", "Pinus patula", 10, parametros_veiga={"edad_retroproyeccion": 5})
        veiga = evaluacion["escenarios"]["veiga"]
        self.assertEqual(veiga["estado"], "diagnostico")
        self.assertIsNotNone(veiga["t_veiga"])
        self.assertEqual(veiga["modelo_referencia"], "Pinus patula")
        self.assertEqual(veiga["ce_modelo"], "CE1")
        self.assertIn("diagnostico_crecimiento", veiga)
        self.assertIn("interpretacion_t", veiga["diagnostico_crecimiento"])

    def test_mmobi_usa_ica_porcentaje_sobre_100(self):
        actual = {
            "ica_indicador_historico": 23.276, "v": 100.0, "n": 100.0, "g": 10.0,
            "clases": [{"dncc": 20, "n": 100.0, "g": 10.0, "v": 100.0}],
        }

        mmobi = escenario_mmobi(actual, 10, None)

        self.assertAlmostEqual(mmobi["parametros"]["p_anual"], 0.23276)
        self.assertAlmostEqual(mmobi["intensidad_original"], 87.662855, places=6)

    def test_propuesta_por_arboles_reporta_intensidades_equivalentes(self):
        pmf = proyecto_estructurado()
        actual = resumen_rodal_especie(pmf, "R1", "Pinus patula")
        escenario = escenario_usuario(actual, 20, "numero_arboles", None)
        self.assertAlmostEqual(escenario["intensidades_equivalentes"]["n"], 20)
        self.assertLess(escenario["intensidades_equivalentes"]["g"], 20)
        self.assertLess(escenario["intensidades_equivalentes"]["v"], 20)

    def test_veiga_montezumae_diagnostico_matematico(self):
        """Prueba matemática del diagnóstico: D10 ≈ 5.41 cm y T ≈ 73.37 %."""
        d10 = _evaluar_modelo_veiga("montezumae_ce1", 10)
        self.assertAlmostEqual(d10, 5.41, places=1)
        # DQ actual dado en el ejemplo: 11.68 cm
        actual = {
            "especie": "Pinus montezumae",
            "n": 100.0, "g": 10.0, "v": 100.0,
            "dq": 11.68, "edad": 15, "clases": [],
        }
        veiga = escenario_veiga(actual, parametros={"edad_retroproyeccion": 10})
        self.assertEqual(veiga["estado"], "diagnostico")
        self.assertAlmostEqual(veiga["dq_retroproyectado"], 5.41, places=1)
        self.assertAlmostEqual(veiga["t_veiga"], 73.37, places=0)
        self.assertEqual(veiga["modelo_referencia"], "Pinus montezumae")
        self.assertEqual(veiga["ce_modelo"], "CE1")

    def test_veiga_regulacion_calcula_area_guia_desde_densidad_objetivo(self):
        actual = {
            "especie": "Pinus montezumae",
            "n": 3024.0, "g": 32.374, "v": 305.448,
            "dq": 11.68, "edad": 15, "clases": [],
        }
        densidad_objetivo = 1400.0
        veiga = escenario_veiga(actual, parametros={
            "diametro_deseado": 15.0, "densidad_objetivo": densidad_objetivo})
        self.assertEqual(veiga["estado"], "disponible")
        ab_ind = math.pi * (15.0 / 100.0) ** 2 / 4.0
        g_guia = densidad_objetivo * ab_ind
        n_residual = densidad_objetivo
        n_extraer = 3024.0 - n_residual
        ic = n_extraer / 3024.0 * 100.0
        self.assertAlmostEqual(veiga["n_residual"], n_residual, places=2)
        self.assertAlmostEqual(veiga["n_extraer"], n_extraer, places=2)
        self.assertAlmostEqual(veiga["densidad_objetivo"], densidad_objetivo, places=4)
        self.assertAlmostEqual(veiga["g_guia"], g_guia, places=4)
        self.assertAlmostEqual(veiga["g_residual"], g_guia, places=4)
        self.assertAlmostEqual(veiga["g_extraer"], 32.374 - g_guia, places=4)
        self.assertAlmostEqual(veiga["intensidad_original"], ic, places=2)
        self.assertEqual(veiga["unidad_original"], "numero_arboles")
        self.assertEqual(veiga["parametros"]["modelo_referencia"], "Pinus montezumae")

    def test_veiga_valida_diametro_deseado_mayor_que_dq_actual(self):
        actual = {
            "especie": "Pinus montezumae",
            "n": 3024.0, "g": 32.374, "v": 305.448,
            "dq": 11.68, "edad": 15, "clases": [],
        }
        veiga = escenario_veiga(actual, parametros={"diametro_deseado": 10.0, "densidad_objetivo": 1400.0})
        self.assertEqual(veiga["estado"], "no_disponible")
        self.assertIn("mayor que el DQ actual", veiga["mensaje"])

    def test_veiga_valida_densidad_objetivo_no_superior_a_n_actual(self):
        actual = {
            "especie": "Pinus montezumae",
            "n": 3024.0, "g": 32.374, "v": 305.448,
            "dq": 11.68, "edad": 15, "clases": [],
        }
        veiga = escenario_veiga(actual, parametros={"diametro_deseado": 15.0, "densidad_objetivo": 4000.0})
        self.assertEqual(veiga["estado"], "no_disponible")
        self.assertIn("supera la densidad actual", veiga["mensaje"])

    def test_veiga_modelos_pendientes_reportan_falta_ecuacion(self):
        # Pinus greggii → Patula CE2 (pendiente)
        actual_greggii = {
            "especie": "Pinus greggii", "n": 100.0, "g": 10.0, "v": 100.0,
            "dq": 15.0, "edad": 20, "clases": [],
        }
        veiga = escenario_veiga(actual_greggii, parametros={"edad_retroproyeccion": 10})
        self.assertEqual(veiga["estado"], "no_disponible")
        self.assertIn("CE2", veiga["mensaje"])

        # Juniperus deppeana → Rudis CE3 (pendiente)
        actual_deppeana = {
            "especie": "Juniperus deppeana", "n": 100.0, "g": 10.0, "v": 100.0,
            "dq": 15.0, "edad": 20, "clases": [],
        }
        veiga = escenario_veiga(actual_deppeana, parametros={"edad_retroproyeccion": 10})
        self.assertEqual(veiga["estado"], "no_disponible")
        self.assertIn("CE3", veiga["mensaje"])

    def test_generacion_adopcion_y_persistencia_por_ruta(self):
        pmf = proyecto_estructurado()
        pmf.rodales_aclareo = ["R1"]
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()
        respuesta = cliente.post("/aclareos/intensidad-corta", data={
            "accion": "generar_escenarios", "rodal": "R1", "especie": "Pinus patula",
            "ciclo_corta": "12", "edad_retroproyeccion": "5",
        })
        self.assertEqual(respuesta.status_code, 302)
        self.assertTrue(respuesta.headers["Location"].endswith("#evaluacion-aclareo"))
        pagina = cliente.get(respuesta.headers["Location"])
        html = pagina.get_data(as_text=True)
        self.assertIn("Comparación cuantitativa", html)
        self.assertIn("Veiga", html)
        self.assertIn("Indique el diámetro deseado y la densidad objetivo", html)
        respuesta = cliente.post("/aclareos/intensidad-corta", data={
            "accion": "adoptar", "rodal": "R1", "especie": "Pinus patula",
            "escenario_id": "mmobi",
        })
        self.assertEqual(respuesta.status_code, 302)
        with cliente.session_transaction() as sesion:
            self.assertNotIn("pmf_data", sesion)
            ruta = sesion["ruta_actual"]
        guardado = PMFProyecto.cargar(ruta)
        evaluacion = guardado.escenarios_aclareo["R1||Pinus patula"]
        self.assertEqual(evaluacion["adoptado"]["escenario_id"], "mmobi")
        self.assertEqual(guardado.plan_cortas.ciclo_corta_anios, 12)

    def test_resumen_incluye_altura_promedio_ponderada(self):
        pmf = proyecto_estructurado()
        resumen = resumen_rodal_especie(pmf, "R1", "Pinus patula")
        # (12*120 + 18*80 + 24*40) / 240 = 16.0
        self.assertAlmostEqual(resumen["h_prom"], 16.0)
        self.assertIn("h_prom", resumen)

    def test_cuadro_muestra_h_prom_despues_de_dq(self):
        pmf = proyecto_estructurado()
        pmf.rodales_aclareo = ["R1"]
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()
        html = cliente.get("/aclareos/intensidad-corta").get_data(as_text=True)
        self.assertIn("<th>H prom (m)</th>", html)
        self.assertLess(html.index("<th>Dq (cm)</th>"), html.index("<th>H prom (m)</th>"))
        self.assertIn(">16.00<", html)

    def test_reporte_word_incluye_h_prom(self):
        pmf = proyecto_estructurado()
        pmf.rodales_aclareo = ["R1"]
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()
        respuesta = cliente.post("/aclareos/intensidad-corta/reporte",
                                 data={"accion": "exportar_todos"})
        self.assertEqual(respuesta.status_code, 200)
        documento = Document(io.BytesIO(respuesta.data))
        celdas = [celda.text for tabla in documento.tables
                  for fila in tabla.rows for celda in fila.cells]
        self.assertIn("H prom (m)", celdas)
        self.assertIn("16.00", celdas)


class ConversionVolumetricaTest(unittest.TestCase):
    def test_unidad_volumen_usa_intensidad_original(self):
        escenario = {"estado": "disponible", "unidad_original": "volumen",
                      "intensidad_original": 7.84,
                      "intensidades_equivalentes": {"n": 7.9, "g": 7.8, "v": 7.83}}
        porcentaje, motivo = intensidad_volumetrica_equivalente(escenario)
        self.assertAlmostEqual(porcentaje, 7.84)
        self.assertIsNone(motivo)

    def test_otra_unidad_convierte_con_extraccion(self):
        escenario = {"estado": "disponible", "unidad_original": "numero_arboles",
                      "intensidad_original": 20.0,
                      "intensidades_equivalentes": {"n": 20.0, "g": 15.0, "v": 12.5}}
        porcentaje, motivo = intensidad_volumetrica_equivalente(escenario)
        self.assertAlmostEqual(porcentaje, 12.5)
        self.assertIsNone(motivo)

    def test_no_disponible_no_aplica(self):
        for escenario in ({"estado": "diagnostico", "unidad_original": None,
                           "intensidad_original": None},
                          {"estado": "disponible", "unidad_original": "numero_arboles",
                           "intensidad_original": 5.0,
                           "intensidades_equivalentes": {"n": 5.0}}):
            porcentaje, motivo = intensidad_volumetrica_equivalente(escenario)
            self.assertIsNone(porcentaje)
            self.assertTrue(motivo)


class AplicarIntensidadCuadroTest(unittest.TestCase):
    def _cliente(self, pmf):
        pmf.rodales_aclareo = ["R1"]
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()
        return cliente

    def _generar_y_adoptar_mmobi(self, cliente):
        respuesta = cliente.post("/aclareos/intensidad-corta", data={
            "accion": "generar_escenarios", "rodal": "R1", "especie": "Pinus patula",
            "ciclo_corta": "10"})
        self.assertEqual(respuesta.status_code, 302)
        respuesta = cliente.post("/aclareos/intensidad-corta", data={
            "accion": "adoptar", "rodal": "R1", "especie": "Pinus patula",
            "escenario_id": "mmobi"})
        self.assertEqual(respuesta.status_code, 302)

    def _proyecto_guardado(self, cliente):
        with cliente.session_transaction() as sesion:
            return PMFProyecto.cargar(sesion["ruta_actual"])

    def test_aplicar_mmobi_adoptado_escribe_intensidad_y_origen(self):
        cliente = self._cliente(proyecto_estructurado())
        self._generar_y_adoptar_mmobi(cliente)
        respuesta = cliente.post("/aclareos/intensidad-corta", data={
            "accion": "aplicar_cuadro", "rodal": "R1", "especie": "Pinus patula"})
        self.assertEqual(respuesta.status_code, 302)
        pmf = self._proyecto_guardado(cliente)
        intensidad = pmf.intensidad_corta["R1"]["Pinus patula"]
        self.assertGreater(intensidad, 0)
        origen = pmf.origen_intensidad["R1"]["Pinus patula"]
        self.assertEqual(origen["criterio"], "MMOBI")
        self.assertAlmostEqual(origen["intensidad"], intensidad)
        # El cuadro de existencias recalcula posibilidad con ese valor.
        filas = [f for f in pmf.cuadro_existencias()["filas"] if not f.get("_type")]
        fila = [f for f in filas if f["rodal"] == "R1" and f["especie"] == "Pinus patula"][0]
        self.assertAlmostEqual(fila["intensidad"], intensidad)
        self.assertAlmostEqual(fila["pos_umm"], fila["vol_umm"] * intensidad / 100)

    def test_aplicar_sin_adoptar_se_rechaza(self):
        cliente = self._cliente(proyecto_estructurado())
        cliente.post("/aclareos/intensidad-corta", data={
            "accion": "generar_escenarios", "rodal": "R1", "especie": "Pinus patula",
            "ciclo_corta": "10"})
        respuesta = cliente.post("/aclareos/intensidad-corta", data={
            "accion": "aplicar_cuadro", "rodal": "R1", "especie": "Pinus patula"})
        self.assertEqual(respuesta.status_code, 302)
        pmf = self._proyecto_guardado(cliente)
        self.assertEqual(pmf.intensidad_corta.get("R1", {}), {})
        self.assertEqual(getattr(pmf, "origen_intensidad", {}), {})

    def test_aplicar_veiga_convierte_a_volumen(self):
        cliente = self._cliente(proyecto_estructurado())
        cliente.post("/aclareos/intensidad-corta", data={
            "accion": "generar_escenarios", "rodal": "R1", "especie": "Pinus patula",
            "ciclo_corta": "10"})
        cliente.post("/aclareos/intensidad-corta", data={
            "accion": "calcular_veiga", "rodal": "R1", "especie": "Pinus patula",
            "diametro_deseado": "25", "densidad_objetivo": "100"})
        cliente.post("/aclareos/intensidad-corta", data={
            "accion": "adoptar", "rodal": "R1", "especie": "Pinus patula",
            "escenario_id": "veiga"})
        respuesta = cliente.post("/aclareos/intensidad-corta", data={
            "accion": "aplicar_cuadro", "rodal": "R1", "especie": "Pinus patula"})
        self.assertEqual(respuesta.status_code, 302)
        pmf = self._proyecto_guardado(cliente)
        esperado = pmf.escenarios_aclareo["R1||Pinus patula"]["escenarios"]["veiga"][
            "intensidades_equivalentes"]["v"]
        self.assertAlmostEqual(pmf.intensidad_corta["R1"]["Pinus patula"], esperado, places=2)
        self.assertEqual(pmf.origen_intensidad["R1"]["Pinus patula"]["criterio"], "Veiga")

    def test_aplicar_manual_y_rechazos(self):
        cliente = self._cliente(proyecto_estructurado())
        cliente.post("/aclareos/intensidad-corta", data={
            "accion": "generar_escenarios", "rodal": "R1", "especie": "Pinus patula",
            "ciclo_corta": "10"})
        respuesta = cliente.post("/aclareos/intensidad-corta", data={
            "accion": "aplicar_manual", "rodal": "R1", "especie": "Pinus patula",
            "intensidad_manual": "7.5"})
        self.assertEqual(respuesta.status_code, 302)
        pmf = self._proyecto_guardado(cliente)
        self.assertAlmostEqual(pmf.intensidad_corta["R1"]["Pinus patula"], 7.5)
        self.assertEqual(pmf.origen_intensidad["R1"]["Pinus patula"]["criterio"], "Manual")
        for mala in ("abc", "-3", "101"):
            respuesta = cliente.post("/aclareos/intensidad-corta", data={
                "accion": "aplicar_manual", "rodal": "R1", "especie": "Pinus patula",
                "intensidad_manual": mala})
            self.assertEqual(respuesta.status_code, 302)
        pmf = self._proyecto_guardado(cliente)
        self.assertAlmostEqual(pmf.intensidad_corta["R1"]["Pinus patula"], 7.5)

    def test_editar_cuadro_limpia_procedencia(self):
        cliente = self._cliente(proyecto_estructurado())
        self._generar_y_adoptar_mmobi(cliente)
        cliente.post("/aclareos/intensidad-corta", data={
            "accion": "aplicar_cuadro", "rodal": "R1", "especie": "Pinus patula"})
        pmf = self._proyecto_guardado(cliente)
        self.assertIn("Pinus patula", pmf.origen_intensidad.get("R1", {}))
        respuesta = cliente.post("/reportes/cuadro_existencias/guardar_intensidad", json={
            "intensidades": [{"rodal": "R1", "especie": "Pinus patula", "intensidad": 5.0}]})
        self.assertTrue(respuesta.get_json()["success"])
        pmf = self._proyecto_guardado(cliente)
        self.assertAlmostEqual(pmf.intensidad_corta["R1"]["Pinus patula"], 5.0)
        self.assertNotIn("Pinus patula", pmf.origen_intensidad.get("R1", {}))

    def test_tabla_aplicadas_usa_los_mismos_valores_del_cuadro(self):
        pmf = _proyecto_existencia_directa()
        pmf.fijar_existencia_directa("RX", "Pino", 0, 1.5, 20.0)
        pmf.fijar_incremento_directo("RX", "Pino", 42.0, 1.1, tp=8.0)
        pmf.rodales_aclareo = ["RX"]
        pmf.intensidad_corta = {"RX": {"Pino": 10.0}}
        pmf.origen_intensidad = {"RX": {"Pino": {"criterio": "Manual",
                                                "intensidad": 10.0}}}
        from motor_aclareos import resumen_rodal_especie
        resumen = resumen_rodal_especie(pmf, "RX", "Pino")
        filas = tabla_intensidades_aplicadas(pmf)
        self.assertEqual(len(filas), 1)
        self.assertAlmostEqual(filas[0]["n_ha"], resumen["n"])
        self.assertAlmostEqual(filas[0]["v_ha"], resumen["v"])
        self.assertAlmostEqual(filas[0]["n_ha"], 42.0)
        self.assertAlmostEqual(filas[0]["n_rem_ha"], 4.2)
        self.assertAlmostEqual(filas[0]["n_res_ha"], 37.8)

    def test_aplicar_redirige_al_cuadro(self):
        cliente = self._cliente(proyecto_estructurado())
        self._generar_y_adoptar_mmobi(cliente)
        respuesta = cliente.post("/aclareos/intensidad-corta", data={
            "accion": "aplicar_cuadro", "rodal": "R1", "especie": "Pinus patula"})
        self.assertTrue(respuesta.headers["Location"].endswith("#intensidades-aplicadas"))
        respuesta = cliente.post("/aclareos/intensidad-corta", data={
            "accion": "adoptar", "rodal": "R1", "especie": "Pinus patula",
            "escenario_id": "mmobi"})
        self.assertTrue(respuesta.headers["Location"].endswith("#evaluacion-aclareo"))
        pmf = proyecto_estructurado()
        pmf.intensidad_corta = {"R1": {"Pinus patula": 10.0}}
        pmf.origen_intensidad = {"R1": {"Pinus patula": {"criterio": "MMOBI",
                                                        "intensidad": 10.0}}}
        filas = tabla_intensidades_aplicadas(pmf)
        self.assertEqual(len(filas), 1)
        fila = filas[0]
        valores = pmf._calc_valores_rodal_especie("R1", "Pinus patula")
        self.assertAlmostEqual(fila["n_rem_ha"], valores["Arb/ha"] * 0.1)
        self.assertAlmostEqual(fila["v_rem_total"], valores["ERT VTA"] * 0.1)
        self.assertAlmostEqual(fila["n_res_ha"], valores["Arb/ha"] * 0.9)
        self.assertAlmostEqual(fila["v_res_total"], valores["ERT VTA"] * 0.9)
        self.assertAlmostEqual(fila["n_total"], valores["Arb/ha"] * 10.0)

    def test_inventario_cambiado_bloquea_aplicar(self):
        cliente = self._cliente(proyecto_estructurado())
        self._generar_y_adoptar_mmobi(cliente)
        pmf = self._proyecto_guardado(cliente)
        tabla = pmf.buscar_tabla_inventario("R1", "Pinus patula")
        tabla.clases[0].no_arboles = 999
        pmf.guardar(pmf.ruta_archivo)
        respuesta = cliente.post("/aclareos/intensidad-corta", data={
            "accion": "aplicar_cuadro", "rodal": "R1", "especie": "Pinus patula"})
        self.assertEqual(respuesta.status_code, 302)
        pmf = self._proyecto_guardado(cliente)
        self.assertEqual(pmf.intensidad_corta.get("R1", {}), {})

    def test_cuadro_aplicadas_se_muestra_y_word_la_incluye(self):
        cliente = self._cliente(proyecto_estructurado())
        self._generar_y_adoptar_mmobi(cliente)
        cliente.post("/aclareos/intensidad-corta", data={
            "accion": "aplicar_cuadro", "rodal": "R1", "especie": "Pinus patula"})
        html = cliente.get("/aclareos/intensidad-corta?importar=1").get_data(as_text=True)
        self.assertIn("Intensidades aplicadas al cuadro de existencias", html)
        self.assertIn("MMOBI", html)
        self.assertIn("Exportar cuadro", html)
        respuesta = cliente.post("/aclareos/intensidad-corta/reporte",
                                 data={"accion": "exportar_todos"})
        self.assertEqual(respuesta.status_code, 200)
        documento = Document(io.BytesIO(respuesta.data))
        celdas = [celda.text for tabla in documento.tables
                  for fila in tabla.rows for celda in fila.cells]
        self.assertIn("Intensidad %", celdas)
        self.assertIn("Arboles a remover/ha", celdas)

    def test_exportar_cuadro_aplicadas_excel_word_pdf(self):
        from openpyxl import load_workbook
        cliente = self._cliente(proyecto_estructurado())
        self._generar_y_adoptar_mmobi(cliente)
        cliente.post("/aclareos/intensidad-corta", data={
            "accion": "aplicar_cuadro", "rodal": "R1", "especie": "Pinus patula"})
        respuesta = cliente.get("/aclareos/intensidades-aplicadas/exportar/excel")
        self.assertEqual(respuesta.status_code, 200)
        libro = load_workbook(io.BytesIO(respuesta.data), read_only=True, data_only=True)
        hoja = libro.active
        encabezados = [celda.value for celda in hoja[3]]
        self.assertIn("Intensidad %", encabezados)
        self.assertIn("Arboles a remover/ha", encabezados)
        valores = [[celda.value for celda in fila] for fila in hoja.iter_rows(min_row=4)]
        self.assertEqual(len(valores), 1)
        self.assertEqual(valores[0][0], "R1")
        respuesta = cliente.get("/aclareos/intensidades-aplicadas/exportar/word")
        self.assertEqual(respuesta.status_code, 200)
        documento = Document(io.BytesIO(respuesta.data))
        celdas = [celda.text for tabla in documento.tables
                  for fila in tabla.rows for celda in fila.cells]
        self.assertIn("Intensidad %", celdas)
        self.assertIn("Volumen residual/total", celdas)
        respuesta = cliente.get("/aclareos/intensidades-aplicadas/exportar/pdf")
        self.assertEqual(respuesta.status_code, 200)
        self.assertTrue(respuesta.data.startswith(b"%PDF"))

    def test_pantalla_aplicadas_usa_cabeceras_de_arboles_y_volumen(self):
        cliente = self._cliente(proyecto_estructurado())
        self._generar_y_adoptar_mmobi(cliente)
        cliente.post("/aclareos/intensidad-corta", data={
            "accion": "aplicar_cuadro", "rodal": "R1", "especie": "Pinus patula"})
        html = cliente.get("/aclareos/intensidad-corta?importar=1").get_data(as_text=True)
        for cabecera in ("Arboles/ha", "Arboles/total", "ER/m3/ha", "ERT/m3",
                         "Arboles a remover/ha", "Arboles a remover/total",
                         "Volumen a remover/ha", "Volumen a remover/total",
                         "Arboles residuales/ha", "Arboles residuales/totales",
                         "Volumen residual/ha", "Volumen residual/total"):
            self.assertIn(cabecera, html)

    def test_exportar_sin_aplicadas_redirige(self):
        cliente = self._cliente(proyecto_estructurado())
        for formato in ("excel", "word", "pdf"):
            respuesta = cliente.get(f"/aclareos/intensidades-aplicadas/exportar/{formato}")
            self.assertEqual(respuesta.status_code, 302, formato)

    def test_filas_muestran_subtotal_por_rodal(self):
        cliente = self._cliente(proyecto_estructurado())
        html = cliente.get("/aclareos/intensidad-corta?importar=1").get_data(as_text=True)
        self.assertIn("Subtotal R1", html)

    def test_reporte_rodales_incluye_intensidad_cero(self):
        from motor_aclareos import tabla_reporte_rodales
        pmf = proyecto_estructurado()
        pmf.rodales_aclareo = ["R1"]
        filas = tabla_reporte_rodales(pmf)
        self.assertEqual(len(filas), 1)
        self.assertAlmostEqual(filas[0]["intensidad"], 0.0)
        self.assertEqual(filas[0]["criterio"], "Sin aplicar")
        self.assertAlmostEqual(filas[0]["n_rem_ha"], 0.0)
        self.assertAlmostEqual(filas[0]["v_res_ha"], filas[0]["v_ha"])

    def test_exportar_reporte_rodales_tres_formatos(self):
        from openpyxl import load_workbook
        cliente = self._cliente(proyecto_estructurado())
        for formato in ("excel", "word", "pdf"):
            respuesta = cliente.get(f"/aclareos/reporte-rodales/exportar/{formato}")
            self.assertEqual(respuesta.status_code, 200, formato)
        respuesta = cliente.get("/aclareos/reporte-rodales/exportar/excel")
        libro = load_workbook(io.BytesIO(respuesta.data), data_only=True)
        hoja = libro.active
        hoja_titulo = hoja.cell(1, 1).value
        self.assertIsNotNone(hoja_titulo)
        encabezados = [celda.value for celda in hoja[3]]
        self.assertIn("Intensidad %", encabezados)
        self.assertNotIn("Criterio", encabezados)
        self.assertEqual(hoja.page_setup.orientation, "landscape")
        respuesta = cliente.get("/aclareos/reporte-rodales/exportar/word")
        documento = Document(io.BytesIO(respuesta.data))
        from docx.enum.section import WD_ORIENT
        self.assertEqual(documento.sections[0].orientation, WD_ORIENT.LANDSCAPE)
        texto = "\n".join(
            [parrafo.text for parrafo in documento.paragraphs]
            + [celda.text for tabla in documento.tables
               for fila in tabla.rows for celda in fila.cells])
        self.assertIn("Rodales seleccionados", texto)
        self.assertNotIn("Criterio", texto)
        respuesta = cliente.get("/aclareos/reporte-rodales/exportar/pdf")
        self.assertTrue(respuesta.data.startswith(b"%PDF"))

    def test_exportar_reporte_sin_seleccion_redirige(self):
        pmf = proyecto_estructurado()
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()
        for formato in ("excel", "word", "pdf"):
            respuesta = cliente.get(f"/aclareos/reporte-rodales/exportar/{formato}")
            self.assertEqual(respuesta.status_code, 302, formato)

    def test_boton_exportar_rodales_junto_a_guardar(self):
        cliente = self._cliente(proyecto_estructurado())
        html = cliente.get("/aclareos/intensidad-corta?importar=1").get_data(as_text=True)
        self.assertIn("Exportar rodales", html)
        self.assertIn("exportar_reporte_rodales", html.replace("/aclareos/reporte-rodales/exportar/excel", "exportar_reporte_rodales"))


def _proyecto_existencia_directa():
    pmf = PMFProyecto("Aclareos directos")
    pmf.agregar_rodal(Rodal("RX", 8, sitios=0, area_sitio_m2=0,
                            tipo_inventario="existencias"))
    pmf.agregar_especie("Pino")
    pmf.fijar_existencia_directa("RX", "Pino", 100, 12.5, 80.0)
    pmf.fijar_incremento_directo("RX", "Pino", 100, 12.5,
                                  tp=12.0, ica_ha=3.5, ica_pct=3.5,
                                  ima_ha=4.0, edad=20.0)
    return pmf


class AclareosExistenciasDirectasTest(unittest.TestCase):
    def _cliente(self):
        pmf = _proyecto_existencia_directa()
        pmf.rodales_aclareo = ["RX"]
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()
        return cliente

    def _proyecto_guardado(self, cliente):
        with cliente.session_transaction() as sesion:
            return PMFProyecto.cargar(sesion["ruta_actual"])

    def test_guardar_areas_acepta_rodal_directo(self):
        pmf = _proyecto_existencia_directa()
        cliente = app.test_client()
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()
        html = cliente.get("/aclareos/intensidad-corta?importar=1").get_data(as_text=True)
        self.assertIn("RX", html)
        respuesta = cliente.post("/aclareos/intensidad-corta", data={
            "accion": "seleccionar_areas", "rodales_aclareo": ["RX"]})
        self.assertEqual(respuesta.status_code, 302)
        self.assertEqual(self._proyecto_guardado(cliente).rodales_aclareo, ["RX"])

    def test_filas_incluyen_rodal_directo(self):
        cliente = self._cliente()
        html = cliente.get("/aclareos/intensidad-corta?importar=1").get_data(as_text=True)
        self.assertIn("80.000", html)
        self.assertIn("—", html)

    def test_generar_proponer_adoptar_aplicar_directo(self):
        cliente = self._cliente()
        for datos in ({"accion": "generar_escenarios", "rodal": "RX", "especie": "Pino",
                       "ciclo_corta": "10"},
                      {"accion": "proponer_usuario", "rodal": "RX", "especie": "Pino",
                       "intensidad_usuario": "10", "unidad_usuario": "volumen"},
                      {"accion": "adoptar", "rodal": "RX", "especie": "Pino",
                       "escenario_id": "usuario"},
                      {"accion": "aplicar_cuadro", "rodal": "RX", "especie": "Pino"}):
            respuesta = cliente.post("/aclareos/intensidad-corta", data=datos)
            self.assertEqual(respuesta.status_code, 302, datos["accion"])
        pmf = self._proyecto_guardado(cliente)
        self.assertAlmostEqual(pmf.intensidad_corta["RX"]["Pino"], 10.0)
        self.assertEqual(pmf.origen_intensidad["RX"]["Pino"]["criterio"],
                         "Propuesta del usuario")
        filas = [f for f in pmf.cuadro_existencias()["filas"] if not f.get("_type")]
        fila = [f for f in filas if f["rodal"] == "RX"][0]
        self.assertAlmostEqual(fila["intensidad"], 10.0)
        self.assertAlmostEqual(fila["pos_umm"], fila["vol_umm"] * 0.1)

    def test_mmobi_disponible_con_ica_capturado(self):
        pmf = _proyecto_existencia_directa()
        evaluacion = construir_evaluacion(pmf, "RX", "Pino", 10)
        self.assertEqual(evaluacion["escenarios"]["mmobi"]["estado"], "disponible")

    def test_evaluacion_directa_renderiza_sin_dq(self):
        cliente = self._cliente()
        cliente.post("/aclareos/intensidad-corta", data={
            "accion": "generar_escenarios", "rodal": "RX", "especie": "Pino",
            "ciclo_corta": "10"})
        html = cliente.get(
            "/aclareos/intensidad-corta?importar=1&rid=RX&especie=Pino").get_data(as_text=True)
        self.assertEqual(
            cliente.get("/aclareos/intensidad-corta?importar=1&rid=RX&especie=Pino").status_code,
            200)
        self.assertIn("Comparación simultánea", html)

    def test_filas_vinculan_incrementos_cuando_existencias_en_cero(self):
        pmf = _proyecto_existencia_directa()
        pmf.fijar_existencia_directa("RX", "Pino", 0, 1.5, 20.0)
        pmf.fijar_incremento_directo("RX", "Pino", 42.0, 1.1,
                                      tp=8.0, dq_cm=18.03, h_m=12.86)
        resumen = resumen_rodal_especie(pmf, "RX", "Pino")
        self.assertAlmostEqual(resumen["n"], 42.0)
        self.assertAlmostEqual(resumen["g"], 1.5)
        self.assertAlmostEqual(resumen["v"], 20.0)
        self.assertAlmostEqual(resumen["dq"], 18.03)
        self.assertAlmostEqual(resumen["h_prom"], 12.86)
        self.assertAlmostEqual(resumen["tp"], 8.0)

    def test_dq_capturado_habilita_veiga_en_directo(self):
        pmf = _proyecto_existencia_directa()
        pmf.agregar_especie("Pinus patula")
        pmf.fijar_existencia_directa("RX", "Pinus patula", 100, 12.5, 80.0)
        pmf.fijar_incremento_directo("RX", "Pinus patula", 100, 12.5,
                                      tp=8.0, dq_cm=18.03, h_m=12.86)
        from motor_aclareos import escenario_veiga
        veiga = escenario_veiga(resumen_rodal_especie(pmf, "RX", "Pinus patula"),
                                parametros={"diametro_deseado": "20",
                                            "densidad_objetivo": "20"},
                                modelo=None)
        self.assertEqual(veiga["estado"], "disponible")
        self.assertGreater(veiga["intensidades_equivalentes"]["v"], 0)


if __name__ == "__main__":
    unittest.main()
