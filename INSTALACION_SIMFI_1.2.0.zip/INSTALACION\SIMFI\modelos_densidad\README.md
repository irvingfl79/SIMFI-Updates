# Modelos de densidad

Cada archivo JSON representa una guía independiente y regional. Para registrar
otra guía, agregue un archivo sin modificar los inventarios ni el motor.

Campos de trazabilidad obligatorios:

- `modelo_id`: identificador único que incluya especie y región.
- `version_modelo` y `fecha_registro`.
- `especie.nombre_canonico`, `nombre_cientifico` y `alias`.
- `region_aplicacion`, `ambito_aplicacion` y `observaciones`.
- `fronteras`, con las líneas que realmente define la publicación, su método,
  significado, ecuación y parámetros.
- `reglas_clasificacion`, ordenadas y referidas a los identificadores de las
  fronteras del modelo.
- `metodo_grado_densidad`, definido por la fuente de esa guía.
- `fuente`, con los datos bibliográficos disponibles para la publicación.

SIMFI sólo selecciona modelos cuyo nombre canónico o alias coincide con la
especie dominante. Si existe más de una guía para la especie, obliga a elegir
la región; nunca toma una guía de otra especie como valor predeterminado.

Los tipos de ecuación disponibles son `n_dq_potencia`, representado por
`N = a * Dq^b`, y `fcc_area_maxima_copa_polinomial`, representado por
`N = 100 / (c0 + c1*Dq + c2*Dq^2)`. `n_dq_log_lineal` representa
`ln(N) = alpha + beta*ln(Dq)`. `fcc_modelo_copa_lineal` obtiene N a partir de
`Dc = intercepto + pendiente*D`, el área de copa y su porcentaje de hectárea.
Una frontera sin parámetros validados debe conservar `estado: "pendiente"` y
valores nulos.

La clasificación puede usar `reglas_clasificacion` entre fronteras o
`zonas_densidad` con límites porcentuales inclusivos o exclusivos. El método se
declara en `metodo_clasificacion`; la interfaz no contiene categorías propias
de ninguna especie.

`simulacion_objetivo` habilita un porcentaje objetivo como referencia para el
escenario residual. El técnico sigue definiendo N y G residuales; SIMFI reporta
remoción, grado alcanzado y diferencia, sin imponer una intensidad de corta.
