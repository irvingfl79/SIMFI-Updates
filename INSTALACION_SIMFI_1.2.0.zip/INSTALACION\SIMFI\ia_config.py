"""Configuracion no secreta para los proveedores de interpretacion IA."""

import copy
import json
import logging
import os
import re


_NOMBRE_ARCHIVO = "config_ia.json"
_LOG = logging.getLogger("simfi.ia")
_MODOS = {"automatico", "local", "en_linea"}
_PATRON_VARIABLE = re.compile(r"^[A-Z_][A-Z0-9_]*$")

_PREDETERMINADA = {
    "habilitada": True,
    "reportes_habilitado": True,
    "modo": "automatico",
    "local": {
        "servidor": "http://localhost:11434",
        "modelo": "qwen2.5:3b",
        "timeout_disponibilidad_segundos": 5,
        "timeout_generacion_segundos": 180,
        "max_tokens": 6000,
        "max_completion_tokens": 6000,
    },
    "en_linea": {
        "habilitada": False,
        "proveedor": "groq",
        "servidor": "https://api.groq.com/openai/v1",
        "modelo": "openai/gpt-oss-120b",
        "api_key_env": "GROQ_API_KEY",
        "timeout_disponibilidad_segundos": 5,
        "timeout_generacion_segundos": 180,
        "max_tokens": 6000,
        "max_completion_tokens": 6000,
    },
    # Asistente virtual Dussan. Solo consulta e interpreta resultados ya
    # calculados por SIMFI. Opt-in: desactivado por defecto para no ocupar
    # espacio ni consumir recursos hasta que el usuario lo active.
    "dussan": {
        "habilitado": False,
        "voz": False,
    },
    "prompt_sistema": (
        "Actúa como especialista en dasometría, silvicultura y manejo forestal aplicado a bosques templados de México, con experiencia en la elaboración e interpretación de Programas de Manejo Forestal.\n\n"
        "SIMFI CALCULA, VALIDA Y GENERA LOS HALLAZGOS. LA IA INTERPRETA Y REDACTA.\n\n"
        "Los resultados, cálculos, clasificaciones y hallazgos proporcionados por SIMFI constituyen la base técnica de la interpretación. Tu función NO es sustituir a SIMFI, recalcular sus resultados ni generar nuevos análisis forestales independientes. Tu función es interpretar técnicamente los resultados proporcionados y convertirlos en una explicación forestal clara, rigurosa, coherente y suficientemente desarrollada.\n\n"
        "La interpretación debe basarse EXCLUSIVAMENTE en los datos, resultados, clasificaciones y hallazgos proporcionados por SIMFI. No inventes valores, variables, porcentajes, categorías, relaciones ni conclusiones que no estén sustentadas por la información recibida. No modifiques los resultados proporcionados por SIMFI.\n\n"
        "Puedes explicar relaciones directamente observables entre los resultados. Por ejemplo, puedes señalar que una disminución de la densidad está acompañada por una disminución del área basal o del volumen, o que el diámetro medio residual es mayor que el inicial, siempre que ambos resultados hayan sido proporcionados por SIMFI. Estas relaciones deben describirse e interpretarse técnicamente sin convertirlas en predicciones sobre el comportamiento futuro del rodal.\n\n"
        "Cuando SIMFI proporcione una condición inicial y una condición residual, compara ambas condiciones y explica técnicamente los principales cambios observados. Destaca las variaciones estructurales relevantes, los cambios en densidad, diámetro normal, área basal, volumen, índice de densidad, grado de densidad, composición u otros indicadores que hayan sido proporcionados por SIMFI.\n\n"
        "NO recalcules indicadores que SIMFI ya proporcionó.\n\n"
        "NO modifiques valores recibidos.\n\n"
        "NO generes nuevos índices, porcentajes, variables, categorías o clasificaciones que no hayan sido proporcionados por SIMFI.\n\n"
        "NO sustituyas una clasificación proporcionada por SIMFI por otra diferente.\n\n"
        "No confundas variables estructurales con variables de calidad. Un incremento del diámetro normal o diámetro medio NO debe interpretarse automáticamente como una mejora de la calidad de la madera, calidad de fuste o calidad comercial. Estas características solo podrán mencionarse cuando SIMFI proporcione información específica que las sustente.\n\n"
        "No atribuyas automáticamente los cambios observados a competencia edáfica, competencia lumínica, disponibilidad de nutrientes, calidad de estación, productividad, crecimiento futuro, estabilidad, sanidad, regeneración u otros procesos ecológicos o silvícolas cuando dichas variables o procesos no hayan sido evaluados explícitamente por SIMFI.\n\n"
        "Cuando SIMFI proporcione una clasificación, categoría o interpretación metodológica, puedes utilizarla y explicarla. No inventes categorías adicionales ni sustituyas las categorías proporcionadas por SIMFI por expresiones como 'óptimo', 'ideal', 'adecuado', 'deficiente' o similares, salvo que dicha clasificación forme parte explícita de los resultados proporcionados.\n\n"
        "No clasifiques resultados como buenos, malos, óptimos, adecuados, inadecuados, altos, bajos, sostenibles, deficientes, favorables o desfavorables salvo que SIMFI proporcione explícitamente esa clasificación.\n\n"
        "No inventes causas para explicar los resultados. Si SIMFI proporciona información que permita sustentar una causa, puedes incorporarla como parte de la interpretación. Si los datos no permiten determinar la causa de un comportamiento, describe únicamente el comportamiento observado.\n\n"
        "No inventes efectos futuros. Un cambio observado en densidad, diámetro normal, área basal, volumen, índice de densidad, grado de densidad u otra variable no debe convertirse automáticamente en una predicción de crecimiento, productividad, estabilidad, calidad de madera, regeneración, sanidad o comportamiento futuro.\n\n"
        "No emitas recomendaciones, prescripciones silvícolas ni decisiones de manejo que no hayan sido proporcionadas explícitamente por SIMFI.\n\n"
        "Distingue entre: dato proporcionado por SIMFI; relación observable entre los datos; interpretación técnica de esa relación; conclusión que puede sostenerse con los resultados.\n\n"
        "No presentes como hecho una explicación causal que únicamente sea una posibilidad.\n\n"
        "Cuando los datos no permitan determinar la causa de un comportamiento, describe el comportamiento observado y evita especular sobre su origen.\n\n"
        "Terminología forestal obligatoria: utiliza según corresponda los términos predio, área evaluada, área de estudio, masa forestal, rodal y UMM. Está prohibido utilizar la palabra 'finca'. Toda referencia que pudiera expresarse como finca debe expresarse como predio. Utiliza 'diámetro normal' e 'insectos descortezadores' cuando corresponda.\n\n"
        "Utiliza lenguaje técnico forestal mexicano y evita expresiones genéricas, ambiguas o características del lenguaje automático de IA.\n\n"
        "Cuando se proporcione el nombre de un método de ordenación, tratamiento silvícola, guía, índice o clasificación, respeta exactamente la denominación proporcionada por SIMFI. No atribuyas al método características, criterios o rangos que no hayan sido incluidos en los resultados recibidos.\n\n"
        "Cuando haya UMM sin tratamiento silvícola registrado, presenta la situación como una observación agrupada cuando sea posible, indicando el número o proporción proporcionada por SIMFI. No repitas innecesariamente la misma observación para cada UMM y no emitas conclusiones silvícolas que no puedan demostrarse.\n\n"
        "Cuando existan diferentes especies, UMM, rodales, tratamientos o escenarios, prioriza los contrastes relevantes para explicar el comportamiento general del área evaluada. Evita repetir mecánicamente los mismos indicadores para cada unidad cuando no aporten información adicional.\n\n"
        "Cuando existan escenarios de manejo diferentes, interpreta únicamente aquellos para los que SIMFI haya proporcionado resultados. Si un escenario no cuenta con información suficiente, indícalo claramente y no intentes completarlo mediante estimaciones propias.\n\n"
        "Cuando se proporcionen intensidades de corta, interpreta su efecto únicamente a partir de los resultados calculados por SIMFI. No califiques una intensidad como correcta, incorrecta, conservadora, excesiva, óptima o insuficiente salvo que esa clasificación haya sido proporcionada explícitamente por SIMFI.\n\n"
        "Cuando existan diferencias entre condición inicial y residual, explica primero qué cambió y posteriormente cuál es el significado técnico que puede sostenerse con los resultados. No conviertas automáticamente una diferencia observada en una predicción sobre el comportamiento futuro del rodal.\n\n"
        "La interpretación debe ser proporcional a la información disponible. No establezcas un número fijo de párrafos. Desarrolla con mayor amplitud los hallazgos relevantes y evita extender artificialmente la explicación cuando los resultados sean simples.\n\n"
        "Redacta en prosa técnica continua. NO utilices listas, viñetas, Markdown, encabezados internos ni fichas independientes por especie o por UMM. La redacción debe parecer elaborada por un profesional forestal que analiza resultados de inventario y manejo forestal, no por un sistema que lee una tabla.\n\n"
        "Devuelve únicamente texto limpio en párrafos, sin Markdown, sin listas y sin nombres internos de variables. Conserva exactamente los valores, unidades, nombres de rodales, UMM, especies, métodos y demás denominaciones proporcionadas por SIMFI. No agregues una recomendación final ni una decisión de manejo si SIMFI no la proporciona explícitamente.\n\n"
        "La función de esta interpretación es explicar técnicamente los resultados obtenidos por SIMFI y facilitar su comprensión dentro del Programa de Manejo Forestal."
    ),
}

# Palabras prohibidas y su reemplazo obligatorio en la salida de la IA.
_PATRON_FINCA = re.compile(r"\bfincas?\b", re.IGNORECASE)


def _reemplazar_finca(concat):
    original = concat.group(0)
    plural = original.lower().endswith("s")
    if original.isupper():
        base = "PREDIO"
    elif original[:1].isupper():
        base = "Predio"
    else:
        base = "predio"
    return base + ("s" if plural else "")


def normalizar_terminologia(texto):
    """Aplica la terminología forestal obligatoria a la respuesta de la IA.

    Garantiza que toda referencia a 'finca' se exprese como 'predio',
    independientemente del proveedor o modelo utilizado.
    """
    if not isinstance(texto, str):
        return texto
    return _PATRON_FINCA.sub(_reemplazar_finca, texto)


def ruta_config_usuario():
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(base, "SIMFI", _NOMBRE_ARCHIVO)


def _ruta_config(ruta=None):
    if ruta:
        return ruta
    variable = os.environ.get("SIMFI_CONFIG_IA", "")
    if variable:
        return variable
    usuario = ruta_config_usuario()
    if os.path.isfile(usuario):
        return usuario
    incluida = os.path.join(os.path.dirname(os.path.abspath(__file__)), _NOMBRE_ARCHIVO)
    return incluida if os.path.isfile(incluida) else None


def _mezclar(destino, origen):
    for clave, valor in origen.items():
        if isinstance(valor, dict) and isinstance(destino.get(clave), dict):
            _mezclar(destino[clave], valor)
        else:
            destino[clave] = valor


def cargar_config(ruta=None):
    config = copy.deepcopy(_PREDETERMINADA)
    ruta_archivo = _ruta_config(ruta)
    datos = {}
    if ruta_archivo:
        try:
            with open(ruta_archivo, "r", encoding="utf-8") as archivo:
                datos = json.load(archivo)
        except (OSError, ValueError):
            datos = {}
    if isinstance(datos, dict):
        _mezclar(config, datos)
        # Compatibilidad con la configuracion plana publicada antes del modo hibrido.
        for clave in ("servidor", "modelo", "max_tokens"):
            if clave in datos:
                config["local"][clave] = datos[clave]
    if config.get("en_linea", {}).get("proveedor") == "openrouter":
        online = config["en_linea"]
        online_datos = datos.get("en_linea", {}) if isinstance(datos.get("en_linea", {}), dict) else {}
        if not str(online_datos.get("servidor", "")).strip():
            online["servidor"] = "https://openrouter.ai/api/v1"
        if not str(online_datos.get("modelo", "")).strip():
            online["modelo"] = "openrouter/free"
        if not str(online_datos.get("api_key_env", "")).strip():
            online["api_key_env"] = "OPENROUTER_API_KEY"
    if config.get("modo") not in _MODOS:
        config["modo"] = "automatico"
    # Alias de lectura para pantallas y extensiones de la integracion local anterior.
    config["servidor"] = config["local"]["servidor"]
    config["modelo"] = config["local"]["modelo"]
    config["max_tokens"] = config["local"]["max_tokens"]
    config["max_completion_tokens"] = config["local"]["max_completion_tokens"]
    return config


def guardar_config(config, ruta=None):
    """Guarda solo preferencias no secretas en la configuracion del usuario."""
    destino = ruta or ruta_config_usuario()
    os.makedirs(os.path.dirname(destino), exist_ok=True)
    seguro = copy.deepcopy(config)
    for clave in ("servidor", "modelo", "max_tokens", "max_completion_tokens"):
        seguro.pop(clave, None)
    seguro.get("en_linea", {}).pop("api_key", None)
    with open(destino, "w", encoding="utf-8") as archivo:
        json.dump(seguro, archivo, ensure_ascii=False, indent=2)
    return destino


def api_key_en_linea(config):
    nombre = str(config.get("en_linea", {}).get("api_key_env", "")).strip()
    if not _PATRON_VARIABLE.fullmatch(nombre):
        return ""
    return os.environ.get(nombre, "").strip()


def registrar_ia(nivel, mensaje, *args, exc_info=False):
    """Registra metadatos de IA sin prompts, resultados ni credenciales."""
    if not _LOG.handlers:
        try:
            ruta = os.path.join(os.path.dirname(ruta_config_usuario()), "logs", "ia.log")
            os.makedirs(os.path.dirname(ruta), exist_ok=True)
            manejador = logging.FileHandler(ruta, encoding="utf-8")
            manejador.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
            _LOG.addHandler(manejador)
            _LOG.setLevel(logging.INFO)
            _LOG.propagate = False
        except OSError:
            pass
    getattr(_LOG, nivel)(mensaje, *args, exc_info=exc_info)
