# Regla permanente de paquetes de actualización

Cuando el usuario solicite generar, preparar o crear un paquete de actualización o instalación de SIMFI o MOREDIF, se debe ejecutar automáticamente el procedimiento completo, no limitarse a crear scripts.

## Procedimiento obligatorio

1. Revisar el proyecto e identificar cambios desde la última versión.
2. Proteger datos, inventarios, proyectos, programas de manejo, configuraciones, capturas, reportes y respaldos del usuario.
3. Determinar si existe cambio de estructura de datos y crear una migración no destructiva cuando corresponda.
4. Comprobar que el sistema inicia y ejecutar las pruebas disponibles.
5. Incrementar la versión `MAYOR.MENOR.PARCHE` según el alcance real.
6. Actualizar `version.json` o el mecanismo vigente y la fecha de compilación.
7. Preparar el actualizador para modificar exclusivamente archivos autorizados de la aplicación.
8. Generar antes de actualizar un respaldo recuperable en `RESPALDO_VERSIONES\<SISTEMA>_<VERSION>_<FECHA>\`.
9. Reconocer instalaciones existentes y conservar siempre sus carpetas de datos.
10. Preparar el paquete de actualización en PowerShell (sin `.exe`): copiar `actualizar_simfi.ps1` y `SIMFI_payload_<VERSION>.zip` a la carpeta `DIST\SIMFI_Actualizacion_<VERSION>\` junto con `ACTUALIZAR.bat`, `LEEME.txt` y `SHA256.txt`.
11. Colocar la carpeta del paquete terminado en `DIST\`.
12. Validar contenido, versión, migraciones, respaldo, actualización sobre una instalación de prueba e inicio posterior.
13. Tomar hashes de todos los datos antes de actualizar y comprobar después que ningún archivo preexistente cambió o desapareció.
14. Detectar rutas de instalaciones anteriores antes de reparar accesos directos y recuperar sus datos mediante copia no destructiva.
15. Ejecutar el paquete final exacto de principio a fin (`ACTUALIZAR.bat` o el `actualizar_simfi.ps1` de la carpeta `DIST`) sobre una instalación con proyectos de prueba; no basta validar scripts o contenido interno.
16. Dejar en `DIST\` solamente la carpeta del paquete acumulativo final y retirar versiones anteriores.

## Prohibiciones

- No reemplazar bases existentes por bases vacías.
- No borrar indiscriminadamente carpetas completas.
- No eliminar inventarios, proyectos, programas de manejo, configuraciones, capturas, resultados, reportes o respaldos.
- No cambiar el acceso directo a otra carpeta de instalación sin respaldar y recuperar antes los datos de la carpeta anterior.
- No sobrescribir archivos de datos con el mismo nombre; conservar el original activo y crear una copia recuperada identificable.
- No distribuir como estable un paquete con riesgo de pérdida de información, migraciones fallidas, pruebas fallidas o incompatibilidad conocida.

Si existe un riesgo de pérdida o corrupción, detener la generación estable y reportar claramente el bloqueo.

## Respuesta final

Informar de forma breve: sistema, versión anterior, versión nueva, ruta del paquete (`DIST\SIMFI_Actualizacion_<VERSIÓN>\`), cambios, estado de migración, conservación de datos, respaldo automático y estado final.

## Reglas técnicas del error de muestreo (motor 3.0)

- El error de muestreo relativo se reporta tal como se calcula: E% = t · SE / media · 100. Nunca se escala, se divide ni se ajusta para cumplir un límite.
- El criterio normativo (error objetivo, normalmente 10 %) se evalúa sobre el resultado general estratificado del predio. Los errores por rodal son informativos y no se clasifican como cumple / no cumple.
- Muestreo estratificado: cada rodal es un estrato, ponderado por W_h = A_h / A. Varianza de la media = Σ W_h² · SE_h². Grados de libertad por Welch-Satterthwaite.
- Por rodal: FPC con N_h = superficie del rodal / superficie del sitio; SE_h = √((s²/n)·(1 − n/N)); gl = n − 1.
- Los sitios con volumen cero (estado completado_cero) son observaciones válidas y se incluyen en media y varianza.
- Los cambios de código nunca modifican, migran, recalculan ni borran datos de proyectos existentes. Leer un registro antiguo es solo lectura; un recálculo solicitado por el usuario crea un registro nuevo y conserva el anterior.
- El diagnóstico (diagnostico_muestreo.py) solo recomienda: nunca excluye, corrige ni modifica volúmenes. Aporte al error: C_h = W_h²·SE_h². Sitios adicionales por beneficio marginal W_h²·s²_h·(1/n − 1/(n+1)). Atípicos: razón contra la mediana de los demás sitios < 0.4 o > 2.0, o |z| > 3.
- Datos de referencia para pruebas: predio de 21 rodales / 103 sitios en tests/ debe dar media 130.52 m³/ha y error general 6.78 %.

## Reglas técnicas del asistente Dussan

- SIMFI CALCULA Y VALIDA. Dussan CONSULTA, INTERPRETA Y ORIENTA. Dussan nunca recalcula un indicador, nunca modifica ecuaciones ni metodologías, nunca altera resultados oficiales y nunca escribe en el proyecto ni en la base de datos.
- Toda lectura de Dussan debe provenir de una función que ya existe en SIMFI (`modelos.PMFProyecto` o los analizadores de `reportes_tecnicos.py`). Si una operación ya existe en SIMFI, Dussan la invoca; no se reimplementa.
- Dussan no expone datos de caminos de archivos, no envía el proyecto completo a un proveedor de IA y solo transmite los resultados de las herramientas que consultó.
- Las API keys se leen exclusivamente del entorno mediante `ia_config.api_key_en_linea()`. Ni `dussan_backend.py` ni los archivos de `static/js/dussan*.js` pueden contener claves, variables de entorno o URLs de proveedores.
- La IA se invoca solo a través de `AIInterpretationService`, conservando el prompt maestro de `ia_config` y su normalización de terminología (predio, nunca finca).
- UMM y rodal son la misma unidad de manejo en SIMFI. No se modelan como dos niveles.
- `consultar_remisiones` se declara `no_disponible`: SIMFI no tiene módulo de remisiones y no debe crearse una implementación alterna.
- `ejecutar_proceso`, `modificar_datos` y `eliminar_datos` no se exponen. Esas operaciones se realizan desde el módulo de SIMFI que las valida y las registra.
- Cuando no hay motor de IA disponible, Dussan responde con un resumen determinista de valores ya calculados y lo advierte; nunca completa datos ni estima.
- Dussan debe seguir funcionando si se desactiva por configuración, y su ausencia no puede alterar ningún cálculo ni ninguna vista.
- Dussan es opt-in y está desactivado por defecto (`dussan.habilitado: false`) para no ocupar espacio ni consumir recursos hasta que el usuario lo active en Ajustes > IA.
- La disponibilidad de proveedores de IA se cachea 60 s por instancia y configuración (`ai_interpretation_service.limpiar_cache_estado()` la libera) para no repetir sondeos de red en cada mensaje ni en cada página de estado.
