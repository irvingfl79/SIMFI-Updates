"""Documento Word institucional para el análisis de error de muestreo."""
from docx import Document
from docx.enum.section import WD_ORIENT
from docx.shared import Cm

from reportes_tecnicos import _configurar_documento_institucional, _tabla


def generar_word_error_muestreo(pmf, analisis, resultado):
    documento = Document()
    _configurar_documento_institucional(documento, pmf, analisis)
    documento.add_heading("Análisis del error de muestreo", 0)
    documento.add_paragraph("Variable analizada: Volumen total por hectárea (m3/ha).")
    documento.add_paragraph("Este documento se generó exclusivamente con la matriz de trabajo confirmada y los resultados estadísticos del análisis.")
    documento.add_page_break()
    for titulo, textos in analisis["secciones"]:
        documento.add_heading(titulo, level=1)
        for texto in textos:
            documento.add_paragraph(texto)
    # La sección horizontal debe iniciar antes del título para no dejarlo aislado.
    seccion = documento.add_section(WD_ORIENT.LANDSCAPE)
    seccion.page_width, seccion.page_height = Cm(27.94), Cm(21.59)
    seccion.left_margin, seccion.right_margin = Cm(1.2), Cm(1.2)
    documento.add_heading("8. Resultados estadísticos por rodal", level=1)
    _tabla(documento, analisis["encabezados"], analisis["tabla"],
           titulo="Resultados estadísticos por rodal", numero_tabla=1)
    documento.add_heading("9. Volumen estimado por rodal", level=1)
    totales = []
    for rodal in resultado["rodales"]:
        e = rodal.get("estadistica") or {}
        if e.get("error_absoluto_m3_ha") is None or rodal.get("error_total_m3") is None:
            total = "No calculable"
        else:
            total = f"{rodal['error_total_m3']:.3f}"
        if rodal.get("li_total_m3") is None or rodal.get("ls_total_m3") is None:
            intervalo = "No calculable"
        else:
            intervalo = f"{rodal['li_total_m3']:.3f} a {rodal['ls_total_m3']:.3f}"
        media = e.get("media_m3_ha")
        totales.append((rodal.get("clave", "sin clave"),
                       f"{media:.2f}" if isinstance(media, (int, float)) else "No calculable",
                       f"{rodal.get('volumen_estimado_m3') or 0:.3f}", total, intervalo))
    _tabla(documento, ("Rodal", "Media m3/ha", "Volumen estimado m3", "Error total m3", "Intervalo total m3"), totales,
           titulo="Volumen estimado por rodal", numero_tabla=2)
    documento.add_heading("Diagnóstico y recomendaciones", level=1)
    diagnostico = (resultado or {}).get("diagnostico")
    try:
        motor_anterior = tuple(int(p) for p in str((resultado or {}).get("version_motor")).split(".")[:2]) < (3, 0)
    except (TypeError, ValueError):
        motor_anterior = True
    if not diagnostico or not diagnostico.get("disponible"):
        if motor_anterior:
            documento.add_paragraph("Diagnóstico disponible al recalcular.")
        else:
            documento.add_paragraph((diagnostico or {}).get("mensaje", "Diagnóstico no disponible."))
    else:
        documento.add_paragraph(diagnostico.get("resumen", ""))
        documento.add_paragraph("Aporte de cada rodal al error del predio (informativo; el criterio de "
                                "cumplimiento se evalúa sobre el resultado general):")
        filas_aporte = [(a["clave"], f"{a['aporte_pct']:.2f} %", f"{a['aporte_acumulado_pct']:.2f} %", a["clasificacion"])
                       for a in diagnostico.get("aporte_por_rodal", [])]
        _tabla(documento, ("Rodal", "Aporte %", "Acumulado %", "Clasificación"), filas_aporte,
              titulo="Aporte al error por rodal", numero_tabla=3)
        sitios_adic = diagnostico.get("sitios_adicionales", {})
        documento.add_paragraph(sitios_adic.get("mensaje", ""))
        distribucion = sitios_adic.get("distribucion_por_rodal") or []
        if distribucion:
            _tabla(documento, ("Rodal", "Sitios adicionales sugeridos"),
                  [(d["clave"], d["sitios_adicionales"]) for d in distribucion],
                  titulo="Distribución de sitios adicionales", numero_tabla=4)
        revisar = diagnostico.get("sitios_atipicos_revisar") or []
        if revisar:
            documento.add_paragraph("Sitios con volumen atípico (Revisar):")
            _tabla(documento, ("Rodal", "Sitio", "Volumen m3", "Razón", "z", "Error sin el sitio %"),
                  [(a["clave"], a["numero_sitio"], f"{a['volumen_m3']:.2f}",
                    f"{a['razon']:.2f}" if a["razon"] is not None else "—",
                    f"{a['z']:.2f}" if a["z"] is not None else "—",
                    f"{a['error_general_sin_el_sitio_pct']:.2f}" if a["error_general_sin_el_sitio_pct"] is not None else "—")
                   for a in revisar],
                  titulo="Sitios atípicos a revisar", numero_tabla=5)
            documento.add_paragraph(revisar[0]["mensaje"])
        verificar = diagnostico.get("sitios_atipicos_verificar") or []
        if verificar:
            documento.add_paragraph("Sitios con volumen atípico (Verificar, baja prioridad): " +
                                    "; ".join(f"{a['clave']} sitio {a['numero_sitio']}" for a in verificar) + ".")
    documento.add_heading("Anexo 1. Trazabilidad", level=1)
    documento.add_paragraph(analisis["trazabilidad"])
    for regla in analisis["reglas"]:
        documento.add_paragraph(f"{regla['codigo_interpretacion']}: {regla['regla']}", style="List Bullet")
    return documento
