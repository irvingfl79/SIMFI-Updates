import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from modelos import PMFProyecto

FIRMA_EXPORTACION = "SIMFI — Sistema para el Manejo Forestal Mejorado por Dr.PIFL"
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from openpyxl.utils import get_column_letter

base = os.path.join(os.path.dirname(__file__), "data")
ruta = os.path.join(base, "simulacion.json")
pmf = PMFProyecto.cargar(ruta)

wb = Workbook()
ws = wb.active
ws.title = "Cuadro Existencias"
wb.properties.creator = FIRMA_EXPORTACION
ws.oddFooter.center.text = FIRMA_EXPORTACION

bold = Font(bold=True, size=11)
bold_title = Font(bold=True, size=14)
thin = Side(style='thin')
border = Border(left=thin, right=thin, top=thin, bottom=thin)
hdr_fill = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
sub_fill = PatternFill(start_color="E2EFDA", end_color="E2EFDA", fill_type="solid")
total_fill = PatternFill(start_color="FCE4D6", end_color="FCE4D6", fill_type="solid")

ws.merge_cells('A1:K1')
c = ws['A1']
c.value = f"CUADRO DE EXISTENCIAS - {pmf.predio or pmf.nombre}"
c.font = bold_title
c.alignment = Alignment(horizontal='center')

headers = ["UMM", "Superficie", "Especie", "m3 VTA/ha", "m3 VTA/UMM",
           "AB m2/ha", "Int. %", "Resid m3", "Posib AB", "Posib m3/ha", "Posib m3/UMM"]
for col, h in enumerate(headers, 1):
    cell = ws.cell(row=3, column=col, value=h)
    cell.font = bold
    cell.border = border
    cell.alignment = Alignment(horizontal='center', wrap_text=True)
    cell.fill = hdr_fill

row = 4
data = pmf.cuadro_existencias()
g_tot_vol_ha = g_tot_vol_umm = g_tot_ab = 0.0
g_res_vol = g_res_ab = g_pos_ha = g_pos_umm = 0.0

last_rodal = None
sub_vol_ha = sub_vol_umm = sub_ab = 0.0
sub_res_vol = sub_res_ab = sub_pos_ha = sub_pos_umm = 0.0

for f in data["filas"]:
    if f["rodal"] != last_rodal and last_rodal is not None:
        vals_sub = ["", "", "Subtotal", sub_vol_ha, sub_vol_umm, sub_ab, "",
                    sub_res_vol, sub_res_ab, sub_pos_ha, sub_pos_umm]
        for col, val in enumerate(vals_sub, 1):
            cell = ws.cell(row=row, column=col, value=val)
            cell.font = bold
            cell.border = border
            cell.fill = sub_fill
            cell.alignment = Alignment(horizontal='center' if col <= 3 or col == 7 else 'right')
            if isinstance(val, float):
                cell.number_format = '#,##0.000'
        row += 1
        g_tot_vol_ha += sub_vol_ha
        g_tot_vol_umm += sub_vol_umm
        g_tot_ab += sub_ab
        g_res_vol += sub_res_vol
        g_res_ab += sub_res_ab
        g_pos_ha += sub_pos_ha
        g_pos_umm += sub_pos_umm
        sub_vol_ha = sub_vol_umm = sub_ab = 0.0
        sub_res_vol = sub_res_ab = sub_pos_ha = sub_pos_umm = 0.0

    vals = [f["rodal"] if f["rodal"] != last_rodal else "",
            f["superficie"] if f["rodal"] != last_rodal else "",
            f["especie"], f["vol_ha"], f["vol_umm"], f["ab"],
            f["intensidad"], f["res_vol"], f["res_ab"], f["pos_ha"], f["pos_umm"]]
    for col, val in enumerate(vals, 1):
        cell = ws.cell(row=row, column=col, value=val)
        cell.border = border
        cell.alignment = Alignment(horizontal='center' if col <= 2 or col == 7 else 'right')
        if isinstance(val, float):
            cell.number_format = '#,##0.000'
    row += 1
    sub_vol_ha += f["vol_ha"]
    sub_vol_umm += f["vol_umm"]
    sub_ab += f["ab"]
    sub_res_vol += f["res_vol"]
    sub_res_ab += f["res_ab"]
    sub_pos_ha += f["pos_ha"]
    sub_pos_umm += f["pos_umm"]
    last_rodal = f["rodal"]

if data["filas"]:
    vals_sub = ["", "", "Subtotal", sub_vol_ha, sub_vol_umm, sub_ab, "",
                sub_res_vol, sub_res_ab, sub_pos_ha, sub_pos_umm]
    for col, val in enumerate(vals_sub, 1):
        cell = ws.cell(row=row, column=col, value=val)
        cell.font = bold
        cell.border = border
        cell.fill = sub_fill
        cell.alignment = Alignment(horizontal='center' if col <= 3 or col == 7 else 'right')
        if isinstance(val, float):
            cell.number_format = '#,##0.000'
    row += 1
    g_tot_vol_ha += sub_vol_ha
    g_tot_vol_umm += sub_vol_umm
    g_tot_ab += sub_ab
    g_res_vol += sub_res_vol
    g_res_ab += sub_res_ab
    g_pos_ha += sub_pos_ha
    g_pos_umm += sub_pos_umm

vals_tot = ["TOTAL", "", "", g_tot_vol_ha, g_tot_vol_umm, g_tot_ab, "",
            g_res_vol, g_res_ab, g_pos_ha, g_pos_umm]
for col, val in enumerate(vals_tot, 1):
    cell = ws.cell(row=row, column=col, value=val)
    cell.font = bold
    cell.border = border
    cell.fill = total_fill
    cell.alignment = Alignment(horizontal='center' if col <= 3 or col == 7 else 'right')
    if isinstance(val, float):
        cell.number_format = '#,##0.000'

widths = [8, 12, 22, 14, 14, 12, 8, 12, 12, 14, 14]
for i, w in enumerate(widths, 1):
    ws.column_dimensions[get_column_letter(i)].width = w

ruta_xlsx = os.path.join(base, "..", "cuadro_existencias_v2.xlsx")
wb.save(ruta_xlsx)
print(f"Exportado: {ruta_xlsx}")
