"""Diagnóstico y recomendaciones automáticas del error de muestreo (motor 3.0).

Este módulo SOLO recomienda: nunca modifica, excluye ni corrige volúmenes por
su cuenta. Recibe el resultado ya calculado por ``calcular_error_muestreo()``
y produce, de forma puramente informativa:

  6.1 Aporte de cada rodal al error del predio (Prioritario/Relevante/Bajo impacto).
  6.2 Sitios adicionales recomendados por beneficio marginal.
  6.3 Sitios con volumen atípico (para revisión).
  6.4 Resumen en lenguaje llano.

No se guarda ni se genera para registros calculados con un motor anterior a
la versión "3.0"; eso lo decide quien integra este módulo (no esta función).
"""
import math
import statistics

from error_muestreo import valor_t

VERSION_DIAGNOSTICO = "1.0"

LIMITE_ITERACIONES = 500
UMBRAL_PRIORITARIO_ACUM_PCT = 70.0
UMBRAL_RELEVANTE_PCT = 5.0
UMBRAL_APORTE_REVISAR_PCT = 1.0
UMBRAL_ERROR_INDIVIDUAL_ALTO_PCT = 50.0
RAZON_MINIMA = 0.4
RAZON_MAXIMA = 2.0
Z_LIMITE = 3.0
TOLERANCIA_UMBRAL = 1e-9  # evita falsos positivos por redondeo binario justo en el límite


def _es_numero(valor):
    return isinstance(valor, (int, float)) and not isinstance(valor, bool)


def _valores_validos(sitios):
    """Sitios válidos para estadística: numéricos, no booleanos, >= 0."""
    return [s for s in (sitios or [])
            if _es_numero(s.get("volumen_ha_m3")) and s["volumen_ha_m3"] >= 0]


def _se_con_n(varianza, n, poblacion_n):
    """Error estándar recalculado con un tamaño de muestra hipotético n.

    Supone que la varianza (s²) se mantiene; aplica la misma FPC histórica
    que ``error_muestreo._estadistica()``.
    """
    if varianza is None or not n or n <= 0:
        return None
    se = math.sqrt(varianza / n)
    if poblacion_n:
        fpc = math.sqrt(max(0.0, 1 - n / poblacion_n))
        se *= fpc
    return se


def _recalcular_general(rodales_calc, area_total, confianza):
    """Reproduce la fórmula estratificada de ``calcular_error_muestreo()``
    (ponderación por superficie, gl de Welch-Satterthwaite) a partir de una
    lista de dicts con: superficie_ha, media_m3_ha, error_estandar, n.

    Solo lectura/simulación: no altera ningún dato real.
    """
    if not rodales_calc or not area_total:
        return None
    if any(r.get("error_estandar") is None or r.get("n") is None or r.get("n") < 2 for r in rodales_calc):
        return None
    componentes = [(r["superficie_ha"] / area_total) ** 2 * r["error_estandar"] ** 2 for r in rodales_calc]
    varianza = sum(componentes)
    denominador = sum((c ** 2) / (r["n"] - 1) for c, r in zip(componentes, rodales_calc))
    gl = varianza ** 2 / denominador if denominador else None
    if not gl:
        return None
    se = math.sqrt(varianza)
    tcrit = valor_t(confianza, gl)
    if tcrit is None:
        return None
    media = sum(r["superficie_ha"] / area_total * r["media_m3_ha"] for r in rodales_calc)
    if not media:
        return None
    error = tcrit * se
    return error / media * 100


def _aporte_por_rodal(rodales_datos, area_total):
    """6.1: aporte de cada rodal evaluable al error general del predio."""
    evaluables = [r for r in rodales_datos if (r.get("estadistica") or {}).get("estado") == "Evaluable"]
    crudos = []
    for r in evaluables:
        e = r["estadistica"]
        w_h = r["superficie_ha"] / area_total
        se_h = e.get("error_estandar")
        c_h = (w_h ** 2) * (se_h ** 2) if se_h is not None else 0.0
        crudos.append({"id": r.get("id"), "clave": r.get("clave"), "w_h": w_h, "c_h": c_h,
                       "error_relativo_pct": e.get("error_relativo_pct")})
    total_c = sum(item["c_h"] for item in crudos)
    crudos.sort(key=lambda item: item["c_h"], reverse=True)
    aportes = {}
    acumulado = 0.0
    cruzo_70 = False
    salida = []
    for item in crudos:
        pct = (item["c_h"] / total_c * 100) if total_c else 0.0
        if not cruzo_70:
            clasificacion = "Prioritario"
            acumulado += pct
            if acumulado >= UMBRAL_PRIORITARIO_ACUM_PCT:
                cruzo_70 = True
        else:
            acumulado += pct
            clasificacion = "Relevante" if pct >= UMBRAL_RELEVANTE_PCT else "Bajo impacto"
        mensaje = None
        if clasificacion == "Prioritario":
            mensaje = (f"Concentra {pct:.2f} % del error del predio. Es donde un sitio adicional "
                      f"reduce más el error general.")
        elif clasificacion == "Bajo impacto" and _es_numero(item["error_relativo_pct"]) and item["error_relativo_pct"] > UMBRAL_ERROR_INDIVIDUAL_ALTO_PCT:
            mensaje = (f"Error individual alto ({item['error_relativo_pct']:.2f} %), pero su aporte al "
                      f"predio es de {pct:.2f} %. No requiere sitios adicionales para el cumplimiento general.")
        registro = {"id": item["id"], "clave": item["clave"], "aporte_pct": pct,
                   "aporte_acumulado_pct": acumulado, "clasificacion": clasificacion, "mensaje": mensaje}
        aportes[item["clave"]] = registro
        salida.append(registro)
    return salida, aportes


def _beneficio_marginal(w_h, varianza_h, n_h, poblacion_n_h):
    if poblacion_n_h is not None and n_h >= poblacion_n_h:
        return 0.0
    if not varianza_h or n_h <= 0:
        return 0.0
    return (w_h ** 2) * varianza_h * (1.0 / n_h - 1.0 / (n_h + 1))


def _estado_base_para_simulacion(rodales_datos, area_total):
    estado = []
    for r in rodales_datos:
        e = r.get("estadistica") or {}
        if e.get("estado") != "Evaluable":
            continue
        estado.append({"id": r.get("id"), "clave": r.get("clave"), "superficie_ha": r["superficie_ha"],
                       "media_m3_ha": e.get("media_m3_ha"), "varianza": e.get("varianza"),
                       "n": e.get("n"), "poblacion_n": e.get("poblacion_N")})
    return estado


def _asignacion_incremental(rodales_datos, area_total, confianza, objetivo_pct,
                            limite_iteraciones=LIMITE_ITERACIONES):
    """6.2 (rama 'no cumple'): agrega sitios uno a uno al rodal de mayor
    beneficio marginal hasta que E% <= objetivo, o hasta el límite de
    seguridad / agotar la población de todos los rodales (censo).

    Devuelve (adicionales_por_rodal: {clave: n}, error_final_pct, alcanzable, iteraciones).
    """
    estado = _estado_base_para_simulacion(rodales_datos, area_total)
    adicionales = {r["clave"]: 0 for r in estado}

    def _error_actual():
        calc = [{"superficie_ha": r["superficie_ha"], "media_m3_ha": r["media_m3_ha"],
                 "error_estandar": _se_con_n(r["varianza"], r["n"], r["poblacion_n"]), "n": r["n"]}
                for r in estado]
        return _recalcular_general(calc, area_total, confianza)

    error_actual = _error_actual()
    if error_actual is None or objetivo_pct is None:
        return adicionales, error_actual, False, 0
    iteraciones = 0
    while error_actual > objetivo_pct and iteraciones < limite_iteraciones:
        mejor, mejor_beneficio = None, -1.0
        for r in estado:
            if r["poblacion_n"] is not None and r["n"] >= r["poblacion_n"]:
                continue
            beneficio = _beneficio_marginal(r["superficie_ha"] / area_total, r["varianza"], r["n"], r["poblacion_n"])
            if beneficio > mejor_beneficio:
                mejor_beneficio, mejor = beneficio, r
        if mejor is None:
            break
        mejor["n"] += 1
        adicionales[mejor["clave"]] += 1
        iteraciones += 1
        error_actual = _error_actual()
    alcanzable = error_actual is not None and error_actual <= objetivo_pct
    return adicionales, error_actual, alcanzable, iteraciones


def _referencia_top3_beneficio(rodales_datos, area_total, confianza):
    """6.2 (rama 'sí cumple'): los tres rodales con mayor beneficio marginal
    y el error general esperado si se agregara un sitio en cada uno, por
    separado (no acumulado)."""
    estado = _estado_base_para_simulacion(rodales_datos, area_total)
    candidatos = []
    for r in estado:
        beneficio = _beneficio_marginal(r["superficie_ha"] / area_total, r["varianza"], r["n"], r["poblacion_n"])
        candidatos.append({"clave": r["clave"], "beneficio": beneficio, "ref": r})
    candidatos.sort(key=lambda c: c["beneficio"], reverse=True)
    top = candidatos[:3]
    referencias = []
    for cand in top:
        calc = []
        for r in estado:
            n = r["n"] + 1 if r["clave"] == cand["clave"] else r["n"]
            calc.append({"superficie_ha": r["superficie_ha"], "media_m3_ha": r["media_m3_ha"],
                        "error_estandar": _se_con_n(r["varianza"], n, r["poblacion_n"]), "n": n})
        error_con_1_sitio = _recalcular_general(calc, area_total, confianza)
        referencias.append({"clave": cand["clave"], "beneficio_marginal": cand["beneficio"],
                            "error_esperado_pct": error_con_1_sitio})
    return referencias


def _sitios_adicionales(resultado, rodales_datos, area_total, confianza):
    """6.2 completo: decide entre asignación incremental o referencia top-3."""
    general = resultado.get("resultado_general") or {}
    objetivo = (resultado.get("configuracion") or {}).get("error_objetivo_pct")
    no_evaluables = [r.get("clave") for r in rodales_datos
                     if (r.get("estadistica") or {}).get("n") is not None and (r.get("estadistica") or {}).get("n") < 2]
    if no_evaluables:
        return {"estado": "No evaluable",
               "mensaje": ("No evaluable. Levante al menos 2 sitios (se recomiendan 3) para estimar la "
                          "varianza en: " + ", ".join(no_evaluables) + "."),
               "rodales_insuficientes": no_evaluables}
    if general.get("estado") == "Cumple":
        referencias = _referencia_top3_beneficio(rodales_datos, area_total, confianza)
        return {"estado": "No se requieren sitios adicionales",
               "mensaje": "No se requieren sitios adicionales.",
               "referencia_top3": referencias}
    if general.get("estado") == "No cumple" and _es_numero(objetivo):
        adicionales, error_final, alcanzable, iteraciones = _asignacion_incremental(
            rodales_datos, area_total, confianza, objetivo)
        distribucion = [{"clave": clave, "sitios_adicionales": n} for clave, n in adicionales.items() if n > 0]
        distribucion.sort(key=lambda x: x["sitios_adicionales"], reverse=True)
        if alcanzable:
            return {"estado": "Asignación incremental", "mensaje":
                   (f"Se requieren {sum(x['sitios_adicionales'] for x in distribucion)} sitios adicionales "
                    f"para alcanzar el objetivo de {objetivo:.2f} %: error esperado {error_final:.2f} %."),
                   "sitios_adicionales_totales": sum(x["sitios_adicionales"] for x in distribucion),
                   "distribucion_por_rodal": distribucion, "error_esperado_pct": error_final}
        return {"estado": "Objetivo no alcanzable con muestreo",
               "mensaje": ("El objetivo no es alcanzable únicamente con muestreo dentro del límite de "
                          "seguridad; se sugiere considerar un censo."),
               "sitios_adicionales_totales": sum(x["sitios_adicionales"] for x in distribucion),
               "distribucion_por_rodal": distribucion, "error_esperado_pct": error_final}
    return {"estado": "No calculable", "mensaje": "No hay objetivo de error definido para calcular sitios adicionales."}


def _sitios_atipicos(rodales_datos, aportes_por_rodal, area_total, confianza):
    """6.3: sitios con volumen atípico dentro de su propio rodal (n >= 3)."""
    hallazgos = []
    for r in rodales_datos:
        e = r.get("estadistica") or {}
        if e.get("estado") != "Evaluable" or (e.get("n") or 0) < 3:
            continue
        validos = _valores_validos(r.get("sitios"))
        if len(validos) < 3:
            continue
        aporte_info = aportes_por_rodal.get(r.get("clave"))
        aporte_pct = aporte_info["aporte_pct"] if aporte_info else 0.0
        for sitio in validos:
            # razón/z se calculan sobre m3/ha (comparable entre sitios aunque
            # el área varíe); el volumen reportado al usuario es el medido en
            # campo dentro del sitio (m3), para cotejarlo contra el formato.
            x_i = sitio["volumen_ha_m3"]
            volumen_reportado = sitio.get("volumen_sitio_m3")
            otros = [s["volumen_ha_m3"] for s in validos if s.get("id") != sitio.get("id")]
            razon = None
            if otros:
                mediana_otros = statistics.median(otros)
                if mediana_otros > 0:
                    razon = x_i / mediana_otros
            z = None
            if len(otros) >= 3:
                media_otros = sum(otros) / len(otros)
                try:
                    s_otros = statistics.stdev(otros)
                except statistics.StatisticsError:
                    s_otros = 0.0
                if s_otros > 0:
                    z = (x_i - media_otros) / s_otros
            atipico = ((razon is not None and (razon < RAZON_MINIMA - TOLERANCIA_UMBRAL
                                              or razon > RAZON_MAXIMA + TOLERANCIA_UMBRAL))
                      or (z is not None and abs(z) > Z_LIMITE + TOLERANCIA_UMBRAL))
            if not atipico:
                continue
            error_sin_sitio = _recalcular_excluyendo_sitio(rodales_datos, area_total, confianza,
                                                           r.get("id"), sitio.get("id"))
            nivel = "Revisar" if aporte_pct >= UMBRAL_APORTE_REVISAR_PCT else "Verificar (baja prioridad)"
            hallazgos.append({"rodal_id": r.get("id"), "clave": r.get("clave"), "numero_sitio": sitio.get("numero"),
                              "volumen_m3": volumen_reportado, "volumen_ha_m3": x_i,
                              "mediana_otros_ha_m3": statistics.median(otros) if otros else None,
                              "razon": razon, "z": z, "nivel": nivel, "aporte_pct_rodal": aporte_pct,
                              "error_general_sin_el_sitio_pct": error_sin_sitio,
                              "mensaje": ("Confirme este volumen contra el formato de campo. Si es correcto "
                                         "(claro, manchón denso, etc.), consérvelo.")})
    general_pct = None

    def _cambio(item):
        return abs(item["error_general_sin_el_sitio_pct"]) if item["error_general_sin_el_sitio_pct"] is not None else -1
    return hallazgos


def _recalcular_excluyendo_sitio(rodales_datos, area_total, confianza, rodal_id, sitio_id):
    """Error general del predio si un sitio se excluyera (solo informativo;
    no modifica la matriz real)."""
    calc = []
    for r in rodales_datos:
        e = r.get("estadistica") or {}
        if e.get("estado") != "Evaluable":
            return None
        if r.get("id") == rodal_id:
            valores = [s["volumen_ha_m3"] for s in _valores_validos(r.get("sitios")) if s.get("id") != sitio_id]
            n = len(valores)
            if n < 2:
                return None
            media = sum(valores) / n
            varianza = sum((v - media) ** 2 for v in valores) / (n - 1)
            se = _se_con_n(varianza, n, e.get("poblacion_N"))
            calc.append({"superficie_ha": r["superficie_ha"], "media_m3_ha": media, "error_estandar": se, "n": n})
        else:
            calc.append({"superficie_ha": r["superficie_ha"], "media_m3_ha": e.get("media_m3_ha"),
                        "error_estandar": e.get("error_estandar"), "n": e.get("n")})
    return _recalcular_general(calc, area_total, confianza)


def _ordenar_atipicos(hallazgos):
    def _cambio(item):
        v = item.get("error_general_sin_el_sitio_pct")
        base = item.get("_error_base_pct")
        if v is None or base is None:
            return -1.0
        return abs(base - v)
    return sorted(hallazgos, key=_cambio, reverse=True)


def _resumen_lenguaje_llano(resultado, aporte_general, sitios_adicionales, atipicos):
    general = resultado.get("resultado_general") or {}
    error_general = general.get("error_relativo_pct")
    frases = []
    if general.get("estado") == "Cumple" and _es_numero(error_general):
        frases.append(f"El predio cumple con un error de muestreo de {error_general:.2f} %.")
    elif general.get("estado") == "No cumple" and _es_numero(error_general):
        frases.append(f"El predio no cumple; el error de muestreo actual es de {error_general:.2f} %.")
    else:
        frases.append("El resultado general del predio no es evaluable con la información disponible.")
    frases.append(sitios_adicionales.get("mensaje", ""))
    prioritarios = [a["clave"] for a in aporte_general if a["clasificacion"] == "Prioritario"]
    if prioritarios:
        acumulado = aporte_general[len(prioritarios) - 1]["aporte_acumulado_pct"]
        frases.append(f"Los rodales {', '.join(prioritarios)} concentran el {acumulado:.0f} % del error; "
                      f"si se necesita mayor precisión, los sitios nuevos deben levantarse ahí.")
    if atipicos:
        primero = atipicos[0]
        frases.append(f"Se recomienda revisar {len(atipicos)} volúmenes atípicos, en particular el sitio "
                      f"{primero['numero_sitio']} del {primero['clave']} ({primero['volumen_m3']:.2f} m³).")
    return " ".join(f for f in frases if f)


def diagnosticar_muestreo(resultado, rodales_datos=None):
    """Punto de entrada. Recibe el resultado de ``calcular_error_muestreo()``
    y devuelve el bloque ``diagnostico`` con las 4 partes (6.1 a 6.4).

    Es una función pura y de solo lectura: no modifica ``resultado`` ni los
    datos de origen. Quien la invoque decide si guarda o no el resultado.
    """
    resultado = resultado or {}
    rodales_datos = rodales_datos if rodales_datos is not None else (resultado.get("rodales") or [])
    validacion = resultado.get("validacion") or {}
    area_total = validacion.get("superficie_predio_ha")
    confianza = (resultado.get("configuracion") or {}).get("nivel_confianza")
    if not area_total or not confianza:
        return {"version_diagnostico": VERSION_DIAGNOSTICO, "disponible": False,
               "mensaje": "No es posible calcular el diagnóstico sin superficie del predio o nivel de confianza."}
    aporte_lista, aporte_por_clave = _aporte_por_rodal(rodales_datos, area_total)
    sitios_adicionales = _sitios_adicionales(resultado, rodales_datos, area_total, confianza)
    error_base = (resultado.get("resultado_general") or {}).get("error_relativo_pct")
    atipicos = _sitios_atipicos(rodales_datos, aporte_por_clave, area_total, confianza)
    for item in atipicos:
        item["_error_base_pct"] = error_base
    atipicos = _ordenar_atipicos(atipicos)
    for item in atipicos:
        item.pop("_error_base_pct", None)
    revisar = [a for a in atipicos if a["nivel"] == "Revisar"]
    verificar = [a for a in atipicos if a["nivel"] != "Revisar"]
    resumen = _resumen_lenguaje_llano(resultado, aporte_lista, sitios_adicionales, atipicos)
    return {"version_diagnostico": VERSION_DIAGNOSTICO, "disponible": True,
           "aporte_por_rodal": aporte_lista,
           "sitios_adicionales": sitios_adicionales,
           "sitios_atipicos": atipicos, "sitios_atipicos_revisar": revisar,
           "sitios_atipicos_verificar": verificar,
           "resumen": resumen}
