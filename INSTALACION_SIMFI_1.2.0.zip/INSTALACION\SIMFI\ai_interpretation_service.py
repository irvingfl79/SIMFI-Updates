"""Selecciona el proveedor de interpretacion sin exponerlo a los modulos forestales."""

import time

from ia_config import api_key_en_linea, cargar_config, registrar_ia
from ia_ollama import LocalOllamaProvider
from ia_online import OnlineAIProvider

# Disponibilidad cacheada por poco tiempo: cada sondeo hace llamadas de red
# (hasta ~5 s si Ollama no responde) y no debe repetirse en cada mensaje ni en
# cada pagina que muestra el estado de los servicios.
_ESTADO_CACHE = {}
_ESTADO_TTL_SEGUNDOS = 60.0


def _huella_proveedor(nombre, config):
    if nombre == "ollama_local":
        local = config.get("local", config)
        return ("local", str(local.get("servidor", "")))
    online = config.get("en_linea", {})
    return ("online", str(online.get("proveedor", "")),
            str(online.get("servidor", "")), str(online.get("modelo", "")),
            bool(online.get("habilitada", False)),
            bool(api_key_en_linea(config)))


def limpiar_cache_estado():
    """Libera la disponibilidad cacheada. Util para pruebas."""
    _ESTADO_CACHE.clear()


class AIInterpretationService:
    def __init__(self, local=None, online=None):
        self.local = local or LocalOllamaProvider()
        self.online = online or OnlineAIProvider()

    def _estado_cacheado(self, proveedor, config, ttl_segundos):
        # La clave es (nombre del proveedor, huella de su configuracion): los
        # proveedores reales tienen nombres distintos y son apatridas respecto
        # a la configuracion, asi que compartir la caché entre servicios es
        # correcto y los cambios de configuracion generan otra entrada.
        nombre = getattr(proveedor, "nombre", type(proveedor).__name__)
        clave = (nombre, _huella_proveedor(nombre, config))
        ahora = time.monotonic()
        registrado = _ESTADO_CACHE.get(clave)
        if registrado and ahora - registrado[0] < ttl_segundos:
            return registrado[1]
        resultado = proveedor.estado(config)
        _ESTADO_CACHE[clave] = (ahora, resultado)
        return resultado

    def estado(self, config=None, ttl_segundos=_ESTADO_TTL_SEGUNDOS):
        config = config or cargar_config()
        return {"modo": config.get("modo", "automatico"),
                "local": self._estado_cacheado(self.local, config, ttl_segundos),
                "en_linea": self._estado_cacheado(self.online, config, ttl_segundos)}

    def interpret(self, data, module, context, config=None):
        """Interpreta datos ya calculados; nunca recalcula ni altera su contenido."""
        config = config or cargar_config()
        if not config.get("habilitada", True):
            return {"ok": False, "texto": None, "motor": "ninguno", "modelo": "",
                    "mensaje": "La integracion de IA esta deshabilitada."}
        modo = config.get("modo", "automatico")
        if modo == "local":
            return self.local.interpretar(data, module, context, config)
        if modo == "en_linea":
            return self.online.interpretar(data, module, context, config)

        estado_online = self._estado_cacheado(self.online, config, _ESTADO_TTL_SEGUNDOS)
        if estado_online["disponible"]:
            resultado = self.online.interpretar(data, module, context, config)
            if resultado["ok"]:
                return resultado
            registrar_ia("warning", "online fallo en modo automatico; se intenta Ollama. modulo=%s", module)
        estado_local = self._estado_cacheado(self.local, config, _ESTADO_TTL_SEGUNDOS)
        if estado_local["disponible"]:
            return self.local.interpretar(data, module, context, config)
        return {"ok": False, "texto": None, "motor": "ninguno", "modelo": "",
                "mensaje": "No hay un motor de IA disponible. " + estado_local["mensaje"]}
