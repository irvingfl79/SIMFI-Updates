import io
import unittest

from openpyxl import Workbook

from app import _parsear_rodales_pegados, app
from modelos import (ClaseDiametrica, IntervencionCorta, PMFProyecto, Rodal,
                     TablaInventarioRodal)


ENCABEZADOS = "ID\tSuperficie (ha)\tSitios\tÁrea/sitio (m²)"


class ParsearRodalesTest(unittest.TestCase):
    def test_renombra_rodal_y_todas_sus_referencias(self):
        pmf = PMFProyecto("Prueba")
        pmf.agregar_rodal(Rodal("R1", 10))
        pmf.agregar_rodal(Rodal("R2", 8))
        pmf.agregar_tabla_inventario(TablaInventarioRodal("R1", "Pinus patula"))
        pmf.plan_cortas.intervenciones.append(IntervencionCorta(
            "I-1", 1, "R1", 10, "Aclareo"))
        pmf.intensidad_corta["R1"] = {"Pinus patula": 20}
        pmf.rodales_aclareo = ["R1"]
        pmf.escenarios_aclareo["R1||Pinus patula"] = {
            "actual": {"rodal": "R1", "especie": "Pinus patula"}}

        self.assertTrue(pmf.renombrar_rodal("R1", "Rodal Norte"))
        self.assertIsNone(pmf.buscar_rodal("R1"))
        self.assertIsNotNone(pmf.buscar_rodal("Rodal Norte"))
        self.assertEqual(pmf.tablas_inventario[0].rodal_id, "Rodal Norte")
        self.assertEqual(pmf.plan_cortas.intervenciones[0].rodal_id, "Rodal Norte")
        self.assertIn("Rodal Norte", pmf.intensidad_corta)
        self.assertEqual(pmf.rodales_aclareo, ["Rodal Norte"])
        self.assertIn("Rodal Norte||Pinus patula", pmf.escenarios_aclareo)
        self.assertEqual(
            pmf.escenarios_aclareo["Rodal Norte||Pinus patula"]["actual"]["rodal"],
            "Rodal Norte")
        with self.assertRaises(ValueError):
            pmf.renombrar_rodal("Rodal Norte", "R2")

    def test_rodal_oculto_conserva_datos_y_se_excluye_de_calculos(self):
        pmf = PMFProyecto("Prueba")
        pmf.agregar_rodal(Rodal("ACTIVO", 10, sitios=1, area_sitio_m2=1000))
        pmf.agregar_rodal(Rodal("OCULTO", 20, sitios=1, area_sitio_m2=1000, oculto=True))
        for rid in ("ACTIVO", "OCULTO"):
            pmf.agregar_tabla_inventario(TablaInventarioRodal(
                rid, "Pinus patula", [ClaseDiametrica(20, 15, 10)]))

        self.assertEqual(pmf.num_rodales, 1)
        self.assertAlmostEqual(pmf.superficie_total_ha, 10)
        self.assertEqual([rodal.id for rodal in pmf.rodales_visibles], ["ACTIVO"])
        self.assertIsNotNone(pmf.buscar_tabla_inventario("OCULTO", "Pinus patula"))
        self.assertIsNone(pmf._calc_valores_rodal_especie("OCULTO", "Pinus patula"))
        self.assertEqual({fila["rodal"] for fila in pmf.cuadro_existencias()["filas"]}, {"ACTIVO"})
        self.assertEqual({fila["rodal"] for fila in pmf.resumen_incrementos()["filas"]}, {"ACTIVO"})
        self.assertEqual({fila["rodal"] for fila in pmf.reporte_carbono()["filas"]}, {"ACTIVO"})

    def test_parsea_columnas_requeridas_opcionales_y_decimales(self):
        pmf = PMFProyecto("Prueba")
        texto = ENCABEZADOS + "\nR1\t12,5\t4\t1000\nR2\t8.75\t\t"
        rodales = _parsear_rodales_pegados(texto, pmf)
        self.assertEqual(len(rodales), 2)
        self.assertAlmostEqual(rodales[0]["superficie_ha"], 12.5)
        self.assertEqual(rodales[0]["sitios"], 4)
        self.assertEqual(rodales[1]["sitios"], 1)
        self.assertEqual(rodales[1]["area_sitio_m2"], 500)

    def test_identifica_existentes_sin_sobrescribir(self):
        pmf = PMFProyecto("Prueba")
        pmf.agregar_rodal(Rodal("R1", 5))
        rodales = _parsear_rodales_pegados(
            "ID\tSuperficie\nR1\t99\nR2\t8", pmf)
        self.assertTrue(rodales[0]["existente"])
        self.assertFalse(rodales[1]["existente"])

    def test_agrega_rodal_en_la_ubicacion_elegida(self):
        pmf = PMFProyecto("Prueba")
        pmf.agregar_rodal(Rodal("2025", 5))
        pmf.agregar_rodal(Rodal("2026", 5))
        pmf.agregar_rodal(Rodal("2027", 5))

        pmf.agregar_rodal(Rodal("2026-b", 5), despues_de="2026")
        for rodal_id in ("2025", "2026", "2026-b", "2027"):
            pmf.agregar_tabla_inventario(TablaInventarioRodal(
                rodal_id, "Pinus patula", [ClaseDiametrica(20, 15, 10)]))

        self.assertEqual([rodal.id for rodal in pmf.rodales], ["2025", "2026", "2026-b", "2027"])
        self.assertEqual(
            [fila["rodal"] for fila in pmf.cuadro_existencias()["filas"] if not fila.get("_type")],
            ["2025", "2026", "2026-b", "2027"])

    def test_rechaza_duplicados_y_filas_invalidas(self):
        pmf = PMFProyecto("Prueba")
        casos = [
            "ID\tSuperficie\nR1\t10\nr1\t11",
            "ID\tSuperficie\nR1\t0",
            "ID\tSuperficie\nR1\ttexto",
            "ID\tSuperficie\tTipo\nR1\t10\tPino",
            "ID\tSuperficie\tFactor corrección\nR1\t10\t18",
            "ID\tSuperficie\tDesconocida\nR1\t10\tX",
        ]
        for texto in casos:
            with self.subTest(texto=texto), self.assertRaises(ValueError):
                _parsear_rodales_pegados(texto, pmf)


class ImportarRodalesRutaTest(unittest.TestCase):
    def setUp(self):
        self.cliente = app.test_client()
        pmf = PMFProyecto("Prueba")
        pmf.agregar_rodal(Rodal("EXISTENTE", 5))
        with self.cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()

    def _pmf_guardado(self):
        with self.cliente.session_transaction() as sesion:
            requiere_migracion = "pmf_data" in sesion
        if requiere_migracion:
            self.cliente.get("/")
        with self.cliente.session_transaction() as sesion:
            self.assertNotIn("pmf_data", sesion)
            ruta = sesion["ruta_actual"]
        return PMFProyecto.cargar(ruta)

    def test_vista_rodales_incluye_boton_y_modal(self):
        pagina = self.cliente.get("/rodales")
        html = pagina.get_data(as_text=True)
        self.assertEqual(pagina.status_code, 200)
        self.assertIn("Importar datos", html)
        self.assertIn("Factor de corrección para todos los rodales", html)
        self.assertIn("Ubicación", html)
        self.assertIn("Archivo Excel", html)
        self.assertIn("Pegar datos", html)
        self.assertIn('id="sitios-lote"', html)
        self.assertIn('id="area-sitio-lote"', html)
        self.assertNotIn("<th>Factor</th>", html)
        self.assertIn("Nombre / ID del rodal", html)

    def test_editar_permite_renombrar_rodal(self):
        respuesta = self.cliente.post("/rodales/editar/EXISTENTE", data={
            "id": "Rodal Renombrado", "superficie_ha": "7.5",
            "sitios": "3", "area_sitio_m2": "400",
        })
        self.assertEqual(respuesta.status_code, 302)
        pmf = self._pmf_guardado()
        self.assertIsNone(pmf.buscar_rodal("EXISTENTE"))
        renombrado = pmf.buscar_rodal("Rodal Renombrado")
        self.assertIsNotNone(renombrado)
        self.assertAlmostEqual(renombrado.superficie_ha, 7.5)
        self.assertEqual(renombrado.sitios, 3)

    def test_agregar_rodal_guarda_la_ubicacion_elegida(self):
        pmf = self._pmf_guardado()
        pmf.agregar_rodal(Rodal("POSTERIOR", 5))
        self.assertTrue(pmf.guardar())

        respuesta = self.cliente.post("/rodales/agregar", data={
            "id": "INTERMEDIO", "superficie_ha": "7", "sitios": "1",
            "area_sitio_m2": "500", "despues_de": "EXISTENTE",
        })

        self.assertEqual(respuesta.status_code, 302)
        guardado = self._pmf_guardado()
        self.assertEqual([rodal.id for rodal in guardado.rodales], [
            "EXISTENTE", "INTERMEDIO", "POSTERIOR"])

    def test_ocultar_y_restaurar_rodal_sin_eliminarlo(self):
        respuesta = self.cliente.post("/rodales/ocultar/EXISTENTE")
        self.assertEqual(respuesta.status_code, 302)
        pmf = self._pmf_guardado()
        self.assertTrue(pmf.buscar_rodal("EXISTENTE").oculto)
        self.assertEqual(pmf.num_rodales, 0)

        respuesta = self.cliente.post("/rodales/ocultar/EXISTENTE")
        self.assertEqual(respuesta.status_code, 302)
        pmf = self._pmf_guardado()
        self.assertFalse(pmf.buscar_rodal("EXISTENTE").oculto)
        self.assertEqual(pmf.num_rodales, 1)

    def test_previsualiza_y_confirma_datos_pegados(self):
        texto = "ID\tSuperficie (ha)\tSitios\nEXISTENTE\t99\t3\nNUEVO 1\t12.5\t4"
        previa = self.cliente.post("/rodales/importar", data={
            "modo": "pegado", "confirmar": "false", "texto": texto})
        datos = previa.get_json()
        self.assertEqual(previa.status_code, 200)
        self.assertEqual(datos["total"], 2)
        self.assertEqual(datos["nuevos"], 1)
        self.assertEqual(datos["existentes"], 1)

        respuesta = self.cliente.post("/rodales/importar", data={
            "modo": "pegado", "confirmar": "true", "texto": texto})
        self.assertEqual(respuesta.status_code, 200)
        self.assertEqual(respuesta.get_json()["importados"], 1)
        pmf = self._pmf_guardado()
        self.assertAlmostEqual(pmf.buscar_rodal("EXISTENTE").superficie_ha, 5)
        nuevo = pmf.buscar_rodal("NUEVO 1")
        self.assertIsNotNone(nuevo)
        self.assertEqual(nuevo.sitios, 4)
        self.assertEqual(nuevo.calidad_sitio, "Media")

    def test_importa_archivo_excel(self):
        libro = Workbook()
        hoja = libro.active
        hoja.append(["UMM", "Superficie ha", "Número de sitios", "Área por sitio m2"])
        hoja.append(["EXCEL-1", 15.75, 6, 400])
        salida = io.BytesIO()
        libro.save(salida)
        salida.seek(0)
        respuesta = self.cliente.post(
            "/rodales/importar",
            data={"modo": "excel", "confirmar": "true",
                  "archivo": (salida, "rodales.xlsx")},
            content_type="multipart/form-data",
        )
        self.assertEqual(respuesta.status_code, 200)
        self.assertEqual(respuesta.get_json()["importados"], 1)
        rodal = self._pmf_guardado().buscar_rodal("EXCEL-1")
        self.assertAlmostEqual(rodal.superficie_ha, 15.75)
        self.assertEqual(rodal.area_sitio_m2, 400)

    def test_error_no_realiza_importacion_parcial(self):
        texto = "ID\tSuperficie\nVALIDO\t10\nINVALIDO\t-2"
        respuesta = self.cliente.post("/rodales/importar", data={
            "modo": "pegado", "confirmar": "true", "texto": texto})
        self.assertEqual(respuesta.status_code, 400)
        pmf = self._pmf_guardado()
        self.assertIsNone(pmf.buscar_rodal("VALIDO"))
        self.assertEqual(len(pmf.rodales), 1)

    def test_factor_general_se_guarda_y_limpia_factores_anteriores(self):
        pmf = self._pmf_guardado()
        pmf.rodales[0].factor_correccion = 99
        self.assertTrue(pmf.guardar())
        respuesta = self.cliente.post("/rodales/factor-correccion", data={
            "usar_factor_ajuste": "on", "factor_ajuste": "18.5"})
        self.assertEqual(respuesta.status_code, 302)
        guardado = self._pmf_guardado()
        self.assertTrue(guardado.usar_factor_ajuste)
        self.assertAlmostEqual(guardado.factor_ajuste, 18.5)
        self.assertIsNone(guardado.rodales[0].factor_correccion)

    def test_existencias_usan_factor_general_y_no_factor_antiguo_del_rodal(self):
        pmf = PMFProyecto("Factores")
        rodal = Rodal("R1", 10, sitios=1, area_sitio_m2=1000, factor_correccion=99)
        pmf.agregar_rodal(rodal)
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Pinus patula", [ClaseDiametrica(20, 15, 10)]))
        pmf.usar_factor_ajuste = True
        pmf.factor_ajuste = 18
        con_general = pmf._calc_valores_rodal_especie("R1", "Pinus patula")
        self.assertAlmostEqual(con_general["Arb/ha"], 180)
        pmf.usar_factor_ajuste = False
        sin_general = pmf._calc_valores_rodal_especie("R1", "Pinus patula")
        self.assertAlmostEqual(sin_general["Arb/ha"], 100)

    def test_ajustes_ya_no_muestra_captura_del_factor(self):
        pagina = self.cliente.get("/ajustes")
        html = pagina.get_data(as_text=True)
        self.assertNotIn('name="factor_ajuste"', html)
        self.assertIn("ahora se configura en", html)


class ImportarInventarioPegadoTest(unittest.TestCase):
    def test_vista_previa_compara_arboles_pegados_con_simfi(self):
        cliente = app.test_client()
        pmf = PMFProyecto("Inventario")
        pmf.agregar_rodal(Rodal("R1", 10))
        pmf.agregar_especie("Pinus patula")
        pmf.agregar_tabla_inventario(TablaInventarioRodal(
            "R1", "Pinus patula", [ClaseDiametrica(10, 6, 7), ClaseDiametrica(15, 8, 3)]))
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()

        respuesta = cliente.post("/inventario/rodal/importar_pegado/R1", json={
            "texto": "CD\tPinus patula (ARB)\tPinus patula (ALT)\n10\t4\t6\n15\t8\t8",
            "sitios": 3, "area_sitio_m2": 400,
            "confirmar": False,
        })

        self.assertEqual(respuesta.status_code, 200)
        especie = respuesta.get_json()["especies"][0]
        self.assertEqual(especie["arboles_pegados"], 12)
        self.assertEqual(especie["arboles_simfi"], 10)
        self.assertTrue(especie["reemplaza"])

    def test_confirma_inventario_pegado_y_actualiza_sitios_del_rodal(self):
        cliente = app.test_client()
        pmf = PMFProyecto("Inventario")
        pmf.agregar_rodal(Rodal("R1", 10, sitios=1, area_sitio_m2=500))
        pmf.agregar_especie("Pinus patula")
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()

        respuesta = cliente.post("/inventario/rodal/importar_pegado/R1", json={
            "texto": "CD\tPinus patula (ARB)\tPinus patula (ALT)\n10\t4\t6",
            "sitios": 4, "area_sitio_m2": 400, "confirmar": True,
        })

        self.assertEqual(respuesta.status_code, 200)
        with cliente.session_transaction() as sesion:
            ruta = sesion["ruta_actual"]
        guardado = PMFProyecto.cargar(ruta)
        rodal = guardado.buscar_rodal("R1")
        self.assertEqual(rodal.sitios, 4)
        self.assertAlmostEqual(rodal.area_sitio_m2, 400)

    def test_importacion_pegada_requiere_sitios_y_area_por_sitio(self):
        cliente = app.test_client()
        pmf = PMFProyecto("Inventario")
        pmf.agregar_rodal(Rodal("R1", 10, sitios=1, area_sitio_m2=500))
        with cliente.session_transaction() as sesion:
            sesion["usuario"] = "prueba"
            sesion["pmf_data"] = pmf.serializar()

        respuesta = cliente.post("/inventario/rodal/importar_pegado/R1", json={
            "texto": "CD\tPinus patula (ARB)\tPinus patula (ALT)\n10\t4\t6",
            "confirmar": False,
        })

        self.assertEqual(respuesta.status_code, 400)
        self.assertIn("sitios", respuesta.get_json()["error"])


if __name__ == "__main__":
    unittest.main()
