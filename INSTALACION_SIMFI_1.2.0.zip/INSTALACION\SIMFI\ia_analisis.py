"""Capa de analisis determinista calculada por SIMFI para la interpretacion con IA.

SIMFI CALCULA, LA IA INTERPRETA. Este modulo genera hallazgos estructurales
(solo hechos: valores, porcentajes, comparaciones y agrupaciones) a partir de
resultados ya calculados y validados por SIMFI. No emite conclusiones, juicios
ni recomendaciones: la IA elabora el significado tecnico a partir de estos
hechos. Los umbrales numericos son criterios de clasificacion determinista
documentados y reutilizables.

Las funciones reciben las filas del cuadro de existencias y del resumen por
especie tal como las producen los calculos de SIMFI, de modo que el resultado
sea reproducible y no dependa del proveedor de IA.
"""

_UMBRAL_DOMINANCIA_PCT = 50.0
_UMBRAL_ACUMULADO_PRINCIPALES_PCT = 80.0
_UMBRAL_PARTICIPACION_REDUCIDA_PCT = 5.0


def _redondear(valor, decimales=2):
    try:
        return round(float(valor), decimales)
    except (TypeError, ValueError):
        return None


def distribucion_porcentual(pares):
    """Ordena pares (clave, valor) por valor descendente con porcentaje y acumulado.

    Devuelve {"total": ..., "distribucion": [{"clave", "valor",
    "porcentaje_pct", "acumulado_pct"}, ...]}. Las claves con valor no positivo
    se conservan en la lista con porcentaje cero para no perder informacion.
    """
    items = []
    for clave, valor in pares:
        try:
            valor_num = float(valor or 0)
        except (TypeError, ValueError):
            continue
        items.append({"clave": clave, "valor": _redondear(valor_num)})
    total = sum(float(item["valor"]) for item in items)
    for item in items:
        item["porcentaje_pct"] = _redondear(100.0 * item["valor"] / total if total else 0.0)
    items.sort(key=lambda item: item["valor"], reverse=True)
    acumulado = 0.0
    for item in items:
        acumulado += item["porcentaje_pct"]
        item["acumulado_pct"] = _redondear(acumulado)
    return {"total": _redondear(total), "distribucion": items}


def composicion_existencias(por_especie):
    """Hallazgos de composicion y distribucion de existencias por especie.

    Clasifica la participacion de cada especie respecto al volumen total:
    especie principal (la de mayor volumen), especie dominante (la que supera
    un 50 por ciento del volumen), especies principales (las que en conjunto
    alcanzan un 80 por ciento acumulado), especies secundarias y especies de
    participacion reducida. Incluye la concentracion acumulada de las primeras
    cinco especies para describir la representatividad de la masa.
    """
    pares = [(fila.get("especie"), fila.get("existencias"))
             for fila in por_especie]
    resumen = distribucion_porcentual(pares)
    distribucion = resumen["distribucion"]

    principales = []
    for item in distribucion:
        principales.append(item)
        if item["acumulado_pct"] >= _UMBRAL_ACUMULADO_PRINCIPALES_PCT:
            break
    acumulado_principales = principales[-1]["acumulado_pct"] if principales else 0.0

    ids_principales = {item["clave"] for item in principales}
    resto = [item for item in distribucion if item["clave"] not in ids_principales]
    secundarias = [item["clave"] for item in resto
                   if item["porcentaje_pct"] >= _UMBRAL_PARTICIPACION_REDUCIDA_PCT]
    reducidas = [item["clave"] for item in resto
                 if item["porcentaje_pct"] < _UMBRAL_PARTICIPACION_REDUCIDA_PCT]

    principal = distribucion[0] if distribucion else None
    dominante = distribucion[0] if (distribucion and distribucion[0]["porcentaje_pct"]
                                    >= _UMBRAL_DOMINANCIA_PCT) else None

    concentracion = []
    for n in range(1, min(len(distribucion), 5) + 1):
        primeras = distribucion[:n]
        concentracion.append({
            "n_especies": n,
            "especies": [item["clave"] for item in primeras],
            "porcentaje_acumulado_pct": _redondear(
                sum(item["porcentaje_pct"] for item in primeras)),
        })

    return {
        "especie_principal": principal,
        "especie_dominante": dominante,
        "especies_principales": [item["clave"] for item in principales],
        "acumulado_principales_pct": _redondear(acumulado_principales),
        "especies_secundarias": secundarias,
        "especies_de_participacion_reducida": reducidas,
        "concentracion": concentracion,
        "distribucion": distribucion,
        "total_existencias_m3": resumen["total"],
    }


def intensidad_existencias(por_especie):
    """Hallazgos de intensidad de corta por especie.

    La intensidad de corta es el porcentaje de las existencias de la especie
    propuesto para extraccion. Se reporta la intensidad de cada especie, la
    mayor y la menor entre las especies con corta, y la lista de especies sin
    aprovechamiento (intensidad cero).
    """
    datos = []
    for fila in por_especie:
        especie = fila.get("especie")
        existencias = float(fila.get("existencias") or 0)
        posibilidad = float(fila.get("posibilidad") or 0)
        if not existencias:
            continue
        datos.append({
            "especie": especie,
            "existencias_m3": _redondear(existencias),
            "con_corta": posibilidad > 0,
            "intensidad_pct": _redondear(min(100.0, 100.0 * posibilidad / existencias)),
        })
    datos.sort(key=lambda item: item["intensidad_pct"], reverse=True)
    con_corta = [item for item in datos if item["con_corta"]]
    return {
        "mayor": con_corta[0] if con_corta else None,
        "menor": con_corta[-1] if con_corta else None,
        "especies_con_aprovechamiento": con_corta,
        "especies_sin_aprovechamiento": [item["especie"] for item in datos
                                         if not item["con_corta"]],
        "intensidades": datos,
    }


def residual_existencias(por_especie):
    """Hallazgos de la condicion residual por especie.

    Porcentaje de las existencias de cada especie que permanece despues del
    aprovechamiento (retencion) y porcentaje extraido. Se reportan las especies
    con mayor y menor retencion.
    """
    datos = []
    for fila in por_especie:
        especie = fila.get("especie")
        existencias = float(fila.get("existencias") or 0)
        residuales = float(fila.get("residuales") or 0)
        if not existencias:
            continue
        retencion = min(100.0, 100.0 * residuales / existencias)
        datos.append({
            "especie": especie,
            "retencion_pct": _redondear(retencion),
            "extraccion_pct": _redondear(100.0 - retencion),
        })
    datos.sort(key=lambda item: item["retencion_pct"], reverse=True)
    return {
        "mayor_retencion": datos[0] if datos else None,
        "menor_retencion": datos[-1] if datos else None,
        "residuales": datos,
    }


def comparacion_umm(filas):
    """Hallazgos de comparacion entre UMM (rodales) a partir del cuadro.

    Agrega las filas por UMM (existencias totales y por hectarea, area basal,
    posibilidad, intensidad de corta y especies presentes) y ordena las UMM
    por existencias por hectarea, por area basal y por intensidad. Identifica
    contrastes entre UMM: las que combinan alta existencia con aprovechamiento
    intensivo y las que combinan baja existencia con aprovechamiento reducido.
    """
    rodales = {}
    for fila in filas:
        if fila.get("_type"):
            continue
        rid = fila.get("rodal")
        if rid is None:
            continue
        ag = rodales.setdefault(str(rid), {
            "umm": str(rid),
            "superficie_ha": float(fila.get("superficie") or 0),
            "existencias_m3": 0.0, "existencias_m3_ha": 0.0,
            "area_basal_m2_ha": 0.0, "posibilidad_m3": 0.0,
            "especies": set(),
        })
        ag["existencias_m3"] += float(fila.get("vol_umm") or 0)
        ag["existencias_m3_ha"] += float(fila.get("vol_ha") or 0)
        ag["area_basal_m2_ha"] += float(fila.get("ab") or 0)
        ag["posibilidad_m3"] += float(fila.get("pos_umm") or 0)
        if fila.get("especie"):
            ag["especies"].add(fila.get("especie"))

    lista = []
    for ag in rodales.values():
        lista.append({
            "umm": ag["umm"],
            "superficie_ha": _redondear(ag["superficie_ha"]),
            "existencias_m3": _redondear(ag["existencias_m3"]),
            "existencias_m3_ha": _redondear(ag["existencias_m3_ha"]),
            "area_basal_m2_ha": _redondear(ag["area_basal_m2_ha"]),
            "posibilidad_m3": _redondear(ag["posibilidad_m3"]),
            "intensidad_pct": _redondear(
                100.0 * ag["posibilidad_m3"] / ag["existencias_m3"]
                if ag["existencias_m3"] else 0.0),
            "especies": sorted(ag["especies"]),
        })
    lista.sort(key=lambda item: item["existencias_m3_ha"], reverse=True)

    por_ab = sorted(lista, key=lambda item: item["area_basal_m2_ha"], reverse=True)
    por_int = sorted((item for item in lista if item["existencias_m3"] > 0),
                     key=lambda item: item["intensidad_pct"], reverse=True)

    contrastes = []
    if len(lista) >= 3:
        tercil = max(1, len(lista) // 3)
        altas_ex = {item["umm"] for item in lista[:tercil]}
        bajas_ex = {item["umm"] for item in lista[-tercil:]}
        altas_int = {item["umm"] for item in por_int[:tercil]}
        bajas_int = {item["umm"] for item in por_int[-tercil:]}
        for umm in sorted(altas_ex & altas_int):
            contrastes.append({"umm": umm,
                               "tipo": "alta existencia y aprovechamiento intensivo"})
        for umm in sorted(bajas_ex & bajas_int):
            contrastes.append({"umm": umm,
                               "tipo": "baja existencia y aprovechamiento reducido"})

    return {
        "ordenadas_por_existencia_ha": lista,
        "mayor_existencia_ha": lista[0] if lista else None,
        "menor_existencia_ha": lista[-1] if lista else None,
        "mayor_existencia_total": max(lista, key=lambda item: item["existencias_m3"])
        if lista else None,
        "mayor_area_basal": por_ab[0] if por_ab else None,
        "menor_area_basal": por_ab[-1] if por_ab else None,
        "mayor_intensidad": por_int[0] if por_int else None,
        "menor_intensidad": por_int[-1] if por_int else None,
        "contrastes": contrastes,
    }


def hallazgos_existencias(data, resumen):
    """Hallazgos deterministas del cuadro de existencias.

    Seccion caracterizacion: superficie total, existencias totales y promedio
    por hectarea, area basal promedio, posibilidad total y promedio por
    hectarea, residual total y area basal residual promedio, e intensidad
    global con su porcentaje residual (unicamente si hay existencias).
    Combina las secciones de composicion, intensidad por especie y residual
    por especie, ademas de la comparacion entre UMM.
    """
    umm = comparacion_umm(data.get("filas", []))
    por_especie = resumen.get("filas", [])
    caracterizacion = {
        "superficie_total_ha": {
            "valor": _redondear(sum(item["superficie_ha"]
                                    for item in umm["ordenadas_por_existencia_ha"])),
            "unidad": "ha"},
        "existencias_totales_m3": {
            "valor": _redondear(data.get("total_vol_umm") or 0), "unidad": "m3 VTA"},
        "existencias_promedio_m3_ha": {
            "valor": _redondear(data.get("total_vol_ha") or 0), "unidad": "m3 VTA/ha"},
        "area_basal_promedio_m2_ha": {
            "valor": _redondear(data.get("total_ab") or 0), "unidad": "m2/ha"},
        "posibilidad_total_m3": {
            "valor": _redondear(data.get("total_pos_umm") or 0), "unidad": "m3 VTA"},
        "posibilidad_promedio_m3_ha": {
            "valor": _redondear(data.get("total_pos_ha") or 0), "unidad": "m3 VTA/ha"},
        "residual_total_m3": {
            "valor": _redondear(data.get("total_res_vol") or 0), "unidad": "m3 VTA"},
        "area_basal_residual_promedio_m2_ha": {
            "valor": _redondear(data.get("total_res_ab") or 0), "unidad": "m2/ha"},
    }
    total_vol = float(data.get("total_vol_umm") or 0)
    total_pos = float(data.get("total_pos_umm") or 0)
    if total_vol:
        intensidad_global = _redondear(100.0 * total_pos / total_vol)
        caracterizacion["intensidad_global_pct"] = {
            "valor": intensidad_global, "unidad": "%"}
        caracterizacion["porcentaje_residual_global_pct"] = {
            "valor": _redondear(100.0 - intensidad_global), "unidad": "%"}

    return {
        "caracterizacion": caracterizacion,
        "composicion": composicion_existencias(por_especie),
        "intensidad_por_especie": intensidad_existencias(por_especie),
        "residual_por_especie": residual_existencias(por_especie),
        "comparacion_umm": umm,
    }


def tratamientos_agrupados(tratamientos, umm_del_cuadro):
    """Agrupa los tratamientos silvicolas registrados en el plan de cortas.

    Devuelve tres rutinas de hecho: los tratamientos agrupados por UMM que
    existen en el cuadro de existencias, la lista de UMM con tratamiento
    registrado, y la lista de UMM sin tratamiento registrado. Las UMM sin
    tratamiento deben interpretarse como una observacion agrupada, no repetida
    por UMM.
    """
    por_umm = {}
    for rid, lista in (tratamientos or {}).items():
        valores = {str(tratamiento).strip() for tratamiento in lista or []
                   if str(tratamiento).strip()}
        if valores:
            por_umm[str(rid)] = sorted(valores)
    umm_tratadas = sorted(set(por_umm) & set(umm_del_cuadro))
    por_umm = {umm: por_umm[umm] for umm in umm_tratadas}
    umm_sin = sorted(set(umm_del_cuadro) - set(por_umm))
    agrupados = sorted({tratamiento
                        for lista in por_umm.values() for tratamiento in lista})
    return {
        "por_umm": por_umm,
        "tratamientos_presentes": agrupados,
        "umm_con_tratamiento": umm_tratadas,
        "umm_sin_tratamiento": umm_sin,
    }