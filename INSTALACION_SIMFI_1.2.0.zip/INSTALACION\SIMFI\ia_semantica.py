"""Contexto semántico por módulo para la interpretación con IA.

Empaqueta variables ya calculadas y validadas por SIMFI junto con su nombre
técnico, valor, unidad, significado y tipo de resultado. No calcula ni modifica
resultados: SIMFI CALCULA, LA IA INTERPRETA. Cada módulo construye su propio
contexto y no mezcla la información de otros módulos.
"""

from ia_analisis import hallazgos_existencias, tratamientos_agrupados


def _sem(especificacion, fila):
    """Convierte una fila plana en variables semánticas (valor, unidad, significado, tipo)."""
    resultado = {}
    for clave_tecnica, (campo, unidad, significado, tipo) in especificacion.items():
        valor = fila.get(campo)
        if valor is None or valor == "":
            continue
        try:
            valor = float(valor)
        except (TypeError, ValueError):
            continue
        resultado[clave_tecnica] = {
            "valor": valor, "unidad": unidad,
            "significado": significado, "tipo": tipo,
        }
    return resultado


def _porcentaje_residual(intensidad):
    return {
        "valor": 100 - intensidad["valor"],
        "unidad": "%",
        "significado": "Porcentaje de las existencias que permanece después de la corta",
        "tipo": "porcentaje",
    }


def _intensidad_y_residual(variables):
    """Añade intensidad y porcentaje residual derivados cuando hay datos suficientes."""
    resultado = dict(variables)
    existencias = resultado.get("existencias_m3_vta") or resultado.get("existencias_m3_vta_umm")
    posibilidad = resultado.get("posibilidad_m3_vta") or resultado.get("posibilidad_m3_vta_umm")
    intensidad = resultado.get("intensidad_corta_pct")
    if intensidad is None and existencias and posibilidad and existencias["valor"]:
        intensidad = {
            "valor": posibilidad["valor"] * 100 / existencias["valor"],
            "unidad": "%",
            "significado": "Porcentaje de las existencias propuesto para extracción",
            "tipo": "porcentaje",
        }
        resultado["intensidad_corta_pct"] = intensidad
    if intensidad is not None:
        resultado["porcentaje_residual_pct"] = _porcentaje_residual(intensidad)
    return resultado


_EXISTENCIAS_FILA = {
    "superficie_ha": ("superficie", "ha", "Superficie de la UMM", "superficie"),
    "existencias_m3_vta_ha": ("vol_ha", "m3 VTA/ha", "Existencias reales por hectárea", "promedio_por_hectarea"),
    "existencias_m3_vta_umm": ("vol_umm", "m3 VTA", "Existencias reales totales de la UMM", "total"),
    "area_basal_m2_ha": ("ab", "m2/ha", "Área basal por hectárea", "promedio_por_hectarea"),
    "intensidad_corta_pct": ("intensidad", "%", "Porcentaje de las existencias propuesto para extracción", "porcentaje"),
    "posibilidad_m3_vta_umm": ("pos_umm", "m3 VTA", "Volumen propuesto para aprovechamiento", "total"),
    "posibilidad_m3_vta_ha": ("pos_ha", "m3 VTA/ha", "Volumen propuesto para aprovechamiento por hectárea", "promedio_por_hectarea"),
    "residual_m3_vta_umm": ("res_vol", "m3 VTA", "Volumen que permanece después del aprovechamiento", "total"),
    "area_basal_residual_m2_ha": ("res_ab", "m2/ha", "Área basal residual por hectárea", "promedio_por_hectarea"),
}

_EXISTENCIAS_ESPECIE = {
    "existencias_m3_vta": ("existencias", "m3 VTA", "Existencias reales totales por especie", "total"),
    "posibilidad_m3_vta": ("posibilidad", "m3 VTA", "Volumen propuesto para aprovechamiento por especie", "total"),
    "residual_m3_vta": ("residuales", "m3 VTA", "Volumen que permanece después del aprovechamiento por especie", "total"),
}

_INCREMENTOS_FILA = {
    "superficie_ha": ("superficie", "ha", "Superficie de la UMM", "superficie"),
    "arboles_ha": ("arb_ha", "árboles/ha", "Número de árboles por hectárea", "valor_por_hectarea"),
    "area_basal_m2_ha": ("ab", "m2/ha", "Área basal por hectárea", "promedio_por_hectarea"),
    "tiempo_paso_anios": ("tp", "años", "Tiempo de paso entre clases diamétricas", "calculo_especifico"),
    "incremento_corriente_m3_ha_anio": ("ica", "m3/ha/año", "Incremento corriente anual en volumen por hectárea", "calculo_especifico"),
    "incremento_corriente_porcentaje": ("ica_pct", "%", "Incremento corriente anual porcentual", "porcentaje"),
    "incremento_medio_m3_ha_anio": ("ima", "m3/ha/año", "Incremento medio anual en volumen por hectárea", "calculo_especifico"),
    "edad_anios": ("edad", "años", "Edad estimada de la masa forestal", "calculo_especifico"),
}

_CARBONO_FILA = {
    "superficie_ha": ("superficie", "ha", "Superficie de la UMM", "superficie"),
    "volumen_m3_vta_ha": ("vol_ha", "m3 VTA/ha", "Volumen real por hectárea", "promedio_por_hectarea"),
    "factor_carbono": ("cf", "adimensional", "Fracción de carbono aplicada en el cálculo", "calculo_especifico"),
    "materia_seca_ha_t": ("ms_ha", "t/ha", "Materia seca por hectárea", "promedio_por_hectarea"),
    "materia_seca_total_t": ("ms_total", "t", "Materia seca total", "total"),
    "carbono_ha_t": ("carbono_ha", "t/ha", "Carbono por hectárea", "promedio_por_hectarea"),
    "carbono_total_t": ("carbono_total", "t", "Carbono total", "total"),
    "co2e_ha_t": ("co2_ha", "t CO2e/ha", "CO2 equivalente por hectárea", "promedio_por_hectarea"),
    "co2e_total_t": ("co2_total", "t CO2e", "CO2 equivalente total", "total"),
}

_CAPTURA_FILA = {
    "volumen_m3_vta_ha": ("vol_ha", "m3 VTA/ha", "Volumen real por hectárea", "promedio_por_hectarea"),
    "incremento_anual_m3_ha_anio": ("ica", "m3/ha/año", "Incremento corriente anual en volumen por hectárea", "calculo_especifico"),
    "factor_carbono": ("cf", "adimensional", "Fracción de carbono aplicada en el cálculo", "calculo_especifico"),
    "captura_carbono_t_ha_anio": ("captura_c", "t C/ha/año", "Captura anual de carbono por hectárea", "promedio_por_hectarea"),
    "captura_co2e_t_ha_anio": ("captura_co2", "t CO2e/ha/año", "Captura anual de CO2 equivalente por hectárea", "promedio_por_hectarea"),
}

_OXIGENO_FILA = {
    "incremento_anual_m3_ha_anio": ("ica", "m3/ha/año", "Incremento corriente anual en volumen por hectárea", "calculo_especifico"),
    "factor_carbono": ("cf", "adimensional", "Fracción de carbono aplicada en el cálculo", "calculo_especifico"),
    "captura_carbono_t_ha_anio": ("captura_c", "t C/ha/año", "Captura anual de carbono por hectárea", "promedio_por_hectarea"),
    "produccion_oxigeno_t_ha_anio": ("oxigeno", "t O2/ha/año", "Producción anual de oxígeno por hectárea", "promedio_por_hectarea"),
}


def _filas_con_variables(especificacion, filas):
    detalle = []
    for fila in filas:
        if fila.get("_type"):
            continue
        detalle.append({"rodal": fila.get("rodal"), "especie": fila.get("especie"),
                        "variables": _sem(especificacion, fila)})
    return detalle


def _superficie_total(data):
    rodales = {}
    for fila in data.get("filas", []):
        if fila.get("_type"):
            continue
        rodales[fila.get("rodal")] = float(fila.get("superficie") or 0)
    return sum(rodales.values())


def contexto_existencias(data, resumen, alertas=None, tratamientos=None):
    """Contexto semántico del cuadro de existencias (módulo de existencias exclusivamente).

    Incluye la capa de análisis determinista calculada por SIMFI (hallazgos:
    caracterización, composición por especie, intensidad, condición residual y
    comparación entre UMM) y el agrupamiento de tratamientos silvícolas del
    plan de cortas. El orden de claves es: totales, hallazgos, filas,
    por_especie, alertas y tratamientos.
    """
    filas = []
    for fila in data.get("filas", []):
        if fila.get("_type"):
            continue
        filas.append({"rodal": fila.get("rodal"), "especie": fila.get("especie"),
                      "variables": _intensidad_y_residual(_sem(_EXISTENCIAS_FILA, fila))})
    por_especie = []
    for fila in resumen.get("filas", []):
        por_especie.append({"especie": fila.get("especie"),
                            "variables": _intensidad_y_residual(_sem(_EXISTENCIAS_ESPECIE, fila))})
    superficie = _superficie_total(data)
    total_vol = float(data.get("total_vol_umm") or 0)
    total_pos = float(data.get("total_pos_umm") or 0)
    intensidad_global = total_pos * 100 / total_vol if total_vol else None
    totales = {
        "superficie_ha": {"valor": superficie, "unidad": "ha",
                          "significado": "Superficie total del área evaluada", "tipo": "superficie"},
        "existencias_m3_vta": {"valor": total_vol, "unidad": "m3 VTA",
                               "significado": "Existencias reales totales del área evaluada", "tipo": "total"},
        "existencias_m3_vta_ha": {"valor": float(data.get("total_vol_ha") or 0), "unidad": "m3 VTA/ha",
                                  "significado": "Existencias reales promedio por hectárea (promedio simple sin ponderación)", "tipo": "promedio_por_hectarea"},
        "area_basal_m2_ha": {"valor": float(data.get("total_ab") or 0), "unidad": "m2/ha",
                             "significado": "Área basal promedio por hectárea (promedio simple sin ponderación)", "tipo": "promedio_por_hectarea"},
        "posibilidad_m3_vta": {"valor": total_pos, "unidad": "m3 VTA",
                               "significado": "Volumen total propuesto para aprovechamiento", "tipo": "total"},
        "residual_m3_vta": {"valor": float(data.get("total_res_vol") or 0), "unidad": "m3 VTA",
                            "significado": "Volumen total que permanece después del aprovechamiento", "tipo": "total"},
        "area_basal_residual_m2_ha": {"valor": float(data.get("total_res_ab") or 0), "unidad": "m2/ha",
                                      "significado": "Área basal residual promedio por hectárea (promedio simple sin ponderación)", "tipo": "promedio_por_hectarea"},
    }
    if intensidad_global is not None:
        totales["intensidad_corta_pct"] = {
            "valor": intensidad_global, "unidad": "%",
            "significado": "Porcentaje de las existencias propuesto para extracción", "tipo": "porcentaje"}
        totales["porcentaje_residual_pct"] = {
            "valor": 100 - intensidad_global, "unidad": "%",
            "significado": "Porcentaje de las existencias que permanece después de la corta", "tipo": "porcentaje"}
    hallazgos = hallazgos_existencias(data, resumen)
    umm_del_cuadro = [str(fila["rodal"]) for fila in data.get("filas", [])
                      if not fila.get("_type") and fila.get("rodal") is not None]
    tratamientos = tratamientos_agrupados(tratamientos, umm_del_cuadro)
    return {"modulo": "existencias", "totales": totales, "hallazgos": hallazgos,
            "filas": filas, "por_especie": por_especie,
            "alertas": list(alertas or []),
            "tratamientos": tratamientos}


def contexto_incrementos(data, alertas=None):
    """Contexto semántico del resumen de incrementos (crecimiento e incremento exclusivamente)."""
    filas = _filas_con_variables(_INCREMENTOS_FILA, data.get("filas", []))
    totales = {
        "superficie_ha": {"valor": float(data.get("total_superficie") or 0), "unidad": "ha",
                          "significado": "Superficie total del área evaluada", "tipo": "superficie"},
        "arboles_ha": {"valor": float(data.get("total_arb_ha") or 0), "unidad": "árboles/ha",
                       "significado": "Promedio simple de árboles por hectárea (sin ponderación)", "tipo": "promedio_por_hectarea"},
        "area_basal_m2_ha": {"valor": float(data.get("total_ab") or 0), "unidad": "m2/ha",
                             "significado": "Área basal promedio por hectárea (promedio simple sin ponderación)", "tipo": "promedio_por_hectarea"},
        "tiempo_paso_anios": {"valor": float(data.get("total_tp") or 0), "unidad": "años",
                              "significado": "Tiempo de paso promedio (promedio simple)", "tipo": "calculo_especifico"},
        "incremento_corriente_m3_ha_anio": {"valor": float(data.get("total_ica") or 0), "unidad": "m3/ha/año",
                                            "significado": "Incremento corriente anual promedio por hectárea (promedio simple sin ponderación)", "tipo": "promedio_por_hectarea"},
        "incremento_corriente_porcentaje": {"valor": float(data.get("total_ica_pct") or 0), "unidad": "%",
                                            "significado": "Incremento corriente anual porcentual (promedio simple)", "tipo": "porcentaje"},
        "incremento_medio_m3_ha_anio": {"valor": float(data.get("total_ima") or 0), "unidad": "m3/ha/año",
                                        "significado": "Incremento medio anual promedio por hectárea (promedio simple sin ponderación)", "tipo": "promedio_por_hectarea"},
        "edad_anios": {"valor": float(data.get("total_edad") or 0), "unidad": "años",
                       "significado": "Edad promedio estimada (promedio simple)", "tipo": "calculo_especifico"},
    }
    return {"modulo": "incrementos", "totales": totales, "filas": filas,
            "alertas": list(alertas or [])}


def contexto_carbono_contenido(data, alertas=None):
    """Contexto semántico de la pestaña Contenido de CO2 (variables exclusivas del módulo)."""
    filas = _filas_con_variables(_CARBONO_FILA, data.get("filas", []))
    totales = {
        "volumen_m3_vta": {"valor": float(data.get("total_vol") or 0), "unidad": "m3 VTA",
                           "significado": "Volumen real total", "tipo": "total"},
        "volumen_m3_vta_ha": {"valor": float(data.get("prom_vol_ha") or 0), "unidad": "m3 VTA/ha",
                              "significado": "Volumen promedio por hectárea (promedio simple)", "tipo": "promedio_por_hectarea"},
        "materia_seca_total_t": {"valor": float(data.get("total_ms") or 0), "unidad": "t",
                                 "significado": "Materia seca total", "tipo": "total"},
        "materia_seca_ha_t": {"valor": float(data.get("prom_ms_ha") or 0), "unidad": "t/ha",
                              "significado": "Materia seca promedio por hectárea (promedio simple)", "tipo": "promedio_por_hectarea"},
        "carbono_total_t": {"valor": float(data.get("total_carbono") or 0), "unidad": "t",
                            "significado": "Carbono total", "tipo": "total"},
        "carbono_ha_t": {"valor": float(data.get("prom_carbono_ha") or 0), "unidad": "t/ha",
                         "significado": "Carbono promedio por hectárea (promedio simple)", "tipo": "promedio_por_hectarea"},
        "co2e_total_t": {"valor": float(data.get("total_co2") or 0), "unidad": "t CO2e",
                         "significado": "CO2 equivalente total", "tipo": "total"},
        "co2e_ha_t": {"valor": float(data.get("prom_co2_ha") or 0), "unidad": "t CO2e/ha",
                      "significado": "CO2 equivalente promedio por hectárea (promedio simple)", "tipo": "promedio_por_hectarea"},
    }
    return {"modulo": "carbono", "pestana": "contenido", "totales": totales,
            "filas": filas, "alertas": list(alertas or [])}


def contexto_carbono_captura(data, alertas=None):
    """Contexto semántico de la pestaña Captura de CO2."""
    filas = _filas_con_variables(_CAPTURA_FILA, data.get("filas", []))
    totales = {
        "captura_carbono_t_anio": {"valor": float(data.get("total_captura_c") or 0), "unidad": "t C/año",
                                   "significado": "Captura anual total de carbono", "tipo": "total"},
        "captura_co2e_t_anio": {"valor": float(data.get("total_captura_co2") or 0), "unidad": "t CO2e/año",
                                "significado": "Captura anual total de CO2 equivalente", "tipo": "total"},
        "captura_carbono_t_ha_anio": {"valor": float(data.get("prom_captura_c") or 0), "unidad": "t C/ha/año",
                                      "significado": "Captura anual promedio por hectárea (promedio simple)", "tipo": "promedio_por_hectarea"},
        "captura_co2e_t_ha_anio": {"valor": float(data.get("prom_captura_co2") or 0), "unidad": "t CO2e/ha/año",
                                   "significado": "Captura anual promedio de CO2 equivalente por hectárea (promedio simple)", "tipo": "promedio_por_hectarea"},
        "volumen_m3_vta": {"valor": float(data.get("total_vol") or 0), "unidad": "m3 VTA",
                           "significado": "Volumen real total del área con captura", "tipo": "total"},
        "volumen_m3_vta_ha": {"valor": float(data.get("prom_vol_ha") or 0), "unidad": "m3 VTA/ha",
                              "significado": "Volumen promedio por hectárea (promedio simple)", "tipo": "promedio_por_hectarea"},
    }
    return {"modulo": "carbono", "pestana": "captura", "totales": totales,
            "filas": filas, "alertas": list(alertas or [])}


def contexto_carbono_oxigeno(data, alertas=None):
    """Contexto semántico de la pestaña Producción de Oxígeno."""
    filas = _filas_con_variables(_OXIGENO_FILA, data.get("filas", []))
    totales = {
        "captura_carbono_t_anio": {"valor": float(data.get("total_captura_c") or 0), "unidad": "t C/año",
                                   "significado": "Captura anual total de carbono", "tipo": "total"},
        "produccion_oxigeno_t_anio": {"valor": float(data.get("total_oxigeno") or 0), "unidad": "t O2/año",
                                      "significado": "Producción anual total de oxígeno", "tipo": "total"},
        "captura_carbono_t_ha_anio": {"valor": float(data.get("prom_captura_c") or 0), "unidad": "t C/ha/año",
                                      "significado": "Captura anual promedio por hectárea (promedio simple)", "tipo": "promedio_por_hectarea"},
        "produccion_oxigeno_t_ha_anio": {"valor": float(data.get("prom_oxigeno") or 0), "unidad": "t O2/ha/año",
                                         "significado": "Producción anual promedio de oxígeno por hectárea (promedio simple)", "tipo": "promedio_por_hectarea"},
    }
    return {"modulo": "carbono", "pestana": "oxigeno", "totales": totales,
            "filas": filas, "alertas": list(alertas or [])}