@echo off
setlocal
cd /d "%~dp0"
title SIMFI - Buscar actualizaciones en linea
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0consultar_actualizaciones.ps1"
if errorlevel 1 (
  echo.
  echo Ocurrio un problema al consultar. La instalacion no cambio.
)
pause
exit /b 0